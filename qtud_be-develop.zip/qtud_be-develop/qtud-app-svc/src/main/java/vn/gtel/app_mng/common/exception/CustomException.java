package vn.gtel.app_mng.common.exception;

import lombok.Getter;
import lombok.Setter;
import vn.gtel.app_mng.system.log.DTO.ServiceLogDTO;

@Getter
@Setter

public class CustomException extends Exception{

    private boolean flag;
    private ServiceLogDTO serviceLogDTO;

//    private String serviceCode;
//    private String serviceName;
//    private String url;
//    private String method;
//    private String description;
//    private String result;
//    private String input;
//    private String output;


// Doi voi cac exception khong luu log API chi luu log file
    public CustomException(String message){
        super(message);
        this.flag = true;
    }

// Doi voi cac exception luu ca log API va log file
    public CustomException(String serviceCode, String serviceName, String url, String method,
                           String description, String result, String input, String output, String message){
        super(message);
        this.serviceLogDTO = new ServiceLogDTO(url, method,description, result, input, output) ;

//        this.serviceCode = serviceCode;
//        this.serviceName = serviceName;
//        this.url = url;
//        this.method = method;
//        this.description = description;
//        this.result = result;
//        this.input = input;
//        this.output = output;
    }
}
