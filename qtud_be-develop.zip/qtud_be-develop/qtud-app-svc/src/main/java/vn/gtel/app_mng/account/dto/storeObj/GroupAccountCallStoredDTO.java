package vn.gtel.app_mng.account.dto.storeObj;

import java.util.HashMap;
import java.util.Map;

import vn.gtel.app_mng.account.reponse.GroupAccountByAccountIdReponse;
import vn.gtel.app_mng.account.reponse.GroupAccountReponse;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;

public class GroupAccountCallStoredDTO extends ICallStoredObj {

	private static final String PACKAGE_NAME = "PKG_GROUP_ACCOUNT";
	private static final String PROC_SEARCH_NAME = "PROC_SEARCH_GROUP_ACCOUNT";

	private static final String IN_KEY_SEARCH = "pi_key_search";
	private static final String IN_PAGE = "pi_page";
	private static final String IN_SIZE = "pi_size";

	private static final String PROC_SEARCH_FIND = "PROC_GROUP_ACCOUNT_BY_ID_ACCOUNT";
	private static final String IN_PI_ID = "PI_ID";
	private static final String PROC_SEARCH_NAME_FIND = "PROC_FIND_GROUP_ACCOUNT_ID";
	private static final String PROC_FIND_ACCOUNT_GROUP_ACCOUNT_FIND_ACCOUNT_ID = "PROC_FIND_ACCOUNT_GROUP_ACCOUNT_FIND_ACCOUNT_ID";
	Map<String, Object> params = new HashMap<>();

	private void setBase() {
		setPackageName(PACKAGE_NAME);
		setResponseType(GroupAccountReponse.class);
	};

	public GroupAccountCallStoredDTO(TextFilter textFilter) {
		setBase();
		setStoredName(PROC_SEARCH_NAME);
		params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
		params.put(IN_PAGE, textFilter.getPage());
		params.put(IN_SIZE, textFilter.getSize());
		setParams(params);
	}

	public GroupAccountCallStoredDTO(String id, String type) {
		setBase();
		if(type.equals("ACCOUNT_ID")) {
			setStoredName(PROC_FIND_ACCOUNT_GROUP_ACCOUNT_FIND_ACCOUNT_ID);
		}else if(type.equals("DETAIL_ACCOUNT")) {
			setResponseType(GroupAccountByAccountIdReponse.class);
			setStoredName(PROC_SEARCH_FIND);
		}
		params.put(IN_PI_ID, id);
		setParams(params);
	}

	public GroupAccountCallStoredDTO(String id) {
		setBase();
		setStoredName(PROC_SEARCH_NAME_FIND);
		params.put(IN_PI_ID, id);
		setParams(params);
	}
}
