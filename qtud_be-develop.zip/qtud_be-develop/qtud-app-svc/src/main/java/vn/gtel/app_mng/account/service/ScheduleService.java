package vn.gtel.app_mng.account.service;

public interface ScheduleService {
    void everyDay();

    void every15Minute();

    void TwelveHoursEveryDay();

    void every10minus();
}
