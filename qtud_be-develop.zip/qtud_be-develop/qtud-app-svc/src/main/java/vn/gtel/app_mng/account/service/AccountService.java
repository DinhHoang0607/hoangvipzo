/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountService.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 3:24 PM
 *
 */

package vn.gtel.app_mng.account.service;

import javassist.NotFoundException;
import net.sf.jasperreports.engine.JRException;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.dto.*;
import vn.gtel.app_mng.account.dto.request.AdminGeneratorReq;
import vn.gtel.app_mng.account.dto.request.ForgetPWRequestDTO;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferByGroupReq;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferReq;
import vn.gtel.app_mng.account.filter.*;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.validation.Valid;
import javax.xml.bind.ValidationException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;

public interface AccountService {

    // General
    ResponseBase save(AccountRequestDTO accountDetailDTO) throws IllegalAccessException, ValidationException;

    ResponseBase setActiveDeActive(ReasonUpdateAccountDTO reasonUpdateAccountDTO) throws Exception;

    String enPassWordAES(String pass) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, ValidationException;

    ResponseBase listAccount(AccountFilter textFilter) throws IllegalAccessException;

    ResponseBase listAccountTHDB(TextFilter textFilter) throws IllegalAccessException;

    ResponseBase listAllAccount(AccountFilter textFilter) throws IllegalAccessException;

    ResponseBase listAllAccount(AccountExploitFilter textFilter) throws IllegalAccessException;

    ResponseBase listAccountLead(TextFilter textFilter, String status, String acc, String typeAcc, String org) throws IllegalAccessException, ValidationException;

    ResponseBase listOrg(TextFilter textFilter) throws IllegalAccessException, ValidationException;

    ResponseEntity exportAccount(AccountFilter filter, String type) throws FileNotFoundException, JRException, IllegalAccessException;

    ResponseBase getAccountInGroupRole(TextFilter roleMenuFilter) throws IllegalAccessException;

    ResponseBase getAccountWithoutGroupRole(TextFilter roleMenuFilter) throws IllegalAccessException;

    ResponseBase getMe() throws Exception;

    ResponseBase getMeForManage(String user) throws Exception;

    // Account Employee Detail
    ResponseBase detailAccount(String id) throws Exception;

    ResponseBase resetPw(String id) throws NotFoundException, ValidationException, Exception;

    ResponseBase changePw(ChangePWRequestDTO changePWRequestDTO) throws ValidationException, IllegalAccessException;

    ResponseEntity importEmp(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException;

    // Account Service
    ResponseBase detailAccountService(String id) throws Exception;

    ResponseBase changePw(ChangePWServiceRequestDTO changePWServiceRequestDTO) throws Exception;

    ResponseEntity exportAccountService(TextFilter filter, String type) throws FileNotFoundException, JRException;

    ResponseBase importExcel(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;

    // Account Exploit

    ResponseBase compareAcc(String fulLName, String policeNumber);

    ResponseBase listAccountByRequirePurpose(TextFilter filter, String requirePurposeCode, Long flag) throws IllegalAccessException;

    ResponseEntity importExcelReturnResult(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;

    ResponseBase listAccountDirect(String code, String parentCode) throws IllegalAccessException, ValidationException;

    ResponseBase listAccountDirectBottom(TextFilter textFilter, String position, String org) throws IllegalAccessException, ValidationException;

    ResponseBase changeOrg(AccountChangeOrgDTO accountChangeOrgDTO) throws IllegalAccessException, ValidationException, NotFoundException;

    ResponseBase listAccountQLTT(TextFilter textFilter) throws IllegalAccessException;

    ResponseBase listLead(TextFilter textFilter) throws IllegalAccessException;

    ResponseEntity createTemplate() throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException;

    ResponseBase transferOrganization(OrganizationTransferReq request) throws Exception;

    ResponseBase updateTransferProcess(String transferId, Integer action, String decisionSigner) throws NotFoundException, ValidationException;

    ResponseBase listTransferOrg(AccountTransferOrgFilter accountTransferOrgFilter) throws NotFoundException;

    ResponseEntity exportAcc(String acc) throws NotFoundException, ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, JRException;

    ResponseBase updatePassAdmin(String text) throws NotFoundException, ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, JRException;

    ResponseBase exportByProvinceCode() throws Exception;

    ResponseBase cloneGroup(CloneGroupRoleDTO cloneGroupRoleDTO) throws Exception;

    ResponseBase confirmInfo(AccConfirmInfoDTO accConfirmInfoDTO) throws ValidationException, NotFoundException;

    ResponseBase checkNumberPhoneOrPoliceNumber(AccNumberPhoneOrPoliceNumberDTO accNumberPhoneOrPoliceNumberDTO) throws ValidationException;

    boolean removeAccount(String account) throws ValidationException;

    ResponseBase listLeadOrEmByOrg(AccountLeadOrEmFilter accountLeadOrEmFilter) throws ValidationException, IllegalAccessException;

    ResponseBase getAccountInListOrg(List<String> orgs);

    ResponseEntity exportAccountV2(String acc, String passWord) throws NotFoundException, ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, JRException;

    ResponseBase groupTransferList(GroupTransferOrgFilter filter) throws IllegalAccessException;

    ResponseBase groupTransfer(OrganizationTransferByGroupReq request) throws IllegalAccessException, NotFoundException;

    ResponseBase accountWithPositionTypeInOrg(AccountWithPositionTypeInOrgFilter filter) throws IllegalAccessException;

    ResponseBase accountCheck(String id, String app) throws IllegalAccessException;

    ResponseBase updateDisplayPosition(DisplayPositionDTO request) throws Exception;

    ResponseBase accountHistory(String id, Integer page, Integer size) throws Exception;

    ResponseBase kafkaLog(KafkaLogFilter filter);

    ResponseBase forgetPw(ForgetPWRequestDTO forgetPWRequestDTO) throws IllegalAccessException, NotFoundException, ValidationException;

    void revokeToken(String account);

    void changeStatusPW();

    ResponseBase getTreeAccountTrafficPolice(String currentNode, int pageNumber, int sizeNumber) throws IllegalAccessException;

    void deleteAccountAfter30Days();

    ResponseBase sumAccountTransfer();
}
