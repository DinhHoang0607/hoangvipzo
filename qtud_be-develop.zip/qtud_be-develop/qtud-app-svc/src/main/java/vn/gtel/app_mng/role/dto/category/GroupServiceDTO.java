 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 17, 2021
 */
package vn.gtel.app_mng.role.dto.category;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class GroupServiceDTO {

	@Column(name = "id")
	private String serviceId;
	
	@Column(name = "ten")
	private String serviceName;

}
