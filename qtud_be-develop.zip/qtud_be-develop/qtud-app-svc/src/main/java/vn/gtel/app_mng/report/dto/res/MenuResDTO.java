package vn.gtel.app_mng.report.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldNameConstants

public class MenuResDTO extends CommonReportResponseDTO {
    @Column(name = "TEN_CHUC_NANG")
    private String menuName;
    @Column(name = "TIEU_DE")
    private String type;
}
