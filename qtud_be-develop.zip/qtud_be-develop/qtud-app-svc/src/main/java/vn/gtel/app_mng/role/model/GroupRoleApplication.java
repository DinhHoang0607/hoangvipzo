package vn.gtel.app_mng.role.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;
import vn.gtel.app_mng.common.model.AuditModelBase;

import java.time.Instant;

@Entity
@Table(name = "TBL_Q_NHOM_QUYEN_UNG_DUNG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleApplication extends AuditModelBase {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

	@Basic
	@Column(name = "UNG_DUNG")
	private String application;

	@Basic
	@Column(name = "NHOM_QUYEN")
	private String groupRole;

	public GroupRoleApplication(String groupRole, String application, Integer status) {
		super(status);
		this.application = application;
		this.groupRole = groupRole;
	}
}
