package vn.gtel.app_mng.common.dto.response;

import lombok.Data;

import javax.persistence.Column;

@Data
public class DDLItemResponse {

    @Column(name = "ID")
    private String id;

    @Column(name = "TEN")
    private String name;

    @Column(name = "GIA_TRI_NUMBER")
    private Long longValue;

    @Column(name = "GIA_TRI")
    private String value;

}
