package vn.gtel.app_mng.account.dto;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class InputAccountDTO {
    private String account;
    private Timestamp birthDate;
    private String position;
    private String dignity;
    private String military;
    private String politicalLevel;
    private String academicLevel;
    private String gender;
    private String phoneNumber;
}
