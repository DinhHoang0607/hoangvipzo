package vn.gtel.app_mng.feedback.dto;

import lombok.Data;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Data
public class FeedBackDetailResponse {

    private String id;

    private String content;

    private String title;

    private Long level;

    private String organization;

    private String orgCodeSend;

    private String orgNameSend;

    private String senderName;

    private String sender;

    private String createdDate;

    private String phoneNumber;

    private Long classify;

    private Long status;

    private String code;

    private List<FileFeedBackDTO> files = new ArrayList<>();

    private List<FeedBackHistoryResponse> feedBackHistoryResponses = new ArrayList<>();

    private List<FeedbackRelateToDTO> feedbackRelateToDTOS = new ArrayList<>();
}
