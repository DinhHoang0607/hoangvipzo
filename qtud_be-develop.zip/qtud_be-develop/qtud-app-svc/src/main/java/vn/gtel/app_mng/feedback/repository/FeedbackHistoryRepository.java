package vn.gtel.app_mng.feedback.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import vn.gtel.app_mng.feedback.model.FeedbackHistory;

import java.util.List;

public interface FeedbackHistoryRepository extends JpaRepository<FeedbackHistory, String> {
    List<FeedbackHistory> findByFeedbackId(String feedbackId);

    @Query("SELECT f FROM FeedbackHistory  f where f.id = :id and (f.status = :status1 or f.status = :status2) ")
    List<FeedbackHistory> findByFeedbackIdAndStatus(String id, Long status1, Long status2);

}
