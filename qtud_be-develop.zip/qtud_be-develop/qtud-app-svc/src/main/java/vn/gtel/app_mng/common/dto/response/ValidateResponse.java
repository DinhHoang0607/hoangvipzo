package vn.gtel.app_mng.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Value;
import org.springframework.validation.FieldError;
import vn.gtel.app_mng.common.config.constant.Messages;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ValidateResponse extends ResponseBase{
    @Value
    @AllArgsConstructor
    public static class Error{
        private String field;
        private Object value;
        private String message;
    }

    @Value
    @AllArgsConstructor
    public static class ApiError{
        List<Error> errors;
    }
    public ValidateResponse (String messageCode, List<FieldError> errors){
        super(messageCode, Messages.getString("response.message.error."+messageCode), new ApiError(errors.stream().map(e->{

            return new Error(e.getField(), e.getRejectedValue(), Messages.getString(e.getDefaultMessage()));
        }).collect(Collectors.toList())));
    }

}
