package vn.gtel.app_mng.category.dto.res.share;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShareServiceGroupResponseDTO {

    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Column(name = "MO_TA")
    private String description;
}
