package vn.gtel.app_mng.account.model;

import javax.persistence.*;

import lombok.*;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;
import vn.gtel.app_mng.common.model.AuditModelBase;

@Entity
@Table(name = "TBL_TK_NHOM_TAI_KHOAN")
@Setter
@Getter
@NoArgsConstructor
@FieldNameConstants
public class AccountGroup extends AuditModelBase {

	private static final Long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

	@Basic
	@Column(name = "MO_TA")
	private String description;

	@Basic
	@Column(name = "MA")
	private String code;

	@Basic
	@Column(name = "TEN")
	private String name;

}
