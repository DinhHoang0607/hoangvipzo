package vn.gtel.app_mng.common.dto.response;

import lombok.Data;

import javax.persistence.Column;
import java.util.List;

@Data
public class PermissionForLogListDTO {

    private List<PermissionForLogDTO> permissionForLogDTOS;


}
