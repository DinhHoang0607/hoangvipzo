package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.category.dto.res.MenuActionRes;
import vn.gtel.app_mng.category.model.Menu;

import java.util.List;


@Repository
public interface MenuCatRepo extends JpaRepository<Menu, String> {

    Menu findByCode(String menuCode);

    Boolean existsMenuByCode(String menuCode);

    Menu findByCodeAndName(String code, String name);

    Menu findByComponentAndAppCode(String component, String appCode);

    List<Menu> findByAppCodeAndTypeMenuAndStatus(String appCode, int type, int status);

    boolean existsByParentMenuCodeAndStatus(String code, int status);

    boolean existsByCodeAndStatus(String parentMenuCode, int status);

    boolean existsByParentMenuCodeAndStatusNot(String code, Integer deleted);

    @Query("SELECT new vn.gtel.app_mng.category.dto.res.MenuActionRes(menu, menuAction, action) FROM Menu menu " +
            " left join MenuAction menuAction on menu.code = menuAction.menu " +
            " left join Action action on menuAction.action = action.code where menu.id = ?1")
    List<MenuActionRes> getMenuActionById(String id);
}
