package vn.gtel.app_mng.category.dto.res;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import vn.gtel.app_mng.common.dto.response.AuditCategoryResponseDTO;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.time.Instant;

@Data
public class OrganizationLevelResponseDTO extends AuditCategoryResponseDTO {

    @Basic
    @Column(name = "THU_TU")
    private String order;
}
