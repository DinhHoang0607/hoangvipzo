package vn.gtel.app_mng.role.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.account.dto.GroupCodeItemWithActionDTO;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "TBL_Q_NHOM_QUYEN_NHOM_TK")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleAccountGroup extends AuditModelBase {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "NHOM_QUYEN")
    private String groupRole;

    @Basic
    @Column(name = "NHOM_TAI_KHOAN")
    private String groupAccount;

    @Formula("(select nq.TEN from TBL_Q_NHOM_QUYEN nq where nq.MA = NHOM_QUYEN)")
    private String groupRoleName;

    public GroupRoleAccountGroup(GroupCodeItemWithActionDTO groupCodeItemWithActionDTO) {
        this.id = groupCodeItemWithActionDTO.getId();
        this.groupRole = groupCodeItemWithActionDTO.getCode();
        this.groupAccount = groupCodeItemWithActionDTO.getGroupCode();
        this.setStatus(groupCodeItemWithActionDTO.getAction());
    }

    public GroupRoleAccountGroup(List<GroupRoleAccountGroup> groupRoleAccountGroups, GroupCodeItemWithActionDTO groupCodeItemWithActionDTO) {
        GroupRoleAccountGroup groupRoleAccountGroup = groupRoleAccountGroups.stream().filter(
                e -> e.getGroupRole().equals(groupCodeItemWithActionDTO.getCode())).findFirst().orElse(null);
        if (groupRoleAccountGroup == null) {
            groupRoleAccountGroup = new GroupRoleAccountGroup(groupCodeItemWithActionDTO);
        } else {
            groupRoleAccountGroup.setStatus(Constants.COMMON_STATUS.ACTIVE);
        }
        this.id = groupRoleAccountGroup.getId();
        this.groupRole = groupRoleAccountGroup.getGroupRole();
        this.groupAccount = groupRoleAccountGroup.getGroupAccount();
        this.setStatus(groupRoleAccountGroup.getStatus());
    }

    public GroupRoleAccountGroup(String groupRole, String groupAccount) {
        this.groupRole = groupRole;
        this.groupAccount = groupAccount;
    }

    public GroupRoleAccountGroup(GroupRoleAccountGroup e, Integer active) {
        this.id = e.getId();
        this.groupRole = e.getGroupRole();
        this.groupAccount = e.getGroupAccount();
        this.setStatus(active);
    }
}
