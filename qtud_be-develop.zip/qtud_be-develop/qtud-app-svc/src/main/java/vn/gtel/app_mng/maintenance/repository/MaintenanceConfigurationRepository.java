package vn.gtel.app_mng.maintenance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.maintenance.model.MaintenanceConfiguration;

import java.util.List;
import java.util.Optional;

@Repository
public interface MaintenanceConfigurationRepository extends JpaRepository<MaintenanceConfiguration, String>  {

    @Query(value = "select l from MaintenanceConfiguration l where (l.status = 0 or l.status = 1) and l.deleted = 0 order by l.startedDate")
    List<MaintenanceConfiguration> findNextMaintenanceSchedules();

    @Query(value = "select l from MaintenanceConfiguration l where l.status = 1 and l.deleted = 0")
    Optional<MaintenanceConfiguration> findCurrentMaintenanceSchedule();
}