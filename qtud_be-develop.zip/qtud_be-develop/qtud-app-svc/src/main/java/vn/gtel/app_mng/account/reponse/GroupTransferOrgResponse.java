package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Column;

@Data
public class GroupTransferOrgResponse {
    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "HO_TEN")
    private String name;

    @Column(name = "DON_VI")
    private String organization;

    @Column(name = "SO_HIEU_CAND")
    private String policeNumber;

    @Column(name = "PHAN_LOAI_CHUC_VU")
    private Integer positionType;

    @Column(name = "TEN_DON_VI")
    private String organizationName;

    @Column(name = "KY_HIEU")
    private String signOrganization;

    @Column(name = "HIEN_THI_DON_VI")
    private String displayOrganization;

    @Column(name = "HIEN_THI_PHAN_LOAI_CHUC_VU")
    private String displayPositionType;
}
