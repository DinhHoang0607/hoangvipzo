/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  GroupRoleDTO.java
 * Created By :  tuannp
 * Created at :  12/20/21, 3:55 PM
 * LastModified  :  12/20/21, 2:02 PM
 */

package vn.gtel.app_mng.role.dto;


import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;
import vn.gtel.app_mng.role.dto.menu_action.RoleMenuItemDTO;
import vn.gtel.app_mng.role.dto.service.RoleServiceItemDTO;

import java.io.Serializable;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME,include = JsonTypeInfo.As.PROPERTY,property = "type")
@JsonSubTypes({
		@JsonSubTypes.Type(value = RoleMenuItemDTO.class),
		@JsonSubTypes.Type(value = RoleServiceItemDTO.class)
})
@Data
public class RoleItemDTO implements Serializable {

//	private Long disabled;

}
