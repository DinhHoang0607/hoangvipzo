package vn.gtel.app_mng.common.config.constant;

import java.util.List;

public class Constants {

    public static final int MAX_ROW_SELECT = 999999999;
    public static final int MAX_ROW_EXPORT = 9999;
    public static final int MAX_ROW_DDL = 500;
    public static final int DEFAULT_PAGE = 0;
    public static final int DEFAULT_SIZE = 10;
    public static final int DEFAULT_INT_TYPE = 0;
    public static Integer STATUS_CATEGORY_ACTIVE = 1;
    public static Integer STATUS_CATEGORY_INACTIVE = 2;
    public static Integer STATUS_CHANGE_ORG = -3;
    public static String GROUP_ROLE_THDB_CODE_DEFAULT = "006%";

    public static final Integer DELETED = -1;

    public static final String ADMIN = "admin";
    public static final String SUB_ADMIN_PC08 = "admin100037";
    public static final String MA_DV_DOI_THUOC_HUYEN = "012";

    public static final String SYSTEM_USER = "SYSTEM"; // 1
    public static final String MENU_EXPIRED_PASSWORD = "EXPIRED PASSWORD"; // 1

    public static final class BOOLEAN {
        public static final int TRUE = 1;
        public static final int FALSE = 0;
    }

    public static final class CHANGE_ORG_TYPE {
        public static final int SAME_ORG = 1;
        public static final int DIFFERENT_ORG = 2;
    }

    public static final class COMMON_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;

        public static String getNameByStatus(Integer action) {
            if (action != null) {
                if (action == ACTIVE) {
                    return "Kích hoạt";
                } else if (action == INACTIVE) {
                    return "Vô hiệu hóa";
                } else if (action == DELETED) {
                    return "Xóa";
                }
            }
            return "";
        }
    }

    public static final class COMMON_ACTION {
        public static final int INSERT = 1;
        public static final int UPDATE = 2;
        public static final int ACTIVE = 3;
        public static final int DELETE = -1;
    }

    public static final class ACCOUNT_ACTION {
        public static final String INSERT = "INSERT"; // 1
        public static final String UPDATE = "UPDATE";
        public static final String ACTIVE = "ACTIVE";
        public static final String DELETE = "DELETE";
        public static final String RESETPASS = "RESET";
        public static final String INACTIVE = "INACTIVE";
    }

    public static final class LIST_TYPE {
        public static final String ACCOUNT = "ACCOUNT"; // 1
        public static final String GROUP_ROLE = "GROUP_ROLE";
        public static final String STATUS_IN = "IN";
        public static final String STATUS_OUT = "OUT";
    }

    public static final class CONFIG {
        public static final String TIME_OUT = "TIME_OUT";
    }

    public static final class CONFIRM_INFO {
        public static final Integer WAITING = 1;
        public static final Integer ACCEPT = 2;
        public static final Integer REFUSE = 3;
    }

    public static final class APP_NAME {
        public static final String DTHS = "Điều Tra Hình Sự";
        public static final String HSAN_NVCB = "HỒ Sơ An Ninh - Nghiệp Vụ Cơ Bản";
        public static final String HSCS_TT = "Hồ Sơ Cảnh Sát Trực Tuyến";
    }

    public static final class ACCOUNT_STATUS {
        public static final Integer SIMULATED = 0; //Trạng thái chờ tạo tài khoản bên ĐTHS
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer LOCKED = 3;
        public static final Integer DELETED = -1;
        public static final Integer WAITING_CREATE = -2;
        public static final Integer WAITING_CHANGE_ORG = 4;
    }

    public static final class TRANSFER_ORG_STATUS {
        //        public static final Integer DEFAULT = 1;
        public static final Integer IN_PROGRESS = 1;
        public static final Integer APPROVE = 2;
        public static final Integer REJECT = 3;
    }

    public static final class TRANSFER_ORG_TYPE {
        public static final Integer MERGE_ORG = 1;
        public static final Integer NORMAL_TRANSFER = 1;

        public static final class INCORRECT {
            public static final Integer GENERAL = 4;
            public static final Integer DISTRICT_TO_TEAM = 5;
            public static final Integer ROOM_TO_TEAM = 6;
            public static final List<Integer> ALL = List.of(GENERAL, DISTRICT_TO_TEAM, ROOM_TO_TEAM);
        }
    }

    public static final class ACCOUNT_RQ_CHANGE_PW {
        public static final Integer REQUIRED = 1;
        public static final Integer NOT_RQ = 2;
    }

    public static final class ACCOUNT_RQ_CONFIRM_INFORMATION {
        public static final Integer CONFIRM = 1;
        public static final Integer NOT_RQ = 2;
    }

    public static final class REASON_CONFIG_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
    }

    public static final class GROUP_ROLE_TYPE {
        public static final int MENU_ACTION = 1;
        public static final int SERVICE = 2;
        public static final String NOT_ROLE = "NOT_ROLE";
    }

    public static final class PasswordEncoder {
        public static final String BCRYPT = "{bcrypt}";
        public static final String NOOP = "{noop}";
    }

    public static final class SYS_PARAM_GROUP_NAME {
        public static final String APPLICATION_STATUS = "Trạng thái ứng dụng";
        public static final String SYS_PARAM_STATUS = "Trạng thái tham số hệ thống";
        public static final String FILE_STATUS = "Trạng thái tệp";
        public static final Integer DELETED = -1;
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final String TYPE = "NHOM_THAM_SO_HE_THONG";
    }

    public static final class APPLICATION_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
        public static final String GROUP_ACTION = "Trạng thái ứng dụng";
    }

    public static final class ACTION_GROUP_STATUS {
        public static final String NAME = "Trạng thái hành động";
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
    }

    public static final class MENU_GROUP_STATUS {
        public static final String NAME = "Trạng thái thực đơn";
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
    }

    public static final class M_QDV_STATUS {
        public static final String NAME = "Trạng thái bảng mẫu quyền dữ liệu";
        public static final Integer USE = 1;
        public static final Integer NOT_USE = -1;
    }

    public static final class FILE_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
    }

    public static final class GROUP_ROLE_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
        public static final Integer WITHDRAWN = 3;
        public static final String GROUP_ACTION = "Trạng thái nhóm quyền";
    }


    public static final class GROUP_ACCOUNT_STATUS {
        public static final String ACTIVE = "Hoạt động"; // 1
        public static final String INACTIVE = "Vô hiệu hóa";
        public static final String GROUP_ACTION = "Trạng thái nhóm quyền";
        public static final String DELETE = "Đã xóa";

    }

    public static final class APPLICATION_CODE {
        public static final String QTUD = "001";
        public static final String VN_TRAFFIC = "1125";
    }

    public static final class MENU_CODE {
        public static final class LOGIN {
            public static final String CODE = "LOGIN";
            public static final String NAME = "001";
        }

        public static final class ACCOUNT {
            public static final String base = APPLICATION_CODE.QTUD + "002";
            public static final String emp = ACCOUNT.base + "003";
            public static final String system = ACCOUNT.base + "004";
            public static final String exploit = ACCOUNT.base + "005";
            public static final String admin = ACCOUNT.base + "006";
            public static final String group = ACCOUNT.base + "010";
            public static final String transferProcess = ACCOUNT.base + "007";
        }

        public static final class ROLE {
            public static final String base = APPLICATION_CODE.QTUD + "002";
            public static final String menu = ROLE.base + "001";
            public static final String service = ROLE.base + "002";
            public static final String unitIntegrate = ROLE.base + "033";
        }

        public static final class SYSTEM {
            public static final String base = APPLICATION_CODE.QTUD + "004";

            public static final class CONFIG {
                public static final String base = SYSTEM.base + "006";
                public static final String propose = CONFIG.base + "002";
            }
        }

        public static final class CATEGORY {
            public static final String base = APPLICATION_CODE.QTUD + "003";
            public static final String app = CATEGORY.base + "001";
            public static final String menu = CATEGORY.base + "002";
            public static final String action = CATEGORY.base + "003";
            public static final String profileStatus = CATEGORY.base + "010";
        }
    }

    public static final class JwtClaimName {
        public static final String USERNAME = "username";
        public static final String USER_INFO = "user_info";
        public static final String USER_ROLE = "user_role";
    }

    public static final class TYPE_ROLE {
        public static final Long APPLICATION = 1L;// tài khoản hệ thống
        public static final Long SERVICE = 2L;// tài khoản dịch vụ
    }

    public static final class GROUP_SERVICE_STATUS {
        public static final Long ACTIVE = 1L; // 1
        public static final Long INACTIVE = 2L;
        public static final Long DELETED = -1L;
        public static final String GROUP_ACTION = "Trạng thái nhóm dịch vụ";
    }

    public static final class SERVICE_STATUS {
        public static final Long ACTIVE = 1L;
        public static final Long INACTIVE = 2L;
        public static final Long DELETED = -1L;
        public static final String GROUP_ACTION = "Trạng thái bảng dịch vụ";
    }

    public static final class SERVICE_TYPE {
        public static final String SYNC = "Dịch vụ đồng bộ"; // 1
        public static final String INT = "Dịch vụ tích hợp";
        public static final String GROUP_ACTION = "Loại dịch vụ";
    }

    public static final class POSITION {
        public static final String EMPLOYEE_TYPE = "008"; // 1
    }

    public static final class COUNTRY_STATUS {
        public static final Long ACTIVE = 1L;
        public static final Long INACTIVE = 2L;
        public static final Long DELETED = -1L;
        public static final String GROUP_ACTION = "Trạng thái bảng quốc gia";
    }

//	public static final class CATEGORY_STATUS {
//		public static final Long ACTIVE = "Kích hoạt"; // 1
//		public static final Long INACTIVE = "Vô hiệu hóa";
//		public static final Long GROUP_ACTION = "Trạng thái danh mục dùng chung";
//	}

    public static final class CATEGORY_GROUP_STATUS {
        public static final String ACTIVE = "Hoạt động"; // 1
        public static final String INACTIVE = "Vô hiệu hóa";
        public static final String GROUP_ACTION = "Trạng thái bảng nhóm danh mục dùng chung";
        public static final Integer STATUS_ACTIVE = 1;
        public static final Integer STATUS_INACTIVE = 2;
    }

    public static final class AREA_ADMINISTRATIVE_STATUS {
        public static final String ACTIVE = "Hoạt động"; // 1
        public static final String INACTIVE = "Vô hiệu hóa";
        public static final String GROUP_ACTION = "Trạng thái danh mục địa giới hành chính";
    }

    public static final class ORGANIZATION_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
        public static final String GROUP_ACTION = "Trạng thái bảng đơn vị";
    }

    public static final String COMMON_CALL_PREFIX = "SELECT concat((select GIA_TRI from TBL_THAM_SO_HE_THONG where ten = 'PREFIX')";

    public static final class MODULES {
        public static final String GROUP_ROLE = "GroupRole";
        public static final String ROLE = "Role";
        public static final String GROUP_ACCOUNT = "GroupAccount";
        public static final String ACCOUNT = "Account";
        public static final String ACTION = "Action";
        public static final String APPLICATION = "Application";
        public static final String GROUP_ACTION = "Trạng thái bảng quốc gia";
    }

    public static final class ACTION {
        public static final String SAVE = "SAVE";
        public static final String INSERT = "INSERT";
        public static final String UPDATE = "UPDATE";
        public static final String DELETE = "DELETE";
        public static final String URL = "/api/v1/action";
    }

    public static final class USB_TOKEN_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer DELETED = -1;
        public static final String GROUP_USB_TOKEN = "Trạng thái USB Token";
    }

    public static final class FIELD_STATUS {
        public static final Long CHECK_ROLE = 1L;
        public static final Long UN_CHECK_ROLE = 2L;
        public static final Long DELETED = -1L;
        public static final String GROUP_FIELD = "Trạng thái cột dữ liệu";
    }

    public static final class MAIL_BOX_STATUS {
        public static final Long DRAFT = 1L;
        public static final Long SENT = 2L;
        public static final Long DELETED = -1L;
        public static final String GROUP_MAIL = "Trạng thái hòm thư";
    }

    public static final class MAIL_ACCOUNT_STATUS {
        public static final Long DRAFT = 1L;
        public static final Long SENT = 2L;
        public static final Long READ = 3L;
        public static final Long DELETED = -1L;
        public static final String GROUP_MAIL_ACCOUNT = "Trạng thái hòm thư tài khoản";
    }

    public static final class MAIL_ACCOUNT_TYPE {
        public static final String SENDER = "SENDER";
        public static final String RECEIVER = "RECEIVER";
        public static final String CARBON_COPY = "CC";
        public static final String UN_READ_VAL = "UN_READ";
        public static final String GROUP_MAIL_ACCOUNT = "Loại hòm thư tài khoản";
    }

    public static final class ACCOUNT_TYPE {
        public static final Integer EMPLOYEE = 1;
        public static final Integer SERVICE = 2;
        public static final Integer EXPLOIT = 3;
    }

    public static final class ACCOUNT_EMP_TYPE {
        public static final Integer ADMIN = 1;
        public static final Integer USER = 2;
    }

    public static final class LEVEL_ACC_MANAGE {
        public static final String TOP = "CAP_TREN";
        public static final String BUTTOM = "CAP_DUOI";

    }

    public static final class ACCOUNT_SERVICE_TYPE {
        public static final Long INTEGRATION = 1L;
        public static final Long SYNCHRONIZE = 2L;
        public static final String INTEGRATION_STR = "Tích hợp";
        public static final String SYNCHRONIZE_STR = "Đồng bộ";
    }

    public static class SHARE_CATEGORY_TYPE {
        public static final String APPLICATION = "APPLICATION";
        public static final String MENU = "MENU";
        public static final String ACTION = "ACTION";
        public static final String GROUP_CATEGORY = "GROUP_CATEGORY";
        public static final String CATEGORY = "CATEGORY";
    }

    public static String SUCCESS_CODE = "200";

    public static class ERROR_CODE {
        public static final String VALIDATION = "100006";
        public static final String EXCEPTION = "1001000";
        public static final String MISSING_CACHE = "1001000";
    }

    public static final String MAIL_MESSAGE_NOTIFY = "NEW_INBOX";

    public static final class LOGIN_LOG_STATUS {
        public static final Long SUCCESS = 1L;
        public static final Long FAIL = 2L;
        public static final Long DISCONNECT = 3L;
        public static final Long DELETED = -1L;
        public static final String GROUP_MAIL_ACCOUNT = "Trạng thái đăng nhập";
    }

    public static final class ORGANIZATION_GROUP_TYPE {
        public static final String POLICE_ORGANIZATION = "414";
        public static final String CATEGORY_CODE = "CAP_DON_VI";
    }

    public static final class ORGANIZATION_LEVEL {
        public static final String QH = "008";
        public static final String PNV = "007";
        public static final String Đ_QH = "011";
        public static final String Đ_PNV = "009";
    }

    public static final class TIME_FORMAT {
        public static final String DAY = "YYYYMMDD";
        public static final String YEAR = "YYYY";
    }

    public static final String DATE_FM_PATTERN = "yyyyMMdd";

    public enum AggType {
        day, week, month, quarter, year;
    }

    public static final class CONFIG_STATUS {
        public static final Integer ACTIVE = 1;
        public static final Integer INACTIVE = 2;
        public static final Integer USE = 3;
        public static final Integer DELETED = -1;
        public static final String GROUP_NAME = "Trạng thái cấu hình";
    }

    public enum BackupDataConfigType {
        CATEGORY, INTERNAL_TOP_SECRET, LOCAL_CENTER_TOP_SECRET;
    }

    public enum KEY_CHECK {
        ADMIN, ADMIN_V06
    }

    public static final class NOTIFICATION_STATUS {
        public static final Integer SAVED = 1;
        public static final Integer UNREAD = 2;
        public static final Integer READ = 3;
        public static final Integer PROCESSED = 4;
        public static final Integer DELETED = -1;
        public static final String GROUP_NAME = "Trạng thái thông báo";
    }

    public static final class SYNC_FILE_STATUS {
        public static final Long NOT_DOWNLOAD_YET = 1L;
        public static final Long DOWNLOADED = 2L;
        public static final String GROUP_NAME = "Trạng thái tải tệp";
    }

    public static final class SYNC_FILE {
        public static final int CATEGORY_FILE = 1;
        public static final int DATA_FILE = 2;
    }

    public static final class ORGANIZATION_ID {
        public static final String VO6 = "2";
    }

    public static final class REDIS_KEY {
        public static final String ROLE = "ROLE_";
        public static final String ROLE_APP = "ROLE_APP_";
        public static final String SEC_APP_CF = "SEC_APP_CF_";
        public static final String APP_BY_CODE = "APP_BY_CODE_";
        public static final String DEFAULT_PW = "DEFAULT_PW";
        public static final String HSM_PRE = "HSM_";
        public static final String SIGN_IMG_PRE_ = "SIGN_IMG_";

        public static final String GET_ME = "GET_ME_";

    }

    public static final class TBL_NAME {
        public static final String APPLICATION = "TBL_DM_UNG_DUNG";
        public static final String ACCOUNT = "TBL_TK_TAI_KHOAN";
        public static final String ACCOUNT_DETAIL = "TBL_TK_NGUOI_DUNG";
        public static final String ACCOUNT_SERVICE = "TBL_TK_HE_THONG";
        public static final String MENU = "TBL_DM_CHUC_NANG";
        public static final String FEED_BACK = "TBL_PHAN_ANH";
        public static final String HOLIDAY = "TBL_NGAY_LE";
    }

    public static final class HOLIDAY {
        public static final Integer DELETED = -1;
    }

    public static final class ACTION_TYPE {
        public static final Integer FEATURE = 1;
        public static final Integer SCREEN = 2;
        public static final Integer COMPONENT = 3;

    }

    public enum EXPORT_TYPE {
        XLSX, PDF, DOCX, docx
    }

    public static final class VALID {
        public static final int MIN_PAGE = 0;
        public static final int MIN_PHONE_NUMBER = 10;
        public static final int MIN_POLICE_NUMBER = 7;
        public static final int MAX_PAGE = 99999999;
        public static final int MIN_SIZE = 0;
        public static final int MAX_SIZE = 99999999;
        public static final int MAX_LENGTH_KEY_SEARCH = 250;
        public static final int MAX_LENGTH_ACCOUNT_50 = 50;
        public static final int MIN_LENGTH_ACCOUNT_3 = 3;
        public static final int MAX_LENGTH_NAME_100 = 100;
        public static final int MIN_LENGTH_NAME_5 = 5;
        public static final int MAX_LENGTH_NAME_200 = 200;
        public static final int MAX_LENGTH_NAME_250 = 250;
        public static final int MAX_LENGTH_1000 = 1000;
        public static final int MAX_LENGTH_ID = 36;
        public static final int MAX_LENGTH_CODE = 32;
        public static final int MAX_LENGTH_ACCOUNT = 100;
        public static final int MAX_LENGTH_SEARCH_STATUS = 2;
        public static final int MAX_LENGTH_18 = 18;
        public static final int MAX_VAL_ORDER = 100000;
        public static final int MAX_VAL_STATUS = 20;
        public static final int MIN_VAL_0 = 0;
        public static final int MAX_LENGTH_FEEDBACK = 3;
        public static final int MAX_LENGTH_TITLE = 250;
        public static final int MAX_LENGTH_CONTENT = 4000;
        public static final int MAX_LENGTH_CITY_50 = 50;
    }

    public static final class Regex {
        // Cho phep space
        //public  static final String NOT_SPECIAL_CHARACTERS ="^(?:\\p{L}\\p{M}*|[\\( 0-9)*])*$";
//		public  static final String NOT_SPECIAL_CHARACTERS ="^(?:\\p{L}\\p{M}*|)*$";
        public static final String NUMBER_CHARACTER = "[a-zA-Z0-9]*";
        public static final String NOT_SPECIAL_CHARACTERS = "^[^`~!@#$%^*|{}<>]*$";
        //		public static final String NOT_SPECIAL_CHARACTERS = "^([^\\%'|~!@#$^*{}<>~]|\\[^%|'~!@#$^*{}<>~])*$";
        public static final String NUMBER = "[0-9]+";
        public static final String CODE = NUMBER_CHARACTER;
        public static final String CATEGORY_CODE = NUMBER;
        public static final String NAME = NOT_SPECIAL_CHARACTERS;
        public static final String KEY_SEARCH = NOT_SPECIAL_CHARACTERS;
        //		public static final String KEY_SEARCH_2 = NOT_SPECIAL_CHARACTERS;
        public static final String FULL_NAME = "^(?:\\p{L}\\p{M}*|[\\( )*])*$";
        public static final String DATE = "^(0?[1-9]|[12][0-9]|[3][01])[/](0?[1-9]|1[012])[/](19[0-9]{2}|20[0-9]{2})$";
        //public static final String DATE = "^(0?[1-9]|[12][0-9]|[3][01])[/](0?[1-9]|1[012])[/]$";
    }

    public static final class CHECKED_VAL {
        public static final Long CHECKED = 1L;
        public static final Long UNCHECKED = 0L;
    }

    public static final class EXCEPTION {
        public static final String Validation = "ValidationException";
        public static final Long UNCHECKED = 0L;
    }

    public static final class Flag {
        public static final Long REQUIRE_PURPOSE = 1L;
        public static final Long NOT_REQUIRE_PURPOSE = 2L;
    }

    public static class DataLog {
        public static final String METHOD_POST = "POST";
        public static final String METHOD_GET = "GET";
        public static final String METHOD_PUT = "PUT";
        public static final String METHOD_DELETE = "DELETE";
        public static final String SUCCESS_RESULT = "Thành công";
        public static final String FAIL_RESULT = "Thất bại";
    }

    public static class MenuAction {
        public static final String URL = "/api/v1/menu";
    }

    public static final class FEED_BACK {
        public static final Integer NOT_SEEN = 1;
        public static final Integer WATCHED = 2;
        public static final Integer PROCESSING = 3;
        public static final Integer PROCESSED = 4;
        public static final Integer CLOSED = 5;
        public static final Integer DELETED = -1;
        public static final Integer SEND_REQUIRE_PURPOSE = 0;
        public static final Integer NOT_SEND_REQUIRE_PURPOSE = 1;
        public static final Integer SAVE_FEEDBACK = 0;
        public static final Integer REMOVE_FEEDBACK = 1;
        public static final String V06_COUNTRYCODE = "V06";
        public static final String V06_CODE = "100055";
        public static final String V01_CODE = "100050";
        public static final String PV06_CODE = "500101055";
        public static final String CAT_CODE = "500";
        public static final String PROVICE_LEVEL = "002";
        public static final String CENTER_LEVEL = "001";
        public static final Integer JOB_TYPE = 1;
        public static final Integer SYSTEM_TYPE = 2;
        public static final String C08_CODE = "100037";
    }

    public static final class FEED_BACK_HISTORY {
        public static final String RELY_FEED_BACK = "Đã phản hồi";
        public static final String SEND_FEED_BACK = "Gửi phản ánh";
        public static final String REMOVE_FEED_BACK = "Chuyển xử lý phản ánh";
        public static final String CLOSE_FEED_BACK = "Đóng phản ánh";
        public static final String FINISH_FEED_BACK = "Xử lí thành công";
        public static final String REPROCESS_FEED_BACK = "Gửi xử lý lại";
        public static final String RECEIVED_FEED_BACK = "Đã tiếp nhân";
        public static final Integer REPROCESS = 6;
    }

    public static final class ACC_EMPLOYEE_TYPE {
        public static final int ADMIN = 1;
        public static final int EMPLOYEE = 2;
    }


    public static final class DiGITAL_CERTIFICATE_TYPE {
        public static final int INDIVIDUAL = 1;
        public static final int ORGANIZATION = 2;

    }

    public static final class ORGANIZATION_CODE {
        public static final String V06 = "100055";
        public static final String Pv06 = "500101055";
        public static final String V01 = "100050";
        public static final String strV01 = "V01";
        public static final String BCA = "100";
        public static final String CAT = "500";

    }

    public static final class POSITION_CODE {
        public static final String PRE_LEADER = "60";
    }

    public static final class TYPE_EMPLOYEE {
        public static final String ADMIN = "1";
        public static final String USER = "2";
    }


    public static final class ACTION_TYPE_CODE_FOR_DTHS {
        public static final int ERROR_INSERT = -1;
        public static final int ERROR_UPDATE = -2;
        public static final int ERROR_REJECT = -3;
        public static final int ERROR_ACCEPT = -4;
        public static final int SUCESS = 1;
        public static final int INSERT_TYPE = 2;
        public static final int UPDATE_TYPE = 3;
        public static final int REJECT_TYPE = 4;
        public static final int ACCEPT_TYPE = 5;
        public static final int SYNCHRONIZED = 1;
        public static final int NOT_SYNCHRONIZED = 2;
    }

    public static final class CHARACTER_SET {
        public static final String LOWER_CASE = "abcdefghijklmnopqrstuvwxyz";
        public static final String UPPER_CASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public static final String NUMBER = "0123456789";
        public static final String SPECIAL = "@#$%*";
        public static final List<String> ALL = List.of(LOWER_CASE, UPPER_CASE, NUMBER, SPECIAL);
    }

    public static final class GENERAL_CONFIG_STATUS {
        public static final Integer STATUS_ACTIVE = 1;
        public static final Integer STATUS_INACTIVE = 2;
        public static final Integer STATUS_DELETE = -1;
    }

    public static final class GENERAL_CONFIG_ATTRIBUTES {
        public static final String TEXT = "TEXT";
        public static final String VALUE = "VALUE";
        public static final String DEFAULT = "DEFAULT_VALUE";
        public static final String DESCRIPTION = "DESCRIPTION";
        public static final String DATATYPES = "DATATYPES";
        public static final String UNIT = "UNIT";
        public static final String STATUS = "STATUS";
        public static final String ORDER = "ORDER";
        public static final List<String> ALL = List.of(TEXT, VALUE, DEFAULT, DESCRIPTION, DATATYPES, UNIT, STATUS, ORDER);
    }

    public static final class GENERAL_CONFIG_DATATYPES {
        public static final String NUMBER = "NUMBER";
        public static final String BOOLEAN = "BOOLEAN";
        public static final List<String> ALL = List.of(NUMBER, BOOLEAN);
    }

    public static final class GENERAL_CONFIG_UNITS {
        public static final String KY_TU = "ký tự";
        public static final String SECOND = "giây";
        public static final String MINUTE = "phút";
        public static final String HOUR = "giờ";
        public static final String DAY = "ngày";
        public static final String WEEK = "tuần";
        public static final String MONTH = "tháng";
        public static final String YEAR = "năm";
        public static final List<String> TIME = List.of(SECOND, MINUTE, HOUR, DAY, WEEK, MONTH, YEAR);
    }

    public static final class GENERAL_CONFIG {
        public static final List<String> SECURITY = List.of("SECURITY");
        public static final List<String> PASSWORD = List.of("SECURITY", "PASSWORD");
        public static final List<String> LOGIN = List.of("SECURITY", "LOGIN");
    }

    public static final class CACHE {
        public static final class CATEGORY {
            public static final String ALL_DGHC = "ALL_DGHC";
            public static final String ALL_ORG = "ALL_ORG";
            public static final String ALL_CRIME = "ALL_CRIME";
            public static final String ALL_LAW = "ALL_LAW";
            public static final String ALL_COUNTRY = "ALL_COUNTRY";
            public static final List<String> ALL = List.of(ALL_DGHC, ALL_ORG, ALL_CRIME, ALL_LAW, ALL_COUNTRY);
        }

        public static final class APP {
            public static final String PASSWORD_CONFIG = "PASSWORD_CONFIG";
            public static final String LOGIN_CONFIG = "LOGIN_CONFIG";
            public static final List<String> GENERAL_CONFIG = List.of(PASSWORD_CONFIG, LOGIN_CONFIG);
            public static final String ALL_USER_EMPLOYEE = "ALL_USER_EMPLOYEE";
            public static final String ALL_USER_EMPLOYEE_V1 = "ALL_USER_EMPLOYEE_V1";
        }
    }

    public static final class USERNAME {
        public static final String ADMIN = "admin";
        public static final String PRE_ADMIN = "g01";
    }

    public static class MAINTENANCE_STATUS {
        public static final Long PREPARED = 0L;
        public static final Long IN_PROGRESS = 1L;
        public static final Long FINISHED = 2L;
    }

    public static class DELETED_MAINTENANCE {
        public static final Long DELETED = 1L;
        public static final Long NOT_DELETED = 0L;
    }

    public static class SERVER_STATUS {
        public static final Long UNDER_MAINTENANCE_CODE = 1L;
        public static final String UNDER_MAINTENANCE = "UNDER_MAINTENANCE";
        public static final Long NORMAL_CODE = 0L;
        public static final String NORMAL = "NORMAL";
    }

    public static final class NOTIFICATION_TYPE {
        public static final int NOTICE = 1;
        public static final int WARN = 2;
    }

    public static final class URL_CONFIG {
        public static final String GET_TEMP_NOTI = "/api/v1/notification/get-by-code/FORGET_PW";
        public static final String GET_ORG_CSGT = "/api/v1/organization/organization-traffic-police";
    }

    public static final class SSE_TYPE {
        public static final String MAIL = "mail";
        public static final String NOTIFICATION = "notification";
        public static final String LOG_OUT = "log_out";
        public static final String NTF_MAINTAIN = "ntf_maintain";
    }

    public static final class ORG_CODE {
        public static final String C08 = "100037";
    }

    public static final class APPLICATION_TYPE {
        public static final Integer IN = 1;
        public static final Integer OUT = 2; // Phần mềm ngoài hệ thống (3)
    }

    public static final class APPLICATION_TYPE_NAME {
        public static final String IN = "Phần mềm trong hệ thống";
        public static final String OUT = "Phần mềm ngoài hệ thống";
    }

    public static final class ORG_TYPE {
        public static final Integer IN_ONE = 1;
        public static final Integer IN_TWO = 2;
        public static final Integer OUT = 3;//Trong nghành giao thông
    }

    public static final class ORG_TYPE_NAME {
        public static final String IN = "Đơn vị trong nghành CSGT";
        public static final String OUT = "Đơn vị ngoài nghành CSGT";
    }
}
