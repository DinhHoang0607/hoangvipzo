/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/18/22, 8:32 AM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountGroupRoleCloneDTO {
    @NotEmpty
    private String account;
    @NotEmpty
    @Pattern(regexp = "^(ADD|REMOVE)$", message = "Phân loại in (ADD|REMOVE)")
    private String action;
    private List<String> cloneRoleAccounts;
}
