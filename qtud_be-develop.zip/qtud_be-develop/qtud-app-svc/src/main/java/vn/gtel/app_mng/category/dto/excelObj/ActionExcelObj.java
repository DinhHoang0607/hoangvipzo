package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class ActionExcelObj extends IExcelMapperObj {
    public ActionExcelObj(int stt) {
        setFieldToIndexMap(new HashMap<>());
        getFieldToIndexMap().put("pooledCode", stt + 1);
        getFieldToIndexMap().put("name", stt + 2);
        getFieldToIndexMap().put("code", stt + 3);
        getFieldToIndexMap().put("description", stt + 4);
        getFieldToIndexMap().put("order", stt + 5);
        getFieldToIndexMap().put("resultColumn", stt + 6);

        setFieldExport(List.of("pooledCode", "name", "code"));
    }
}
