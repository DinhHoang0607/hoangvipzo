/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  Category.java
 * Created By :  tuannp
 * Created at :  12/20/21, 4:12 PM
 * LastModified  :  12/20/21, 4:12 PM
 */

package vn.gtel.app_mng.category.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;
import java.util.Objects;

@Data
@Entity
@Table(name = "TBL_DM_DANH_MUC")
public class Category extends AuditModel {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "MA_DANH_MUC")
    private String codeCategory;

    @Basic
    @Column(name = "ID_NHOM_DANH_MUC")
    private String categoryGroupId;

    @Basic
    @Column(name = "TEN_NHOM_DANH_MUC")
    private String groupName;

    @Basic
    @Column(name = "ID_DANH_MUC")
    private String categoryId;

    @Basic
    @Column(name = "TEN_DANH_MUC")
    private String categoryName;

    @Basic
    @Column(name = "MA_DANG_KY")
    private String codeRegis;

    @Basic
    @Column(name = "MA_LUU_TRU")
    private String codeResidence;

    @Basic
    @Column(name = "AP_DUNG_VOI")
    private String forWith;

    @Basic
    @Column(name = "PHAN_HE")
    private String subSystem;

    @Basic
    @Column(name = "TINH_TRANG")
    private String statusBusiness;

    @Basic
    @Column(name = "LA_DANH_MUC")
    private String isCategory;

    @Basic
    @Column(name = "MA_DM_AN_NINH")
    private String codeSecurity;

    @Basic
    @Column(name = "MA_DM_CANH_SAT")
    private String codePolice;

    @Basic
    @Column(name = "MA_DANH_MUC_CHUAN")
    private String codeStandard;

    @Basic
    @Column(name = "THU_TU")
    private Long order;

}
