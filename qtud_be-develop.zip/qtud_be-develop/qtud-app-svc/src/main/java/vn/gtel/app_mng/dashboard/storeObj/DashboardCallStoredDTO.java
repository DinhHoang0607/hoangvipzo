/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ActionLogCallStoredDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/4/21, 11:07 AM
 */

package vn.gtel.app_mng.dashboard.storeObj;

import vn.gtel.app_mng.dashboard.dto.req.GridFilter;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.dashboard.dto.res.AccessCount;
import vn.gtel.app_mng.dashboard.dto.res.AccountDashboardResponse;
import vn.gtel.app_mng.dashboard.dto.res.CountItemResponseDTO;
import vn.gtel.app_mng.dashboard.dto.res.CountResponseDTO;

import java.util.HashMap;
import java.util.Map;

public class DashboardCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_DASHBOARD";
    public static final String PROC_COUNT_ONLINE = "PROC_COUNT_ONLINE";
    public static final String PROC_SUM_LOGIN = "PROC_SUM_LOGIN";
    public static final String PROC_COUNT_BY_APP = "PROC_COUNT_BY_APP";
    public static final String PROC_COUNT_BY_ORG = "PROC_COUNT_BY_ORG";
    public static final String PROC_COUNT_ONLINE_BY_CITY = "PROC_COUNT_ONLINE_BY_CITY";
    public static final String PROC_ALERT_ACCESS = "PROC_ALERT_ACCESS";
    public static final String PROC_LOGIN_ACCOUNT = "PROC_LOGIN_ACCOUNT";
    public static final String PROC_COUNT_ACCOUNT = "PROC_COUNT_ACCOUNT";
    public static final String PROC_COUNT_ACCOUNT_BY_ORG = "PROC_COUNT_ACCOUNT_BY_ORG";
    public static final String PROC_COUNT_CLIENT_LOGIN = "PROC_COUNT_CLIENT_LOGIN";
    public static final String PROC_RANK_10_USE_CATEGORY = "PROC_RANK_10_USE_CATEGORY";

    private static final String IN_FORMAT_TIME = "PI_THOI_GIAN";
    private static final String IN_FROM_TIME = "PI_FROM_TIME";
    private static final String IN_TO_TIME = "PI_TO_TIME";
    private static final String IN_AGG_TYPE = "AGG_TYPE";
    private static final String IN_ORG_CODE = "PI_DON_VI";
    private static final String IN_TYPE = "PI_TYPE";


    private static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_SIZE = "PI_SIZE";
    Map<String, Object> params = new HashMap<>();

    public DashboardCallStoredDTO(GridFilter gridFilter, Class clazz) {
        setBase();
        setResponseType(clazz);
        setStoredName(PROC_COUNT_ONLINE_BY_CITY);
        params.put(IN_FROM_TIME, gridFilter.getFromDateTime());
        params.put(IN_TO_TIME, gridFilter.getToDateTime());
        params.put(IN_AGG_TYPE, gridFilter.getAggType());
        setParams(params);
    }

    private void setBase() {
        params.put(getPiCurrentAccountId(), AccountLogonContext.currentUser().getId());
        params.put(getPiCurrentOrg(), AccountLogonContext.currentUser().getOrganization());
        setPackageName(PACKAGE_NAME);
        setResponseType(CountItemResponseDTO.class);
    }

    ;

    private void setBaseCountAccount() {
        params.put(getPiCurrentAccountId(), AccountLogonContext.currentUser().getId());
        params.put(getPiCurrentOrg(), AccountLogonContext.currentUser().getOrganization());
        setPackageName(PACKAGE_NAME);
        setResponseType(CountResponseDTO.class);
    }

    ;

    public DashboardCallStoredDTO(String type, Class clazz) {
        setBase();
        // type = storeName
        setStoredName(type);
        setResponseType(clazz);
        setParams(params);
    }

    public DashboardCallStoredDTO(String type) {
        setBase();
        setResponseType(AccessCount.class);
        // type = storeName
        setStoredName(type);
        setParams(params);
    }

    public DashboardCallStoredDTO(FilterChart filterChart) {
        setBase();
        setStoredName(filterChart.getChartType());
        params.put(IN_FROM_TIME, filterChart.getFromDateTime());
        params.put(IN_TO_TIME, filterChart.getToDateTime());
        params.put(IN_AGG_TYPE, filterChart.getAggType());
        params.put(IN_ORG_CODE, filterChart.getOrgCode());
        setParams(params);
    }

    public DashboardCallStoredDTO() {
        setBaseCountAccount();
        setResponseType(AccountDashboardResponse.class);
        setStoredName(PROC_COUNT_ACCOUNT);
        setParams(params);
    }

    public DashboardCallStoredDTO(Class clazz, String orgCode) {
        setBaseCountAccount();
        setResponseType(AccountDashboardResponse.class);
        setStoredName(PROC_COUNT_ACCOUNT_BY_ORG);
        if (clazz.getSimpleName().equals("AccountDashboardResponse")) {
            params.put(IN_ORG_CODE, orgCode);
        }
        setParams(params);
    }
}
