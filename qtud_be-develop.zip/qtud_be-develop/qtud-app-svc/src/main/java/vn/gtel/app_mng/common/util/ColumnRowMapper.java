package vn.gtel.app_mng.common.util;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import javax.persistence.Column;
import java.lang.reflect.Field;

@Slf4j
public class ColumnRowMapper<T> extends BeanPropertyRowMapper<T> {

    private ColumnRowMapper(final Class<T> mappedClass) {
        super(mappedClass);
    }

    @SneakyThrows
    protected String underscoreName(final String name) {
        final Column annotation;
        String columnName = null;
        Field declaredField = null;

        try {
            declaredField = getMappedClass().getDeclaredField(name);
        } catch (NoSuchFieldException | SecurityException e) {
            if (getMappedClass().getSuperclass() != null) {
                declaredField = parentFields(getMappedClass(), name);
//                declaredField = getMappedClass().getSuperclass().getDeclaredField(name);
            } else {
                log.error(String.format(" --- ERROR Map Column : %s", e.getMessage()));
            }
        }
        if (declaredField == null || (annotation = declaredField.getAnnotation(Column.class)) == null || StringUtils.isEmpty(columnName = annotation.name())) {
            super.underscoreName(name);
        }
        return StringUtils.lowerCase(columnName);
    }

    private Field parentFields(Class clazz, String name) {
        try {
            return clazz.getSuperclass().getDeclaredField(name);
        } catch (NoSuchFieldException | SecurityException e) {
            return parentFields(clazz.getSuperclass(), name);
        }
    }

    public static <T> BeanPropertyRowMapper<T> newInstance(final Class<T> mappedClass) {
        return new ColumnRowMapper<>(mappedClass);
    }
}
