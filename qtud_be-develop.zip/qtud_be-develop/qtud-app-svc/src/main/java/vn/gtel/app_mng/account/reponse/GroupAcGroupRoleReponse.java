package vn.gtel.app_mng.account.reponse;

import javax.persistence.Column;

import lombok.Data;

@Data
public class GroupAcGroupRoleReponse {
	@Column(name = "ID")
	private String id;

	@Column(name = "ID_NHOM_QUYEN")
	private String groupRoleId;

	@Column(name = "TEN_NHOM_QUYEN")
	private String groupRoleName;
}
