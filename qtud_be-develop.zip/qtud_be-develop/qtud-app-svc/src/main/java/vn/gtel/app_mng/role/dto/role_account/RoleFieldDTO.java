package vn.gtel.app_mng.role.dto.role_account;

import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonTypeName("roleField")
@AllArgsConstructor
@NoArgsConstructor
public class RoleFieldDTO extends RoleDTO{
	private Long view;
	
	private Long add;
	
	private Long update;
	
	private Long delete;
	
	private String fieldId;
}
