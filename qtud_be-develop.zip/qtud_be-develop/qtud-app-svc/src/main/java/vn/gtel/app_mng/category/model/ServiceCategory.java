/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  Service.java
 * Created By :  tuannp
 * Created at :  12/20/21, 4:12 PM
 * LastModified  :  12/20/21, 4:12 PM
 */

package vn.gtel.app_mng.category.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TBL_DM_DICH_VU")
public class ServiceCategory extends AuditModel {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "NHOM_DICH_VU")
    private String ServiceGroup;

    @Basic
    @Column(name = "DON_VI")
    private String Organization;


    @Basic
    @Column(name = "URI")
    private String uri;


    @Basic
    @Column(name = "PHAN_LOAI")
    private Long type;


}
