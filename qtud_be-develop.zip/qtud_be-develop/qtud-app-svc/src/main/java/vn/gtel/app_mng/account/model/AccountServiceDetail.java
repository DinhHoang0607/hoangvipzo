/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceDetail.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/22/22, 3:36 PM
 *
 */

package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TBL_TK_HE_THONG", catalog = "")
public class AccountServiceDetail {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "HO_TEN_LH")
    private String relationName;

    @Basic
    @Column(name = "CHUC_VU_LH")
    private String relationPosition;

    @Basic
    @Column(name = "SO_HIEU_CAND_LH")
    private String relationPoliceNumber;

    @Basic
    @Column(name = "DIEN_THOAI_LH")
    private String relationPhone;

    @Basic
    @Column(name = "CAP_BAC_LH")
    private String relationMilitary;


    @Basic
    @Column(name = "HO_TEN_DD")
    private String representativeName;

    @Basic
    @Column(name = "CHUC_VU_DD")
    private String representativePosition;

    @Basic
    @Column(name = "SO_HIEU_CAND_DD")
    private String representativePoliceNumber;

    @Basic
    @Column(name = "DIEN_THOAI_DD")
    private String representativePhone;

    @Basic
    @Column(name = "CAP_BAC_DD")
    private String representativeMilitary;

    @Basic
    @Column(name = "GHI_CHU_LD")
    private String relationDescription;

    @Basic
    @Column(name = "GHI_CHU_DD")
    private String representativeDescription;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Long serviceType;

    @Basic
    @Column(name = "MO_TA")
    private String description;
}
