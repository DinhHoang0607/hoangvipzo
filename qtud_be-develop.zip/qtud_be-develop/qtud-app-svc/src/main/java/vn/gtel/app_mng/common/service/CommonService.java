/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  CommonService.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/19/22, 11:28 AM
 *
 */

package vn.gtel.app_mng.common.service;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.common.util.CommonUtils;

import java.io.*;
import java.util.Map;

public class CommonService {

    public static String pathTemp(String path){
        return String.format("%s%s", "template/excel/", path);
    }
    public static String pathTempDocx(String path){
        return String.format("%s%s", "template/docx/", path);
    }
    public static InputStream getReport(String path) throws IOException {
        return CommonUtils.getInputStream(String.format("%s%s", "template/report/", path));
    }

    public static ResponseEntity downloadTemplate(String path, String fileName) throws IOException {
        return CommonUtils.downloadFile(pathTemp(path), fileName);
    }

    public static ByteArrayOutputStream generateReport(JRDataSource dataSource, String templatePath,
                                                Map<String, Object> reportParam, String fileType) throws JRException, FileNotFoundException {
        templatePath = "template/jasper/" + templatePath;
        Map<String, Object> param1 = reportParam;
        return createReport(templatePath, param1, dataSource, fileType);
    }

    private static ByteArrayOutputStream createReport(String templatePath, Map<String, Object> reportParam,
                                                      JRDataSource datasource, String fileType) throws JRException, FileNotFoundException {
        switch (fileType) {
            case "pdf": case "docx":
                reportParam.put(JRParameter.IS_IGNORE_PAGINATION,false);
                break;
            case "xlsx":
                reportParam.put(JRParameter.IS_IGNORE_PAGINATION,true);
                break;
            default:
                break;
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        InputStream report = null;
        try {
             report = CommonService.class.getClassLoader().getResourceAsStream(templatePath);
            //JasperReport jasperReport = JasperCompileManager.compileReport(report);
            JasperPrint jasperPrint = JasperFillManager.fillReport(report, reportParam, datasource);

            switch (fileType) {
                case "pdf":
                    JasperExportManager.exportReportToPdfStream(jasperPrint, bos);
                    break;
                case "xlsx":
                    JRXlsxExporter xlsxExporter = new JRXlsxExporter();
                    xlsxExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
                    xlsxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(bos));
                    xlsxExporter.exportReport();
                    break;
                case "docx":
                    JRDocxExporter docxExporter = new JRDocxExporter();
                    docxExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
                    docxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(bos));
                    docxExporter.exportReport();
                    break;
                default:
                    break;
            }

            return bos;
        }finally {
            CloseInput(report);
        }
    }

    public static void CloseInput(InputStream fileInputStream){
        if (fileInputStream != null){
            try {
                fileInputStream.close();
            }catch (IOException e){
                e.getMessage();
            }
        }
    }

    public static ResponseEntity downloadFileExcelWhenImport(MultipartFile file,String fileName) throws IOException {

        return CommonUtils.downloadFile(file.getInputStream(), fileName);
    }

}
