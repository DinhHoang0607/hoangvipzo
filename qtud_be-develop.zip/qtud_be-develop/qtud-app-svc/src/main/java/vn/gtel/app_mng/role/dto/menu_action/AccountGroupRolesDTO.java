/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/18/22, 8:32 AM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountGroupRolesDTO {
    @NotEmpty
    private String account;
    private List<AccountGroupRoleItemDTO> groupRoles;
}
