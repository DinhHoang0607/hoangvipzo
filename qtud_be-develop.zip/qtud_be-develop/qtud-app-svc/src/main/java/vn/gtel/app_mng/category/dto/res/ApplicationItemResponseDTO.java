package vn.gtel.app_mng.category.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;
import vn.gtel.app_mng.category.model.AuditCategoryCommon;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationItemResponseDTO extends AuditCategoryResponseDTO {

    @Column(name = "TEN")
    private String name;

    @Column(name = "MA")
    private String code;

    @Column(name = "DUONG_DAN")
    private String url;

    @Column(name = "MA_BI_MAT")
    private String clientSecret;

    @Column(name = "LOAI_UY_QUYEN")
    private String grantType;

    @Column(name = "THOI_HAN_MA_TRUY_CAP")
    private Integer accessTokenValidity;

    @Column(name = "THOI_HAN_MA_LAM_MOI")
    private Integer refreshTokenValidity;

    private String file;
    private String fileName;

    @Column(name = "MO_TA")
    private String description;

    @Column(name = "MA_CHA")
    private String parentCode;
    @Column(name = "TEN_CHA")
    private String parentName;

    @Column(name = "ANH")
    private String logo;

    @Column(name = "TEN_VIET_TAT")
    private String sortName;

    @Column(name = "PHAN_LOAI")
    private Integer type;

    @Column(name = "TEN_PHAN_LOAI")
    private String typeName;

    @Column(name = "KHONG_SUA")
    private String notEdit;

    @Column(name = "LA_TRANG_WEB")
    private Integer isWebsite;

}
