package vn.gtel.app_mng.account.filter;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
public class AccountGroupRoleTHDBFilter extends TextFilter {
    private String groupRole;
    private String position;
    private String org;


    public AccountGroupRoleTHDBFilter(Integer page, Integer size, String keySearch, String groupRole, String position, String org) {
        super(page, size, keySearch);
        this.groupRole = groupRole;
        this.position = position;
        this.org = org;
    }
}
