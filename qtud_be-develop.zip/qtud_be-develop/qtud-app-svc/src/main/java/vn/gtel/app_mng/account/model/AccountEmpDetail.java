package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "TBL_TK_NGUOI_DUNG")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class AccountEmpDetail {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;


	@Basic
	@Column(name = "HO_TEN")
	private String fullName;

	@Basic
	@Column(name = "NGAY_SINH")
	private Timestamp birthDate;

	@Basic
	@Column(name = "DIA_CHI")
	private String address;

//	@Basic
//	@Column(name = "GIOI_TINH")
//	private String gender;

//	@Basic
//	@Column(name = "DAN_TOC")
//	private String ethnic;

	@Basic
	@Column(name = "TRINH_DO_HOC_VAN")
	private String academicLevel;

	@Basic
	@Column(name = "CHUC_VU")
	private String position;

	@Basic
	@Column(name = "CHUC_DANH")
	private String dignity;

	@Basic
	@Column(name = "TRINH_DO_CHINH_TRI")
	private String politicalLevel;

	@Basic
	@Column(name = "SO_HIEU_CAND")
	private String policeNumber;

	@Basic
	@Column(name = "CAP_BAC")
	private String military;

	@Basic
	@Column(name = "DIEN_THOAI")
	private String phone;

	@Basic
	@Column(name = "TAI_KHOAN")
	private String account;

//	@Basic
//	@Column(name = "DON_VI")
//	private String organization;

	@Basic
	@Column(name = "MO_TA")
	private String description;
	@Basic
	@Column(name = "GIOI_TINH")
	private String gender;

	@Basic
	@Column(name = "CHU_KY")
	private String signature;

	@Basic
	@Column(name = "PHAN_LOAI")
	private Integer accountType;

	@Basic
	@Column(name = "TAI_KHOAN_THUOC_DV")
	private Integer accountInOrganization;
	
	@Basic
	@Column(name = "CBQL_TRUC_TIEP")
	private String directManager;

	@Basic
	@Column(name = "TRANG_THAI_CHUYEN")
	private Integer moveStatus;

	@Basic
	@Column(name = "LY_DO_HUY_BO")
	private String reason;

	@Basic
	@Column(name = "HIEN_THI_CHUC_VU")
	private String displayPosition;

	@Formula(" (select cb.TEN from TBL_DM_CAP_BAC cb where cb.MA = CAP_BAC and cb.TRANG_THAI = 1 ) ")
	private String militaryName;

	@Formula(" (select cv.TEN from TBL_DM_CHUC_VU cv where cv.MA = CHUC_VU and cv.TRANG_THAI = 1 ) ")
	private String positionName;

	@Basic
	@Column(name = "THUOC_CQDT")
	private String investigativeAgencyType;
}
