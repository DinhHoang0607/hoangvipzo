package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccountServiceByRequirePurposeReponse {

    @Column(name = "ID")
    private String id;

    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "UU_TIEN")
    private String priority;

    @Column(name = "HO_TEN")
    private String name;

    @Column(name = "TEN")
    private String organizationName;

}
