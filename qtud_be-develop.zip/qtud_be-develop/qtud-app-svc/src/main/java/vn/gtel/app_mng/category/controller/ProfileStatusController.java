package vn.gtel.app_mng.category.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.category.dto.req.ProfileStatusFilter;
import vn.gtel.app_mng.category.dto.req.ProfileStatusRequestDto;
import vn.gtel.app_mng.category.service.ProfileStatusService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.Optional;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/profile-status")
public class ProfileStatusController {
    private final ProfileStatusService service;

    @GetMapping(value = "/list")
    public ResponseBase list(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "typeCode", required = false) String typeCode,
            @RequestParam(name = "codeXLVP", required = false) String codeXLVP,
            @RequestParam(name = "codeTNGT", required = false) String codeTNGT,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size
    ) throws Exception {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        Integer status = Constants.COMMON_STATUS.ACTIVE;
        ProfileStatusFilter commonFilter = new ProfileStatusFilter(pageNumber, sizeNumber, keySearch, typeCode, status, codeXLVP, codeTNGT);
        return service.search(commonFilter);
    }

    @GetMapping(value = "")
    public ResponseBase search(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "typeCode", required = false) String typeCode,
            @RequestParam(name = "status", required = false) Integer status,
            @RequestParam(name = "codeXLVP", required = false) String codeXLVP,
            @RequestParam(name = "codeTNGT", required = false) String codeTNGT,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size
    ) throws Exception {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        ProfileStatusFilter commonFilter = new ProfileStatusFilter(pageNumber, sizeNumber, keySearch, typeCode, status, codeXLVP, codeTNGT);
        return service.search(commonFilter);
    }

    @GetMapping(value = "/{id}")
    public ResponseBase detail(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return service.detail(id);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return service.delete(id);

    }

    @PostMapping(value = "")
    public ResponseBase create(@RequestBody @Valid ProfileStatusRequestDto request) throws Exception {
        return service.save(request);
    }

    @PutMapping(value = "")
    public ResponseBase update(@RequestBody @Valid ProfileStatusRequestDto request) throws Exception {
        return service.save(request);
    }

    @PutMapping(value = "/{id}")
    public ResponseBase setActiveDeActive(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                          @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
                                          @PathVariable String id) throws Exception {
        return service.activeInActive(id);
    }
}
