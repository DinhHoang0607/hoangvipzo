package vn.gtel.app_mng.account.service;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.app_mng.account.dto.AccountHSMDTO;
import vn.gtel.app_mng.account.dto.AccountSignImgDTO;
import vn.gtel.app_mng.account.dto.AccountSignImgResDTO;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.model.AccountHSM;
import vn.gtel.app_mng.account.model.AccountSignImg;
import vn.gtel.app_mng.account.repository.AccountHSMRepository;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.account.repository.AccountSignImgRepository;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.xml.bind.ValidationException;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

@AllArgsConstructor
@Service
public class AccountHSMService {

    private final AccountHSMRepository accountHSMRepository;
    private final AccountRepository accountRepository;
    private final AccountSignImgRepository accountSignImgRepository;
    private ModelMapper modelMapper;
    private RedisTemplate redisTemplate;

    public ResponseBase get(String username) {
        Object obj = redisTemplate.opsForValue().get(Constants.REDIS_KEY.HSM_PRE + username);
        AccountHSM accountHSM;
        if (obj != null) {
            accountHSM = new Gson().fromJson((String) obj, AccountHSM.class);
        } else {
            accountHSM = accountHSMRepository.findByAccount(username);
            if (accountHSM != null) {
                pushCache(accountHSM.getAccount(), accountHSM);
            }
        }

        return new ResponseBase(accountHSM);
    }

    public ResponseBase save(AccountHSMDTO accountHSMDTO) throws ValidationException, IOException {
        Account account = accountRepository.findByAccount(accountHSMDTO.getAccount()).orElse(null);
        if (account == null) {
            throw new ValidationException("TK khong ton tai!");
        }
        AccountHSM accountHSM = accountHSMRepository.findByAccount(accountHSMDTO.getAccount());
        if (accountHSM == null) {
            accountHSM = new AccountHSM();
        }
        modelMapper.getConfiguration().setSkipNullEnabled(true);
        modelMapper.map(accountHSMDTO, accountHSM);

//        if (accountHSMDTO.getSignImg().getBytes() != null) {
//            accountHSM.setSignImg(accountHSMDTO.getSignImg().getBytes());
//            accountHSM.setSignImgName(accountHSMDTO.getSignImg().getOriginalFilename());
//        }

//        pushCache(accountHSM.getAccount(), accountHSM);
        return new ResponseBase(accountHSMRepository.save(accountHSM));
    }

    public ResponseBase saveImgSign(AccountSignImgDTO accountSignImgDTO) throws ValidationException, IOException {
        Account account = accountRepository.findByAccount(accountSignImgDTO.getAccount()).orElse(null);
        if (account == null) {
            throw new ValidationException("TK khong ton tai!");
        }
        AccountSignImg accountSignImg = accountSignImgRepository.findByAccount(accountSignImgDTO.getAccount());
        if (accountSignImg == null) {
            accountSignImg = new AccountSignImg();
            accountSignImg.setAccount(accountSignImgDTO.getAccount());
        }

        accountSignImg.setSignImg(accountSignImgDTO.getSignImg().getBytes());
        accountSignImg.setSignImgName(accountSignImgDTO.getSignImg().getOriginalFilename());

//        pushCache(new AccountSignImgResDTO(accountSignImgDTO.getAccount(), accountSignImgDTO.getSignImg().getBytes(), accountSignImgDTO.getSignImg().getOriginalFilename()));
        accountSignImgRepository.save(accountSignImg);
        return new ResponseBase();
    }


    public ResponseBase delete(String account) throws ValidationException {
        AccountHSM accountHSM = accountHSMRepository.findByAccount(account);
        if (accountHSM == null) {
            throw new ValidationException("TK khong ton tai!");
        }
        accountHSM.setStatus(-1);
        redisTemplate.opsForValue().set(Constants.REDIS_KEY.HSM_PRE + accountHSM.getAccount(), null);
        return new ResponseBase(accountHSMRepository.save(accountHSM));
    }

    public ResponseBase deleteImg(String account) throws ValidationException {
        AccountSignImg accountSignImg = accountSignImgRepository.findByAccount(account);
        if (accountSignImg == null) {
            throw new ValidationException("TK khong ton tai!");
        }
        accountSignImgRepository.delete(accountSignImg);
        redisTemplate.opsForValue().set(Constants.REDIS_KEY.SIGN_IMG_PRE_ + account, null);
        return new ResponseBase();
    }

    private void pushCache(String account, AccountHSM entity) {
        redisTemplate.opsForValue().set(Constants.REDIS_KEY.HSM_PRE + account, new Gson().toJson(entity), 8, TimeUnit.HOURS);
    }

    private void pushCache(AccountSignImgResDTO accountSignImgResDTO) {
        redisTemplate.opsForValue().set(Constants.REDIS_KEY.SIGN_IMG_PRE_ + accountSignImgResDTO.getAccount() , accountSignImgResDTO.getSignImg(), 8, TimeUnit.HOURS);
    }

    public ResponseBase getMe() {
        return get(AccountLogonContext.getUsername());
    }

    public ResponseBase getSignImg(String account) {
//        Object obj = redisTemplate.opsForValue().get(Constants.REDIS_KEY.SIGN_IMG_PRE_ + account + "_" + type);
        AccountSignImgResDTO accountSignImgResDTO;
//        if (obj == null){
            AccountSignImg accountSignImg = accountSignImgRepository.findByAccount(account);
            accountSignImgResDTO = new AccountSignImgResDTO(accountSignImg.getAccount(), accountSignImg.getSignImg(), accountSignImg.getSignImgName());
//            pushCache(accountSignImgResDTO);
//        } else {
//            byte[] signImg = (byte[]) obj;
//            accountSignImgResDTO = new AccountSignImgResDTO(account, signImg, null);// new Gson().fromJson(new JsonReader(new InputStreamReader(new ByteArrayInputStream())), AccountSignImgResDTO.class);
//        }
        return new ResponseBase(accountSignImgResDTO);
    }
}
