package vn.gtel.app_mng.account.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonTypeName("accountServiceDetail")
public class AccountServiceExtraInfoDTO extends AccountDetailDTO {


    private String id;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(min = Constants.VALID.MIN_LENGTH_NAME_5, message = "error.common.validate.min.size.5")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String name;

    private String representativeName;
    private String representativePosition;
    private String representativePoliceNumber;
    private String representativePhone;
    private String representativeMilitary;
    private String representativeDescription;

    @NotEmpty(message = "error.common.validate.not.empty")
    private String relationName;

    private String relationPosition;

    private String relationPoliceNumber;

    @NotEmpty(message = "error.common.validate.not.empty")
    private String relationPhone;
    private String relationMilitary;
    private String relationDescription;

    private Long serviceType;

    private String description;

    private String citizenID;
}
