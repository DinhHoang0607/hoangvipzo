/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  BackUpDataConfig.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/7/22, 2:44 PM
 *
 */

package vn.gtel.app_mng.config.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TBL_CH_SAO_LUU_DL", catalog = "")
public class BackupDataConfig extends AuditModelBase {

    @Basic
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;


    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "GIO")
    private Long hour;

    @Basic
    @Column(name = "THANG")
    private Long month;

    @Basic
    @Column(name = "DUONG_DAN")
    private String path;

    @Basic
    @Column(name = "PHAN_LOAI")
    private String type;


}
