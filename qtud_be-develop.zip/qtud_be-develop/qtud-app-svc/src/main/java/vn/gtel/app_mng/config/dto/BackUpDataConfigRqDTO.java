/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  BackUpDataConfigRqDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/7/22, 4:06 PM
 *
 */

package vn.gtel.app_mng.config.dto;

import lombok.Data;

import javax.validation.Valid;
import java.util.List;

@Data
public class BackUpDataConfigRqDTO {

    @Valid
    private List<BackUpDataConfigItemRqDTO> configs;

}
