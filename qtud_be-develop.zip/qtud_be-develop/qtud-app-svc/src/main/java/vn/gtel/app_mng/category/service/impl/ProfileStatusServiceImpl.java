package vn.gtel.app_mng.category.service.impl;

import javassist.NotFoundException;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.gtel.common.constants.ActionCode;
import vn.gtel.common.dto.LogActionDTO;
import vn.gtel.common.service.LoggingService;
import vn.gtel.common.util.LogUtil;
import vn.gtel.common.util.StringUtils;
import vn.gtel.app_mng.category.dto.req.ProfileStatusFilter;
import vn.gtel.app_mng.category.dto.req.ProfileStatusRequestDto;
import vn.gtel.app_mng.category.dto.res.ProfileStatusResponseDto;
import vn.gtel.app_mng.category.model.ProfileStatus;
import vn.gtel.app_mng.category.repo.ProfileStatusRepo;
import vn.gtel.app_mng.category.repo.ProfileTypeRepo;
import vn.gtel.app_mng.category.service.ProfileStatusService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.model.AuditModel;
import vn.gtel.app_mng.common.model.AuditModelBase;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.xml.bind.ValidationException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProfileStatusServiceImpl implements ProfileStatusService {
    private final ProfileStatusRepo profileStatusRepo;
    private final ProfileTypeRepo profileTypeRepo;
    private final ModelMapper modelMapper;
    private final EntityManager entityManager;
    private final TrimSpaceUtil trimSpaceUtil;
    private final LoggingService loggingService;

    @Override
    public ResponseBase search(ProfileStatusFilter dto) throws Exception {
        trimSpaceUtil.validate(dto);
        List<ProfileStatusResponseDto> data = this.getData(dto);
        long total = this.getTotal(dto);
        return new ResponseBase(new ListResponse(data, total));
    }

    @Override
    public ResponseBase detail(String id) throws Exception {
        ProfileStatus entity = profileStatusRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("ValidationException.error.profile.status.id.not.exists"));
        return new ResponseBase(modelMapper.map(entity, ProfileStatusResponseDto.class));
    }

    @Override
    public ResponseBase save(ProfileStatusRequestDto dto) throws Exception {
        trimSpaceUtil.validate(dto);
        this.validateDto(dto);
        ProfileStatus entity;
        String action = null;
        String content = null;
        boolean isUpdate = StringUtils.isNotEmpty(dto.getId());
        if (isUpdate) {
            action = ActionCode.EDIT;
            entity = profileStatusRepo.findById(dto.getId())
                    .orElseThrow(() -> new NotFoundException("ValidationException.error.profile.status.id.not.exists"));
            content = String.format(" Đã sửa trạng thái hồ sơ có mã là %s ,", entity.getCode());
            String logMess = this.getDetailProfileStatus(content, dto, entity);
            if (!logMess.equals(content)) {
                loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                        Constants.MENU_CODE.CATEGORY.profileStatus, action, logMess, Instant.now()));
            }
        } else {
            entity = new ProfileStatus();
            action = ActionCode.ADD;
        }

        modelMapper.map(dto, entity);

        entity = profileStatusRepo.save(entity);
        if (action.equals(ActionCode.ADD)) {
            content = String.format(" Đã thêm mới trạng thái hồ sơ có tên là %s và mã là %s", entity.getName(), entity.getCode());
        }
//        else if (action.equals(ActionCode.EDIT)) {
//            content = String.format(" Đã sửa trạng thái hồ sơ có tên là %s và mã là %s", entity.getName(), entity.getCode());
//        }
        if (!action.equals(ActionCode.EDIT)) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.profileStatus, action, content, Instant.now()));
        }
        return new ResponseBase(modelMapper.map(entity, ProfileStatusResponseDto.class));
    }

    private String getDetailProfileStatus(String logContent, ProfileStatusRequestDto dto, ProfileStatus entity) {
        if (dto == null || entity == null) {
            return null;
        }

        StringBuilder logMessage = new StringBuilder();
        logMessage.append(logContent);
        LogUtil.compareAndLog(logMessage, "[Tên trạng thái hồ sơ] ", dto.getName(), entity.getName());
        LogUtil.compareAndLog(logMessage, "[Giá trị] ", dto.getValue(), entity.getValue());
        LogUtil.compareAndLog(logMessage, "[Trạng thái] ", dto.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa", entity.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa");
        LogUtil.compareAndLog(logMessage, "[Mô tả] ", dto.getDescription(), entity.getDescription());
        return logMessage.toString();
    }

    @Override
    public ResponseBase delete(String id) throws Exception {
        ProfileStatus entity = profileStatusRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("ValidationException.error.profile.status.id.not.exists"));
        entity.setStatus(Constants.COMMON_STATUS.DELETED);
        entity = profileStatusRepo.save(entity);
        String content = String.format("Đã xóa trạng thái hồ sơ có tên là %s và mã là %s", entity.getName(), entity.getCode());
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.profileStatus, ActionCode.DEL, content, Instant.now()));
        return new ResponseBase(modelMapper.map(entity, ProfileStatusResponseDto.class));
    }

    @Override
    public ResponseBase activeInActive(String id) throws Exception {
        ProfileStatus entity = profileStatusRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("ValidationException.error.profile.status.id.not.exists"));
        Integer status = entity.getStatus();
        if (Constants.COMMON_STATUS.ACTIVE.equals(status) ||
                Constants.COMMON_STATUS.INACTIVE.equals(status)) {
            entity.setStatus(CommonUtils.switchStatus(status));
            if (entity.getStatus() == 1) {
                if (profileTypeRepo.existsByCodeAndStatus(entity.getTypeCode(), 2)) {
                    throw new ValidationException("ValidationException.error.profile.status.is.active");
                }
            }
            entity = profileStatusRepo.save(entity);
            String action = null;
            String content = null;
            if (entity.getStatus().equals(Constants.COMMON_STATUS.ACTIVE)) {
                action = ActionCode.ACTIVE;
                content = String.format("Đã kích hoạt trạng thái hồ sơ có tên là %s và mã là %s", entity.getName(), entity.getCode());
            } else {
                action = ActionCode.INACTIVE;
                content = String.format("Đã vô hiệu hóa trạng thái hồ sơ có tên là %s và mã là %s", entity.getName(), entity.getCode());
            }
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.profileStatus, action, content, Instant.now()));
            return new ResponseBase(modelMapper.map(entity, ProfileStatusResponseDto.class));
        }
        return new ResponseBase("ValidationException.error.profile.status.nothing.changes");
    }

    private void validateDto(@NonNull ProfileStatusRequestDto dto) throws ValidationException {
        if (!profileTypeRepo.existsByCodeAndStatus(dto.getTypeCode(), Constants.COMMON_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.error.profile.status.type.not.exists");
        }

        ProfileStatus entity = profileStatusRepo.findByCode(dto.getCode());
        if (entity != null && !entity.getId().equals(dto.getId())) {
            throw new ValidationException("ValidationException.error.profile.status.code.exists");
        }

        entity = profileStatusRepo.findByTypeCodeAndValueAndStatusNot(dto.getTypeCode(), dto.getValue(), Constants.COMMON_STATUS.DELETED);
        if (entity != null && !entity.getId().equals(dto.getId())) {
            throw new ValidationException("ValidationException.error.profile.status.value.exists");
        }
    }

    private List<ProfileStatusResponseDto> getData(ProfileStatusFilter dto) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<ProfileStatusResponseDto> criteriaQuery = criteriaBuilder.createQuery(ProfileStatusResponseDto.class);
        Root<ProfileStatus> root = criteriaQuery.from(ProfileStatus.class);
        Predicate predicate = buildPredicate(dto, criteriaBuilder, root);
        criteriaQuery.select(criteriaBuilder.construct(ProfileStatusResponseDto.class, root));
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get(AuditModel.Fields.code)));
        criteriaQuery.where(predicate);
        TypedQuery<ProfileStatusResponseDto> dataQuery = entityManager.createQuery(criteriaQuery);
        dataQuery.setFirstResult(dto.getPage() * dto.getSize());
        dataQuery.setMaxResults(dto.getSize());

        return dataQuery.getResultList();
    }

    private long getTotal(ProfileStatusFilter dto) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> criteriaCountQuery = criteriaBuilder.createQuery(Long.class);
        Root<ProfileStatus> countRoot = criteriaCountQuery.from(ProfileStatus.class);
        criteriaCountQuery.select(criteriaBuilder.count(countRoot));
        Predicate countPredicate = buildPredicate(dto, criteriaBuilder, countRoot);
        criteriaCountQuery.where(countPredicate);
        TypedQuery<Long> countQuery = entityManager.createQuery(criteriaCountQuery);
        return countQuery.getSingleResult();
    }

    private Predicate buildPredicate(ProfileStatusFilter dto, CriteriaBuilder criteriaBuilder, Root<ProfileStatus> root) {
        List<Predicate> predicates = new ArrayList<>();
        String keySearch = dto.getLikeKeySearch();
        if (StringUtils.isNotEmpty(keySearch)) {
            predicates.add(criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(AuditModel.Fields.name)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(AuditModel.Fields.code)), keySearch)
            ));
        }

        String typeCode = dto.getTypeCode();
        if (StringUtils.isNotEmpty(typeCode)) {
            predicates.add(criteriaBuilder.equal(root.get(ProfileStatus.Fields.typeCode), typeCode));
        }

        if (StringUtils.isNotEmpty(dto.getCodeTNGT())) {
            predicates.add(criteriaBuilder.equal(root.get(ProfileStatus.Fields.codeTNGT), dto.getCodeTNGT()));
        }

        if (StringUtils.isNotEmpty(dto.getCodeXLVP())) {
            predicates.add(criteriaBuilder.equal(root.get(ProfileStatus.Fields.codeXLVP), dto.getCodeXLVP()));
        }

        Integer status = dto.getStatus();
        if (status != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuditModelBase.Fields.status), status));
        } else {
            predicates.add(criteriaBuilder.notEqual(root.get(AuditModelBase.Fields.status), Constants.COMMON_STATUS.DELETED));
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }
}
