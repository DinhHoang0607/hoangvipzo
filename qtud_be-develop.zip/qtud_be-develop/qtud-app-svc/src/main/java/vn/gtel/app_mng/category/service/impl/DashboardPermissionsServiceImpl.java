package vn.gtel.app_mng.category.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.category.dto.req.DashboardPermissionsReqDTO;
import vn.gtel.app_mng.category.model.DashboardPermissions;
import vn.gtel.app_mng.category.repo.DashboardPermissionsRepo;
import vn.gtel.app_mng.category.service.DashboardPermissionsService;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DashboardPermissionsServiceImpl implements DashboardPermissionsService {
    private final DashboardPermissionsRepo dashboardPermissionsRepo;

    @Override
    public ResponseBase getListByUserName(String userName) {
        if (userName == null) {
            return new ResponseBase(new ArrayList<>());
        }
        return new ResponseBase(dashboardPermissionsRepo.getAllByAccount(userName));
    }

    @Override
    public ResponseBase save(DashboardPermissionsReqDTO request) {
        List<DashboardPermissions> dashboardPermissions = dashboardPermissionsRepo.getAllByAccount(request.getAccount());
        if (dashboardPermissions != null && dashboardPermissions.size() > 0) {
            dashboardPermissionsRepo.deleteAll(dashboardPermissions);
        }
        List<DashboardPermissions> permissionsList = new ArrayList<>();
        if (request.getActions() != null && request.getActions().size() > 0) {
            for (String action : request.getActions()) {
                DashboardPermissions permissions = new DashboardPermissions();
                permissions.setAccount(request.getAccount());
                permissions.setAction(action);
                permissionsList.add(permissions);
            }
        }
        if (permissionsList.size() > 0) {
            return new ResponseBase(dashboardPermissionsRepo.saveAll(permissionsList));
        }
        return new ResponseBase(new ArrayList<>());
    }
}
