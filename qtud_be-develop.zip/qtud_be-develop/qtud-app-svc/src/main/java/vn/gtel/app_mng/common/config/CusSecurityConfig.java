package vn.gtel.app_mng.common.config;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CsrfFilter;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.PatternRoleDTO;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.dto.response.RoleByAppCodeDTO;
import vn.gtel.app_mng.role.service.RoleService;

import java.util.List;
import java.util.stream.Collectors;

@Configuration
@Order(202)
@RequiredArgsConstructor
public class CusSecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${toggle.check.role:true}")
    private Boolean enableRole;

    private final PermissionFilter permissionFilter;
    private final RoleService roleService;
    private final CustomCsrfRepository customCsrfRepository;

    @Override
    public void configure(final HttpSecurity http) throws Exception {
        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry x = http
//                .cors().disable()
                .csrf().csrfTokenRepository(customCsrfRepository)
                .and()
                .authorizeRequests()
                .requestMatchers(EndpointRequest.to("info", "health", "prometheus")).permitAll()
                .antMatchers(HttpMethod.GET, "/v2/api-docs", "/configuration/**", "/swagger*/**", "/webjars/**").permitAll()
                .antMatchers(HttpMethod.GET, "/api/v1/permission/be/appCode**", "/api/v1/permission/log/appCode**", "/api/v1/holiday/today", "/api/v1/news").permitAll()
                .antMatchers("/api/v1/permission", "/api/v1/permission/fe/appCode", "/api/v1/permission/apps").authenticated()
                .antMatchers("/api/v1/account/get-me", "/api/v1/account/get-account-org").authenticated()
                .antMatchers("/api/v1/account/change-pw").authenticated()
                .antMatchers("/api/v1/maintenanceConfiguration/state", "/api/v1/account/forget-pw").permitAll();
        if (enableRole) {
            http.addFilterAfter(permissionFilter, BasicAuthenticationFilter.class);
            RoleByAppCodeDTO roleByAppCodeDTO = (RoleByAppCodeDTO) ((ResponseBase) roleService.getPermission(Constants.APPLICATION_CODE.QTUD, true)).getData();
            List<PatternRoleDTO> roles = roleByAppCodeDTO.getAuthorities().stream()
                    .filter(e -> StringUtils.isNotEmpty(e.getEndpoint()) && StringUtils.isNotEmpty(e.getPermissionCode())).collect(Collectors.toList());

            for (PatternRoleDTO authority : roles) {
                if (StringUtils.isEmpty(authority.getMethod())) {
                    x = x.antMatchers(authority.getEndpoint()).hasAnyAuthority(authority.getPermissionCode());
                } else {
                    x = x.antMatchers(HttpMethod.valueOf(authority.getMethod()), authority.getEndpoint()).hasAnyAuthority(authority.getPermissionCode());
                }
            }
        }
        CsrfTokenFilter csrfTokenFilter = new CsrfTokenFilter();
        http.addFilterBefore(csrfTokenFilter, CsrfFilter.class);
    }
}
