/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  CallRestAPIServiceImpl.java
 *  * Created By :  tuannp
 *  * Created at :  12/13/21, 9:15 AM
 *  * LastModified  :  4/15/21, 3:48 PM
 *
 */

package vn.gtel.app_mng.common.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import vn.gtel.app_mng.account.dto.AccountChangeOrgDTO;
import vn.gtel.app_mng.account.dto.AccountChangeOrgResponseDTO;
import vn.gtel.app_mng.account.dto.request.AccountTransferReq;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.CallRestAPIService;

import javax.servlet.http.Cookie;
import java.util.Arrays;
import java.util.Map;

@Slf4j
@Service
public class CallRestAPIServiceImpl implements CallRestAPIService {


    // ham phuc vu cho dieu tra hinh su
    @Override
    public ResponseEntity<String> call(String restUrl, HttpMethod httpMethod,
                                       Map<String, String> headerMap, String body, String authorizationString, AccountEmployeeDetail accountEmployeeDetail, int actionType) {
        try {
            log.trace("Endpoint: " + restUrl);
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    headers.set(key, headerMap.get(key));
                }
            }
            if (authorizationString != null && !authorizationString.isEmpty()) {
                //  headers.set("Authorization", authorizationString);
                // Set BearerAuth
                headers.setBearerAuth(authorizationString);
            }

            headers.setContentType(MediaType.APPLICATION_JSON);
            // Request Entity
            HttpEntity<String> requestEntity = new HttpEntity<String>(body, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    String.class);
            log.debug("Response: " + response);
            // khi ko thể call đến api  insert or update của Điều Tra Hình sự sẽ cập nhập lại trạng thái
            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
                        restUrl, headers.toString(), response.getBody());
                log.error(msg);
                if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.INSERT_TYPE) {
                    accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_INSERT);
                } else if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.UPDATE_TYPE) {
                    accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_UPDATE);
                } else if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.REJECT_TYPE) {
                    accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_REJECT);
                } else if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.ACCEPT_TYPE) {
                    accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_ACCEPT);
                }
                throw new RuntimeException(msg);
            }
            return response;
        } catch (Exception e) {  // khi ko thể call đến api  insert or update của Điều Tra Hình sự sẽ cập nhập lại trạng thái
            String msg = String.format("Không thể gọi đến API: %s, error: %s", restUrl, e.getMessage());
            log.error(msg);
            if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.INSERT_TYPE) {
                accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_INSERT);
            } else if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.UPDATE_TYPE) {
                accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_UPDATE);
            } else if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.REJECT_TYPE) {
                accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_REJECT);
            } else if (actionType == Constants.ACTION_TYPE_CODE_FOR_DTHS.ACCEPT_TYPE) {
                accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.ERROR_ACCEPT);
            }
            throw new RuntimeException(msg);
        }
    }

    @Override
    public ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, String body, String authorizationString, Map<String, String> params) {
        try {
            log.trace("Endpoint: " + restUrl);
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    headers.set(key, headerMap.get(key));
                }
            }
            if (authorizationString != null && !authorizationString.isEmpty()) {
                // headers.set("Authorization", authorizationString);
                // Set BearerAuth
                headers.setBearerAuth(authorizationString);
            }

            headers.setContentType(MediaType.APPLICATION_JSON);
            // Request Entity
            HttpEntity<String> requestEntity = new HttpEntity<String>(body, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    String.class, params);
            log.debug("Response: " + response);
            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
                        restUrl, headers.toString(), response.getBody());
                log.error(msg);
                throw new RuntimeException(msg);
            }
            return response;
        } catch (Exception e) {
            String msg = String.format("Không thể gọi đến API: %s, error: %s", restUrl, e.getMessage());
            log.error(msg);
            throw new RuntimeException(msg);
        }
    }

    @Override
    public ResponseEntity<String> call(String restUrl, HttpMethod httpMethod,
                                       Map<String, String> headerMap, String body, String username, String password,
                                       String authorizationString) {

        try {
            log.trace("Endpoint: " + restUrl);
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    headers.set(key, headerMap.get(key));
                }
            }
//      if (authorizationString != null && !authorizationString.isEmpty()) {
//        // headers.set("Authorization", authorizationString);
//        // Set BearerAuth
//        headers.setBearerAuth(authorizationString);
//      }
//      username = "admin";
//      password = "123456";
//      if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
//        // Set BasicAuth
//        headers.setBasicAuth(username, password);
//      }

            log.info(username + "user:pass" + password);
            headers.setContentType(MediaType.APPLICATION_JSON);
            // Request Entity
            HttpEntity<String> requestEntity = new HttpEntity<String>(body, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    String.class);
            log.debug("Response: " + response);
            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
                        restUrl, headers.toString(), response.getBody());
                log.error(msg);
                throw new RuntimeException(msg);
            }
            return response;
        } catch (Exception e) {
            String msg = String.format("Không thể gọi đến API: %s, error: %s", restUrl, e.getMessage());
            log.error(msg);
            throw new RuntimeException(msg);
        }
    }

    @Override
    public ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Cookie[] cookies)
            throws RuntimeException {
        try {
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);

            for (Cookie cookie : cookies) {
                headers.add(HttpHeaders.COOKIE, cookie.getName() + "=" + cookie.getValue());
            }

            // Request Entity
            HttpEntity<String> requestEntity = new HttpEntity<String>(null, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();

            ResponseEntity<String> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    String.class);
            log.debug("Response: " + response);
            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
                        restUrl, response.getStatusCode(), response.getBody());
                log.error(msg);
                throw new RuntimeException(msg);
            }
            return response;
        } catch (Exception e) {
            String msg = String.format("Không thể gọi đến API: %s, error: %s", restUrl, e.getMessage());
            log.error(msg);
            log.trace("Error : " + msg);
            throw new RuntimeException(msg);
        }
    }

    @Override
    public ResponseEntity<ResponseBase> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, String body) {
        log.trace("Endpoint: " + restUrl + " , Method = " + httpMethod);
        log.trace("Request Body String : " + body);
        // Request Header
        HttpHeaders headers = new HttpHeaders();
        //
        headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
        // Request to return JSON format
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (headerMap != null) {
            for (String key : headerMap.keySet()) {
                headers.set(key, headerMap.get(key));
            }
        }

        // Request Entity
        HttpEntity<String> requestEntity = new HttpEntity<String>(body, headers);

        // RestTemplate
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<ResponseBase> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                ResponseBase.class);
        log.trace("Endpoint : " + response);
        return response;
    }


    @Override
    public ResponseEntity<String> call(String restUrl, HttpMethod httpMethod,
                                       Map<String, String> headerMap, String body, String username, String password) {

        try {
            log.trace("Endpoint: " + restUrl);
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    headers.set(key, headerMap.get(key));
                }
            }
            if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
                // Set BasicAuth
                headers.setBasicAuth(username, password);
            }

            log.info(username + "user : pass" + password);

            headers.setContentType(MediaType.APPLICATION_JSON);
            // Request Entity
            HttpEntity<String> requestEntity = new HttpEntity<String>(body, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    String.class);
            log.debug("Response: " + response);
            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
                        restUrl, headers.toString(), response.getBody());
                log.error(msg);
                throw new RuntimeException(msg);
            }
            return response;
        } catch (Exception e) {
            String msg = String.format("Không thể gọi đến API: %s, error: %s", restUrl, e.getMessage());
            log.error(msg);
            throw new RuntimeException(msg);
        }
    }

    @Override
    public ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, String body, String authorizationString) {
        return null;
    }

    @Override
    public ResponseEntity<AccountChangeOrgResponseDTO> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, AccountChangeOrgDTO accountChangeOrgDTO, String authorizationString, String appName) throws Exception {
        try {
            log.trace("Endpoint: " + restUrl);
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    headers.set(key, headerMap.get(key));
                }
            }
            if (authorizationString != null && !authorizationString.isBlank()) {
                // Set BasicAuth
                headers.setBearerAuth(authorizationString);
            }

            //log.info(username + "user:pass" + password);
            //headers.setContentType(MediaType.APPLICATION_JSON);
            // Request Entity
            HttpEntity<AccountChangeOrgDTO> requestEntity = new HttpEntity<AccountChangeOrgDTO>(accountChangeOrgDTO, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<AccountChangeOrgResponseDTO> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    AccountChangeOrgResponseDTO.class);
            log.debug("Response: " + response);
//            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
//                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
//                        restUrl, headers.toString(), response.getBody());
//                log.error(msg);
//                throw new RuntimeException(msg);
//            }
            return response;
        } catch (Exception e) {
            String msg = String.format("Không thể gọi đến API kiểm tra bàn giao hồ sơ %s", appName);
            log.error(msg);
            throw new Exception(msg);
        }
    }

    @Override
    public ResponseEntity<AccountChangeOrgResponseDTO> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, AccountTransferReq request, String authorizationString, String appName) throws Exception {
        try {
            log.trace("Endpoint: " + restUrl);
            // Request Header
            HttpHeaders headers = new HttpHeaders();
            //
            headers.setAccept(Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON}));
            // Request to return JSON format
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    headers.set(key, headerMap.get(key));
                }
            }
            if (authorizationString != null && !authorizationString.isBlank()) {
                // Set BasicAuth
                headers.setBearerAuth(authorizationString);
            }

            //log.info(username + "user:pass" + password);
            //headers.setContentType(MediaType.APPLICATION_JSON);
            // Request Entity
            HttpEntity<AccountTransferReq> requestEntity = new HttpEntity<AccountTransferReq>(request, headers);

            // RestTemplate
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<AccountChangeOrgResponseDTO> response = restTemplate.exchange(restUrl, httpMethod, requestEntity,
                    AccountChangeOrgResponseDTO.class);
            log.debug("Response: " + response);
//            if (response.getStatusCodeValue() != 200 && response.getStatusCodeValue() != 202) {
//                String msg = String.format("Có lỗi trong quá trình gọi đến API: %s, status: %s, error: %s",
//                        restUrl, headers.toString(), response.getBody());
//                log.error(msg);
//                throw new RuntimeException(msg);
//            }
            return response;
        } catch (Exception e) {
            String msg = String.format("Không thể gọi đến API kiểm tra bàn giao hồ sơ %s", appName);
            log.error(msg);
            throw new Exception(msg);
        }
    }

}
