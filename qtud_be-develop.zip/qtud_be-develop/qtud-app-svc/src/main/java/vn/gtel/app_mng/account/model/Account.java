package vn.gtel.app_mng.account.model;

import lombok.*;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_TK_TAI_KHOAN")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class Account extends AuditModelBase {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "MAT_KHAU")
    private String password;

    @Basic
    @Column(name = "MAT_KHAU_BAN_DAU")
    private String passwordStart;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Integer type;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

//    @Formula("(select dv.TEN from TBL_DM_DON_VI dv where dv.MA = DON_VI) ")
//    private String organizationName;

    @Formula("(select dghc.TEN_DIA_DANH_BAN_HANh_VB from TBL_DM_DON_VI dv left join tbl_dm_dia_gioi_hanh_chinh dghc on dv.tinh_tp = dghc.ma where dv.MA = DON_VI) ")
    private String addressOrgProvinceName;

    @Formula("(select dvc.TEN from TBL_DM_DON_VI dv left join tbl_dm_don_vi dvc on dv.don_vi_cha = dvc.ma where dv.MA = DON_VI) ")
    private String organizationParentName;

    @Basic
    @Column(name = "ANH_KY_SO")
    private String pictureDigitalSign;

    @Basic
    @Column(name = "YC_DOI_MK")
    private Integer rqChangePw;

    @Basic
    @Column(name = "XAC_NHAN_THONG_TIN")
    private Integer confirmInformation;

    public Account(Account account) {
        this.id = account.getId();
        this.account = account.getAccount();
        this.password = account.getPassword();
        this.type = account.getType();
        this.organization = account.getOrganization();
        this.rqChangePw = account.getRqChangePw();
    }
}
