 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 16, 2021
 */
package vn.gtel.app_mng.role.dto.category;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

 @Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TableDTO {
	@Column(name = "ID")
	private String id;
	@Column(name = "MO_TA")
	private String ten;
}
