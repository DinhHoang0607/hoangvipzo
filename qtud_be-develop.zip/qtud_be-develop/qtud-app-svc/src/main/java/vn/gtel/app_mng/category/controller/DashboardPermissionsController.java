package vn.gtel.app_mng.category.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.category.dto.req.DashboardPermissionsReqDTO;
import vn.gtel.app_mng.category.service.DashboardPermissionsService;
import vn.gtel.app_mng.common.dto.response.ResponseBase;


@Validated
@Tag(name = "Quản lý phân quyền dashboard")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/dashboard-permissions")
@AllArgsConstructor
public class DashboardPermissionsController {
    private final DashboardPermissionsService dashboardPermissionsService;

    @PostMapping(value = "")
    public ResponseBase create(@RequestBody DashboardPermissionsReqDTO request) {
        return dashboardPermissionsService.save(request);
    }

    @GetMapping(value = "/{userName}")
    public ResponseBase create(@PathVariable String userName)  {
        return dashboardPermissionsService.getListByUserName(userName);
    }
}
