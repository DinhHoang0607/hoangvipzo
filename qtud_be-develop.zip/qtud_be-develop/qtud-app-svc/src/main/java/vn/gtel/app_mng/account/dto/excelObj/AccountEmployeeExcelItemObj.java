/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceExcelItemObj.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 11:29 AM
 *
 */

package vn.gtel.app_mng.account.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

import java.util.List;

@Data
public class AccountEmployeeExcelItemObj extends IExcelItem {

    private String account;
    private String name;
    private String password;
    private String confirmPassword;
    private String description;
    private String organization;
    private String organizationName;
    private String gender;

    private String phone;
    private String citizenID;
    private String military;
    private String position;
    private String title;
    private String militaryText;
    private String positionText;
    private String titleText;
    private String policeNumber;
    private String directManager;
    private String orgManaged;
    private String fieldManage;
    private List<String> checkedFieldManage;

    private Long type;
}
