package vn.gtel.app_mng.category.dto.res;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.time.Instant;
@Data
public class AuditOrganizationResponse {
    @Column(name = "NGAY_TAO")
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGUOI_TAO")
    @CreatedBy
    private String createdBy;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    @LastModifiedBy
    private String lastModifiedBy;

    @Basic
    @Column(name = "TRANG_THAI")
    private Long status;

    @Basic
    @Column(name = "MO_TA")
    private String description;

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "TEN")
    private String name;

}
