/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  CountResponseDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/28/22, 5:34 PM
 *
 */

package vn.gtel.app_mng.dashboard.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@FieldNameConstants
public class CountItemResponseDTO extends CountResponseDTO {

    @Column(name = "TEN")
    private String name;

    @Column(name = "MA")
    private String code;

    public CountItemResponseDTO(String name) {
        super(0L);
        this.name = name;
    }
}
