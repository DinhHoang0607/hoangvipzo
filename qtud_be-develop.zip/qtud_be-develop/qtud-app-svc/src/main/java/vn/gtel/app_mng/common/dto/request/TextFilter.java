/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  TextFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/6/21, 2:10 PM
 */

package vn.gtel.app_mng.common.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import vn.gtel.app_mng.common.util.CommonUtils;

import javax.validation.Valid;

@Data
@NoArgsConstructor
@Valid
public class TextFilter extends PageFilter {

    private String keySearch;

    public TextFilter(Integer page, Integer size, String keySearch) {
        super(page, size);
        this.keySearch = keySearch;
    }

    public String getLikeKeySearch() {
        return CommonUtils.likeString(CommonUtils.toUpperCase(keySearch));
    }
}
