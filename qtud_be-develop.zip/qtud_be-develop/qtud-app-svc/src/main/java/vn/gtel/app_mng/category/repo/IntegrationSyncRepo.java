package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.IntegrationSync;

import java.util.List;
import java.util.Optional;

@Repository
public interface IntegrationSyncRepo extends JpaRepository<IntegrationSync, String> {
    IntegrationSync getByOrgCodeOrAppCode(String orgCode, String appCode);

    @Query("select e.orgCode from IntegrationSync e where e.status = 1")
    List<String> getOrgCode();

    @Query("select e from IntegrationSync e where e.orgCode = ?1 and e.status = 1")
    Optional<IntegrationSync> getByOrgCode(String orgCode);

    boolean existsByAppCodeAndStatus(String code, Integer active);

    IntegrationSync findByAppCode(String code);

    IntegrationSync getByOrgCodeOrAppCodeAndStatusNot(String orgCode, String appCode, Integer deleted);
}
