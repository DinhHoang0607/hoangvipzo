package vn.gtel.app_mng.feedback.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class IdeaDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    private String idFeedBack;

    private String idea;

    private List<FileFeedBackDTO> files;
}
