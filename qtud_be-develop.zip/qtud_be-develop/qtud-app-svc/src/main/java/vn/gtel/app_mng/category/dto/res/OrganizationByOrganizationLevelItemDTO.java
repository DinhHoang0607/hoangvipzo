package vn.gtel.app_mng.category.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationByOrganizationLevelItemDTO {
    @Column(name = "ID")
    private String organizationId;
    @Column(name = "TEN")
    private String organizationName;
}
