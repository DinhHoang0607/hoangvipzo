/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ActionLogCallStoredDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/4/21, 11:07 AM
 */

package vn.gtel.app_mng.report.storeObj;

import vn.gtel.app_mng.account.dto.excelObj.ReportAccountDTO;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.report.dto.filter.StatisticFilter;
import vn.gtel.app_mng.report.dto.res.CommonReportResponseDTO;
import vn.gtel.app_mng.report.dto.res.MenuResDTO;
import vn.gtel.common.userinfo.AccountLogonContext;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class ReportCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_BAO_CAO";
    public static final String PROC_SUM_ACCOUNT = "PROC_THONG_KE_TK";
    public static final String PROC_RP_SUM_COUNTRY_ACCOUNT = "PROC_THONG_KE_TOAN_QUOC_TK";
    public static final String PROC_COUNT_WARNING = "PROC_THONG_KE_CANH_BAO";

    private static final String IN_STATISTIC_BY = "PI_THONG_KE_THEO";
    private static final String IN_ORGANIZATION = "PI_DON_VI";
    private static final String IN_ORIGIN_ORG = "PI_DON_VI_GOC";
    private static final String IN_ORDER = "PI_SAP_XEP";
    private static final String IN_DISPLAY_NAME = "PI_TEN_HIEN_THI";
    private static final String IN_ACCOUNT_NAME = "pi_account_name";
    private static final String IN_FROM_TIME = "PI_FROM_TIME";
    private static final String IN_TO_TIME = "PI_TO_TIME";
    private static final String IN_AGG_TYPE = "AGG_TYPE";
    private static final String IN_ORG_CODE = "PI_DON_VI";
    private static final String IN_APP = "PI_UNG_DUNG";
    private static final String IN_GROUP_ROLE = "PI_NHOM_QUYEN";

    private static final String PROVINCE_CODE = "PI_PROVINCE_CODE";
    private static final String IN_MANAGER = "PI_LANH_DAO_QUAN_LY";

    private static final String IN_CURRENT_ACCOUNT_ORG = "PI_DON_VI_TK_DANG_NHAP";
    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        params.put(getPiCurrentAccountId(), AccountLogonContext.currentUser().getId());
        setPackageName(PACKAGE_NAME);
        setStoredName(PROC_SUM_ACCOUNT);
        setResponseType(CommonReportResponseDTO.class);
    }

    public ReportCallStoredDTO(StatisticFilter filter) {
        setBase();
        params.put(IN_STATISTIC_BY, filter.getStatisticType());
        params.put(IN_ORDER, filter.getOrderBy());
        params.put(IN_DISPLAY_NAME, filter.getDisplayNameMode());
        params.put(IN_ACCOUNT_NAME, filter.getAccountName());
        params.put(IN_ORGANIZATION, filter.getOrganization());
        params.put(IN_ORIGIN_ORG, filter.getOriginOrganization());
        params.put(IN_APP, filter.getApplication());
        params.put(IN_GROUP_ROLE, filter.getGroupRole());
        params.put(PROVINCE_CODE, filter.getProvinceCode());
        params.put(IN_MANAGER, filter.getManager());
        params.put(IN_FROM_TIME, CommonUtils.instantToTimeStamp(filter.getFromDate()));
        params.put(IN_TO_TIME, CommonUtils.instantToTimeStamp(filter.getToDate()));
        setParams(params);
    }

    public ReportCallStoredDTO(FilterChart filterChart) {
//        Account account = new Account();//  UserLogonUtils.currentUser();
        setBase();
        setPackageName("PKG_DASHBOARD");
        setStoredName(filterChart.getChartType());
        params.put(IN_FROM_TIME, filterChart.getFromDateTime());
        params.put(IN_TO_TIME, filterChart.getToDateTime());
        params.put(IN_AGG_TYPE, filterChart.getAggType());
        params.put(IN_ORG_CODE, filterChart.getOrgCode());
        params.put(IN_CURRENT_ACCOUNT_ORG, AccountLogonContext.currentUser().getOrganization());

        setParams(params);
    }

    public ReportCallStoredDTO(Instant fromDate, Instant toDate, String type) {
        setBase();
        setResponseType(ReportAccountDTO.class);
        setStoredName(PROC_RP_SUM_COUNTRY_ACCOUNT);
        params.put(IN_FROM_TIME, CommonUtils.yyyyMMddInstant(fromDate));
        params.put(IN_TO_TIME, CommonUtils.yyyyMMddInstant(toDate));
        setParams(params);
    }

    public void isWarning(boolean b) {
        if (b) {
            setPackageName(PACKAGE_NAME);
            setResponseType(MenuResDTO.class);
        }
    }
}
