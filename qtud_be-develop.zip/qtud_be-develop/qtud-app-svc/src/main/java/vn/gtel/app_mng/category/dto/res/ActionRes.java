 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 6, 2021
 */
package vn.gtel.app_mng.category.dto.res;

import javax.persistence.Column;

import lombok.Data;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

@Data
public class ActionRes extends AuditItemResponse{
	
	@Column(name = "TEN")
    private String name;
	
	@Column(name = "THU_TU")
    private Long order;
	
}
