/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  DashboardService.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/1/22, 10:30 AM
 *
 */

package vn.gtel.app_mng.config.service;

import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.config.dto.BackUpDataConfigFilter;
import vn.gtel.app_mng.config.dto.BackUpDataConfigRqDTO;

public interface BackupDataConfigService {
    ResponseBase save(BackUpDataConfigRqDTO backUpDataConfigRqDTO) throws Exception;
    ResponseBase search(BackUpDataConfigFilter backUpDataConfigFilter) throws IllegalAccessException;
}
