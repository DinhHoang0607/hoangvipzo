package vn.gtel.app_mng.common.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.OAuthFlow;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

//    @Value("${spring.cf.swagger.scheme.name}")
//    private String springSchemeName;

//    @Value("${spring.cf.swagger.oauth.clientId}")
//    private String clientId;
//
//    @Value("${spring.cf.swagger.oauth.clientSecret}")
//    private String clientSecret;

    @Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}")
    private String tokenUrl;

    @Bean
    public OpenAPI openAPI() {
        OAuthFlow oAuthFlow = new OAuthFlow();
        oAuthFlow.tokenUrl(tokenUrl);

        return new OpenAPI()
                .info(new Info().title("Quản trị ứng dụng REST API")
                        .description("Quản trị ứng dụng REST API")
                        .version("1.0")
                        .termsOfService("Terms of service")
                        .license(new License().name("License of gtel.vn")
                                .url("https://www.gtel.vn")))
                .components(new Components().addSecuritySchemes("OAuth", new SecurityScheme()
                        .type(SecurityScheme.Type.OAUTH2)
                        .scheme("bearer")
                        .bearerFormat("jwt")
                        .in(SecurityScheme.In.HEADER)
                        .name("Authorization")
                        .flows(new OAuthFlows()
                                .password(oAuthFlow))))
                .addSecurityItem(new SecurityRequirement().addList("OAuth"))
//                .security(Collections.singletonList(new SecurityRequirement().addList("Authorization")))
                .externalDocs(new ExternalDocumentation());
    }

//    @Bean
//    public Docket api() {
//        return new Docket(DocumentationType.SWAGGER_2)
//                .apiInfo(apiInfo())
//                .securityContexts(Arrays.asList(securityContext()))
//                .securitySchemes(Arrays.asList(securityScheme()))
//                .select()
//                .apis(RequestHandlerSelectors.basePackage("vn.gtel.app_mng"))
//                .paths(PathSelectors.any())
//                .build()
//                .groupName("App Manager");
//    }
//
//    @Bean
//    public SecurityConfiguration security(){
//        return SecurityConfigurationBuilder.builder()
//                .clientId(clientId)
//                .clientSecret(clientSecret)
//                .scopeSeparator(" ")
//                .useBasicAuthenticationWithAccessCodeGrant(false)
//                .build();
//    }
//
//
//    private SecurityContext securityContext(){
//        return SecurityContext.builder()
//                .securityReferences(Arrays.asList(new SecurityReference(springSchemeName, scope())))
//                .build();
//    }
//
//    private ApiInfo apiInfo() {
//        return new ApiInfo(
//                "Quản trị ứng dụng REST API",
//                "Quản trị ứng dụng REST API",
//                "1.0",
//                "Terms of service",
//                new Contact("www.gtel.vn", "www.gtel.vn", "www.gtel.vn"),
//                "License of gtel.vn",
//                "www.gtel.vn",
//                Collections.emptyList());
//    }
//
//    private AuthorizationScope[] scope() {
////        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
//        AuthorizationScope[] authorizationScopes = new AuthorizationScope[0];
////        authorizationScopes[0] = new AuthorizationScope("openid", "accessEverything");
////        authorizationScopes[1] = new AuthorizationScope("app-mng:read", "read app-mng");
////        authorizationScopes[2] = new AuthorizationScope("app-mng:write", "write app-mng");
////        authorizationScopes[2] = new AuthorizationScope("app-mng:admin", "CRUD app-mng");
//        return authorizationScopes;
//    }
//
//    private SecurityScheme securityScheme(){
//        GrantType grantType = new ResourceOwnerPasswordCredentialsGrant(tokenUrl);
//        SecurityScheme oauth = new OAuthBuilder().name(springSchemeName)
//                .grantTypes(Arrays.asList(grantType))
//                .scopes(Arrays.asList(scope()))
//                .build();
//        return oauth;
//    }
}
