package vn.gtel.app_mng.common.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;


public class CommonUtils {

    public static InputStream getInputStream(String path) throws IOException {
        InputStream inputStream = null;
        try {
            inputStream = CommonUtils.class.getClassLoader().getResourceAsStream(path);
            return inputStream;
        } catch (Exception e) {
            inputStream.close();
        }
        return null;
    }

    public static ResponseEntity downloadFile(String path, String fileName) throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName.replaceAll("/", "_"));
        headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
        if (CommonUtils.toLowerCase(fileName).indexOf("pdf") > 0) {
            headers.setContentType(MediaType.APPLICATION_PDF);
        } else if (CommonUtils.toLowerCase(fileName).indexOf("xlsx") > 0) {
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        }
        InputStreamResource isr = null;
        ByteArrayInputStream bais = null;
        InputStream inputStream = null;

        try {
            inputStream = CommonUtils.class.getClassLoader().getResourceAsStream(path);
//            try {
            bais = new ByteArrayInputStream(inputStream.readAllBytes());
        } finally {
            if (bais != null) {
                isr = new InputStreamResource(bais);
                try {
                    bais.close();
                } catch (IOException e) {
                    e.getMessage();
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.getMessage();
                }
            }
//            }
            return ResponseEntity.ok().headers(headers).body(isr);
//        }finally {
//            if(inputStream != null) {
//                try {
//                    inputStream.close();
//                } catch (IOException e) {
//                    e.getMessage();
//                }
//            }
        }
    }

    public static ResponseEntity downloadFile(InputStream iStream, String fileName) throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName.replaceAll("/", "_"));
        headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
        if (CommonUtils.toLowerCase(fileName).indexOf("pdf") > 0) {
            headers.setContentType(MediaType.APPLICATION_PDF);
        } else if (CommonUtils.toLowerCase(fileName).indexOf("xlsx") > 0) {
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        }
        InputStreamResource isr = null;
        ByteArrayInputStream bais = null;

        try {
            bais = new ByteArrayInputStream(iStream.readAllBytes());
        } finally {
            if (bais != null) {
                isr = new InputStreamResource(bais);
                bais.close();
            }
        }
        return ResponseEntity.ok().headers(headers).body(isr);

//        return ResponseEntity.ok().headers(headers).body(new InputStreamResource(new ByteArrayInputStream(iStream.readAllBytes())));
    }

    public static ResponseEntity downloadFileJasper(ByteArrayOutputStream oStream, String fileName) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName.replaceAll("/", "_"));
        headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
        if (CommonUtils.toLowerCase(fileName).indexOf("pdf") > 0) {
            headers.setContentType(MediaType.APPLICATION_PDF);
        } else if (CommonUtils.toLowerCase(fileName).indexOf("xlsx") > 0 || CommonUtils.toLowerCase(fileName).indexOf("docx") > 0) {
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        }
        return ResponseEntity.ok().headers(headers).body(new InputStreamResource(new ByteArrayInputStream(oStream.toByteArray())));
    }

    public static ResponseEntity downloadFile(byte[] byteArray, String fileName) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName.replaceAll("/", "_"));
        headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
        if (CommonUtils.toLowerCase(fileName).indexOf("xml") > 0) {
            headers.setContentType(MediaType.APPLICATION_XML);
        } else if (CommonUtils.toLowerCase(fileName).indexOf("json") > 0) {
            headers.setContentType(MediaType.APPLICATION_JSON);
        }
        return ResponseEntity.ok().headers(headers).body(new InputStreamResource(new ByteArrayInputStream(byteArray)));
    }

    public static ResponseEntity downloadFile(Workbook workbook, String fileName) throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName.replaceAll("/", "_"));
        headers.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        workbook.write(bos);
        return ResponseEntity.ok().headers(headers).body(new InputStreamResource(new ByteArrayInputStream(bos.toByteArray())));
    }

    public static List<Field> getAllFields(List<Field> fields, Class<?> type) {
        fields.addAll(Arrays.asList(type.getDeclaredFields()));

        if (type.getSuperclass() != null) {
            getAllFields(fields, type.getSuperclass());
        }
        return fields;
    }

    public static List<Field> getAllFields(List<Field> fields, Object obj) {
        fields.addAll(Arrays.asList(obj.getClass().getDeclaredFields()));

        if (obj.getClass().getSuperclass() != null) {
            getAllFields(fields, obj.getClass().getSuperclass());
        }
        return fields;
    }


    public static BigDecimal calPercent(Long x, Long y, int scale) {
        if (x == null || y == null || 0 == x || 0 == y) {
            return BigDecimal.ZERO;
        }
        BigDecimal bdX = new BigDecimal(x);
        BigDecimal bdY = new BigDecimal(y);

        BigDecimal per = bdX.multiply(new BigDecimal(100)).divide(bdY, scale, RoundingMode.HALF_UP);
        return per;
    }

    public static Map<String, Integer> betweenTime(Long fromTime, Long toTime) {
        Map<String, Integer> hm = new HashMap<>();
        if (fromTime != null && toTime != null) {
            long duration = toTime - fromTime;
            long days = TimeUnit.MILLISECONDS.toDays(duration);
            if (days > 0) {
                hm.put("day", (int) days);
            }
            duration -= days * 24 * 60 * 60 * 1000;
            long hours = TimeUnit.MILLISECONDS.toHours(duration);
            if (hours > 0) {
                hm.put("hour", (int) hours);
            }
            duration -= hours * 60 * 60 * 1000;
            long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
            if (minutes > 0) {
                hm.put("minute", (int) minutes);
            }
            duration -= minutes * 60 * 1000;
            long seconds = TimeUnit.MILLISECONDS.toSeconds(duration);
            if (seconds > 0) {
                hm.put("second", (int) seconds);
            }
        }
        return hm;
    }

    public static String convertDateToString(Date date, String formatType) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(formatType);
        return dateFormat.format(date);
    }

    public static String likeString(String str) {
        if (StringUtils.isNotEmpty(str)) {
            return "%" + String.format("%s", str) + "%";
        }
        return null;
    }

    public static Long longValueFromString(String str) {
        if (StringUtils.isNumeric(str)) {
            return Long.parseLong(str);
        }
        return -1L;
    }

    public static String longToString(Long number) {
        return String.valueOf(number);
    }

    public static boolean checked(Long check) {
        if (check == null) {
            return false;
        }
        if (check == 1) {
            return true;
        }
        return false;
    }

    public static boolean isValidId(String id) {
        if (id == null) {
            return false;
        }
        if (id.isEmpty()) {
            return false;
        }
        return true;
    }

    public static String rmVNString(String vnString) {
        if (vnString == null) {
            return null;
        }
        String normalize = Normalizer.normalize(vnString, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{IncombiningDiacriticalMarks}+");
        return pattern.matcher(normalize).replaceAll("").replaceAll("Đ", "D").replaceAll("đ", "d");
    }

    public static String yyyyMMddInstant(Instant instant) {
        if (instant == null) {
            return null;
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd").withZone(ZoneId.systemDefault());// .ofLocalizedDate(FormatStyle.SHORT).withZone(ZoneId.systemDefault());
        return dtf.format(instant);
    }

    public static Timestamp instantToTimeStamp(Instant instant) {
        if (instant == null) {
            return null;
        }
        return Timestamp.from(instant);
    }

    public static String getHostName() {
        return "LOCAL";
    }

    public static boolean isValidWithPattern(String checkStr, String pattern) {
        return checkStr.matches(pattern);
    }

    public static boolean isValidMin(int checkNum, int minVal) {
        return checkNum >= minVal;
    }

    public static boolean isValidMax(int checkNum, int maxVal) {
        return checkNum <= maxVal;
    }

    public static boolean isValidMinLength(String checkStr, int minLength) {
        return checkStr.length() >= minLength;
    }

    public static boolean isValidMaxLength(String checkStr, int maxLength) {
        return checkStr.length() <= maxLength;
    }

    public static String errorAccountMsg(String account) {
        String messageError = "";
        if (!isValidWithPattern(account, Constants.Regex.CODE)) {
            messageError += Messages.getString("error.common.validate.character.number");
        }
        if (!isValidMinLength(account, Constants.VALID.MIN_LENGTH_ACCOUNT_3)) {
            messageError += Messages.getString("error.common.validate.min.size.3");
        }
        if (!isValidMaxLength(account, Constants.VALID.MAX_LENGTH_ACCOUNT)) {
            messageError += Messages.getString("error.common.validate.max.size.20");
        }
        return messageError;
    }

    public static String errorAccountServiceNameMsg(String name, String fieldName) {
        String messageError = "";
        if (fieldName == null) {
            fieldName = "";
        }
        if (!isValidWithPattern(name, Constants.Regex.NAME)) {
            messageError += fieldName + Messages.getString("error.common.validate.not.special-characters");
        }
        if (!isValidMinLength(name, Constants.VALID.MIN_LENGTH_NAME_5)) {
            messageError += fieldName + Messages.getString("error.common.validate.min.size.5");
        }
        if (!isValidMaxLength(name, Constants.VALID.MAX_LENGTH_NAME_100)) {
            messageError += fieldName + Messages.getString("error.common.validate.max.size.100");
        }
        return messageError;
    }

    public static String errorPasswordMsg(String password) {
        String messageError = "";
        if (!isValidMinLength(password, Constants.VALID.MIN_LENGTH_NAME_5)) {
            messageError += Messages.getString("error.common.validate.min.size.3");
        }
        if (!isValidMaxLength(password, Constants.VALID.MAX_LENGTH_NAME_100)) {
            messageError += Messages.getString("error.common.validate.max.size.100");
        }
        return messageError;
    }

    public static String errorCodeMsg(String code) {
        String messageError = "";
        if (!isValidWithPattern(code, Constants.Regex.CODE)) {
            messageError += Messages.getString("error.common.validate.only.number");
        }
        if (!isValidMinLength(code, Constants.VALID.MIN_LENGTH_ACCOUNT_3)) {
            messageError += Messages.getString("error.common.validate.min.size.3");
        }
        if (!isValidMaxLength(code, Constants.VALID.MAX_LENGTH_18)) {
            messageError += Messages.getString("error.common.validate.max.size.18");
        }
        return messageError;
    }

    public static String errorCodeActionMsg(String code) {
        String messageError = "";
        if (!isValidWithPattern(code, Constants.Regex.NUMBER)) {
            messageError += Messages.getString("error.common.validate.only.number");
        }
        if (!isValidMinLength(code, Constants.VALID.MIN_LENGTH_ACCOUNT_3)) {
            messageError += Messages.getString("error.common.validate.min.size.3");
        }
        if (!isValidMaxLength(code, Constants.VALID.MIN_LENGTH_ACCOUNT_3)) {
            messageError += Messages.getString("error.common.validate.max.size.3");
        }
        return messageError;
    }

    public static String errorNameMsg(String name) {
        String messageError = "";
        if (!isValidWithPattern(name, Constants.Regex.NAME)) {
            messageError += Messages.getString("error.common.validate.not.special-characters");
        }
        if (!isValidMaxLength(name, Constants.VALID.MAX_LENGTH_NAME_250)) {
            messageError += Messages.getString("error.common.validate.max.size.250");
        }
        return messageError;
    }

    public static String errorActionNameMsg(String name) {
        String messageError = "";
        if (!isValidWithPattern(name, Constants.Regex.NAME)) {
            messageError += Messages.getString("error.common.validate.not.special-characters");
        }
        if (!isValidMaxLength(name, Constants.VALID.MAX_LENGTH_NAME_100)) {
            messageError += Messages.getString("error.common.validate.max.size.100");
        }
        return messageError;
    }

    public static String errorActionTypeMsg(Integer type) {
        String messageError = "";
        if (type != Constants.ACTION_TYPE.FEATURE && type != Constants.ACTION_TYPE.SCREEN && type != Constants.ACTION_TYPE.COMPONENT) {
            messageError += Messages.getString("ValidationException.error.invalid.menu.type");
        }
        return messageError;
    }

    public static String errorDateMsg(String name) {
        String messageError = "";
        if (!isValidWithPattern(name, Constants.Regex.DATE)) {
            messageError += Messages.getString("error.common.validate.not.date");
        }
        return messageError;
    }

    public static String errorDescriptionMsg(String description) {
        String messageError = "";
        if (!isValidMaxLength(description, Constants.VALID.MAX_LENGTH_NAME_250)) {
            messageError += Messages.getString("error.common.validate.max.size.250");
        }
        return messageError;
    }


    public static String errorCmndDatePlace(String code) {
        String messageError = "";
        if (!isValidMaxLength(code, Constants.VALID.MAX_LENGTH_NAME_250)) {
            messageError += Messages.getString("error.common.validate.max.size.250");
        }
        return messageError;
    }

    public static String errorCity(String cityName) {
        String messageError = "";
        if (!isValidMaxLength(cityName, Constants.VALID.MAX_LENGTH_CITY_50)) {
            messageError += Messages.getString("error.common.validate.max.size.50");
        }
        return messageError;
    }

    public static String errorDigitalCertificate(String name) {
        String messageError = "";
        if (!isValidMaxLength(name, Constants.VALID.MAX_LENGTH_CITY_50)) {
            messageError += Messages.getString("error.common.validate.max.size.50");
        }
        return messageError;
    }

    public static String errorSim(String sim) {
        String messageError = "";
        if (!isValidMaxLength(sim, Constants.VALID.MAX_LENGTH_CITY_50)) {
            messageError += Messages.getString("error.common.validate.max.size.50");
        }
        return messageError;
    }


    public static String errorAddress(String address) {
        String messageError = "";
        if (!isValidMaxLength(address, Constants.VALID.MAX_LENGTH_CITY_50)) {
            messageError += Messages.getString("error.common.validate.max.size.50.address");
        }
        return messageError;
    }

    public static boolean equalsEnum(Enum e, String check) {
        return e.name().equals(check);
    }


    public static String toLowerCase(String characters) {
        if (StringUtils.isEmpty(characters)) return null;
        return characters.toLowerCase(Locale.ENGLISH);
    }

    public static String toUpperCase(String characters) {
        if (StringUtils.isEmpty(characters)) return null;
        return characters.toUpperCase(Locale.ENGLISH);
    }

    public static Integer switchStatus(Integer oldStatus) {
        return List.of(Constants.COMMON_STATUS.ACTIVE, Constants.COMMON_STATUS.INACTIVE).stream()
                .filter(e -> !e.equals(oldStatus))
                .findFirst().orElse(Constants.COMMON_STATUS.ACTIVE);
    }

    public static String nextCode(String code) {
        int current = StringUtils.isNumeric(code) ? Integer.parseInt(code) : 0;
        return String.format("%03d", ++current);
    }

    public static String replaceTemp(String content, String key, String value) {
        return content.replace("{" + key + "}", value);
    }

    public static boolean searchCondition(String left, String right) {
        if (rmVNString(CommonUtils.toUpperCase(left)) == null || rmVNString(CommonUtils.toUpperCase(right)) == null) {
            return false;
        }
        return rmVNString(CommonUtils.toUpperCase(left)).indexOf(rmVNString(CommonUtils.toUpperCase(right))) > -1;
    }
}
