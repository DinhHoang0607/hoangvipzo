//package vn.gtel.app_mng.account.service;
//
//import net.sf.jasperreports.engine.JRException;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.multipart.MultipartFile;
//import vn.gtel.app_mng.account.dto.AccountRequestDTO;
//import vn.gtel.app_mng.account.dto.AccountDetailServiceRequestDTO;
//import vn.gtel.app_mng.account.filter.AccountFilter;
//import vn.gtel.app_mng.common.dto.response.ResponseBase;
//
//import java.io.FileNotFoundException;
//import java.io.IOException;
//
//public interface AccountDetailService {
//	ResponseBase submitAccount(AccountRequestDTO accountDetailDTO) throws Exception;
//	ResponseBase actionAccount(String id, String type, String url, String method) throws Exception;
//
//	ResponseBase listAccount(AccountFilter textFilter);
//	ResponseBase detailAccount(String id) throws Exception;
//
//
//	ResponseBase submitAccount(AccountDetailServiceRequestDTO accountDetailServiceRequestDTO) throws Exception;
//	ResponseBase detailAccountService(String id) throws Exception;
//	ResponseEntity export(String type) throws FileNotFoundException, JRException;
//
//	ResponseBase importExcel(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;
//}
