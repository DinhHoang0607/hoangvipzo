package vn.gtel.app_mng.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class EncryptAndDecryptTheDatabaseUtil {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${config.secret}")
    private String secret;

    @Value("${config.encode}")
    private String encode;

    public String encrypt(String encryptedData) {
        if(encode.equalsIgnoreCase("true")){
            String sql = "SELECT encrypt_string(?,?) as enc FROM dual";
            return jdbcTemplate.queryForObject(sql, new Object[]{encryptedData, secret}, String.class);
        }

        return encryptedData;
    }

    public String decrypt(String encryptedData) {
        if(encode.equalsIgnoreCase("true")) {
            String sql = "SELECT decrypt_string(?,?) as enc FROM dual";
            return jdbcTemplate.queryForObject(sql, new Object[]{encryptedData, secret}, String.class);
        }
        return encryptedData;
    }
}
