package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_CH_CHUNG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GeneralConfig extends AuditModelBase {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "KEY")
    private String key;

    @Basic
    @Column(name = "VALUE")
    private String value;

    public GeneralConfig(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
