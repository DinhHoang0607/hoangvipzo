/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  RoleTempAppDTO.java
 * Created By :  tuannp
 * Created at :  12/20/21, 3:55 PM
 * LastModified  :  12/20/21, 2:02 PM
 */

package vn.gtel.app_mng.role.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleApplicationDTO {

	@Column(name = "APPLICATION")
	@Size(max = 36, message = "error.common.size.max.36")
	private String application;

//	@Column(name = "APP_NAME")
//	@Size(max = 100, message = "error.100085.size.max.100")
//	private String appName;
}
