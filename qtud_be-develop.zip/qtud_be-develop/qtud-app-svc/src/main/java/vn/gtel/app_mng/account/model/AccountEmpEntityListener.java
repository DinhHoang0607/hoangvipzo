package vn.gtel.app_mng.account.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vn.gtel.app_mng.common.util.EncryptAndDecryptTheDatabaseUtil;

import javax.persistence.*;

@Component
public class AccountEmpEntityListener {

    @Autowired
    private EncryptAndDecryptTheDatabaseUtil encryptAndDecryptTheDatabaseUtil;

    @PrePersist
    @PreUpdate
    public void encryptPhoneNumberData(AccountEmployeeDetail empDetail){
        if(empDetail.getPhone() != null){
            String encryptedData = encryptAndDecryptTheDatabaseUtil.encrypt(empDetail.getPhone());
            empDetail.setPhone(encryptedData);
        }
        if(empDetail.getPoliceNumber() != null){
            String encryptedData = encryptAndDecryptTheDatabaseUtil.encrypt(empDetail.getPoliceNumber());
            empDetail.setPoliceNumber(encryptedData);
        }
    }

    @PostLoad
    @PostPersist
    @PostUpdate
    public void decryptData(AccountEmployeeDetail empDetail){
        if(empDetail.getPhone() != null){
            String decryptData = encryptAndDecryptTheDatabaseUtil.decrypt(empDetail.getPhone());
            empDetail.setPhone(decryptData);
        }
        if(empDetail.getPoliceNumber() != null){
            String decryptData = encryptAndDecryptTheDatabaseUtil.decrypt(empDetail.getPoliceNumber());
            empDetail.setPoliceNumber(decryptData);
        }
    }
}
