package vn.gtel.app_mng.category.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TBL_DM_CAP_DON_VI")
public class OrganizationLevel extends AuditCategoryModel {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;


}
