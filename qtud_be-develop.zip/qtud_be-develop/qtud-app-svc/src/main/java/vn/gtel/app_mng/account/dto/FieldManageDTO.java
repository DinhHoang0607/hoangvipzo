package vn.gtel.app_mng.account.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Basic;
import javax.persistence.Column;

@Getter
@Setter
public class FieldManageDTO {
    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "TEN")
    private String name;

    public FieldManageDTO(String code, String name) {
        this.code = code;
        this.name = name;
    }
}
