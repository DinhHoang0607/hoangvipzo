package vn.gtel.app_mng.account.dto.excelObj;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportAccountDTO {

    private String orgCode;
    private String orgName;
    private String orgSign;

    private String totalAccount;

    private String totalNewAccount;
    private String totalNewAccountFromDate;

    private String totalLoginAccount;
    private String totalLoginAccountFromDate;

}
