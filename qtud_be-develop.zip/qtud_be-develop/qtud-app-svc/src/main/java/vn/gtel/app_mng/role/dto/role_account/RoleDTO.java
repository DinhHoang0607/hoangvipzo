package vn.gtel.app_mng.role.dto.role_account;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;


@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = MenuActionDTO.class),
//	@JsonSubTypes.Type(value = RoleFieldDTO.class),
        @JsonSubTypes.Type(value = RoleServiceDTO.class)
})
@Data
public abstract class RoleDTO {

    private Long disabled;

}
