/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  BackUpDataConfigItemRqDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/7/22, 4:06 PM
 *
 */

package vn.gtel.app_mng.config.dto;

import lombok.Data;
import lombok.Value;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.validation.constraints.*;

@Data
public class BackUpDataConfigItemRqDTO {

    @Basic
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Pattern(regexp = "^(CATEGORY|INTERNAL_TOP_SECRET|LOCAL_CENTER_TOP_SECRET)$", message = "Phân loại in (CATEGORY|INTERNAL_TOP_SECRET|LOCAL_CENTER_TOP_SECRET) ")
    @Column(name = "PHAN_LOAI")
    @NotEmpty
    private String type;

    @Basic
    @Column(name = "GIO")
    @NotNull(message = "error.common.validate.not.null")
    @Max(value = 100000,message = "error.common.validate.max.value.100000")
    @Min(value = 0L,message = "error.common.validate.only.positive.number")
    private Long hour;

    @Basic
    @Column(name = "THANG")
    @Max(value = 100000,message = "error.common.validate.max.value.100000")
    @Min(value = 0L,message = "error.common.validate.only.positive.number")
    @NotNull(message = "error.common.validate.not.null")
    private Long month;

    @Basic
    @Column(name = "DUONG_DAN")
    private String path;

}
