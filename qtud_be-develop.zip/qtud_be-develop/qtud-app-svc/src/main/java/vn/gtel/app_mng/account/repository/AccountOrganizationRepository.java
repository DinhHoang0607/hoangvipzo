package vn.gtel.app_mng.account.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.account.model.AccountOrganization;
import vn.gtel.app_mng.report.dto.filter.StatisticFilter;

@Repository
public interface AccountOrganizationRepository extends JpaRepository<AccountOrganization, String> {

    List<AccountOrganization> findByAccount(String account);

    AccountOrganization findByIdAndStatus(String id, Integer status);

    AccountOrganization findByAccountAndStatus(String account, Integer status);

//    int sumAccountTransfer();
    @Query("select e from AccountOrganization e where (1=1) and (:#{#dto.getOriginOrganization()} is null " +
            " OR e.oldOrganization = :#{#dto.getOriginOrganization()} " +
            " OR e.newOrganization = :#{#dto.getOriginOrganization()})" +
            " and (:#{#dto.getFromDate()} is null OR e.createdDate >= :#{#dto.getFromDate()}) " +
            " and (:#{#dto.getToDate()} is null OR e.createdDate <= :#{#dto.getToDate()})")
    List<AccountOrganization> findReportOrganization(StatisticFilter dto);
}
