package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupTransferOrgFilter extends TextFilter {
    private String account;
    private List<String> excludeAccount;
    private String organization;
    private String policeNumber;
    private Integer positionType;

    public GroupTransferOrgFilter(Integer page, Integer size, String keySearch, String organization, String account, List<String> excludeAccount, String policeNumber, Integer positionType) {
        super(page, size, keySearch);
        this.organization = organization;
        this.account = account;
        this.excludeAccount = excludeAccount;
        this.policeNumber = policeNumber;
        this.positionType = positionType;
    }
}
