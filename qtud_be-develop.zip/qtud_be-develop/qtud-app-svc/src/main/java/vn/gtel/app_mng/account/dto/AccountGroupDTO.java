package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditBaseDTO;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountGroupDTO extends AuditBaseDTO {
    @Size(max = Constants.VALID.MAX_LENGTH_1000, message = "error.common.validate.max.size.250")
    private String description;
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String name;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String code;
    private List<CodeItemWithActionDTO> accounts;
    private List<CodeItemWithActionDTO> groupRoles;
    private String statusName;
}
