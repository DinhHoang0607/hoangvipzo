package vn.gtel.app_mng.account.generator;

import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.stereotype.Component;
import vn.gtel.app_mng.account.filter.AccountFilter;

import java.lang.reflect.Method;
import java.util.StringJoiner;

@Component("CustomKeyGenerator")
public class CustomKeyGenerator implements KeyGenerator {
    @Override
    public Object generate(Object target, Method method, Object... params) {
        if (params.length > 0 && params[0] instanceof AccountFilter) {
            AccountFilter dto = (AccountFilter) params[0];
            StringJoiner key = new StringJoiner(",");
            if (dto.getPage() != null) key.add("page=" + dto.getPage());
            if (dto.getSize() != null) key.add("size=" + dto.getSize());
            if (dto.getTypeEmployee() != null) key.add("typeEmployee=" + dto.getTypeEmployee());
            if (dto.getKeySearch() != null) key.add("keySearch=" + dto.getKeySearch());
            if (dto.getOrganization() != null) key.add("organization=" + dto.getOrganization());
            if (dto.getOrganizationParent() != null) key.add("organizationParent=" + dto.getOrganizationParent());
            if (dto.getType() != null) key.add("type=" + dto.getType());
            if (dto.getAccount() != null) key.add("account=" + dto.getAccount());
            if (dto.getAccountName() != null) key.add("accountName=" + dto.getAccountName());
            if (dto.getName() != null) key.add("name=" + dto.getName());
            if (dto.getPosition() != null) key.add("position=" + dto.getPosition());
            if (dto.getMilitary() != null) key.add("military=" + dto.getMilitary());
            if (dto.getStatus() != null) key.add("status=" + dto.getStatus());
            if (dto.getOrganizationLevel() != null) key.add("organizationLevel=" + dto.getOrganizationLevel());
            if (dto.getStatusConfirmInfo() != null) key.add("statusConfirmInfo=" + dto.getStatusConfirmInfo());
            return key.toString();
        }
        return null;
    }
}
