/*
 *  UTF8Control.java
 *  Copyright (c) 2021.
 *  Modification Logs:
 *  DATE                AUTHOR             DESCRIPTION
 *  8/10/21, 8:44 AM    TuanNP             File is created
 *
 */

package vn.gtel.app_mng.common.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class UTF8Control extends ResourceBundle.Control {
  public ResourceBundle newBundle(String baseName, Locale locale, String format,
      ClassLoader loader, boolean reload)
      throws IllegalAccessException, InstantiationException, IOException {
    if (baseName == null || locale == null || format == null || loader == null) {
      throw new NullPointerException();
    }
    ResourceBundle bundle = null;
    String bundleName = toBundleName(baseName, locale);
    String resourceName = toResourceName(bundleName, "properties");
    InputStream stream = null;
    try {
      if (reload) {
        URL url = loader.getResource(resourceName);
        if (url != null) {
          URLConnection connection = url.openConnection();
          if (connection != null) {
            connection.setUseCaches(false);
            stream = connection.getInputStream();
          }
        }
      } else {
        stream = loader.getResourceAsStream(resourceName);
      }
      if (stream != null) {
        InputStreamReader isr = null;
        try {
          isr = new InputStreamReader(stream, "UTF-8");
          bundle = new PropertyResourceBundle(isr);
          stream.close();
          return bundle;
        } finally {
          if (isr != null) {
            isr.close();
          }
          if (stream != null) {
            stream.close();
          }
        }
      }
    } catch (IOException e) {
      return null;
    }
    return null;
  }


  public static void CloseInputStreamReader(InputStreamReader inputStreamReader){
    if (inputStreamReader != null){
      try {
        inputStreamReader.close();
      }catch (IOException e){
        e.getMessage();
      }
    }
  }
}
