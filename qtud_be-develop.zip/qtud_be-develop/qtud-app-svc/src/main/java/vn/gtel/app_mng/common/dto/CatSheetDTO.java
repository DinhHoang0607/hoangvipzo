package vn.gtel.app_mng.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CatSheetDTO {

    private int sheetAt;
    private List<IExcelItem> data;

}
