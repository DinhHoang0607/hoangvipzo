
/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationCallStoredDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 10:43 AM
 */

package vn.gtel.app_mng.category.dto.storedObj;

import vn.gtel.app_mng.category.dto.req.UsbTokenFilterDTO;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterV2DTO;
import vn.gtel.app_mng.category.dto.res.UsbTokenHisResponseDTO;
import vn.gtel.app_mng.category.dto.res.UsbTokenResponseDTO;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.common.userinfo.AccountLogonContext;

import java.util.HashMap;
import java.util.Map;

public class UsbTokenCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_USB_TOKEN";
    private static final String PROC_SEARCH_NAME = "PROC_SEARCH_USB_TOKEN";
    private static final String PROC_FIND_BY_ID_NAME = "PROC_FIND_USB_TOKEN";
    private static final String PROC_FIND_HISTORY = "PROC_FIND_HISTORY_USB_TOKEN";

    private static final String IN_CODE = "PI_CODE";

    private static final String IN_ORG_LOGIN = "PI_ORG_LOGIN";
    private static final String IN_TEXT_SEARCH = "PI_TEXT_SEARCH";
    private static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    private static final String IN_ORGANIZATION = "PI_ORGANIZATION";
    private static final String ID_TRANG_THAI = "PI_TRANG_THAI";
    private static final String IN_ACCOUNT = "PI_ACCOUNT";
    private static final String IN_EXPIRED_FROM = "PI_HET_HAN_TU";
    private static final String IN_EXPIRED_TO = "PI_HET_HAN_DEN";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_SIZE = "PI_SIZE";
    private static final String IN_ID = "PI_ID";
    private static final String IN_TYPE_DATE = "PI_TYPE_DATE";

    private static final String IN_LOAI_CHUNG_THU_SO = "pi_LOAI_CHUNG_THU_SO";
    private static final String IN_SO_CMND_CCCD_HO_CHIEU = "pi_SO_CMND_CCCD_HO_CHIEU";
    private static final String IN_HO_TEN = "pi_HO_TEN";
    private static final String IN_SO_DIEN_THOAI = "pi_SO_DIEN_THOAI";
    private static final String IN_MA = "pi_MA";
    private static final String IN_DIA_CHI_THU = "pi_DIA_CHI_THU";
    private static final String IN_TINH_THANH_PHO = "pi_TINH_THANH_PHO";
    private static final String IN_CO_QUAN_CONG_TAC = "pi_CO_QUAN_CONG_TAC";


    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(UsbTokenResponseDTO.class);
    }

    ;

    public UsbTokenCallStoredDTO(UsbTokenFilterDTO usbTokenFilterDTO) {
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_CODE, usbTokenFilterDTO.getCode());
        params.put(IN_TEXT_SEARCH, usbTokenFilterDTO.getTextSearch());
        params.put(IN_TYPE_DATE, usbTokenFilterDTO.getTypeDate());
        params.put(ID_TRANG_THAI, usbTokenFilterDTO.getStatus());
        params.put(IN_ACCOUNT, usbTokenFilterDTO.getAccount());
        params.put(IN_ORGANIZATION, usbTokenFilterDTO.getOrganization());
        params.put(IN_EXPIRED_FROM, CommonUtils.yyyyMMddInstant(usbTokenFilterDTO.getExpiredDateFrom()));
        params.put(IN_EXPIRED_TO, CommonUtils.yyyyMMddInstant(usbTokenFilterDTO.getExpiredDateTo()));
        params.put(IN_PAGE, usbTokenFilterDTO.getPage());
        params.put(IN_SIZE, usbTokenFilterDTO.getSize());
        setParams(params);
    }

    public UsbTokenCallStoredDTO(UsbTokenFilterV2DTO usbTokenFilterV2DTO) {
        setBase();
//        setResponseType(UsbTokenV2ResponseDTO.class);
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_TEXT_SEARCH, usbTokenFilterV2DTO.getTextSearch());
        params.put(IN_KEY_SEARCH, usbTokenFilterV2DTO.getTextSearch());
        params.put(IN_ORGANIZATION, usbTokenFilterV2DTO.getOrganization());
        params.put(IN_CODE, usbTokenFilterV2DTO.getCode());
        params.put(IN_ACCOUNT, usbTokenFilterV2DTO.getAccount());
        params.put(IN_EXPIRED_FROM, usbTokenFilterV2DTO.getExpired_from());
        params.put(IN_EXPIRED_TO, usbTokenFilterV2DTO.getExpired_to());
        params.put(IN_TYPE_DATE, usbTokenFilterV2DTO.getType_date());
        params.put(ID_TRANG_THAI, usbTokenFilterV2DTO.getStatus());
        params.put(IN_PAGE, usbTokenFilterV2DTO.getPage());
        params.put(IN_SIZE, usbTokenFilterV2DTO.getSize());

        params.put(IN_MA, usbTokenFilterV2DTO.getCode());
        params.put(IN_LOAI_CHUNG_THU_SO, usbTokenFilterV2DTO.getDigitalCertificateType());
        params.put(IN_SO_CMND_CCCD_HO_CHIEU, usbTokenFilterV2DTO.getCmndCccd());
        params.put(IN_HO_TEN, usbTokenFilterV2DTO.getFullName());
        params.put(IN_SO_DIEN_THOAI, usbTokenFilterV2DTO.getPhoneNumber());
        params.put(IN_DIA_CHI_THU, usbTokenFilterV2DTO.getAddress());
        params.put(IN_TINH_THANH_PHO, usbTokenFilterV2DTO.getCity());
        params.put(IN_CO_QUAN_CONG_TAC, usbTokenFilterV2DTO.getOrganization());
        params.put(IN_ORG_LOGIN, AccountLogonContext.currentUser().getOrganization());
        setParams(params);
    }

    public UsbTokenCallStoredDTO(String id) {
        setBase();
        setStoredName(PROC_FIND_BY_ID_NAME);
        params.put(IN_ID, id);
        setParams(params);
    }

    public UsbTokenCallStoredDTO(String code, boolean isHistory) {
        setBase();
        setResponseType(UsbTokenHisResponseDTO.class);
        setStoredName(PROC_FIND_HISTORY);
        params.put(IN_CODE, code);
        setParams(params);
    }
}
