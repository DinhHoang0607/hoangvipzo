package vn.gtel.app_mng.category.dto.res;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.gtel.app_mng.category.model.ProfileStatus;
import vn.gtel.app_mng.category.model.ProfileType;
import vn.gtel.app_mng.common.config.constant.StatusEnum;

import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
public class ProfileStatusResponseDto {
    private String id;

    private String typeCode;

    private String typeName;

    private String code;

    private String name;

    private String value;

    private String description;

    private Integer status;
    private String codeXLVP;
    private String codeTNGT;

    private StatusEnum statusName;

    public ProfileStatusResponseDto(ProfileStatus entity) {
        this.id = entity.getId();
        this.code = entity.getCode();
        this.name = entity.getName();
        this.value = entity.getValue();
        this.description = entity.getDescription();
        this.status = entity.getStatus();
        this.codeXLVP = entity.getCodeXLVP();
        this.codeTNGT = entity.getCodeTNGT();
        this.statusName = StatusEnum.parseByCode(this.status);
        ProfileType type = entity.getType();
        if (Objects.nonNull(type)) {
            this.typeCode = type.getCode();
            this.typeName = type.getName();
        }
    }
}
