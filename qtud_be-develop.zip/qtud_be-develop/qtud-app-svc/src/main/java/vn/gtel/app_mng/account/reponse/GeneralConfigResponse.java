package vn.gtel.app_mng.account.reponse;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.Column;
import java.time.Instant;

@Data
public class GeneralConfigResponse {

    @Column(name = "ID")
    private String id;

    @Column(name = "KEY")
    private String key;
    @Column(name = "VALUE")
    private String value;

    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    @Column(name = "NGAY_TAO")
    private Instant createdDate;

    @Column(name = "NGUOI_TAO")
    private String createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    @Column(name = "NGAY_SUA")
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    private String lastModifiedBy;

    @Column(name = "TRANG_THAI")
    private Integer status;
}
