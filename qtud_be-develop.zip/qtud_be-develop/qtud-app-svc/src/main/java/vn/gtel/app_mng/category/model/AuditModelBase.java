package vn.gtel.app_mng.category.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class AuditModelBase implements Serializable {

    @Column(name = "NGAY_TAO")
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGUOI_TAO")
    @CreatedBy
    private String createdBy;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    @LastModifiedBy
    private String lastModifiedBy;

    @Basic
    @Column(name = "TRANG_THAI")
    private Integer status;

    @Basic
    @Column(name = "MO_TA")
    private String description;

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "THU_TU")
    private Long order;

    public AuditModelBase(Integer status) {
        this.status = status;
    }

    @PrePersist
    public void prePersist() {
        if(this.status == null){
            this.status = 1;
        }
//        Account logonAccount = UserLogonUtils.currentUser();
//        if (logonAccount != null) {
//            this.createdById = UserLogonUtils.currentUser().getId();
//            this.lastModifiedById = UserLogonUtils.currentUser().getId();
//        } else {
//            this.createdById = "LOCAL";
//            this.lastModifiedById = "LOCAL";
//        }
    }

    @PreUpdate
    public void preUpdate() {
//        Account logonAccount = UserLogonUtils.currentUser();
//        if (logonAccount != null) {
//            this.lastModifiedById = UserLogonUtils.currentUser().getId();
//        } else {
//            this.lastModifiedById = "LOCAL";
//        }
    }
}
