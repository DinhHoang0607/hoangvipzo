package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.gtel.app_mng.category.model.Position;
import vn.gtel.app_mng.category.model.Rank;

import java.util.List;

public interface RankCatRepo extends JpaRepository<Rank,String> {

    Rank findByNameAndStatus(String name, Integer status);
    Rank findByCodeAndStatus(String code, Integer status);

    List<Rank> findByStatusOrderByCodeAsc(Integer status);

    boolean existsByCodeAndStatus(String code, int status);
}
