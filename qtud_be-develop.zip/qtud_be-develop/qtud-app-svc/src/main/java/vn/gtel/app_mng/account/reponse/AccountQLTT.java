package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
public class AccountQLTT {
    @Column(name = "ID")
    private String id;

    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "HO_TEN")
    private String fullName;

    @Basic
    @Column(name = "CHUC_VU")
    private String position;

    @Basic
    @Column(name = "TEN_CHUC_VU")
    private String positionName;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

}
