package vn.gtel.app_mng.account.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonTypeName("accountDetail")
public class AccountEmployeeDetailDTO extends AccountDetailDTO {

    private String id;

    @NotEmpty(message = "error.common.validate.not.empty")
//	@Size(min = Constants.VALID.MIN_LENGTH_NAME_5, message = "error.common.validate.min.size.5")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String fullName;

    //@NotEmpty(message = "error.common.validate.not.empty")
//	@Size(min = Constants.VALID.MIN_LENGTH_ACCOUNT_3, message = "error.common.validate.min.size.3")
    @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
    private String policeNumber;

    private String citizenID;

    //@NotEmpty(message = "error.common.validate.not.empty")
    private String position;
    private String positionName;
    private String displayPosition;

    //@NotEmpty(message = "error.common.validate.not.empty")
    private String military;
    private String militaryName;


    private String academicLevel;
    private String politicalLevel;

    private String dignity;

    private String phone;
    private Instant birthDate;
    private String gender;
    private String genderName;

    private String description;
    //Anh chu ki
    //private List<FileFeedBackDTO> files;
    private String signature;

    private int accountType;

    private int accountInOrganization;

    private String directManager;

    private Integer investigativeAgencyType;

    private List<String> orgManage = new ArrayList<>();

    private List<String> fieldManage = new ArrayList<>();

    private List<String> groups = new ArrayList<>();
}
