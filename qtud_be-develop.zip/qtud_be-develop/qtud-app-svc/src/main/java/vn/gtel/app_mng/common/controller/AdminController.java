/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  CacheController.java
 *  * Created By :  tuannp
 *  * Created at :  12/13/21, 11:16 AM
 *  * LastModified  :  6/18/21, 4:56 PM
 *
 */

package vn.gtel.app_mng.common.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.account.repository.AccountEmployeeDetailRepository;
import vn.gtel.app_mng.category.model.Application;
import vn.gtel.app_mng.category.repo.ApplicationRepo;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/admin")

public class AdminController {

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private AccountEmployeeDetailRepository accountEmployeeDetailRepository;
    @Autowired
    private ApplicationRepo applicationRepo;

    @GetMapping(value = "/cache/clear")
    public ResponseBase clearCache() {
        for (String name : cacheManager.getCacheNames()) {
            System.out.println("cache name" + name);
            Object obj = cacheManager.getCache(name);
            System.out.println("obj name" + obj);
            cacheManager.getCache(name).clear();
        }


        return new ResponseBase("Clear cache success !");
    }

    @GetMapping(value = "/cache/clear/fe")
    public ResponseBase clearCacheFe(@RequestParam String account, @RequestParam String app) {
        if(account != null && !account.isEmpty() && app != null && !app.isEmpty() ){
            redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + app + "_" + account);
            return new ResponseBase("Clear cache " + Constants.REDIS_KEY.ROLE_APP + app + "_" + account + " success !");
        } else {
            List<AccountEmployeeDetail> users = accountEmployeeDetailRepository.findAll();
            List<Application> applications = applicationRepo.findAll();
            if(!users.isEmpty() && !applications.isEmpty()){
                for (AccountEmployeeDetail accountEmployeeDetail: users){
                    for (Application application: applications){
                        String userName = accountEmployeeDetail.getAccount() != null ? accountEmployeeDetail.getAccount() : "";
                        String appCode = application.getCode() != null ? application.getCode() : "";
                        redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + appCode + "_" + userName);
                    }
                }
            }
        }
        return new ResponseBase("Clear cache success !");
    }

    @GetMapping(value = "/cache/clear/app-account")
    public ResponseBase clearCacheApp(@RequestParam String account) {
        if(account != null && !account.isEmpty()){
            redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + account);
        }else {
            List<AccountEmployeeDetail> users = accountEmployeeDetailRepository.findAll();
            if(!users.isEmpty()){
                for (AccountEmployeeDetail accountEmployeeDetail: users){
                    String userName = accountEmployeeDetail.getAccount() != null ? accountEmployeeDetail.getAccount() : "";
                    redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + userName);
                }
            }
        }
        return new ResponseBase("Clear cache success !");
    }

//    @GetMapping(value = "/restart")
//    public ResponseBase restart() {
//        AppApplication.restart();
//        return new ResponseBase("Waiting to restart application !");
//    }

    @GetMapping(value = "/status")
    public ResponseBase status() {
        return new ResponseBase("Is active !");
    }

    @GetMapping(value = "/cache/clear/get-me")
    public ResponseBase clearCacheGetMe(@RequestParam String account) {
        if(account != null && !account.isEmpty()){
            redisTemplate.delete(Constants.REDIS_KEY.GET_ME + account);
        }else {
            List<AccountEmployeeDetail> users = accountEmployeeDetailRepository.findAll();
            if(!users.isEmpty()){
                for (AccountEmployeeDetail accountEmployeeDetail: users){
                    String userName = accountEmployeeDetail.getAccount() != null ? accountEmployeeDetail.getAccount() : "";
                    redisTemplate.delete(Constants.REDIS_KEY.GET_ME + userName);
                }
            }
        }
        return new ResponseBase("Clear cache success !");
    }

//    @GetMapping(value = "/get-sec-app-cf")
//    public ResponseBase getSec(@RequestParam String appCode){
//        return new ResponseBase(redisTemplate.opsForValue().get(Constants.REDIS_KEY.SEC_APP_CF+appCode));
//    }

}
