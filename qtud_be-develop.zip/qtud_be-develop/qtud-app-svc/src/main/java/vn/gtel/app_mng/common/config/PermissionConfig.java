//package vn.gtel.app_mng.common.config;
//
//import com.google.gson.Gson;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.annotation.Order;
//import org.springframework.data.redis.core.RedisTemplate;
//import vn.gtel.app_mng.common.config.constant.Constants;
//import vn.gtel.app_mng.common.dto.response.PermissionForLogDTO;
//import vn.gtel.app_mng.common.dto.response.PermissionForLogListDTO;
//import vn.gtel.app_mng.common.dto.response.ResponseBase;
//import vn.gtel.app_mng.role.service.RoleService;
//
//import java.util.List;
//
////@Configuration
////@Order(-1)
//public class PermissionConfig {
//    @Autowired
//    private RedisTemplate redisTemplate;
//    @Autowired
//    private RoleService roleService;
//    @Bean
//    public void pushPermissionForLogToRedis() throws IllegalAccessException {
//        PermissionForLogListDTO permissionForLogListDTO = (PermissionForLogListDTO) ((ResponseBase)roleService.getPermissionForLog(Constants.APPLICATION_CODE.QTUD)).getData();
//        List<PermissionForLogDTO> log = permissionForLogListDTO.getPermissionForLogDTOS();
//        for(PermissionForLogDTO permissionForLogDTO : log){
//            redisTemplate.opsForValue().set(permissionForLogDTO.getAppCode()+"_"+permissionForLogDTO.getMethod()+"_"+permissionForLogDTO.getEndpoint(), new Gson().toJson(permissionForLogDTO));
//        }
//    }
//}
