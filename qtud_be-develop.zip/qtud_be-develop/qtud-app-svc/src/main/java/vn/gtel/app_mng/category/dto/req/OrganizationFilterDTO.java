/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationRequestDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 11:28 AM
 */

package vn.gtel.app_mng.category.dto.req;

import lombok.Data;

import java.io.Serializable;

@Data
public class OrganizationFilterDTO implements Serializable {

    public OrganizationFilterDTO(String idParent, Long page, Long size) {
        this.idParent = idParent;
        this.page = page;
        this.size = size;
    }

    private String idParent;
    private Long page;
    private Long size;

}
