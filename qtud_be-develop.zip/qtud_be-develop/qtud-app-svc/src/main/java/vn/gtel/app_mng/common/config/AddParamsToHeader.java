package vn.gtel.app_mng.common.config;

import vn.gtel.app_mng.common.config.constant.CsrfConstants;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class AddParamsToHeader extends HttpServletRequestWrapper {
    public AddParamsToHeader(HttpServletRequest request) {
        super(request);
    }

    public String getHeader(String name){

        if (CsrfConstants.CSRF_FIELD_HEADER.equalsIgnoreCase(name)){
            return CsrfConstants.CSRF_TOKEN;
        }

        String header = super.getHeader(name);
        return (header != null) ? header : super.getParameter(name);
    }

    public Enumeration getHeaderNames() {
        List<String> names = Collections.list(super.getHeaderNames());
        names.addAll(Collections.list(super.getHeaderNames()));
        return Collections.enumeration(names);
    }
}
