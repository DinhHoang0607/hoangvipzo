package vn.gtel.app_mng.category.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

@Entity
@Table(name = "TBL_DM_CHUC_NANG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Menu extends AuditModel {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "BIEU_TUONG")
    private String icon;

    @Basic
    @Column(name = "CHUC_NANG_CHA")
    private String parentMenuCode;

    @Basic
    @Column(name = "THANH_PHAN")
    private String component;

    @Basic
    @Column(name = "URL")
    private String url;

    @Basic
    @Column(name = "UNG_DUNG")
    private String appCode;

    @Basic
    @Column(name = "THU_TU")
    private Integer order;

    @Basic
    @Column(name = "LOAI_CHUC_NANG")
    private Integer typeMenu;

    @Basic
    @Column(name = "END_POINT")
    private String endPoint;

    @Basic
    @Column(name = "MA_KHAC")
    private String codeOther;

}
