package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
public class FieldManageResponse {
    @Basic
    @Column(name = "MA")
    private String fieldCode;

    @Basic
    @Column(name = "TEN")
    private String fieldName;
}
