package vn.gtel.app_mng.category.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.model.AuditModel;

@Data
@NoArgsConstructor
@AllArgsConstructor	
@MappedSuperclass
public abstract class AuditCategoryCommon extends AuditModel{
	
    @Basic
    @Column(name = "MA")
    private String code;
    
    @Basic
    @Column(name = "TEN")
    private String name;
    
    @Basic
    @Column(name = "THU_TU")
    private Long order;

}
