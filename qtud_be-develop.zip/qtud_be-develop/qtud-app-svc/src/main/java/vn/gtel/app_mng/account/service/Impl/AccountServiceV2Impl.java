package vn.gtel.app_mng.account.service.Impl;


import com.google.gson.Gson;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.dto.AccountDetailOrgDTO;
import vn.gtel.app_mng.account.dto.OrganizationManageDTO;
import vn.gtel.app_mng.account.dto.storeObj.AccountCallStoredDTO;
import vn.gtel.app_mng.account.filter.AccountFilter;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.reponse.*;
import vn.gtel.app_mng.account.repository.AccountGroupAccountRepository;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.account.repository.GeneralConfigRepository;
import vn.gtel.app_mng.account.service.AccountServiceV2;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.DetailResponse;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.EncryptAndDecryptTheDatabaseUtil;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.common.util.StringUtils;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.ValidationException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountServiceV2Impl implements AccountServiceV2 {
    private final CallStoredRepository callStoredRepository;
    private final TrimSpaceUtil trimSpaceUtil;
    private final RedisTemplate redisTemplate;
    private final EncryptAndDecryptTheDatabaseUtil encryptAndDecryptTheDatabaseUtil;
    private final AccountRepository accountRepository;
    private final GeneralConfigRepository generalConfigRepository;
    private final AccountGroupAccountRepository accountGroupAccountRepository;
    @Value("${toggle.cache.dghc.search:1}")
    private  Long enableSearchCache;
    @Value("${secret_key.value:http}")
    private  String secret_key;
    @Override
    public ResponseBase listAccount(AccountFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);

        if (textFilter instanceof AccountFilter) {
            AccountFilter accountFilter = (AccountFilter) textFilter;
            if (!Constants.ACCOUNT_EMP_TYPE.ADMIN.toString().equals(accountFilter.getTypeEmployee())) {
                if (enableSearchCache != null && enableSearchCache.equals(1L)) {
//                    log.info("------------cache----------------");
                    List<AccountResponse> employees = cacheAll();
                    List<AccountResponse> resultRes = new ArrayList<>();
                    if (accountFilter.getOrganization() != null) {
                        resultRes = employees.stream().filter(e -> e.getOrganization() != null && e.getOrganization().equals(accountFilter.getOrganization())).collect(Collectors.toList());
                    } else {
                        resultRes = employees;
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getKeySearch())) {
                        resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getAccount(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getPoliceNumber(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganization(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationName(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getSignOrganization(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getName(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationNew(), accountFilter.getKeySearch())).collect(Collectors.toList());
                    }

//                    if (StringUtils.isNotEmpty(accountFilter.getAccount()) && !"admin".equals(accountFilter.getAccount())) {
//                        resultRes = resultRes.stream().filter(e -> e.getCreatedBy() != null && e.getCreatedBy()
//                                .equalsIgnoreCase(accountFilter.getAccount())).collect(Collectors.toList());
//                    }

                    if (StringUtils.isNotEmpty(accountFilter.getAccount()) && !"admin".equals(accountFilter.getAccount())) {
                        resultRes = resultRes.stream().filter(e -> validAccountOfSubAdmin(e, accountFilter)).collect(Collectors.toList());

                    }

                    if (StringUtils.isNotEmpty(accountFilter.getAccountName())) {
                        resultRes = resultRes.stream().filter(e -> e.getAccount() != null && e.getAccount().equalsIgnoreCase(accountFilter.getAccountName())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getName())) {
                        resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getName(), accountFilter.getName())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getPoliceNumber())) {
                        resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && e.getPoliceNumber().equalsIgnoreCase(accountFilter.getPoliceNumber())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getPosition())) {
                        resultRes = resultRes.stream().filter(e -> e.getPosition() != null && e.getPosition().equalsIgnoreCase(accountFilter.getPosition())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getMilitary())) {
                        resultRes = resultRes.stream().filter(e -> e.getMilitary() != null && e.getMilitary().equalsIgnoreCase(accountFilter.getMilitary())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getStatus())) {
                        resultRes = resultRes.stream().filter(e -> e.getStatus() != null && e.getStatus().toString().equalsIgnoreCase(accountFilter.getStatus())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getOrganizationLevel())) {
                        resultRes = resultRes.stream().filter(e -> e.getOrganizationLevel() != null && e.getOrganizationLevel().equalsIgnoreCase(accountFilter.getOrganizationLevel())).collect(Collectors.toList());
                    }

                    if (accountFilter.getStatusConfirmInfo() != null) {
                        resultRes = resultRes.stream().filter(e -> e.getConfirmStatus() != null && accountFilter.getStatusConfirmInfo() != null && e.getConfirmStatus().equalsIgnoreCase(accountFilter.getStatusConfirmInfo().toString())).collect(Collectors.toList());
                    }

                    if (accountFilter.getPoliceNumbers() != null && accountFilter.getPoliceNumbers().size() > 0) {
                        resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && accountFilter.getPoliceNumbers().contains(e.getPoliceNumber())).collect(Collectors.toList());
                    }

                    int page = accountFilter.getPage();
                    int size = accountFilter.getSize();
                    List<AccountResponse> finalResultRes;
                    if (page * size + size <= resultRes.size()) {
                        finalResultRes = resultRes.subList(page * size, page * size + size);
                    } else {
                        finalResultRes = resultRes.subList(page * size, resultRes.size());
                    }
//                    ListResponse listResponse = new ListResponse(finalResultRes, (long) resultRes.size());
                    ListResponse listResponse = new ListResponse(new ArrayList<>(finalResultRes), (long) resultRes.size());
                    return new ResponseBase(listResponse);
                }
            }
        }
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    @Cacheable(value = "detailUser", key = "#id", unless = "#result == null")
    public ResponseBase detailAccount(String id) throws Exception {
        log.info("------------getDetailAccount----------------");
        Account account = accountRepository.findById(id).orElse(null);
        if (account == null) {
            throw new ValidationException("ValidationException.error.not.account");
        }

        ICallStoredObj callStoredObj = new AccountCallStoredDTO(account.getAccount(), 1);
        Object response = callStoredRepository.findById(callStoredObj);
        AccountDetailResponse accountDetailResponse = (AccountDetailResponse) response;
        if (((AccountDetailResponse) response).getPasswordStart() != null) {
            accountDetailResponse.setPasswordStart(dePassWordAES(((AccountDetailResponse) response).getPasswordStart()));
        }
        if (accountDetailResponse.getPhone() != null) {
            accountDetailResponse.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(accountDetailResponse.getPhone()));
        }
        if (accountDetailResponse.getPoliceNumber() != null) {
            accountDetailResponse.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(accountDetailResponse.getPoliceNumber()));
        }
        //
        ICallStoredObj callStoredGetHisObj = new AccountCallStoredDTO(accountDetailResponse.getAccount(), true);
        Object orgHis = callStoredRepository.getList(callStoredGetHisObj);
        accountDetailResponse.setOrgsHistories((List<AccountOrgResponse>) orgHis);

        accountDetailResponse.setTimeOut(generalConfigRepository.getByKey(Constants.CONFIG.TIME_OUT));

        List<AccountDetailOrg> accountTop = new ArrayList<>();
        List<AccountDetailOrg> accountButtom = new ArrayList<>();
        ListAccountDetailOrg listAccountTop = new ListAccountDetailOrg();
        ListAccountDetailOrg listAccountButtom = new ListAccountDetailOrg();

        ICallStoredObj callStoredObj2 = new AccountCallStoredDTO(account.getAccount(), 2); // tai khoan
        List<AccountDetailOrg> response2 = (List<AccountDetailOrg>) callStoredRepository.getList(callStoredObj2);

        accountTop = response2.stream().filter(e -> Constants.LEVEL_ACC_MANAGE.TOP.equals(e.getType())).collect(Collectors.toList());
        accountButtom = response2.stream().filter(e -> Constants.LEVEL_ACC_MANAGE.BUTTOM.equals(e.getType())).collect(Collectors.toList());


        ICallStoredObj callStoredObj1 = new AccountCallStoredDTO(account.getAccount(), 3); // don vi quan ly
        List<OrganizationManage> response1 = (List<OrganizationManage>) callStoredRepository.getList(callStoredObj1);

        listAccountTop.setAccountDetailOrgs(accountTop);
        listAccountButtom.setAccountDetailOrgs(accountButtom);
//      Phuc vu nhu cau cua frontend
        List<AccountDetailOrgDTO> accountTopConverted = accountTop.stream().map(a -> {
            AccountDetailOrgDTO acc = new AccountDetailOrgDTO();
            acc.setUsername(a.getAccount());
            acc.setAccountName(a.getFullName());
            return acc;
        }).collect(Collectors.toList());

        List<OrganizationManageDTO> response1Converted = response1.stream().map(r -> {
            OrganizationManageDTO org = new OrganizationManageDTO();
            org.setName(r.getOrganizationName());
            org.setOrganization(r.getOrganizationCode());
            return org;
        }).collect(Collectors.toList());

        accountDetailResponse.setListOrganizationManage(response1Converted);
        accountDetailResponse.setGroups(accountGroupAccountRepository.findGroupByAccount(account.getAccount()));
        DetailResponse detailResponse = new DetailResponse(accountDetailResponse);
        return new ResponseBase(detailResponse);
    }
    public boolean validAccountOfSubAdmin(AccountResponse response, AccountFilter accountFilter) {
        String accountOrg = AccountLogonContext.currentUser().getOrganization();
        if ((response.getOrganization().contains(accountOrg)) || (response.getOrganization().contains(accountOrg.substring(0, 6)) && response.getOrganization().contains(Constants.MA_DV_DOI_THUOC_HUYEN) && !response.getOrganization().contains(Constants.ORG_CODE.C08))) {
            return true;
        }
        return false;
    }

    public List<AccountResponse> cacheAll() {
        String cacheData = (String) redisTemplate.opsForValue().get(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        if (org.apache.commons.lang3.StringUtils.isEmpty(cacheData)) {
            AccountFilter textFilter = new AccountFilter(Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT, null, null, Constants.ACCOUNT_TYPE.EMPLOYEE, null, null, null, null, null, null, null, "2", null, null, (String) null);
            ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
            List<AccountResponse> res = (List<AccountResponse>) callStoredRepository.getList(callStoredObj);
            if (res != null && res.size() > 0) {
                res.stream().map(e -> {
                    if (e.getPhone() != null) {
                        e.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPhone()));
                    }
                    if (e.getPoliceNumber() != null) {
                        e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                    }
                    return e;
                }).collect(Collectors.toList());
            }
            redisTemplate.opsForValue().set(Constants.CACHE.APP.ALL_USER_EMPLOYEE, new Gson().toJson(res), 24, TimeUnit.HOURS);
            return res;
        } else {
            List<AccountResponse> res = new Gson().fromJson(cacheData, new TypeToken<List<AccountResponse>>() {
            }.getType());
            return res;
        }
    }

    private String dePassWordAES(String strPass) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, ValidationException {
        if (secret_key.length() == 16 || secret_key.length() == 24 || secret_key.length() == 32) {
            SecretKeySpec secretKeySpec = new SecretKeySpec(secret_key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
            byte[] byteEncrypted = Base64.getDecoder().decode(strPass);
            byte[] byteDecrypted = cipher.doFinal(byteEncrypted);
            String dePass = new String(byteDecrypted);
            return dePass;
        } else {
            throw new ValidationException("ValidationException.length.key");
        }
    }
}
