/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/22/22, 3:56 PM
 *
 */

package vn.gtel.app_mng.account.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.dto.AccountRequestDTO;
import vn.gtel.app_mng.account.dto.ChangePWServiceRequestDTO;
import vn.gtel.app_mng.account.dto.ReasonUpdateAccountDTO;
import vn.gtel.app_mng.account.filter.*;
import vn.gtel.app_mng.account.service.AccountService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.CommonService;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.io.IOException;
import java.sql.SQLException;

@Tag(name = "Tài khoản hệ thống tích hợp, đồng bộ")
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/account-service")
public class AccountServiceController {

    @Autowired
    private AccountService accountService;

    @Operation(summary = "Thêm mới tài khoản")
    @PostMapping(value = "")
    public ResponseBase createAccountDetail(@RequestBody @Valid AccountRequestDTO accountDetailDTO)
            throws Exception, SQLException {
        return accountService.save(accountDetailDTO);
    }

    @Operation(summary = "Sửa tài khoản")
    @PutMapping(value = "")
    public ResponseBase updateAccountDetail(@RequestBody @Valid AccountRequestDTO accountDetailDTO)
            throws Exception, SQLException {

        return accountService.save(accountDetailDTO);
    }

    @Operation(summary = "Danh sách tài khoản tích hợp, đồng bộ")
    @GetMapping(value = "")
    public ResponseBase listAccount(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250") @RequestParam(name = "keySearch", required = false) String keySearch,
                                    @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18") @RequestParam(name = "organization", required = false) String organization,
                                    @Valid @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20") @RequestParam(name = "code", required = false) String code,
                                    @RequestParam(name = "type", required = false) Integer type,
                                    @Valid @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100") @RequestParam(name = "name", required = false) String name,
                                    @Valid @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2") @RequestParam(name = "status", required = false) String status,
                                    @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                    @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                    @Valid @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
                                    @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new AccountServiceFilter(pageNumber, sizeNumber, keySearch, organization, type,
                code, name, status);
        return accountService.listAccountTHDB(textFilter);
    }

    @Operation(summary = "Kích hoạt/ hủy kích hoạt")
    @PutMapping(value = "/update")
    public ResponseBase setActiveDeActive(@RequestBody @Valid ReasonUpdateAccountDTO reasonUpdateAccountDTO) throws Exception {
        return accountService.setActiveDeActive(reasonUpdateAccountDTO);
    }

    @Operation(summary = "Tải template import tài khoản")
    @GetMapping(value = "/template")
    public ResponseEntity template() throws IOException {
        return CommonService.downloadTemplate("IMPORT_ACCOUNT_SERVICE_TEMPLATE.xlsx", "template_import_tai_khoan.xlsx");
    }

    @Operation(summary = "Kết xuất danh sách tài khoản")
    @GetMapping(value = "/export")
    public ResponseEntity export(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "code", required = false) String code,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2")
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "type", required = false) Integer type
    ) throws Exception {
        int pageNumber = Constants.DEFAULT_PAGE;
        int sizeNumber = Constants.MAX_ROW_SELECT;
        TextFilter textFilter = new AccountServiceFilter(pageNumber, sizeNumber, keySearch, organization, type,
                code, name, status);
        return accountService.exportAccountService(textFilter, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "Export docx danh sách tài khoản")
    @GetMapping(value = "/export-doc")
    public ResponseEntity exportDoc(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "code", required = false) String code,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2")
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "type", required = false) Integer type
    ) throws Exception {
        int pageNumber = Constants.DEFAULT_PAGE;
        int sizeNumber = Constants.MAX_ROW_SELECT;
        TextFilter textFilter = new AccountServiceFilter(pageNumber, sizeNumber, keySearch, organization, type,
                code, name, status);
        return accountService.exportAccountService(textFilter, Constants.EXPORT_TYPE.DOCX.toString());
    }

    @Operation(summary = "In danh sách tài khoản")
    @GetMapping(value = "/print")
    public ResponseEntity print(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "code", required = false) String code,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2")
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "type", required = false) Integer type
    ) throws Exception {
        int pageNumber = Constants.DEFAULT_PAGE;
        int sizeNumber = Constants.MAX_ROW_SELECT;
        TextFilter textFilter = new AccountServiceFilter(pageNumber, sizeNumber, keySearch, organization, type,
                code, name, status);
        return accountService.exportAccountService(textFilter, Constants.EXPORT_TYPE.PDF.toString());
    }

    @Operation(summary = "Import danh sách tài khoản")
    @PostMapping(value = "/import")
    public ResponseEntity importExcel(@RequestParam("file") MultipartFile file) throws Exception {
        return accountService.importExcelReturnResult(file);
    }

    @Operation(summary = "Đổi mật khẩu")
    @PutMapping(value = "/change-pw")
    public ResponseBase changePw(@RequestBody @Valid ChangePWServiceRequestDTO changePWRequestDTO) throws Exception {
        return accountService.changePw(changePWRequestDTO);
    }

    @Operation(summary = "Xem chi tiết tài khoản tích hợp, đồng bộ ")
    @GetMapping(value = "/{id}")
    public ResponseBase detailForAdd(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                     @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return accountService.detailAccountService(id);
    }

    @Operation(summary = "Danh sách tài khoản chưa gán vào nhóm quyền")
    @GetMapping(value = "/without-group-role/{groupRole}")
    public ResponseBase getAccountWithoutRole(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32")
            @PathVariable String groupRole,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter roleMenuFilter = new WithoutGroupRoleFilter(pageNumber, sizeNumber, keySearch, groupRole, Constants.GROUP_ROLE_TYPE.SERVICE, position, org);
        return accountService.getAccountWithoutGroupRole(roleMenuFilter);
    }

    @Operation(summary = "Danh sách tài khoản đã gán vào nhóm quyền")
    @GetMapping(value = "/in-group-role/{groupRole}")
    public ResponseBase getAccountInRole(@Valid @Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32") @PathVariable String groupRole,
                                         @Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250") @RequestParam(name = "keySearch", required = false) String keySearch,
                                         @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18") @RequestParam(name = "position", required = false) String position,

                                         @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18") @RequestParam(name = "org", required = false) String org,
                                         @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                         @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                         @Valid @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
                                         @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter roleMenuFilter = new AccountGroupRoleFilter(pageNumber, sizeNumber, keySearch, groupRole, position, org);
        return accountService.getAccountInGroupRole(roleMenuFilter);
    }

    @Operation(summary = "Danh sách tài khoản chưa gán vào nhóm quyền dịch vụ")
    @GetMapping(value = "/without-group-role-service/{groupRole}")
    public ResponseBase getAccountWithoutRole(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250") @RequestParam(name = "keySearch", required = false) String keySearch,
                                              @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                              @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                              @Valid @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
                                              @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter roleMenuFilter = new AccountWithoutGroupRoleFilter(pageNumber, sizeNumber, keySearch, Constants.GROUP_ROLE_TYPE.SERVICE, null, null, null);
        return accountService.getAccountWithoutGroupRole(roleMenuFilter);
    }

    @Operation(summary = "DDL Danh sách tài khoản tích hợp, đồng bộ")
    @GetMapping(value = "/list")
    public ResponseBase ddlAccount(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250") @RequestParam(name = "keySearch", required = false) String keySearch,
                                   @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18") @RequestParam(name = "organization", required = false) String organization,
                                   @Valid @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20") @RequestParam(name = "code", required = false) String code,
                                   @Valid @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100") @RequestParam(name = "name", required = false) String name,
                                   @Valid @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2") @RequestParam(name = "status", required = false) String status,
                                   @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                   @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                   @Valid @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
                                   @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new AccountServiceFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.SERVICE,
                code, name, Constants.ACCOUNT_STATUS.ACTIVE + "");
        return accountService.listAccountTHDB(textFilter);
    }

//    @Operation(summary = "Import danh sách tài khoản trả kết quả")
//    @PostMapping(value = "/import-return-result")
//    public ResponseEntity importReturnResultExcel(@RequestParam("file") MultipartFile file) throws Exception {
//        return accountService.importExcelReturnResult(file);
//    }

}
