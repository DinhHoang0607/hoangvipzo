/*
 * Copyright (c) 2024.
 * Project  :  app-mng
 * File  :  TextFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  26/1/24, 2:50 PM
 */

package vn.gtel.app_mng.common.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@Data
@NoArgsConstructor
@Valid
public class StatusTextFilter extends TextFilter {

    private Integer status;
    private boolean isLogin;

    public StatusTextFilter(Integer page, Integer size, String keySearch, Integer status) {
        super(page, size, keySearch);
        this.status = status;
    }

    public StatusTextFilter(Integer page, Integer size, String keySearch, Integer status,boolean isLogin) {
        super(page, size, keySearch);
        this.status = status;
        this.isLogin=isLogin;
    }
}
