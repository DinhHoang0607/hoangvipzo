package vn.gtel.app_mng.category.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.category.model.Application;
import vn.gtel.app_mng.common.dto.AuditDTO;
import vn.gtel.app_mng.role.model.GroupRoleApplication;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepo extends JpaRepository<Application, String> {
    Application findByCode(String appCode);

    Boolean existsApplicationByCode(String appCode);

    Optional<Application> findByCodeAndName(String appCode, String appName);

    Application findByCodeAndStatus(String code, Integer status);

    @Query(value = "select TEN_VIET_TAT from tbl_dm_ung_dung where ma = :code", nativeQuery = true)
    String nameApp(String code);

    boolean existsByCodeAndStatus(String code, int status);

    @Query(
            value = " select new vn.gtel.app_mng.common.dto.AuditDTO(app.id, app.code, app.name) from Application as app " +
                    " left join IntegrationSync as intSyn on app.code = intSyn.appCode " +
                    " and intSyn.status <> -1 " +
                    " where intSyn is null " +
                    " and app.status = 1 and app.type = 2 " +
                    " and ( " +
                    "      :keySearch is null or " +
                    "      upper(app.name) like concat('%',upper(:keySearch),'%') or " +
                    "      upper(app.code) like concat('%',upper(:keySearch),'%') " +
                    "     ) " +
                    " order by app.code asc "
    )
    Page<AuditDTO> findUnusedInIntegrationSync(String keySearch, Pageable pageable);

    boolean existsByParentCodeAndStatus(String code, Integer active);

    boolean existsByUrl(String url);

    List<Application> findByParentCode(String parentCode);

    boolean existsApplicationByParentCodeAndStatus(String code, Integer active);

    boolean existsByCodeAndStatusNot(String appCode, Integer active);

    boolean existsByCode(String code);
}
