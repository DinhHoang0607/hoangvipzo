package vn.gtel.app_mng.account.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountTransferReq {
    @NotNull(message = "error.common.validate.not.null")
    @Size(max = 20, message = "error.common.validate.max.size.20")
    private String account;

    @Size(max = 18, message = "error.common.validate.max.size.18")
    private String oldOrganization;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 18, message = "error.common.validate.max.size.18")
    private String newOrganization;
}
