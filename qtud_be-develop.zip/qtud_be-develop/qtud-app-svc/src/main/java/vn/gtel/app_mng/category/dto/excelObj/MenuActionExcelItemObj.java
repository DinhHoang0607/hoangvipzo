package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

@Data
public class MenuActionExcelItemObj extends IExcelItem {
    private String action;
    private String menu;
    private String method;
    private String endPoint;
    private String codeActionOther;
    private String code;
    private String description;
}
