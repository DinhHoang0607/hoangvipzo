package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.account.model.AccountGroupAccount;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.role.model.GroupRoleAccountGroup;
import vn.gtel.app_mng.role.model.GroupRoleOrg;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CodeItemWithActionDTO {
    private String id;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String code;
    private String name;
    @Max(3)
    @Min(-1)
    private int action;

    public CodeItemWithActionDTO(AccountGroupAccount e) {
        this.code = e.getAccount();
        this.name = e.getAccountName();
    }

    public CodeItemWithActionDTO(GroupRoleAccountGroup groupRoleAccountGroup) {
        this.code = groupRoleAccountGroup.getGroupRole();
        this.name = groupRoleAccountGroup.getGroupRoleName();
    }

    public CodeItemWithActionDTO(String code, String name) {
        this.code = code;
        this.name = name;
    }
}
