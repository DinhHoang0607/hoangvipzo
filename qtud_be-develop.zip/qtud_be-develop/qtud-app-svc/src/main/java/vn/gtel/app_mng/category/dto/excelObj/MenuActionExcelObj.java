package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;
import java.util.Map;

@Data
public class MenuActionExcelObj extends IExcelMapperObj {
    private Map<String, Integer> fieldToIndexMap = new HashMap<>();

    public MenuActionExcelObj(int stt) {
        fieldToIndexMap.put("action", stt + 1);
        fieldToIndexMap.put("menu", stt + 2);
        fieldToIndexMap.put("method", stt + 3);
        fieldToIndexMap.put("endPoint", stt + 4);
        fieldToIndexMap.put("codeActionOther", stt + 5);
        fieldToIndexMap.put("code", stt + 6);
        fieldToIndexMap.put("resultColumn", stt + 7);
        setFieldToIndexMap(fieldToIndexMap);

    }
}
