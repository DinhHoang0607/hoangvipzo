/*
 *
 * Copyright (c) 2022.
 * Project  :  app-role
 * File  :  FERoleAppCodeDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/11/22, 1:42 PM
 *
 */

package vn.gtel.app_mng.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FERoleAppCodeDTO {
    private List<FERoleAppCodeItemDTO> menus;
    private List<FERoleAppCodeItemDTO> actions;
}
