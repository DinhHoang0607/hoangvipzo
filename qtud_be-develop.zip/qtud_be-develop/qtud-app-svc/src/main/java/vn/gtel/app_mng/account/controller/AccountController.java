/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/22/22, 3:27 PM
 *
 */

package vn.gtel.app_mng.account.controller;

import io.swagger.annotations.Scope;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import javassist.NotFoundException;
import lombok.AllArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.dto.*;
import vn.gtel.app_mng.account.dto.request.ForgetPWRequestDTO;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferByGroupReq;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferReq;
import vn.gtel.app_mng.account.filter.*;
import vn.gtel.app_mng.account.service.AccountService;
import vn.gtel.app_mng.account.service.AccountServiceV2;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.system.service.NotificationService;
import vn.gtel.common.util.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.xml.bind.ValidationException;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Validated
@Tag(name = "Tài khoản người dùng", description = "Tài khoản người dùng")
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/account")
@AllArgsConstructor
@Scope(name = "singleton", description = "")
public class AccountController {

    private final AccountService accountService;
    private final NotificationService notificationService;
    private final AccountServiceV2 accountServiceV2;

    @Operation(summary = "Thêm mới tài khoản")
    @PostMapping(value = "")
    public ResponseBase createAccountDetail(@RequestBody @Valid AccountRequestDTO accountDetailDTO)
            throws Exception {
        return accountService.save(accountDetailDTO);
    }

    @Operation(summary = "Sửa tài khoản")
    @PutMapping(value = "")
    public ResponseBase updateAccountDetail(@RequestBody @Valid AccountRequestDTO accountDetailDTO)
            throws Exception {
        return accountService.save(accountDetailDTO);
    }

    @Operation(summary = "Danh sách tài khoản người dùng (Dùng cho phần mềm nghiệp vụ)")
    @GetMapping(value = "")
    public ResponseBase listAccount(
//            @Valid
//            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
//            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "typeEmployee", required = false) String typeEmployee,
            @RequestParam(name = "status", required = false) String status,

//            @Valid
//            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
//            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

//            @Valid
//            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
//            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,

//            @Valid
//            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
//            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "onlyLocalAccounts", required = false) Integer onlyLocalAccount,
            @RequestParam(name = "statusConfirmInfo", required = false) Long statusConfirmInfo,
            @RequestParam(name = "policeNumbers", required = false) List<String> policeNumbers
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        int onlyLocalAccountType = onlyLocalAccount == null ? Constants.DEFAULT_INT_TYPE : onlyLocalAccount;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, status, organizationLevel, typeEmployee, onlyLocalAccountType, statusConfirmInfo, policeNumbers);
        return accountService.listAccount(textFilter);
    }

    @Operation(summary = "Danh sách tài khoản người dùng (Dùng cho phần mềm Qtud)")
    @GetMapping(value = "/employee")
    public ResponseBase listAccountEmployeeToQtud(
//            @Valid
//            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
//            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "accountName", required = false) String accountName,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

//            @Valid
//            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,


            @RequestParam(name = "status", required = false) String status,

//            @Valid
//            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
//            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

//            @Valid
//            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
//            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,

//            @Valid
//            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
//            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "onlyLocalAccounts", required = false) Integer onlyLocalAccount,

            @RequestParam(name = "statusConfirmInfo", required = false) Long statusConfirmInfo
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        int onlyLocalAccountType = onlyLocalAccount == null ? Constants.DEFAULT_INT_TYPE : onlyLocalAccount;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, status, organizationLevel, Constants.ACCOUNT_EMP_TYPE.USER.toString(), onlyLocalAccountType, statusConfirmInfo, accountName);
        return accountServiceV2.listAccount(textFilter);
    }

    @Operation(summary = "Danh sách tài khoản Quản trị (Dùng cho phần mềm Qtud)")
    @GetMapping(value = "/admin")
    public ResponseBase listAccountAdminToQtud(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "accountName", required = false) String accountName,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,


            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "onlyLocalAccounts", required = false) Integer onlyLocalAccount,

            @RequestParam(name = "statusConfirmInfo", required = false) Long statusConfirmInfo
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        int onlyLocalAccountType = onlyLocalAccount == null ? Constants.DEFAULT_INT_TYPE : onlyLocalAccount;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, status, organizationLevel, Constants.ACCOUNT_EMP_TYPE.ADMIN.toString(), onlyLocalAccountType, statusConfirmInfo, accountName);
        return accountService.listAccount(textFilter);
    }

    @Operation(summary = "Danh sách tất cả tài khoản người dùng")
    @GetMapping(value = "all")
    public ResponseBase listAllAccount(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,

            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER, message = "error.common.validate.only.number")
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "typeEmployee", required = false) String typeEmployee,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "onlyLocalAccounts", required = false) Integer onlyLocalAccount,

            @RequestParam(name = "statusConfirmInfo", required = false) Long statusConfirmInfo
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        int onlyLocalAccountType = onlyLocalAccount == null ? Constants.DEFAULT_INT_TYPE : onlyLocalAccount;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, status, organizationLevel, typeEmployee, onlyLocalAccountType, statusConfirmInfo);
        return accountService.listAllAccount(textFilter);
    }

    @Operation(summary = "Danh sách tất cả tài khoản người dùng")
    @GetMapping(value = "/list-in-accounts")
    public ResponseBase listAccountInAccounts(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @RequestParam(name = "typeEmployee", required = false) String typeEmployee,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,

            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER, message = "error.common.validate.only.number")
            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size,
            @RequestParam(name = "accounts", required = false) List<String> accounts
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization,
                name, policeNumber, military, status, accounts, typeEmployee);
        return accountService.listAllAccount(textFilter);
    }

    @Operation(summary = "Xem chi tiết tài khoản ")
    @GetMapping(value = "/{id}")
    public ResponseBase detail(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id
    ) throws Exception {
        return accountServiceV2.detailAccount(id);
    }

    @Operation(summary = "Xem chi tiết tài khoản ")
    @GetMapping(value = "/get-me")
    public ResponseBase getMe() throws Exception {
        return accountService.getMe();
    }

    @Operation(summary = "Xem chi tiết cán bộ quản lý trực tiếp, và đơn vị quản lý ")
    @GetMapping(value = "/get-account-org")
    public ResponseBase getAccOrg(@Valid @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") String user) throws Exception {
        return accountService.getMeForManage(user);
    }

    @Operation(summary = "Kích hoạt/ hủy kích hoạt")
    @PutMapping(value = "/update")
    public ResponseBase setActiveDeActive(@RequestBody @Valid ReasonUpdateAccountDTO reasonUpdateAccountDTO) throws Exception {
        return accountService.setActiveDeActive(reasonUpdateAccountDTO);
    }

    @Operation(summary = "Đổi mật khẩu")
    @PutMapping(value = "/change-pw")
    public ResponseBase changePw(@RequestBody @Valid ChangePWRequestDTO changePWRequestDTO) throws Exception {
        return accountService.changePw(changePWRequestDTO);
    }

    @Operation(summary = "Reset mật khẩu")
    @PatchMapping(value = "/{id}")
    public ResponseBase resetPw(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return accountService.resetPw(id);
    }

    @Operation(summary = "Kết xuất danh sách tài khoản người dùng")
    @GetMapping(value = "/export")
    public ResponseEntity export(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,
            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "onlyLocalAccounts", required = false) Integer onlyLocalAccount,
            @RequestParam(name = "typeEmployee", required = false) String typeEmployee,

            @RequestParam(name = "statusConfirmInfo", required = false) Long statusConfirmInfo
    ) throws IOException, JRException, IllegalAccessException {
        int pageNumber = Constants.DEFAULT_PAGE;
        int sizeNumber = Constants.MAX_ROW_SELECT;
        int onlyLocalAccountType = onlyLocalAccount == null ? Constants.DEFAULT_INT_TYPE : onlyLocalAccount;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, status, organizationLevel, typeEmployee, onlyLocalAccountType, statusConfirmInfo);
        return accountService.exportAccount(textFilter, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "In danh sách tài khoản người dùng")
    @GetMapping(value = "/print")
    public ResponseEntity print(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,
            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "onlyLocalAccounts", required = false) Integer onlyLocalAccount,
            @RequestParam(name = "typeEmployee", required = false) String typeEmployee,

            @RequestParam(name = "statusConfirmInfo", required = false) Long statusConfirmInfo
    ) throws IOException, JRException, IllegalAccessException {
        int pageNumber = Constants.DEFAULT_PAGE;
        int sizeNumber = Constants.MAX_ROW_SELECT;
        int onlyLocalAccountType = onlyLocalAccount == null ? Constants.DEFAULT_INT_TYPE : onlyLocalAccount;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, status, organizationLevel, typeEmployee, onlyLocalAccountType, statusConfirmInfo);
        return accountService.exportAccount(textFilter, Constants.EXPORT_TYPE.PDF.toString());
    }

    @Operation(summary = "Danh sách tài khoản đã gán vào nhóm quyền ")
    @GetMapping(value = "/in-group-role/{groupRole}")
    public ResponseBase getAccountInRole(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32")
            @PathVariable String groupRole,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter roleMenuFilter = new AccountGroupRoleFilter(pageNumber, sizeNumber, keySearch, groupRole, position, org);
        return accountService.getAccountInGroupRole(roleMenuFilter);
    }

    @Operation(summary = "Danh sách tài khoản đã gán vào nhóm quyền tich hop dong bo")
    @GetMapping(value = "/in-group-role-thdb")
    public ResponseBase getAccountInRoleInThdb(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter roleMenuFilter = new AccountGroupRoleTHDBFilter(pageNumber, sizeNumber, keySearch, Constants.GROUP_ROLE_THDB_CODE_DEFAULT, position, org);
        return accountService.getAccountInGroupRole(roleMenuFilter);
    }

    @Operation(summary = "Danh sách tài khoản chưa gán vào nhóm quyền")
    @GetMapping(value = "/without-group-role/{groupRole}")
    public ResponseBase getAccountWithoutRole(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32")
            @PathVariable String groupRole,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter roleMenuFilter = new WithoutGroupRoleFilter(pageNumber, sizeNumber, keySearch, groupRole, Constants.GROUP_ROLE_TYPE.MENU_ACTION, position, org);
        return accountService.getAccountWithoutGroupRole(roleMenuFilter);
    }

    @Operation(summary = "Danh sách tài khoản chưa gán vào nhóm quyền chức năng")
    @PostMapping(value = "/without-group-role-menu")
    public ResponseBase getAccountWithoutRoleMenu(@RequestBody @Valid AccountWithoutGroupRoleFilter accountWithoutGroupRoleFilter) throws IllegalAccessException {
        return accountService.getAccountWithoutGroupRole(accountWithoutGroupRoleFilter);
    }

    @Operation(summary = "DDL Danh sách tài khoản người dùng")
    @GetMapping(value = "/list")
    public ResponseBase ddlAccount(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organizationRank", required = false) String organizationLevel,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account", required = false) String account,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_NAME_100, message = "error.common.validate.max.size.100")
            @RequestParam(name = "name", required = false) String name,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "military", required = false) String military,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        AccountFilter textFilter = new AccountFilter(pageNumber, sizeNumber, keySearch, organization, Constants.ACCOUNT_TYPE.EMPLOYEE,
                account, name, policeNumber, position, military, Constants.ACCOUNT_STATUS.ACTIVE + "", organizationLevel);
        return accountService.listAccount(textFilter);
    }

    @Operation(summary = "danh sách tài khoàn người dùng thuộc mục đích yêu cầu")
    @GetMapping(value = "/require-purpose")
    public ResponseBase listAccountByRe(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,

            @Valid
            @Size(max = 18, message = "error.common.validate.max.size.18")
            @Size(min = 3, message = "error.common.validate.min.size.3")
            @Pattern(regexp = Constants.Regex.CODE, message = "error.common.validate.character.number")
            @RequestParam(name = "requirePurpose", required = true) String requirePurposeCode
    ) throws IllegalAccessException {

        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.MAX_ROW_SELECT;
        }
        TextFilter textFilter = new TextFilter(page, size, keySearch);
        return accountService.listAccountByRequirePurpose(textFilter, requirePurposeCode, Constants.Flag.REQUIRE_PURPOSE);
    }

    @Operation(summary = "danh sách tài khoàn người dùng không thuộc mục đích yêu cầu")
    @GetMapping(value = "/not-require-purpose")
    public ResponseBase listAccountNotByRe(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,

            @Valid
            @Size(max = 18, message = "error.common.validate.max.size.18")
            @Size(min = 3, message = "error.common.validate.min.size.3")
            @Pattern(regexp = Constants.Regex.CODE, message = "error.common.validate.character.number")
            @RequestParam(name = "requirePurpose", required = true) String requirePurposeCode
    ) throws IllegalAccessException {
        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.MAX_ROW_SELECT;
        }
        TextFilter textFilter = new TextFilter(page, size, keySearch);
        return accountService.listAccountByRequirePurpose(textFilter, requirePurposeCode, Constants.Flag.NOT_REQUIRE_PURPOSE);
    }

    @Operation(summary = "Danh sách tài khoản cán bộ lãnh đạo")
    @GetMapping(value = "list-account-lead")
    public ResponseBase listAccountLead(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException, ValidationException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listAccountLead(textFilter, status, null, null, null);
    }

    @Operation(summary = "Danh sách tài khoản lãnh đạo theo đơn vị")
    @GetMapping(value = "list-account-lead-by-org")
    public ResponseBase listAccountLeadByOrg(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException, ValidationException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listAccountLead(textFilter, status, null, null, organization);
    }

    @Operation(summary = "Danh sách tất cả tài khoản tài khoản cán bộ của tất cả đơn vị nghiệp vụ theo đơn vị hồ sơ")
    @GetMapping(value = "list-account-org")
    public ResponseBase listOrg(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException, ValidationException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listOrg(textFilter);
    }

    @Operation(summary = "Danh sách tài khoản cán bộ không theo tài khoản đăng nhập")
    @GetMapping(value = "list-account-lead-not-acc-login")
    public ResponseBase listAccountLeadNotAccLogin(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid @Pattern(regexp = Constants.Regex.CODE, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "account", required = false) String account,

            @RequestParam(name = "status", required = false) String status,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException, ValidationException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listAccountLead(textFilter, status, account, null, null);
    }

    @Operation(summary = "Danh sách tài khoản cán bộ an ninh cảnh sát")
    @GetMapping(value = "list-account-lead-ancs")
    public ResponseBase listAccountLeadANCS(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "status", required = false) String status,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException, ValidationException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listAccountLead(textFilter, status, null, "ANCS", null);
    }

    @Operation(summary = "So sánh tên và số hiệu CAND")
    @GetMapping(value = "compare-acc")
    public ResponseBase compareAcc(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "fullName", required = false) String fullName,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "policeNumber", required = false) String policeNumber
    ) throws IllegalAccessException, ValidationException {
        return accountService.compareAcc(fullName, policeNumber);
    }

//    @Operation(summary = "Danh sách tài khoản QL trực tiếp")
//    @GetMapping(value = "list")
//    public ResponseBase listAccountDirect(@RequestParam(name = "code", required = false)  String code,
//                                          @RequestParam(name = "parentCode", required = false)  String parentCode) throws Exception {
//        return accountService.listAccountDirect(code,parentCode);
//    }

    @Operation(summary = "Danh sách tài khoản QL trực tiếp")
    @GetMapping(value = "listAccountDirect")
    public ResponseBase listAccountDirect(
            @Valid
            @RequestParam(name = "code", required = false) String code,
            @Valid
            @RequestParam(name = "parentCode", required = false) String parentCode
    ) throws Exception {
        return accountService.listAccountDirect(code, parentCode);
    }

    @Operation(summary = "Danh sách tài khoản QL cấp trên")
    @GetMapping(value = "listAccountDirectBottom")
    public ResponseBase listAccountDirectBottom(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size,

            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "position", required = false) String position,

            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org
    ) throws Exception {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listAccountDirectBottom(textFilter, position, org);
    }

    @Operation(summary = "Tải template import tài khoản")
    @GetMapping(value = "/template")
    public ResponseEntity template() throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException {
//        return CommonService.downloadTemplate("IMPORT_ACCOUNT_EMP_TEMPLATE.xlsx", "tem_import_tai_khoan_nguoi_dung.xlsx");
        return accountService.createTemplate();
    }

    @Operation(summary = "Import danh sách tài khoản")
    @PostMapping(value = "/import")
    public ResponseEntity importExcel(@RequestParam("file") MultipartFile file) throws Exception {
        return accountService.importEmp(file);
    }

    @Operation(summary = "Danh sách tất cả tài khoản người dùng (Không giới hạn)")
    @GetMapping(value = "all/unrestricted")
    public ResponseBase listAllAccount(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,


            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        AccountExploitFilter textFilter = new AccountExploitFilter(pageNumber, sizeNumber, keySearch, organization, null);
        return accountService.listAllAccount(textFilter);
    }

    @Operation(summary = "Chuyển đơn vị")
    @PutMapping(value = "change-org")
    public ResponseBase changeOrg(
            @RequestBody @Valid AccountChangeOrgDTO accountChangeOrgDTO
    ) throws Exception {
        return accountService.changeOrg(accountChangeOrgDTO);
    }


    @Operation(summary = "DDL Danh sách tài khoản quản lý trực tiếp cà cùng đơn vị")
    @GetMapping(value = "/list-acc-qltt-same-org")
    public ResponseBase ddlAccountQltt(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listAccountQLTT(textFilter);
    }

    @Operation(summary = "Dánh sách lãnh đạo ngang cấp và dưới 1 cấp")
    @GetMapping(value = "/list-lead-same")
    public ResponseBase ddlLead(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TextFilter textFilter = new TextFilter(pageNumber, sizeNumber, keySearch);
        return accountService.listLead(textFilter);
    }

    @Operation(summary = "Chuyển đơn vị tài khoản")
    @PostMapping(value = "/org-transfer")
    public ResponseBase organizationTransfer(
            @RequestBody @Valid OrganizationTransferReq request
    ) throws Exception {
        return accountService.transferOrganization(request);
    }

    @Operation(summary = "Cập nhật trạng thái chuyển đơn vị hoặc chữ ký")
    @PutMapping(value = "/org-transfer/{id}")
    public ResponseBase updateTransferProcess(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id,

            @RequestParam(name = "action", required = false) Integer action,
            @RequestParam(name = "decisionSigner", required = false) String decisionSigner
    ) throws NotFoundException, ValidationException {
        return accountService.updateTransferProcess(id, action, decisionSigner);
    }


    @Operation(summary = "Danh sách chuyển đơn vị")
    @GetMapping(value = "/list-org-transfer")
    public ResponseBase listTransfer(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org,
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT_50, message = "error.common.validate.max.size.50")
            @RequestParam(name = "account", required = false) String account,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "type") Integer type,
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "fullName", required = false) String fullName,
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "policeNumber", required = false) String policeNumber,

            @RequestParam(name = "status", required = false) Integer status

    ) throws NotFoundException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        AccountTransferOrgFilter accountTransferOrgFilter = new AccountTransferOrgFilter(pageNumber, sizeNumber, keySearch, org, fullName, account, policeNumber, type, status);
        return accountService.listTransferOrg(accountTransferOrgFilter);
    }

    @Operation(summary = "Lấy số lương tài khoản đang chờ chuyển đơn vị")
    @GetMapping(value = "/sum-account-transfer")
    public ResponseBase sumAccountTransfer() {
        return accountService.sumAccountTransfer();
    }

    @Operation(summary = "Kết xuất thống tin tài khoản ban đầu và sau khi lấy lại mật khẩu")
    @GetMapping(value = "/export_reset")
    public ResponseEntity exportReset(
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character")
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account") String account
    ) throws Exception {
        return accountService.exportAcc(account);
    }

    @Operation(summary = "Đổi mật khẩu")
    @GetMapping(value = "/changePass")
    public ResponseBase changePass(
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character")
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "text") String text
    ) throws Exception {
        return accountService.updatePassAdmin(text);
    }

    @Operation(summary = "Kết xuất thống tin tài khoản theo tỉnh")
    @GetMapping(value = "/export-all-in-province")
    public ResponseBase exportInProvince(
    ) throws Exception {
        return accountService.exportByProvinceCode();
    }

    @Operation(summary = "Clone nhom quyen type , 1 admin cục,2 admin tỉnh, 3 admin quân huyen,4 admin phòng nghiệp vụ")
    @PostMapping(value = "/clone-group_role")
    public ResponseBase Clone(
            @RequestBody @Valid CloneGroupRoleDTO cloneGroupRoleDTO
    ) throws Exception {
        return accountService.cloneGroup(cloneGroupRoleDTO);
    }

    @Operation(summary = "Xác nhận thông tin người dùng")
    @PostMapping(value = "/confirm-info")
    public ResponseBase confirmInfo(
            @RequestBody @Valid AccConfirmInfoDTO accConfirmInfoDTO
    ) throws Exception {
        return accountService.confirmInfo(accConfirmInfoDTO);
    }

    @Operation(summary = "Check trùng số điện thoại hoặc số hiệu cand")
    @PostMapping(value = "/check-phone-cand")
    public ResponseBase checkPhoneOrCand(
            @RequestBody @Valid AccNumberPhoneOrPoliceNumberDTO accNumberPhoneOrPoliceNumberDTO
    ) throws Exception {
        return accountService.checkNumberPhoneOrPoliceNumber(accNumberPhoneOrPoliceNumberDTO);
    }

    @Operation(summary = "Xóa tài khoản khi chưa đăng nhập")
    @GetMapping(value = "/remove")
    public ResponseBase remove(
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character")
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account") String account
    ) throws Exception {
        return new ResponseBase(accountService.removeAccount(account));
    }

    @Operation(summary = "Danh sách")
    @GetMapping(value = "/list-lead-by-org")
    public ResponseBase listLeadByOrg(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = false) String org,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size,
            @RequestParam(name = "type", required = false) Integer type,
            @RequestParam(name = "positionType", required = false) Integer positionType
    ) throws NotFoundException, ValidationException, IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        AccountLeadOrEmFilter accountLeadOrEmFilter = new AccountLeadOrEmFilter(pageNumber, sizeNumber, keySearch, positionType, type, org);
        return accountService.listLeadOrEmByOrg(accountLeadOrEmFilter);
    }

    @Operation(summary = "Danh sách tài khoản trong danh sách đơn vị")
    @GetMapping(value = "/in-list-org")
    public ResponseBase getInListOrg(@RequestParam(name = "org") Optional<List<String>> orgs) throws Exception {
        return accountService.getAccountInListOrg(orgs.get());
    }

    @Operation(summary = "Danh sách tài khoản (Phục vụ chuyển đơn vị nhóm tài khoản)")
    @PutMapping(value = "/group-transfer")
    public ResponseBase groupTransferList(@RequestBody @Valid GroupTransferOrgFilter filter) throws IllegalAccessException {
        return accountService.groupTransferList(filter);
    }

    @Operation(summary = "Chuyển đơn vị nhóm tài khoản")
    @PostMapping(value = "/group-transfer")
    public ResponseBase groupTransfer(@RequestBody @Valid OrganizationTransferByGroupReq request) throws IllegalAccessException, NotFoundException {
        return accountService.groupTransfer(request);
    }

    @Operation(summary = "Danh sách cán bộ/lãnh đạo theo đơn vị")
    @GetMapping(value = "/account-with-position-type-in-org")
    public ResponseBase accountWithPositionTypeInOrg(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "org", required = true) String org,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size,
            @RequestParam(name = "position", required = false) String position,
            @RequestParam(name = "positionType", required = true) String positionType,
            @RequestParam(name = "leader", required = false) String leader,
            @RequestParam(name = "staff", required = false) String staff,
            @RequestParam(name = "type", required = false) Integer type
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        AccountWithPositionTypeInOrgFilter filter = new AccountWithPositionTypeInOrgFilter(position, positionType, org, leader, staff, keySearch, pageNumber, sizeNumber, type);
        return accountService.accountWithPositionTypeInOrg(filter);
    }

    @Operation(summary = "Cây tài khoản cảnh sát giao thông (default: đv trực thuộc/ báo cáo)")
    @GetMapping(value = "/tree-account-traffic-police")
    public ResponseBase getTreeTrafficPolice(@RequestParam(name = "currentNode") String currentNode,
                                             @RequestParam(name = "page", required = false) Optional<Integer> page,
                                             @RequestParam(name = "size", required = false) Optional<Integer> size) throws IllegalAccessException {
        int pageNumber = page.orElse(0);
        int sizeNumber = size.orElse(0);
        return accountService.getTreeAccountTrafficPolice(currentNode, pageNumber, sizeNumber);
    }

    @Operation(summary = "Kiểm tra tài khoản đã bàn giao hồ sơ hay chưa")
    @GetMapping(value = "/account-check")
    public ResponseBase accountCheck(
            @RequestParam(name = "account", required = true) String account,
            @RequestParam(name = "app", required = false) String app
    ) throws IllegalAccessException {
        return accountService.accountCheck(account, app);
    }

    @Operation(summary = "Cập nhật chức vụ hiển thị cho tài khoản")
    @PutMapping(value = "/display-position")
    public ResponseBase updateDisplayPosition(@RequestBody @Valid DisplayPositionDTO request) throws Exception {
        return accountService.updateDisplayPosition(request);
    }

    @Operation(summary = "Xem lịch sử tài khoản")
    @GetMapping(value = "/account-history/{id}")
    public ResponseBase accountHistory(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id,
            @RequestParam(name = "page") Optional<Integer> page,
            @RequestParam(name = "size") Optional<Integer> size
    ) throws Exception {
        Integer pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        Integer sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        return accountService.accountHistory(id, pageNumber, sizeNumber);
    }

    @Operation(summary = "Quên mật khẩu")
    @PutMapping(value = "/forget-pw")
    public ResponseBase forgetPw(@RequestBody @Valid ForgetPWRequestDTO forgetPWRequestDTO) throws Exception {
        return accountService.forgetPw(forgetPWRequestDTO);
    }

    @Operation(summary = "Đăng xuất")
    @GetMapping(value = "/log-out")
    public ResponseBase logOut() {
        return notificationService.logOut();
    }
}
