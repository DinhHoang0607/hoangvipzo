package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.account.model.AccountForManageOrganization;

import java.util.List;

@Repository
public interface AccountForManageOrganizationRepository extends JpaRepository<AccountForManageOrganization, String>{
    AccountForManageOrganization findByAccountAndOrganization(String acc,String org);
    List<AccountForManageOrganization> findByAccountAndStatus(String acc, Integer status);
    void deleteAllByAccount(String acc);
}
