package vn.gtel.app_mng.common.dto.response;

import lombok.Data;

import javax.persistence.Column;

@Data
public class NewCodeResponseDTO {
    @Column(name = "MA")
    private String code;

    @Column(name = "TRANG_THAI")
    private Integer status;
}
