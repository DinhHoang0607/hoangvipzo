package vn.gtel.app_mng.account.repository;

import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.model.GeneralConfig;

import javax.transaction.Transactional;

@Repository
public interface GeneralConfigRepository extends JpaRepository<GeneralConfig, String> {
    GeneralConfig findByKey(String key);

    @Query(value = "select a.value from GeneralConfig a where a.key = :key and a.status = 1 ")
    @Cacheable(value = "config", key = "#key", unless = "#result == null")
    String getByKey(String key);


    @Query(value = "select a.value from GeneralConfig a where a.key = :key and a.status = 1 ")
    @CachePut(value = "config", key = "#key", unless = "#result == null")
    String updateCacheByKey(String key);

    @Transactional
    @Modifying
    @Query(value = "update GeneralConfig tbl set tbl.value = :value where tbl.key = :key")
    void saveByKey(String key, String value);
}
