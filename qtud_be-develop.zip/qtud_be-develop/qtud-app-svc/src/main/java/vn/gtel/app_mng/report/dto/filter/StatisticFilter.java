package vn.gtel.app_mng.report.dto.filter;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class StatisticFilter {
    private Integer statisticType;
    private String accountName;
    private String orderBy;
    private String displayNameMode;
    private String organization;
    private String originOrganization;
    private String application;
    private String groupRole;
    private String manager;
    private String provinceCode;
    private Instant fromDate;
    private Instant toDate;
}
