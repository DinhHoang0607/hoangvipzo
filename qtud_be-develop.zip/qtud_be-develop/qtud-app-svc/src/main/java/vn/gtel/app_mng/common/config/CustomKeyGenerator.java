/*
 *  CustomKeyGenerator.java
 *  Copyright (c) 2021.
 *  Modification Logs:
 *  DATE                AUTHOR             DESCRIPTION
 *  4/9/21, 3:16 PM    TuanNP             File is created
 *
 */
package vn.gtel.app_mng.common.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.interceptor.KeyGenerator;

import java.lang.reflect.Method;

public class CustomKeyGenerator implements KeyGenerator {
  private ObjectMapper om = new ObjectMapper();

  @Override
  public Object generate(Object target, Method method, Object... params) {
    try {
      String key = String.format("%s_%s_%s", target.getClass().getSimpleName(), method.getName(),
          om.writeValueAsString(params).hashCode());
      return key;
    } catch (JsonProcessingException e) {
      return null;
    }
  }

}
