package vn.gtel.app_mng.dashboard.dto.req;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@AllArgsConstructor
public class GridFilter extends TextFilter implements Serializable {
    @NotNull
    @Min(value = 2000L)
    @Max(9999999999999L)
    private Long fromDateTime;
    @NotNull
    @Min(2000L)
    @Max(9999999999999L)
    private Long toDateTime;
//    @NotEmpty
    @Pattern(regexp = "^(day|week|month|quarter|year)$")
    private String aggType;
    private String type;

    public GridFilter(String keySearch, @NotNull @Min(value = 2000L) @Max(9999999999999L) Long fromDateTime, @NotNull @Min(2000L) @Max(9999999999999L) Long toDateTime, @Pattern(regexp = "^(day|week|month|quarter|year)$") String aggType) {
        super(Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT, keySearch);
        this.fromDateTime = fromDateTime;
        this.toDateTime = toDateTime;
        this.aggType = aggType;
    }
}
