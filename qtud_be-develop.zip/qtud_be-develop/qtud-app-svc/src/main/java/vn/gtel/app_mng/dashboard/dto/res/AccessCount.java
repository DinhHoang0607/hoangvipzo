package vn.gtel.app_mng.dashboard.dto.res;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccessCount {
    @Column(name = "SO_LUONG")
    private Long countNumber;

    @Column(name = "SO_TRUY_CAP")
    private String accessAmount;

    @Column(name = "GIA_TRI_SO_TRUY_CAP")
    private String accessAmountValue;
}
