package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;

@Data
public class UsbTokenExcelObj extends IExcelMapperObj {

//    public UsbTokenExcelObj(int stt) {
//        setFieldToIndexMap(new HashMap<>());
//        getFieldToIndexMap().put("code",stt + 1);
//        getFieldToIndexMap().put("accountCode", stt + 2);
//        getFieldToIndexMap().put("startDate",stt + 3);
//        getFieldToIndexMap().put("endDate",stt + 4);
//        getFieldToIndexMap().put("description",stt + 5);
//        getFieldToIndexMap().put("resultColumn",stt + 6);
//        setFieldToIndexMap(getFieldToIndexMap());
//    }

    public UsbTokenExcelObj(int stt) {
        setFieldToIndexMap(new HashMap<>());
        getFieldToIndexMap().put("cmmdDatePlace",stt + 3);
        getFieldToIndexMap().put("address", stt + 4);
        getFieldToIndexMap().put("areaAdministrative",stt + 6);
        getFieldToIndexMap().put("code",stt + 9);
        getFieldToIndexMap().put("sim",stt + 10);
        getFieldToIndexMap().put("accountCode",stt + 11);
        getFieldToIndexMap().put("resultColumn",stt+12);
        setFieldToIndexMap(getFieldToIndexMap());
    }

    public UsbTokenExcelObj(int stt,int sheet) {
        setFieldToIndexMap(new HashMap<>());
        getFieldToIndexMap().put("cmmdDatePlace",stt + 3);
        getFieldToIndexMap().put("address", stt + 6);
        getFieldToIndexMap().put("areaAdministrative",stt + 9);
        getFieldToIndexMap().put("code",stt + 12);
        //getFieldToIndexMap().put("sim",stt + 10);
        getFieldToIndexMap().put("accountCode",stt + 13);
        getFieldToIndexMap().put("resultColumn",stt+14);
        setFieldToIndexMap(getFieldToIndexMap());
    }
}
