package vn.gtel.app_mng.feedback.service;

import com.google.gson.Gson;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.account.repository.AccountEmployeeDetailRepository;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.category.repo.ApplicationRepo;
import vn.gtel.app_mng.category.repo.OrganizationRepo;
import vn.gtel.app_mng.category.repo.PositionCatRepo;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CallRestAPIService;
import vn.gtel.app_mng.common.service.impl.CallRestAPIServiceImpl;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.feedback.dto.*;
import vn.gtel.app_mng.feedback.dto.storedObj.FeedBackCallStoredDTO;
import vn.gtel.app_mng.feedback.model.Feedback;
import vn.gtel.app_mng.feedback.model.FeedbackHistory;
import vn.gtel.app_mng.feedback.model.FeedbackRelateTo;
import vn.gtel.app_mng.feedback.repository.FeedbackHistoryRepository;
import vn.gtel.app_mng.feedback.repository.FeedbackRelateToRepository;
import vn.gtel.app_mng.feedback.repository.FeedbackRepository;
//import vn.gtel.app_mng.system.model.File;
import vn.gtel.app_mng.system.repository.FileRepository;
import vn.gtel.common.dto.AccountDTO;
import vn.gtel.common.userinfo.AccountLogonContext;

import javax.xml.bind.ValidationException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private TrimSpaceUtil trimSpaceUtil;

    @Autowired
    private FileRepository fileRepository;
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private OrganizationRepo organizationRepo;
    @Autowired
    private ApplicationRepo applicationRepo;

    @Autowired
    private PositionCatRepo positionCatRepo;

    @Autowired
    private FeedbackRelateToRepository feedbackRelateToRepository;
    @Autowired
    private AccountEmployeeDetailRepository accountEmployeeDetailRepository;

    @Autowired
    private CallStoredRepository callStoredRepository;

    @Autowired
    private FeedbackHistoryRepository feedbackHistoryRepository;

    @Autowired
    private OrganizationRepo getOrganizationRepo;

    @Value("${log.config.status:false}")
    private boolean status = true;

    @Value("${notification.api.url}")
    private String url;

    //    @Autowired
    private CallRestAPIService callRestAPIServiceImpl = new CallRestAPIServiceImpl();

    @Override
    public ResponseBase search() {
        return null;
    }

    @Override
    public ResponseBase save(FeedBackDTO feedBackDTO) throws Exception {
        trimSpaceUtil.validate(feedBackDTO);
//        checkFile(feedBackDTO.getFiles());
        Feedback feedback = new Feedback();
        AccountDTO account = AccountLogonContext.currentUser();
        if (!applicationRepo.existsByCode(feedBackDTO.getApplicationCode())) {
            throw new ValidationException("ValidationException.error.not.exist.feed.back.app.code");
        }
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String strDate = dateFormat.format(date);
        if (StringUtils.isEmpty(feedBackDTO.getId())) {
            modelMapper.getConfiguration().setSkipNullEnabled(true);
            feedback = modelMapper.map(feedBackDTO, Feedback.class);
            if (account != null) {
                feedback.setSender(account.getAccount());
                feedback.setOrganization(Constants.FEED_BACK.C08_CODE);
                Organization organization = organizationRepo.findByCode(account.getOrganization());
                if (organization != null && organization.getCode() != null) {
                    feedback.setOrgFeedbackCode(organization.getCode());
                }
            }
        } else {
            Feedback updateFeedBack = feedbackRepository.findById(feedBackDTO.getId()).orElse(null);
            if (updateFeedBack != null) {
                modelMapper.getConfiguration().setSkipNullEnabled(true);
                modelMapper.map(feedBackDTO, updateFeedBack);
                feedback = modelMapper.map(updateFeedBack, Feedback.class);
            } else {
                throw new ValidationException("ValidationException.error.not.exist.feed.back");
            }
        }
        feedback.setCode("PA" + strDate);
//        Organization organizationName = organizationRepo.findByCodeAndStatus(feedback.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        feedback.setStatus(Constants.FEED_BACK.NOT_SEEN);
        feedback = feedbackRepository.save(feedback);
//        insertFeedBackHistory(feedback.getId(), Constants.FEED_BACK_HISTORY.SEND_FEED_BACK + " " + organizationName.getName(), feedback.getSender(),
//                Constants.FEED_BACK.NOT_SEEN, feedback.getOrganization(), null, Constants.FEED_BACK_HISTORY.SEND_FEED_BACK + " " + organizationName.getName());
        saveIcon(feedBackDTO, feedback);
        return new ResponseBase(feedback);

    }

    @Override
    public void deleteAction(String id) throws ValidationException {
        Feedback feedback = feedbackRepository.findById(id).orElse(null);
        if (feedback == null) {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        } else {
            feedback.setStatus(Constants.FEED_BACK.DELETED);
            feedbackRepository.save(feedback);
        }
    }

    @Override
    public ResponseBase getOneFeedBack(String id) throws Exception {
        Feedback feedback = feedbackRepository.findById(id).orElse(null);
        FeedBackDetailResponse currentFeedBack = new FeedBackDetailResponse();

        List<FeedbackRelateToDTO> feedbackRelateToDTOS = new ArrayList<>();
        if (StringUtils.isNotEmpty(feedback.getId())) {
            feedback.setStatus(Constants.FEED_BACK.WATCHED);
            feedbackRepository.save(feedback);
            currentFeedBack = modelMapper.map(feedback, FeedBackDetailResponse.class);
//            List<File> files = fileRepository.findByRelativeCodeAndTable(id, Constants.TBL_NAME.FEED_BACK);
//            if (CollectionUtils.isNotEmpty(files)) {
//                for (File file : files) {
//                    FileFeedBackDTO fileFeedBackDTO = new FileFeedBackDTO();
//                    fileFeedBackDTO.setFile(Base64.getEncoder().encodeToString(file.getContent()));
//                    fileFeedBackDTO.setFileName(file.getFileName());
//                    currentFeedBack.getFiles().add(fileFeedBackDTO);
//                }
//            }
            List<FeedbackRelateTo> feedbackRelateTos = feedbackRelateToRepository.findAllByFeedbackId(id);
            if (feedbackRelateTos.size() != 0) {
                for (FeedbackRelateTo feedbackRelateTo : feedbackRelateTos) {
                    Feedback feedbackRetake = feedbackRepository.findById(feedbackRelateTo.getFeedbackIdRelateTo()).orElse(null);
                    FeedbackRelateToDTO relateToDTO = new FeedbackRelateToDTO();
                    relateToDTO.setId(feedbackRetake.getId());
                    relateToDTO.setContent(feedbackRetake.getContent());
                    relateToDTO.setTitle(feedbackRetake.getTitle());
                    relateToDTO.setCode(feedbackRetake.getCode());
                    feedbackRelateToDTOS.add(relateToDTO);
                }
                currentFeedBack.setFeedbackRelateToDTOS(feedbackRelateToDTOS);
            }
            Account account = accountRepository.findByAccountAndStatus(feedback.getSender(), Constants.STATUS_CATEGORY_ACTIVE);
            if (account != null && StringUtils.isNotEmpty(account.getId())) {
                Organization organization = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                if (StringUtils.isNotEmpty(organization.getCode())) {
                    currentFeedBack.setOrgCodeSend(organization.getCode());
                    currentFeedBack.setOrgNameSend(organization.getName());
                }

            }

            ICallStoredObj callStoredObj = new FeedBackCallStoredDTO(id, Constants.FEED_BACK.PROCESSED, Constants.FEED_BACK_HISTORY.REPROCESS);
            List<FeedBackHistoryResponse> feedBackHistoryResponses = (List<FeedBackHistoryResponse>) callStoredRepository.getList(callStoredObj);
            if (CollectionUtils.isNotEmpty(feedBackHistoryResponses)) {
                for (FeedBackHistoryResponse feedBackHistoryResponse : feedBackHistoryResponses) {
                    currentFeedBack.getFeedBackHistoryResponses().add(feedBackHistoryResponse);
                }
            }

            AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(feedback.getSender());
            currentFeedBack.setSenderName(accountEmployeeDetail.getFullName());
        } else {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        }
        return new ResponseBase(currentFeedBack);
    }

    @Override
    public Object list(FeedBackTextFilter FeedBackTextFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(FeedBackTextFilter);
        ICallStoredObj callStoredObj = new FeedBackCallStoredDTO(FeedBackTextFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return res;
    }

    @Override
    public ResponseBase removeFeedBack(RemoveFeedBackDTO removeFeedBackDTO) throws Exception {
        checkFile(removeFeedBackDTO.getFiles());
        Feedback feedback = feedbackRepository.findById(removeFeedBackDTO.getIdFeedBack()).orElse(null);
        AccountDTO account = AccountLogonContext.currentUser();

        if (feedback == null) {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        } else {
            if (!(account.getOrganization().equals(feedback.getOrganization()))) {
                throw new ValidationException("ValidationException.error.not.process.organization");
            } else {
                Organization organization = getOrganizationRepo.findByCode(feedback.getOrganization());
                String orgProcessing = "";
                // PV06 -> V06
                if (organization.getOrganizationDependent() != null) {
                    if (removeFeedBackDTO.getClassify() == 1) {
                        //feedbackRepository.updateStatusAndOrganizationById(Constants.FEED_BACK.PROCESSING, Constants.FEED_BACK.V06_CODE, feedback.getId());
                        orgProcessing = Constants.FEED_BACK.V06_CODE;
                    } else if (removeFeedBackDTO.getClassify() == 2) {
                        // PV01 -> V01
                        //feedbackRepository.updateStatusAndOrganizationById(Constants.FEED_BACK.PROCESSING, Constants.FEED_BACK.V01_CODE, feedback.getId());
                        orgProcessing = Constants.FEED_BACK.V01_CODE;
                    } else {
                        if (removeFeedBackDTO.getClassify() == null) {
                            throw new ValidationException("ValidationException.error.not.exist.feed.classify");
                        } else {
                            if (removeFeedBackDTO.getClassify() == 1) {
//                                Organization orgPV06 = organizationRepo.findByAndOrganizationParentAndOrganizationDependentAndStatus(organization.getOrganizationParent(), Constants.FEED_BACK.V06_CODE, Constants.STATUS_CATEGORY_ACTIVE);
//                                orgProcessing = orgPV06.getCode();
                            } else if (removeFeedBackDTO.getClassify() == 2) {
                                // phan anh phan cung ->V01
//                                Organization orgPV01 = organizationRepo.findByAndOrganizationParentAndOrganizationDependentAndStatus(organization.getOrganizationParent(), Constants.FEED_BACK.V01_CODE, Constants.STATUS_CATEGORY_ACTIVE);
//                                orgProcessing = orgPV01.getCode();
                            }
                        }
                    }
                } else if ((organization.getCode().length() == 12) && organization.getCode().startsWith("500")) {
                    // Doi thuoc phong nghiep vu, doi thuoc quan,huyen gui len admin quan,huyen or admin phong nghiep vu
                    //feedbackRepository.updateStatusAndOrganizationById(Constants.FEED_BACK.PROCESSING, organization.getOrganizationParent(), feedback.getId());
                    orgProcessing = organization.getOrganizationParent();
                } else if (organization.getCode().length() == 9 && organization.getCode().startsWith("500")) {


                    // cac phong nghiep vu gui len cac cuc tuong ung
                    // quan,huyen gui phan anh
//                    if (organization.getOrganizationDependent() == null) {
                    // phan anh phan mem ->V06
                    if (removeFeedBackDTO.getClassify() == 1) {
                        //feedbackRepository.updateStatusAndOrganizationById(Constants.FEED_BACK.PROCESSING, Constants.FEED_BACK.V06_CODE, feedback.getId());
//                        Organization orgPV06 = organizationRepo.findByAndOrganizationParentAndOrganizationDependentAndStatus(organization.getOrganizationParent(), Constants.FEED_BACK.V06_CODE, Constants.STATUS_CATEGORY_ACTIVE);
//                        orgProcessing = orgPV06.getCode();
                    } else if (removeFeedBackDTO.getClassify() == 2) {
                        // phan anh phan cung ->V01
                        //feedbackRepository.updateStatusAndOrganizationById(Constants.FEED_BACK.PROCESSING, Constants.FEED_BACK.V01_CODE, feedback.getId());
//                        Organization orgPV01 = organizationRepo.findByAndOrganizationParentAndOrganizationDependentAndStatus(organization.getOrganizationParent(), Constants.FEED_BACK.V01_CODE, Constants.STATUS_CATEGORY_ACTIVE);
//                        orgProcessing = orgPV01.getCode();
                    }
                } else if (organization.getCode().length() == 9 && organization.getCode().startsWith("100")) {
                    orgProcessing = organization.getOrganizationParent();
                } else if (organization.getCode().length() == 6 && organization.getCode().startsWith("100")) {
                    if (organization.getCode().equals(Constants.FEED_BACK.V01_CODE) || organization.getCode().equals(Constants.FEED_BACK.V06_CODE)) {
                        throw new ValidationException("ValidationException.error.not.exist.organization.parent");
                    } else {
                        if (removeFeedBackDTO.getClassify() == null) {
                            throw new ValidationException("ValidationException.error.not.exist.feed.classify");
                        } else {
                            // phan anh phan mem ->V06
                            if (removeFeedBackDTO.getClassify() == 1) {
//                                Organization orgPV06 = organizationRepo.findByAndOrganizationParentAndOrganizationDependentAndStatus(organization.getOrganizationParent(), Constants.FEED_BACK.V06_CODE, Constants.STATUS_CATEGORY_ACTIVE);
//                                orgProcessing = orgPV06.getCode();
                            } else if (removeFeedBackDTO.getClassify() == 2) {
                                // phan anh phan cung ->V01
//                                Organization orgPV01 = organizationRepo.findByAndOrganizationParentAndOrganizationDependentAndStatus(organization.getOrganizationParent(), Constants.FEED_BACK.V01_CODE, Constants.STATUS_CATEGORY_ACTIVE);
//                                orgProcessing = orgPV01.getCode();
                            }
                        }
                    }

                }
                feedbackRepository.updateStatusAndOrganizationById(removeFeedBackDTO.getClassify(), Constants.FEED_BACK.WATCHED, orgProcessing, feedback.getId());
                Organization organizationName = organizationRepo.findByCodeAndStatus(orgProcessing, Constants.STATUS_CATEGORY_ACTIVE);
                FeedbackHistory feedbackHistory = insertFeedBackHistory(feedback.getId(), removeFeedBackDTO.getComment(), account.getAccount(), Constants.FEED_BACK.PROCESSING, organizationName.getCode(), null, Constants.FEED_BACK_HISTORY.REMOVE_FEED_BACK + " " + organizationName.getName());
                saveIconFeedbackRemove(removeFeedBackDTO, feedbackHistory);

            }
        }

        return new ResponseBase(removeFeedBackDTO);
    }

    @Override
    public ResponseBase reply(ReplyDTO replyDTO) throws Exception {
        trimSpaceUtil.validate(replyDTO);
        FeedbackHistory feedbackHistory = new FeedbackHistory();
        if (replyDTO.getFiles() != null)
            checkFile(replyDTO.getFiles());

        AccountDTO account = AccountLogonContext.currentUser();
        Feedback feedback = feedbackRepository.findById(replyDTO.getIdFeedBack()).orElse(null);

        if (feedback == null) {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        } else {
            //if (account.getOrganization().equals(feedback.getOrganization())) {
            feedbackRepository.updateStatusAndOrganizationAndProcessorById(Constants.FEED_BACK.PROCESSED,
                    account.getOrganization(), account.getAccount(), replyDTO.getIdFeedBack());

            Organization organization = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
            feedbackHistory = insertFeedBackHistory(replyDTO.getIdFeedBack(), replyDTO.getComment(),
                    account.getAccount(), Constants.FEED_BACK.PROCESSED, account.getOrganization(), account.getAccount(), organization.getName() + " " + Constants.FEED_BACK_HISTORY.RELY_FEED_BACK);

//            } else {
//                throw new ValidationException("ValidationException.error.not.same.organization.reprocess.feed.back");
//            }
        }
        saveIconFeedbackHistory(replyDTO, feedbackHistory);
        return new ResponseBase(replyDTO);
    }

    @Override
    public ResponseBase closeFeedBack(RemoveFeedBackDTO removeFeedBackDTO) throws ValidationException {
        AccountDTO account = AccountLogonContext.currentUser();
        Feedback feedback = feedbackRepository.findById(removeFeedBackDTO.getIdFeedBack()).orElse(null);
        if (feedback == null) {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        } else {
            if (feedback.getSender().equals(account.getAccount())) {
                feedbackRepository.updateCloseStatusById(Constants.FEED_BACK.CLOSED, removeFeedBackDTO.getIdFeedBack());
//                List<FeedbackRelateTo> feedbackRelateTos = feedbackRelateToRepository.findAllByFeedbackId(removeFeedBackDTO.getIdFeedBack());
//                if (feedbackRelateTos.size() != 0) {
//                    for (FeedbackRelateTo feedbackRelateTo : feedbackRelateTos) {
//                        feedbackRepository.updateStatusAndOrganizationAndProcessorById(Constants.FEED_BACK.PROCESSED,
//                                account.getOrganization(), account.getAccount(), feedbackRelateTo.getFeedbackIdRelateTo());
//                    }
//                }
            } else {
                throw new ValidationException("ValidationException.error.not.same.account.close.feed.back");
            }
        }
        return new ResponseBase(removeFeedBackDTO);
    }

    @Override
    public ResponseBase reprocess(IdeaDTO relyDTO) throws Exception {
        trimSpaceUtil.validate(relyDTO);
        checkFile(relyDTO.getFiles());
        AccountDTO account = AccountLogonContext.currentUser();
        Feedback feedback = feedbackRepository.findById(relyDTO.getIdFeedBack()).orElse(null);

        if (feedback == null) {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        } else {
            if (account.getAccount().equals(feedback.getSender())) {
                feedbackRepository.updateStatusById(Constants.FEED_BACK.WATCHED, relyDTO.getIdFeedBack());
                Organization organization1 = organizationRepo.findByCodeAndStatus(feedback.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                FeedbackHistory feedbackHistory1 = insertFeedBackHistory(relyDTO.getIdFeedBack(), relyDTO.getIdea(), account.getAccount(),
                        Constants.FEED_BACK.WATCHED, feedback.getOrganization(), null, Constants.FEED_BACK_HISTORY.REPROCESS_FEED_BACK + " " + organization1.getName());
                saveIconReprocess(relyDTO, feedbackHistory1);
                List<FeedbackRelateTo> feedbacks = feedbackRelateToRepository.findAllByFeedbackId(relyDTO.getIdFeedBack());

                if (feedbacks.size() != 0) {
                    for (FeedbackRelateTo feedbackRelateTo : feedbacks) {
                        feedbackRepository.updateStatusById(Constants.FEED_BACK.PROCESSING, feedbackRelateTo.getFeedbackIdRelateTo());
                        Organization organization = organizationRepo.findByCodeAndStatus(feedback.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                        FeedbackHistory feedbackHistory = insertFeedBackHistory(feedbackRelateTo.getFeedbackIdRelateTo(), relyDTO.getIdea(), account.getAccount(),
                                Constants.FEED_BACK.WATCHED, feedback.getOrganization(), null, Constants.FEED_BACK_HISTORY.REPROCESS_FEED_BACK + " " + organization.getName());
                        saveIconReprocess(relyDTO, feedbackHistory);
                    }
                }
                List<FeedbackRelateTo> feedbackRelateTos = feedbackRelateToRepository.findAllByFeedbackIdRelateTo(relyDTO.getIdFeedBack());
                if (feedbackRelateTos.size() != 0) {
                    for (FeedbackRelateTo feedbackRelateTo : feedbackRelateTos) {
                        feedbackRepository.updateStatusById(Constants.FEED_BACK.WATCHED, feedbackRelateTo.getFeedbackIdRelateTo());
                        Organization organization = organizationRepo.findByCodeAndStatus(feedback.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                        FeedbackHistory feedbackHistory = insertFeedBackHistory(feedbackRelateTo.getFeedbackIdRelateTo(), relyDTO.getIdea(), account.getAccount(),
                                Constants.FEED_BACK.WATCHED, feedback.getOrganization(), null, Constants.FEED_BACK_HISTORY.REPROCESS_FEED_BACK + " " + organization.getName());
                        saveIconReprocess(relyDTO, feedbackHistory);
                    }

                }

            } else {
                throw new ValidationException("ValidationException.error.not.same.account.reprocess.feed.back");
            }
        }
        return new ResponseBase(relyDTO);
    }

    @Override
    public ResponseBase list(String idFeedBack, int page, int size, Integer status) throws IllegalAccessException {
        List<FeedBackHistoryImgResponse> feedBackHistoryImgResponsesFinal = new ArrayList<>();
        ICallStoredObj callStoredObj = new FeedBackCallStoredDTO(idFeedBack, page, size, status);
        ListResponse res = (ListResponse) callStoredRepository.list(callStoredObj);
        List<FeedBackHistoryResponse> feedBackHistoryResponses = (List<FeedBackHistoryResponse>) res.getList();
        for (FeedBackHistoryResponse feedBackHistoryResponse : feedBackHistoryResponses) {
            FeedBackHistoryImgResponse feedBackHistoryImgResponse = new FeedBackHistoryImgResponse();
            feedBackHistoryImgResponse = modelMapper.map(feedBackHistoryResponse, FeedBackHistoryImgResponse.class);
//            List<File> files = fileRepository.findByRelativeCodeAndTable(feedBackHistoryResponse.getId(), Constants.TBL_NAME.FEED_BACK);
//            if (CollectionUtils.isNotEmpty(files)) {
//                List<FileFeedBackDTO> fileFeedBackDTOS = new ArrayList<>();
//                for (File file : files) {
//                    FileFeedBackDTO fileFeedBackDTO = new FileFeedBackDTO();
//                    fileFeedBackDTO.setFile(Base64.getEncoder().encodeToString(file.getContent()));
//                    fileFeedBackDTO.setFileName(file.getFileName());
//                    fileFeedBackDTOS.add(fileFeedBackDTO);
//                }
//                feedBackHistoryImgResponse.setFiles(fileFeedBackDTOS);
//            }
            feedBackHistoryImgResponsesFinal.add(feedBackHistoryImgResponse);
        }
        return new ResponseBase(feedBackHistoryImgResponsesFinal);
    }

    @Override
    public ResponseBase received(String id) throws Exception {
        Feedback feedback = feedbackRepository.findById(id).orElse(null);
        AccountDTO account = AccountLogonContext.currentUser();
        if (feedback != null) {
            if (account.getOrganization().equals(feedback.getOrganization())) {
                feedbackRepository.updateStatusById(Constants.FEED_BACK.NOT_SEEN, id);
                Organization organization1 = organizationRepo.findByCodeAndStatus(feedback.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                FeedbackHistory feedbackHistory1 = insertFeedBackHistory(id, organization1.getName() + " " + Constants.FEED_BACK_HISTORY.RECEIVED_FEED_BACK, account.getAccount(),
                        Constants.FEED_BACK.NOT_SEEN, feedback.getOrganization(), account.getAccount(), organization1.getName() + " " + Constants.FEED_BACK_HISTORY.RECEIVED_FEED_BACK);

            } else {
                throw new ValidationException("ValidationException.error.not.exist.feed.classify.received");
            }
        } else {
            throw new ValidationException("ValidationException.error.not.exist.feed.back");
        }
        return new ResponseBase(id);
    }

    public FeedbackHistory insertFeedBackHistory(String idFeedBack, String Comment, String sender, Integer status, String Organization, String processor, String action) {
        FeedbackHistory feedbackHistory = new FeedbackHistory();
        feedbackHistory.setFeedbackId(idFeedBack);
        feedbackHistory.setComment(Comment);
        feedbackHistory.setSender(sender);
        feedbackHistory.setStatus(status);
        feedbackHistory.setAction(action);
        feedbackHistory.setOrganization(Organization);
        if (StringUtils.isNotEmpty(processor)) {
            feedbackHistory.setProcessor(processor);
        }
        FeedbackHistory feedbackHistory1 = feedbackHistoryRepository.save(feedbackHistory);
        return feedbackHistory1;
    }

    private void saveIcon(FeedBackDTO feedBackDTO, Feedback feedback) throws Exception {

//        if (feedBackDTO.getId() == null) {  // create
//            if (CollectionUtils.isNotEmpty(feedBackDTO.getFiles())) {
//                insertFile(feedBackDTO.getFiles(), feedback);
//            }
//        } else {  // update
//            List<File> files = fileRepository.findByRelativeCodeAndTable(feedBackDTO.getId(), Constants.TBL_NAME.FEED_BACK);
//            if (CollectionUtils.isEmpty(files)) {
//                if (CollectionUtils.isNotEmpty(feedBackDTO.getFiles())) {
//                    insertFile(feedBackDTO.getFiles(), feedback);
//                }
//            } else {
//                fileRepository.deleteAll(files);
//                if (CollectionUtils.isNotEmpty(feedBackDTO.getFiles())) {
//                    insertFile(feedBackDTO.getFiles(), feedback);
//                }
//            }
//        }
    }

    private void saveIconFeedbackHistory(ReplyDTO replyDTO, FeedbackHistory feedbackHistory) throws Exception {
        if (feedbackHistory.getId() != null) {  // create
            if (CollectionUtils.isNotEmpty(replyDTO.getFiles())) {
                insertFileHistory(replyDTO.getFiles(), feedbackHistory);
            }
        }
    }

    private void saveIconReprocess(IdeaDTO ideaDTO, FeedbackHistory feedbackHistory) throws Exception {
        if (feedbackHistory.getId() != null) {  // create
            if (CollectionUtils.isNotEmpty(ideaDTO.getFiles())) {
                insertFileHistory(ideaDTO.getFiles(), feedbackHistory);
            }
        }
    }

    private void saveIconFeedbackRemove(RemoveFeedBackDTO removeFeedBackDTO, FeedbackHistory feedbackHistory) throws Exception {
        if (feedbackHistory.getId() != null) {  // create
            if (CollectionUtils.isNotEmpty(removeFeedBackDTO.getFiles())) {
                insertFileHistory(removeFeedBackDTO.getFiles(), feedbackHistory);
            }
        }
    }


    public void insertFileHistory(List<FileFeedBackDTO> fileFeedBackDTOS, FeedbackHistory feedbackHistory) throws Exception {
        for (FileFeedBackDTO fileFeedBackDTO : fileFeedBackDTOS) {
//            fileRepository.save(newInstanceFromBase64(fileFeedBackDTO.getFile(), fileFeedBackDTO.getFileName(), feedbackHistory.getId(), Constants.TBL_NAME.FEED_BACK));
        }
    }

    public void insertFile(List<FileFeedBackDTO> fileFeedBackDTOS, Feedback feedback) throws Exception {
        for (FileFeedBackDTO fileFeedBackDTO : fileFeedBackDTOS) {
//            fileRepository.save(newInstanceFromBase64(fileFeedBackDTO.getFile(), fileFeedBackDTO.getFileName(), feedback.getId(), Constants.TBL_NAME.FEED_BACK));
        }
    }


//    private File newInstanceFromBase64(String base64Str, String fileType, String idFeedBack, String appTblName) throws Exception {
//        File file = new File(Base64.getDecoder().decode(base64Str), fileType, idFeedBack, appTblName);
//        file.setStatus(Constants.FILE_STATUS.ACTIVE);
//        return file;
//    }

    public void checkFileType(String fileName) throws ValidationException {
        if (!(fileName.endsWith("png") || fileName.endsWith("jpg") || fileName.endsWith("jpeg")
                || fileName.endsWith("gif") || fileName.endsWith("tiff") || fileName.endsWith("PNG") || fileName.endsWith("JPG") || fileName.endsWith("JPEG")
                || fileName.endsWith("GIF") || fileName.endsWith("TIFF"))) {
            throw new ValidationException("ValidationException.error.type.size.back");
        }
    }

    public void checkFileSize(String base64Str) throws ValidationException {
        var length = base64Str.contains("base64,") ? base64Str.split(",")[1].length() : base64Str.length();
        var fileSizeInByte = ((double) length / 4) * 3;
        fileSizeInByte = (fileSizeInByte / 1024) / 1024;
        if (fileSizeInByte > 200) {
            throw new ValidationException("ValidationException.error.size.file.back.5KB");
        }
    }

    public void checkFile(List<FileFeedBackDTO> fileFeedBackDTOS) throws ValidationException {
        if (fileFeedBackDTOS.size() > 3) {
            throw new ValidationException("ValidationException.error.size.file.feed.back");
        } else {
            for (FileFeedBackDTO fileFeedBackDTO : fileFeedBackDTOS) {
                checkFileType(fileFeedBackDTO.getFileName());
                checkFileSize(fileFeedBackDTO.getFile());
            }
        }

    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public void callNotification(String title, String content) {
        if (status) {
            Gson gson = new Gson();
            NotificationCoreRqDTO notificationCoreRqDTO = new NotificationCoreRqDTO(title, content);
            String body = gson.toJson(notificationCoreRqDTO);
            Authentication authentication = (Authentication) SecurityContextHolder.getContext().getAuthentication();
            if (authentication.getPrincipal() instanceof Jwt) {
                String accountJson = ((Jwt) authentication.getPrincipal()).getTokenValue().toString();
                String res = callRestAPIServiceImpl.call(url, HttpMethod.POST, null, body, accountJson).getBody();
            }
        }
    }

}
