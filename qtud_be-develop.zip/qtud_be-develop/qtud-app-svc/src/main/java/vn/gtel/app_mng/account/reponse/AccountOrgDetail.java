package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import java.util.List;

@Data
public class AccountOrgDetail {
    private List<AccountDetailOrg> listAccountDetailOrgTop;
    private List<AccountDetailOrg> listAccountDetailOrgBottom;
    private List<OrganizationManage> listOrganizationManage;

}
