/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.category.dto.storedObj;

import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.app_mng.category.dto.req.AppTextFilter;
import vn.gtel.app_mng.category.dto.res.ActionNameIdRes;
import vn.gtel.app_mng.category.dto.res.MenuActionItemResponse;
import vn.gtel.app_mng.category.dto.res.MenuActionRes;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.role.dto.menu_action.MenuByAccount;
import vn.gtel.app_mng.role.dto.menu_action.RoleMenuByAppFilter;
import vn.gtel.app_mng.role.dto.menu_action.RoleMenuItemDTO;

import java.util.HashMap;
import java.util.Map;

public class MenuActionCallStoredDTO extends ICallStoredObj {

    public static final String PACKAGE_NAME = "PKG_DM_CHUC_NANG";
    public static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_CHUC_NANG";
    public static final String PROC_SEARCH_TD_HD = "PROC_SEARCH_THUC_DON_HANH_DONG";
    public static final String PROC_GET_MENU_ACTION_BY_APP = "PROC_LAY_CHUC_NANG_HANH_DONG_THEO_PM";

    public static final String PROC_GET_MENU_ACTION_BY_ACCOUNT = "PROC_LAY_CHUC_NANG_HANH_DONG_THEO_TK";

    public static final String PROC_FIND_BY_ID_NAME = "PROC_FIND_CHUC_NANG";
    public static final String PROC_FIND_HANH_DONG_BY_THUC_DON_CODE = "PROC_FIND_HANH_DONG_BY_THUC_DON_CODE";
    public static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    public static final String IN_PAGE = "PI_PAGE";
    public static final String IN_SIZE = "PI_SIZE";
    public static final String IN_ID = "PI_ID";
    public static final String IN_APP_ID = "PI_APP_ID";
    public static final String IN_STATUS = "PI_STATUS";
    public static final String IN_MENU = "PI_MENU"; //
    public static final String IN_PI_NAME = "PI_NAME";
    public static final String IN_PARENT_MENU_CODE = "PI_PARENT_MENU_CODE"; //
    public static final String PI_CODE = "PI_CODE";
    public static final String IN_APP = "PI_UNG_DUNG";
    public static final String IN_GROUP_ROLE = "PI_GROUP_ROLE";
    public static final String IN_TK_DANG_NHAP_ID = "PI_TK_DANG_NHAP_ID";
    public static final String IN_IS_NOT_MENU = "PI_IS_NOT_MENU";
    public static final String IN_CHECK_ADMIN = "PI_CHECK_ADMIN";

    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(ActionNameIdRes.class);
    }

    ;

    private void setSearchBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(MenuActionItemResponse.class);
    }

    ;

    public MenuActionCallStoredDTO(String menuCode, Integer status) {
        setBase();
        setStoredName(PROC_FIND_HANH_DONG_BY_THUC_DON_CODE);
        params.put(PI_CODE, menuCode);
        params.put(IN_STATUS, status);

        setParams(params);
    }

    public MenuActionCallStoredDTO(AppTextFilter appTextFilter) {
        setSearchBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, appTextFilter.getKeySearch());
        params.put(IN_PAGE, appTextFilter.getPage());
        params.put(IN_SIZE, appTextFilter.getSize());
        params.put(IN_APP, appTextFilter.getApp());
        params.put(IN_MENU, appTextFilter.getMenu());
        params.put(IN_PI_NAME, appTextFilter.getName());
        params.put(IN_PARENT_MENU_CODE, appTextFilter.getParentMenuCode());
        params.put(IN_STATUS, appTextFilter.getStatus());
        params.put(IN_GROUP_ROLE, null);
        params.put(IN_TK_DANG_NHAP_ID, null);
        params.put(IN_IS_NOT_MENU, null);
        params.put(IN_CHECK_ADMIN, null);
        setParams(params);
    }

    public MenuActionCallStoredDTO(RoleMenuByAppFilter roleMenuByAppFilter) {
        setBase();
//		setStoredName(PROC_GET_MENU_ACTION_BY_APP);
        setStoredName(PROC_GET_MENU_ACTION_BY_ACCOUNT);
        setResponseType(RoleMenuItemDTO.class);
        params.put(IN_PAGE, roleMenuByAppFilter.getPage());
        params.put(IN_SIZE, roleMenuByAppFilter.getSize());
		params.put(IN_APP, roleMenuByAppFilter.getApplication());
        params.put(IN_TK_DANG_NHAP_ID, AccountLogonContext.currentUser().getId());
        setParams(params);
    }

    public MenuActionCallStoredDTO(String appCode, boolean isPaging) {
        setSearchBase();
        setResponseType(MenuByAccount.class);
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, null);
        params.put(IN_PAGE, Constants.DEFAULT_PAGE);
        params.put(IN_SIZE, Constants.MAX_ROW_SELECT);
        params.put(IN_APP, appCode);
        params.put(IN_MENU, null);
        params.put(IN_PI_NAME, null);
        params.put(IN_PARENT_MENU_CODE, null);
        params.put(IN_STATUS, 1L);
        params.put(IN_GROUP_ROLE, null);
        params.put(IN_TK_DANG_NHAP_ID, AccountLogonContext.currentUser().getId());
        params.put(IN_IS_NOT_MENU, 1L);
        params.put(IN_CHECK_ADMIN, "NONEMPTY");
        setParams(params);
    }

    public MenuActionCallStoredDTO(String id) {
        setBase();
        setResponseType(MenuActionRes.class);
        setStoredName(PROC_FIND_BY_ID_NAME);
        params.put(IN_ID, id);
        setParams(params);
    }

}
