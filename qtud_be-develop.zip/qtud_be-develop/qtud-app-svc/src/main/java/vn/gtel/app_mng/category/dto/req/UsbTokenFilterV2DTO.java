package vn.gtel.app_mng.category.dto.req;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.dto.request.PageFilter;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class UsbTokenFilterV2DTO  extends PageFilter implements Serializable {
    private String textSearch;
    private Integer digitalCertificateType;
    private String code;
    private String fullName;
    private String phoneNumber;
    private String cmndCccd;
    private String address;
    private String city;

    private String organization;
    private String account;
    private Long status;
    private String expired_from;
    private String expired_to;
    private Long type_date;

    public UsbTokenFilterV2DTO(Integer page, Integer size, String textSearch, Integer digitalCertificateType, String code,
                               String fullName, String phoneNumber, String cmndCccd, String address, String city, String organization) {
        super(page, size);
        this.textSearch = textSearch;
        this.digitalCertificateType = digitalCertificateType;
        this.code = code;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.cmndCccd = cmndCccd;
        this.address = address;
        this.city = city;
        this.organization = organization;
    }
}
