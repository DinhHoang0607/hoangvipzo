package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;
import java.util.Map;

@Data
public class MenuExcelObj  extends IExcelMapperObj {
    private Map<String, Integer> fieldToIndexMap = new HashMap<>();
    public MenuExcelObj(int stt){
        setFieldToIndexMap(new HashMap<>());
        getFieldToIndexMap().put("code",stt+1);
        getFieldToIndexMap().put("codeOther",stt+2);
        getFieldToIndexMap().put("name",stt+3);
        getFieldToIndexMap().put("parentMenuCode",stt+4);
        getFieldToIndexMap().put("appCode",stt+5);
        getFieldToIndexMap().put("url",stt+6);
        getFieldToIndexMap().put("endPoint",stt+7);
        getFieldToIndexMap().put("type",stt+8);
        getFieldToIndexMap().put("component",stt+9);
        getFieldToIndexMap().put("description",stt+10);
        getFieldToIndexMap().put("order",stt+11);
        getFieldToIndexMap().put("resultColumn",stt+12);

    }
}
