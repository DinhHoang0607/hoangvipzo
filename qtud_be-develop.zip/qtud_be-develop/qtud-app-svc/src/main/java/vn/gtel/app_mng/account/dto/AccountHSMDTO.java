package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountHSMDTO {

//    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.validate.max.size.36")
//    private String id;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(min = Constants.VALID.MIN_LENGTH_ACCOUNT_3, message = "error.common.validate.min.size.3")
    @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
    @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.character.number")
    private String account;

    @NotEmpty(message = "error.common.validate.not.empty")
    private String alias;

    @NotEmpty(message = "error.common.validate.not.empty")
    private String slotId;

    @NotEmpty(message = "error.common.validate.not.empty")
    private String userPin;

//    @NotEmpty(message = "error.common.validate.not.empty")
//    private MultipartFile signImg;

//    private String signImgName;

    private String thumbprint;

}
