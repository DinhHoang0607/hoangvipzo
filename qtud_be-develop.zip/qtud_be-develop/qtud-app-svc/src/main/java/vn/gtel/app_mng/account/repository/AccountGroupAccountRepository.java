package vn.gtel.app_mng.account.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;
import vn.gtel.app_mng.account.dto.response.AccountResDTO;
import vn.gtel.app_mng.account.model.AccountGroupAccount;

import java.util.List;

@Repository
public interface AccountGroupAccountRepository extends JpaRepository<AccountGroupAccount, String> {
    List<AccountGroupAccount> findByGroupAccount(String groupAccount);

    List<AccountGroupAccount> findByGroupAccountAndStatus(String groupAccount, Integer status);

    @Query(value = "select new vn.gtel.app_mng.account.dto.response.AccountResDTO (ag.id, ag.account, ag.accountName, 2," +
            " a.detail.policeNumber, a.detail.militaryName, a.detail.positionName ) " +
            " from AccountGroupAccount ag " +
            " join AccountInfo a on a.account = ag.account and (a.status = 1 or a.status = 2) " +
            " where ag.groupAccount = :groupAccount and (:keySearch is null or upper(ag.account) like :keySearch " +
            " or upper(ag.accountName) like :keySearch) and ag.status <> -1 "
            , countQuery = "select count(ag) from AccountGroupAccount ag " +
            " join AccountInfo a on a.account = ag.account and (a.status = 1 or a.status = 2) " +
            " where ag.groupAccount = :groupAccount and (:keySearch is null or upper(ag.account) like :keySearch " +
            " or upper(ag.accountName) like :keySearch) and ag.status <> -1 ")
    Page<AccountResDTO> findByGroupAccountAndStatusPaging(String groupAccount, String keySearch, Pageable p);

    @Query(value = "select new vn.gtel.app_mng.account.dto.response.AccountResDTO ( aed.account, aed.fullName, " +
            " a.detail.policeNumber, a.detail.militaryName, a.detail.positionName ) " +
            " from AccountEmployeeDetail aed " +
            " join AccountInfo a on a.account = aed.account " +
            " where (a.status <> -1 and a.status <> 4) " +
            " and (:org is null or a.organization like concat('%',:org,'%')  or (:org like concat(substring(a.organization,1,6),'%') and a.organization like '%012' and a.organization not like '100037%')) " +
            " and (:account is null or a.account not like :account) and aed.account not in " +
            " (select aga.account from AccountGroupAccount aga where aga.status = 1 and aga.groupAccount = :groupAccount ) " +
            " and (:keySearch is null or upper(aed.account) like :keySearch or upper(aed.fullName) like :keySearch ) and aed.account <> 'admin'" +
            " order by aed.account "
            , countQuery = "select count(aed) from AccountEmployeeDetail aed " +
            " join AccountInfo a on a.account = aed.account " +
            " where (a.status <> -1 and a.status <> 4 ) " +
            " and (:org is null or a.organization like concat('%',:org,'%')  or (:org like concat(substring(a.organization,1,6),'%') and a.organization like '%012' and a.organization not like '100037%')) " +
            " and (:account is null or a.account not like :account) and aed.account not in " +
            " (select aga.account from AccountGroupAccount aga where aga.status = 1 and aga.groupAccount = :groupAccount ) " +
            " and (:keySearch is null or upper(aed.account) like :keySearch or upper(aed.fullName) like :keySearch) and aed.account <> 'admin'")
    Page<AccountResDTO> findByGroupAccountAndStatusNotInPaging(String groupAccount, String keySearch, Pageable p, String org, String account);

    List<AccountGroupAccount> findByAccount(String account);

    @Query(value = "select distinct new vn.gtel.app_mng.account.dto.CodeItemWithActionDTO (ag.id, ag.code, ag.name, 2 ) " +
            " from AccountGroup ag " +
            " join AccountGroupAccount aga on aga.groupAccount = ag.code " +
            " where aga.status = 1 and ag.status = 1 " +
            " and aga.account = :account ")
    List<CodeItemWithActionDTO> findGroupByAccount(String account);

    boolean existsAccountGroupAccountByGroupAccountAndStatus(String groupCode, int status);

    void deleteByAccountAndCreatedByNotAndCreatedByNot(String account, String admin, String subAdminPc08);

    boolean existsAccountGroupAccountByGroupAccountAndStatusNot(String code, int i);

    void deleteAllByAccount(String account);
}
