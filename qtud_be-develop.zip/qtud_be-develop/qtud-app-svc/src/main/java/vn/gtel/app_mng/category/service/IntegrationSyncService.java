package vn.gtel.app_mng.category.service;

import javassist.NotFoundException;
import vn.gtel.app_mng.category.dto.req.IntegrationSyncFilter;
import vn.gtel.app_mng.category.dto.req.IntegrationSyncRequestDto;
import vn.gtel.app_mng.category.dto.req.OrgGroupRoleRequestDto;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.xml.bind.ValidationException;
import java.util.List;

public interface IntegrationSyncService {
    ResponseBase search(IntegrationSyncFilter dto);

    List<String> getOrgUnused();

    ResponseBase getAppUnused(String keySearch, Integer pageIndex, Integer pageSize);

    ResponseBase hasExists(String org, String app);

    ResponseBase detail(String id) throws Exception;

    ResponseBase save(IntegrationSyncRequestDto dto) throws Exception;

    ResponseBase delete(String id) throws Exception;

    ResponseBase activeInActive(String id) throws Exception;

    ResponseBase saveRole(String id, OrgGroupRoleRequestDto request) throws ValidationException, NotFoundException;

    ResponseBase getListOrgCode();

    ResponseBase getApplicationByOrganization(String orgCode);
}
