/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/23/22, 4:23 PM
 *
 */

package vn.gtel.app_mng.account.filter;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
public class AccountLeadOrEmFilter extends TextFilter {

    private Integer positionType;
    private Integer type;
    private String org;

    public AccountLeadOrEmFilter(Integer page, Integer size, String keySearch, Integer positionType, Integer type,String org) {
        super(page, size, keySearch);
        this.positionType = positionType;
        this.type = type;
        this.org = org;
    }






}
