package vn.gtel.app_mng.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatternRoleDTO implements Serializable {
    @Column(name = "MA_QUYEN")
    private String permissionCode;
    @Column(name = "PHUONG_THUC")
    private String method;
    @Column(name = "DUONG_DAN")
    private String endpoint;

    private Integer limitReqNumber;

    public PatternRoleDTO(String permissionCode, String method, String endpoint) {
        this.permissionCode = permissionCode;
        this.method = method;
        this.endpoint = endpoint;
    }
}
