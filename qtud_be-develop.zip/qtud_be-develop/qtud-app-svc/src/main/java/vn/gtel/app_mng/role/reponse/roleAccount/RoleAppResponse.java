package vn.gtel.app_mng.role.reponse.roleAccount;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleAppResponse {

	@Column(name = "APP_ID")
	private String applicationId;

	@Column(name = "APP_NAME")
	private String appName;

}
