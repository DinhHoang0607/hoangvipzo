/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  UsbTokenController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  1/17/22, 4:46 PM
 *
 */

package vn.gtel.app_mng.category.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterDTO;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterV2DTO;
import vn.gtel.app_mng.category.dto.req.UsbTokenRequestDTO;
import vn.gtel.app_mng.category.service.UsbTokenService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.CommonService;

import javax.validation.Valid;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Instant;
import java.util.Optional;

@Tag(name = "Quản lý USB Token")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/usb-token")
public class UsbTokenController {


    @Autowired
    private UsbTokenService usbTokenService;

    @Operation(summary = "Danh sách tìm kiếm usb token")
    @GetMapping(value = "")
    public ResponseBase list(@RequestParam(name = "textSearch", required = false) String textSearch,
                             @RequestParam(name = "digitalCertificateType", required = false) Integer digitalCertificateType,
                             @RequestParam(name = "code", required = false) String code,
                             @RequestParam(name = "fullName", required = false) String fullName,
                             @RequestParam(name = "phoneNumber", required = false) String phoneNumber,
                             @RequestParam(name = "cmndCccd", required = false) String cmndCccd,
                             @RequestParam(name = "address", required = false) String  address,
                             @RequestParam(name = "city", required = false) String  city,
                             @RequestParam(name = "organization",required = false) String organization,
//                             @RequestParam(name = "account",required = false) String account,
//                             @RequestParam(name = "status",required = false) String status,
//                             @RequestParam(name = "expired_from",required = false) String expired_from,
//                             @RequestParam(name = "expired_to",required = false) String expired_to,
//                             @RequestParam(name = "type_date",required = false) String type_date,

                             @RequestParam(name = "page") Optional<Integer> page,
                             @RequestParam(name = "size") Optional<Integer> size) throws IllegalAccessException {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.DEFAULT_SIZE);
        UsbTokenFilterV2DTO usbTokenFilterDTO = new UsbTokenFilterV2DTO(pageNumber, sizeNumber, textSearch, digitalCertificateType, code, fullName, phoneNumber, cmndCccd, address, city, organization);
        return usbTokenService.list(usbTokenFilterDTO);
    }

//    @Operation(summary = "Danh sách usb token")
//    @GetMapping(value = "/list")
//    public ResponseBase listSearch(@RequestParam(name = "textSearch", required = false) String textSearch,
//                                   @RequestParam(name = "typeDate", required = false) Long typeDate,
//                                   @RequestParam(name = "code", required = false) String code,
//                                   @RequestParam(name = "organization", required = false) String organization,
//                                   @RequestParam(name = "account", required = false) String account,
//                                   @RequestParam(name = "expiredDateFrom", required = false) Instant expiredDateFrom,
//                                   @RequestParam(name = "expiredDateTo", required = false) Instant expiredDateTo,
//                                   @RequestParam(name = "page", required = false) Optional<Integer> page,
//                                   @RequestParam(name = "size", required = false) Optional<Integer> size) throws IllegalAccessException {
//        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
//        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
//        UsbTokenFilterDTO usbTokenFilterDTO = new UsbTokenFilterDTO(pageNumber, sizeNumber, textSearch, code, account, organization, Constants.STATUS_CATEGORY_ACTIVE, expiredDateFrom, expiredDateTo, typeDate);
//        return usbTokenService.list(usbTokenFilterDTO);
//    }

    @Operation(summary = "Chi tiết usb token")
    @GetMapping(value = "/{id}")
    public ResponseBase detail(@PathVariable String id) throws Exception {
        return usbTokenService.detail(id);
    }

    @Operation(summary = "Thêm mới usb token")
    @PostMapping(value = "")
    public ResponseBase create(@RequestBody @Valid UsbTokenRequestDTO usbTokenRequestDTO) throws Exception {
        return usbTokenService.save(usbTokenRequestDTO);
    }

    @Operation(summary = "Cập nhật usb token")
    @PutMapping(value = "")
    public ResponseBase update(@RequestBody @Valid UsbTokenRequestDTO usbTokenRequestDTO) throws Exception {
        return usbTokenService.save(usbTokenRequestDTO);
    }

    @Operation(summary = "Kích hoạt/ Hủy kích hoạt usb token")
    @PatchMapping(value = "")
    public ResponseBase activeDeActive(@RequestParam String id) throws Exception {
        return usbTokenService.activeInActive(id);
    }

    @Operation(summary = "Xóa usb token")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@PathVariable String id) throws Exception {
        return usbTokenService.delete(id);
    }

    @Operation(summary = "Xóa usb token cứng")
    @DeleteMapping(value = "/delete/{id}")
    public ResponseBase deleteDB(@PathVariable String id) throws Exception {
        return usbTokenService.deleteDB(id);
    }

    @Operation(summary = "Export danh sách usb token")
    @GetMapping(value = "/export")
    public ResponseEntity export(@RequestParam(name = "textSearch", required = false) String textSearch,
                                 @RequestParam(name = "typeDate", required = false) Long typeDate,
                                 @RequestParam(name = "status", required = false) Long status,
                                 @RequestParam(name = "code", required = false) String code,
                                 @RequestParam(name = "organization", required = false) String organization,
                                 @RequestParam(name = "account", required = false) String account,
                                 @RequestParam(name = "expiredDateFrom", required = false) Instant expiredDateFrom,
                                 @RequestParam(name = "expiredDateTo", required = false) Instant expiredDateTo,
                                 @RequestParam(name = "page", required = false) Optional<Integer> page,
                                 @RequestParam(name = "size", required = false) Optional<Integer> size) throws FileNotFoundException, JRException {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        UsbTokenFilterDTO usbTokenFilterDTO = new UsbTokenFilterDTO(pageNumber, sizeNumber, textSearch, code, account, organization, status, expiredDateFrom, expiredDateTo, typeDate);
        return usbTokenService.export(usbTokenFilterDTO, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "Print danh sách usb token")
    @GetMapping(value = "/print")
    public ResponseEntity print(@RequestParam(name = "textSearch", required = false) String textSearch,
                                @RequestParam(name = "typeDate", required = false) Long typeDate,
                                @RequestParam(name = "status", required = false) Long status,
                                @RequestParam(name = "code", required = false) String code,
                                @RequestParam(name = "organization", required = false) String organization,
                                @RequestParam(name = "account", required = false) String account,
                                @RequestParam(name = "expiredDateFrom", required = false) Instant expiredDateFrom,
                                @RequestParam(name = "expiredDateTo", required = false) Instant expiredDateTo,
                                @RequestParam(name = "page", required = false) Optional<Integer> page,
                                @RequestParam(name = "size", required = false) Optional<Integer> size) throws FileNotFoundException, JRException {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        UsbTokenFilterDTO usbTokenFilterDTO = new UsbTokenFilterDTO(pageNumber, sizeNumber, textSearch, code, account, organization, status, expiredDateFrom, expiredDateTo, typeDate);
        return usbTokenService.export(usbTokenFilterDTO, Constants.EXPORT_TYPE.PDF.toString());
    }
    @Operation(summary = "Tải template import usb token")
    @GetMapping(value = "/template")
    public ResponseEntity template() throws IOException {
        return CommonService.downloadTemplate("IMPORT_USB_TOKEN_TEMPLATE1.xlsx", "template_import_usb_token.xlsx");
    }
    @Operation(summary = "Import phần mềm")
    @PostMapping(value = "/import")
    public ResponseEntity importTemplate(@RequestParam("file") MultipartFile file) throws Exception {
        return usbTokenService.importExcel(file);
    }
}
