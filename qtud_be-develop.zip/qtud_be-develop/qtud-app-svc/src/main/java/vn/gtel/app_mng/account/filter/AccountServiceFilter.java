package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountServiceFilter extends TextFilter {
    private String organization;
    private Integer type;
    private String code;
    private String name;
    private String status;


    public AccountServiceFilter(Integer page, Integer size, String keySearch, String organization, Integer type, String code ,
                                String name, String status) {
        super(page, size, keySearch);
        this.name = name;
        this.code = code;
        this.status = status;
        this.organization = organization;
        this.type = type;
    }
}
