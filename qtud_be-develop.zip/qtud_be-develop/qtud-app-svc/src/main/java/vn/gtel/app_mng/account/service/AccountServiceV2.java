package vn.gtel.app_mng.account.service;

import vn.gtel.app_mng.account.filter.AccountFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

public interface AccountServiceV2 {
    ResponseBase listAccount(AccountFilter textFilter) throws IllegalAccessException;

    //    @Cacheable(value = "detailUser", key = "#id")
    ResponseBase detailAccount(String id) throws Exception;
}
