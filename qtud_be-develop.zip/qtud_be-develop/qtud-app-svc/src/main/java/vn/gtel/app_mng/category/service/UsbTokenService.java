
/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  UsbTokenService.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  1/17/22, 4:46 PM
 *
 */

package vn.gtel.app_mng.category.service;

import net.sf.jasperreports.engine.JRException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterDTO;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterV2DTO;
import vn.gtel.app_mng.category.dto.req.UsbTokenRequestDTO;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import java.io.FileNotFoundException;


public interface UsbTokenService {

   ResponseBase list(UsbTokenFilterV2DTO usbTokenFilterDTO) throws IllegalAccessException;

   ResponseBase detail(String id) throws Exception;

   ResponseBase save(UsbTokenRequestDTO usbTokenRequestDTO) throws Exception;

   ResponseBase delete(String id) throws Exception;

   ResponseBase deleteDB(String id) throws Exception;

   ResponseBase activeInActive(String id) throws Exception;

   ResponseEntity export(UsbTokenFilterDTO usbTokenFilterDTO, String type) throws FileNotFoundException, JRException;

   ResponseEntity importExcel(MultipartFile file) throws Exception;
}
