package vn.gtel.app_mng.category.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

@Entity
@Table(name = "TBL_DM_CHUC_NANG_HANH_DONG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuAction extends AuditModelBase {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "CHUC_NANG")
    private String menu;

    @Basic
    @Column(name = "HANH_DONG")
    private String action;

    @Basic
    @Column(name = "DUONG_DAN")
    private String endPoint;

    @Basic
    @Column(name = "PHUONG_THUC")
    private String method;

    @Basic
    @Column(name = "MA_KHAC")
    private String codeActionOther;

}
