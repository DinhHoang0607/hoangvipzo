package vn.gtel.app_mng.account.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;

import java.util.List;

@Data
@NoArgsConstructor
@FieldNameConstants
@AllArgsConstructor
@Builder
public class AccountGroupResDTO {
    private String id;
    private String code;
    private String name;
    private String description;
    private Integer status;
    private String statusName;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<CodeItemWithActionDTO> accounts;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<CodeItemWithActionDTO> groupRoles;

    public AccountGroupResDTO(String id, String code, String name, String description, Integer status, String statusName) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.description = description;
        this.status = status;
        this.statusName = statusName;
    }
}
