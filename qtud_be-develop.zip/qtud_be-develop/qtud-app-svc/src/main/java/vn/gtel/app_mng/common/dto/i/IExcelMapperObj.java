/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  IExcelMapperObj.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  1/17/22, 4:29 PM
 *
 */

package vn.gtel.app_mng.common.dto.i;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class IExcelMapperObj {
    Map<String, Integer> fieldToIndexMap;
    List<String> fieldExport;
}
