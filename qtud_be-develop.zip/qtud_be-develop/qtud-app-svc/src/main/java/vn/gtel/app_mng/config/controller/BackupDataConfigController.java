/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  DashBoardController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/19/22, 2:45 PM
 *
 */

package vn.gtel.app_mng.config.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.config.dto.BackUpDataConfigFilter;
import vn.gtel.app_mng.config.dto.BackUpDataConfigRqDTO;
import vn.gtel.app_mng.config.service.BackupDataConfigService;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Tag(name = "Cấu hình sao lưu dữ liệu")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/backup-data-config")
@Validated
public class BackupDataConfigController {

    @Autowired
    private BackupDataConfigService backupDataConfigService;

    @Operation(summary = "Tìm kiếm danh sách cấu hình")
    @GetMapping(value = "/list")
    public ResponseBase list(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
                             @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "keySearch", required = false) String keySearch,
                             @RequestParam(name = "type", required = false) String type,
                             @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                             @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")  @RequestParam(name = "page", required = false) Integer page,
                             @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                             @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")  @RequestParam(name = "size", required = false) Integer size) throws IllegalAccessException {
        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.DEFAULT_SIZE;
        }
        BackUpDataConfigFilter filter = new BackUpDataConfigFilter(page, size, keySearch, type);
        return backupDataConfigService.search(filter);
    }

    @Operation(summary = "Lưu cấu hình")
    @PostMapping(value = "")
    public ResponseBase save(@RequestBody @Valid BackUpDataConfigRqDTO backUpDataConfigRqDTO) throws Exception {
        return backupDataConfigService.save(backUpDataConfigRqDTO);
    }
//
//    @Operation(summary = "Số truy cập trong năm")
//    @GetMapping(value = "/access-year")
//    public ResponseBase accessYear() {
//        return dashboardService.sumAccessByTime(Constants.TIME_FORMAT.YEAR);
//    }
//
//    @Operation(summary = "Số lượt truy cập theo phần mềm")
//    @GetMapping(value = "/access-by-app")
//    public ResponseBase accessByApp() {
//        return dashboardService.countAccessByApp();
//    }
//
//    @Operation(summary = "Số lượt tài khoản đang trực tuyến theo tỉnh")
//    @GetMapping(value = "/online-by-city")
//    public ResponseBase onlineByCity() {
//        return dashboardService.countOnlineByCity();
//    }
//
//    @Operation(summary = "TK mức độ cảnh báo theo số lượt truy cập")
//    @GetMapping(value = "/alert-by-access")
//    public ResponseBase alertByAccess(@RequestParam Long fromTime,
//                                      @RequestParam Long toTime,
//                                      @RequestParam String aggType) {
//        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_ALERT_ACCESS);
//        return dashboardService.getChartValue(filterChart);
//    }
//
//    @Operation(summary = "Số lượng tài khoản đăng nhập")
//    @GetMapping(value = "/count-login")
//    public ResponseBase countLogin(@RequestParam Long fromTime,
//                                   @RequestParam Long toTime,
//                                   @RequestParam String aggType) {
//        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_LOGIN_ACCOUNT);
//        return dashboardService.getChartValue(filterChart);
//    }


}
