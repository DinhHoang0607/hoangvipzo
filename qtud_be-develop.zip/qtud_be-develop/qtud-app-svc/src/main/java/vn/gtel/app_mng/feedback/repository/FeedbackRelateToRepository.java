package vn.gtel.app_mng.feedback.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.feedback.model.FeedbackRelateTo;

import java.util.List;

@Repository
public interface FeedbackRelateToRepository extends JpaRepository<FeedbackRelateTo, String> {
    List<FeedbackRelateTo> findAllByFeedbackId(String id);

    List<FeedbackRelateTo> findAllByFeedbackIdRelateTo(String id);


}
