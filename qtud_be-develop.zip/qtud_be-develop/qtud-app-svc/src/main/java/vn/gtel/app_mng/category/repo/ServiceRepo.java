package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.ServiceCategory;

@Repository
public interface ServiceRepo extends JpaRepository<ServiceCategory, String>{

}
