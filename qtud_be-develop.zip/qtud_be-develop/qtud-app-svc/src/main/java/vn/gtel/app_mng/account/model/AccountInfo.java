package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_TK_TAI_KHOAN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountInfo extends AuditModelBase {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Integer type;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

    @Basic
    @Column(name = "YC_DOI_MK")
    private Integer rqChangePw;

    @Basic
    @Column(name = "XAC_NHAN_THONG_TIN")
    private Integer confirmInformation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TAI_KHOAN", referencedColumnName = "TAI_KHOAN", insertable = false, updatable = false)
    private AccountEmpDetail detail;
}
