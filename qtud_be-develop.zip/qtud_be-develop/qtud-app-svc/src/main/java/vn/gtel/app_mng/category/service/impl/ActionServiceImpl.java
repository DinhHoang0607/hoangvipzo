/**
 * @author tronglm
 * app-mng
 * Dec 6, 2021
 */
package vn.gtel.app_mng.category.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.ActionCodeDTO;
import vn.gtel.app_mng.category.dto.excelObj.ActionExcelItemObj;
import vn.gtel.app_mng.category.dto.excelObj.ActionExcelObj;
import vn.gtel.app_mng.category.dto.storedObj.ActionCallStoredDTO;
import vn.gtel.app_mng.category.model.Action;
import vn.gtel.app_mng.category.repo.ActionCatRepo;
import vn.gtel.app_mng.category.service.ActionService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.DetailResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.ExcelObjectMapper;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.common.constants.ActionCode;
import vn.gtel.common.dto.LogActionDTO;
import vn.gtel.common.service.LoggingService;
import vn.gtel.common.util.LogUtil;

import javax.xml.bind.ValidationException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

@Service
public class ActionServiceImpl implements ActionService {

    @Autowired
    private ActionCatRepo actionCatRepo;
    @Autowired
    private CallStoredRepository callStoredRepository;
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private TrimSpaceUtil trimSpaceUtil;
    @Autowired
    private LoggingService loggingService;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");

    private static final String PREFIX_ERR_CONSTRAINT_MESSAGE = "ConstraintViolationException.";

    @Override
    @Transactional
    public String createAction(ActionCodeDTO req) throws Exception {
        trimSpaceUtil.validate(req);
        Action actionI = mapper.map(req, Action.class);
        actionCatRepo.save(actionI);
        // log
        String content = String.format("Đã thêm mới hành động có tên là %s và mã là %s", actionI.getName(), actionI.getCode());
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.action, ActionCode.ADD,
                content, Instant.now()));
        return actionI.getId();
    }


    @Override
    @Transactional
    public String updateAction(ActionCodeDTO req) throws Exception {
        trimSpaceUtil.validate(req);
        Action action = actionCatRepo.findById(req.getId()).orElse(null);
        String content = String.format("Đã sửa hành động có mã là %s ,", action.getCode());
        String logMess = this.getDetailAction(content, req, action);
        action.setName(req.getName());
        if (req.getDescription() != null) {
            action.setDescription(req.getDescription());
        }
        action.setOrder(req.getOrder());
        action.setCode(req.getCode());
        action.setStatus(req.getStatus());
        actionCatRepo.save(action);
        // log
        if (!logMess.equals(content)) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.action, ActionCode.EDIT, logMess, Instant.now()));
        }
        return action.getId();
    }

    private String getDetailAction(String logContent, ActionCodeDTO req, Action action) {
        if (req == null || action == null) {
            return null;
        }

        StringBuilder logMessage = new StringBuilder();
        logMessage.append(logContent);
        LogUtil.compareAndLog(logMessage, "[Tên thao tác] ", req.getName(), action.getName());
        LogUtil.compareAndLog(logMessage, "[Thứ tự] ", req.getOrder(), action.getOrder());
        LogUtil.compareAndLog(logMessage, "[Trạng thái] ", req.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa", action.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa");
        LogUtil.compareAndLog(logMessage, "[Mô tả] ", req.getDescription(), action.getDescription());
        return logMessage.toString();
    }


    @Override
    public void deleteAction(String id) throws Exception {
        //actionCatRepo.deleteById(id);
        Action action = actionCatRepo.findById(id).orElse(null);
        if (action == null) {
            throw new ValidationException("ValidationException.error.not.exist.action");
        } else {
            action.setStatus(Constants.ACTION_GROUP_STATUS.DELETED);
        }
        // log
        String content = String.format("Đã xóa hành động có tên là %s và mã là %s", action.getName(), action.getCode());
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.action, ActionCode.DEL, content, Instant.now()));
        actionCatRepo.save(action);

    }


    @Override
    public Object listAction(TextFilter textFilter, Integer status) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        ICallStoredObj callStoredObj = new ActionCallStoredDTO(textFilter, status);
        Object res = callStoredRepository.list(callStoredObj);
        return res;
    }


    @Override
    public Object detailAction(String id) throws Exception {
        ICallStoredObj callStoredObj = new ActionCallStoredDTO(id);
        Object res = callStoredRepository.findById(callStoredObj);
//        logImportDatabase.writeLog(Constants.ACTION.URL, Constants.DataLog.METHOD_GET, Constants.DataLog.SUCCESS_RESULT,
//                id, id, this.getClass(), "detailAction", "xem_chi_tiet_nut_hanh_dong");
        return res;
    }

    @Override
    public ResponseEntity importExcel(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception {
        int sheetAt = 0;
        int firstRow = 4;
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj = new ActionExcelObj(0);
        List<ActionExcelItemObj> list = excelObjectMapper.map(ActionExcelItemObj.class, sheetAt, iExcelMapperObj, firstRow);
        return saveDataExcel(excelObjectMapper, sheetAt, firstRow, list);
//         CommonService.downloadFileExcelWhenImport("actions.xlsx","ket_qua_import_hanh_dong.xlsx");
//        logImportDatabase.writeLog(Constants.ACTION.URL, Constants.DataLog.METHOD_POST, Constants.DataLog.SUCCESS_RESULT,
//                actions,actions,this.getClass(),"importExcel","tai_tep_len_hanh_dong ");
//        return new ResponseBase(actions);
    }

    @Override
    public ResponseBase setActiveDeActive(String id) throws Exception {
        String actionName = null;
        Action action = actionCatRepo.findById(id).orElse(null);
        if (action == null) {
            throw new ValidationException("ValidationException.error.not.exist.action");
        }
        if (action.getStatus() == Constants.ACTION_GROUP_STATUS.INACTIVE || action.getStatus() == Constants.ACTION_GROUP_STATUS.ACTIVE) {
            if (action.getStatus() == Constants.ACTION_GROUP_STATUS.ACTIVE) {
                action.setStatus(Constants.ACTION_GROUP_STATUS.INACTIVE);
                actionName = ActionCode.INACTIVE;
            } else {
                action.setStatus(Constants.ACTION_GROUP_STATUS.ACTIVE);
                actionName = ActionCode.ACTIVE;
            }
            // log
            String content = String.format("Đã %s hành động có tên là %s và mã là %s", Constants.COMMON_STATUS
                    .getNameByStatus(action.getStatus()), action.getName(), action.getCode());
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.action, actionName, content, Instant.now()));
            return new ResponseBase(new DetailResponse(actionCatRepo.save(action)));
        } else return new ResponseBase("Do not anything!");
    }

    @Override
    public ResponseEntity importExcelReturnResult(MultipartFile file) throws Exception {
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        int sheetAt = 0;
        int firstRow = 4;
        IExcelMapperObj iExcelMapperObj = new ActionExcelObj(0);
        List<ActionExcelItemObj> list = excelObjectMapper.map(ActionExcelItemObj.class, sheetAt, iExcelMapperObj, firstRow);
        ResponseEntity actions = saveDataExcelReturnRes(excelObjectMapper, sheetAt, firstRow, list);
        return actions;
    }

    public ResponseEntity saveDataExcel(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<ActionExcelItemObj> list) throws Exception {
        Map<Integer, String> errMap = new HashMap<>();
        List<Action> actions = new ArrayList<>();
        for (ActionExcelItemObj actionExcelItemObj : list) {
            if (!isEmptyRow(actionExcelItemObj)) {
                String messageError = "";
                int flag = 0;
                if (StringUtils.isEmpty(actionExcelItemObj.getCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.action.code");
                    flag++;
                } else {
                    messageError = CommonUtils.errorCodeMsg(actionExcelItemObj.getCode());
                    flag = StringUtils.isEmpty(messageError) ? 0 : flag++;
                }

                if (StringUtils.isEmpty(actionExcelItemObj.getName())) {
                    messageError = String.format("%s ; %s", messageError, Messages.getString("ValidationException.error.not.null.action.name"));
                    flag++;
                } else {
                    messageError = CommonUtils.errorNameMsg(actionExcelItemObj.getName());
                    flag = StringUtils.isEmpty(messageError) ? 0 : flag++;
                }

                if (actionExcelItemObj.getOrder() == 0) {
                    messageError = String.format("%s ; %s", messageError, Messages.getString("ValidationException.error.not.null.application.order"));
                    flag++;
                }
                if (flag == 0) {
                    Action action = mapper.map(actionExcelItemObj, Action.class);
                    action.setStatus(Constants.ACTION_GROUP_STATUS.ACTIVE);
                    try {
                        actionCatRepo.save(action);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                                ;
                            }
                        }
                    }
//                    actions.add(action);
                } else {

                }
                errMap.put(actionExcelItemObj.getRow(), messageError);
            }
        }
//        actionCatRepo.saveAll(actions);
        return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, null), "Ket_qua_import_hanh_dong_" + sdf.format(new Date()) + ".xlsx");
    }

    private boolean isEmptyRow(ActionExcelItemObj actionExcelItemObj) {
        if (actionExcelItemObj == null ||
                (StringUtils.isEmpty(actionExcelItemObj.getCode())) && StringUtils.isEmpty(actionExcelItemObj.getName())
                        && StringUtils.isEmpty(actionExcelItemObj.getDescription())) {
            return true;
        }
        return false;
    }

    public ResponseEntity saveDataExcelReturnRes(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<ActionExcelItemObj> list) throws Exception {
        Map<Integer, String> errMap = new HashMap<>();
        List<Action> actions = new ArrayList<>();
        for (ActionExcelItemObj actionExcelItemObj : list) {
            String messageError = "";
//            if (StringUtils.isNotEmpty(actionExcelItemObj.getCode()) || StringUtils.isNotEmpty(actionExcelItemObj.getName())
//                    || actionExcelItemObj.getOrder() != 0) {
            int flag = 0;
            if (StringUtils.isEmpty(actionExcelItemObj.getCode())) {
                messageError += Messages.getString("ValidationException.error.not.null.action.code");
                flag++;
            } else {
                String messageError1 = CommonUtils.errorCodeMsg(actionExcelItemObj.getCode());
                messageError += messageError1;
                if (messageError1.equalsIgnoreCase("")) {
                    flag = 0;
                } else {
                    flag++;
                }
            }
            if (StringUtils.isEmpty(actionExcelItemObj.getName())) {
                messageError += Messages.getString("ValidationException.error.not.null.action.name");
                flag++;
            } else {
                String messageError1 = CommonUtils.errorNameMsg(actionExcelItemObj.getName());
                messageError += messageError1;
                if (messageError1.equalsIgnoreCase("")) {
                    flag = 0;
                } else {
                    flag++;
                }
            }
            if (Objects.isNull(actionExcelItemObj.getOrder()) || actionExcelItemObj.getOrder() == 0) {
                messageError += Messages.getString("ValidationException.error.not.null.order");
                flag++;
            }
            if (StringUtils.isNotEmpty(actionExcelItemObj.getDescription())) {
                String messageError1 = CommonUtils.errorDescriptionMsg(actionExcelItemObj.getDescription());
                messageError += messageError1;
                if (messageError1.equalsIgnoreCase("")) {
                    flag = 0;
                } else {
                    flag++;
                }
            }
            Action action = mapper.map(actionExcelItemObj, Action.class);
            action.setStatus(Constants.ACTION_GROUP_STATUS.ACTIVE);
            Action current_action = actionCatRepo.findByCodeAndName(action.getCode(), action.getName());
            if (current_action != null && flag == 0) {
                mapper.getConfiguration().setSkipNullEnabled(true);
                mapper.map(actionExcelItemObj, current_action);
                actionCatRepo.save(current_action);
            } else {
                Action actionByCode = actionCatRepo.findByCode(action.getCode()).orElse(null);
                Action actionByName = actionCatRepo.findByName(action.getName()).orElse(null);
                if (actionByCode != null) {
                    messageError += Messages.getString("ValidationException.error.exist.action.code");
                    flag++;
                }
                if (actionByName != null) {
                    messageError += Messages.getString("ValidationException.error.exist.action.name");
                    flag++;
                }
                if (flag == 0) {
                    //actions.add(action);
                    try {
                        actionCatRepo.save(action);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));

                            }
                        }
                    }
                }
                errMap.put(actionExcelItemObj.getRow(), messageError);
            }
        }
        // }
//        if (CollectionUtils.isNotEmpty(actions)) {
//            actionCatRepo.saveAll(actions);
//        }

        return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, null), "Loi_import_hanh_dong.xlsx");
    }

}
