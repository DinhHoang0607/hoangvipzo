 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 7, 2021
 */
package vn.gtel.app_mng.category.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.category.dto.req.MenuActionDTO;
import vn.gtel.app_mng.category.dto.res.ActionNameIdRes;
import vn.gtel.app_mng.category.model.Menu;
import vn.gtel.app_mng.category.model.MenuAction;

@Repository
public interface MenuActionRepo extends JpaRepository<MenuAction, String>{
	
//	@Query("select new vn.gtel.app_mng.category.dto.req.MenuActionDTO(na.id, na.actionId) from MenuAction na where na.menuId = :menuId")
//	List<MenuActionDTO> findMenuActionDTOByMenuId(@Param("menuId") Long menuId);
	
//	@Query("select new vn.gtel.app_mng.category.dto.res.ActionNameIdRes(na.actionId) from MenuAction na where na.menuId = :menuId")
//	List<ActionNameIdRes> findIdByMenuId(@Param("menuId") Long menuId);
	
//	@Query("select new vn.gtel.app_mng.category.dto.res.ActionNameIdRes(na.actionId, na.menuId) from MenuAction na where na.menuId in :lstMenuId order by na.menuId")
//	List<ActionNameIdRes> findIdByLstMenuId(@Param("lstMenuId") List<Long> lstMenuId);



    MenuAction findByCode(String menuCode);

    MenuAction findByCodeAndMenu(String code , String menu);
	
	Optional<MenuAction> findByMenuAndAction(String menu, String action);
    Optional<MenuAction> findByMenuAndEndPointAndMethod(String menu, String endPoint, String method);
    Optional<MenuAction> findByCodeAndMenuAndAction(String code, String menu, String action);

    List<MenuAction> findByMenu(String menu);

    @Query("SELECT new vn.gtel.app_mng.category.dto.res.ActionNameIdRes(menuAction, action) FROM MenuAction menuAction" +
            " JOIN Action action ON menuAction.action = action.code" +
            " WHERE menuAction.menu = ?1 and action.status > 0 and menuAction.status = ?2")
    List<ActionNameIdRes> getActionNameIdResByMenu(String menu, Integer status);
}
