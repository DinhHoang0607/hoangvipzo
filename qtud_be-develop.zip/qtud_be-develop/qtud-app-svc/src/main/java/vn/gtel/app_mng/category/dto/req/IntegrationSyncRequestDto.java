package vn.gtel.app_mng.category.dto.req;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

@Getter
@Setter
public class IntegrationSyncRequestDto {
    private String id;

    @NotEmpty(message = "ValidationException.integration.sync.org.code.empty")
    private String orgCode;

    @NotEmpty(message = "ValidationException.integration.sync.org.name.empty")
    private String orgName;

    @NotEmpty(message = "ValidationException.integration.sync.app.empty")
    private String appCode;

    private String purpose;

    private String description;

    private String relationName;

    //    @NotEmpty(message = "ValidationException.integration.sync.relation.position.empty")
    private String relationPositionCode;

    private String relationPositionName;

    private String relationPoliceNumber;

    private String relationPhone;

    private String relationMilitaryCode;

    private String relationMilitaryName;

    private String relationDescription;

    private String representativeName;

    //    @NotEmpty(message = "ValidationException.integration.sync.representative.position.empty")
    private String representativePositionCode;

    private String representativePositionName;

    private String representativePoliceNumber;

    private String representativePhone;

    private String representativeMilitaryCode;

    private String representativeMilitaryName;

    private String representativeDescription;

    private Integer status;

    private String statusName;
}
