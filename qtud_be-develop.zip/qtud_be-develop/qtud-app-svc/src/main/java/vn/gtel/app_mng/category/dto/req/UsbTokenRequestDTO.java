/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationRequestDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 11:28 AM
 */

package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import vn.gtel.app_mng.common.dto.AuditBaseDTO;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.time.Instant;

@Data
public class UsbTokenRequestDTO extends AuditBaseDTO {

    private String accountCode;
    private String digitalCertificate;
//    private String code;

//    private Integer digitalCertificateType;

//    private String cmndCccd;
//
//    private Instant dateOfIssue;
//
//    private String placeOfIssue;
//
//    private String address;
//
//    private Instant dateOfBirth;
//
//    private String agency;
//
//    private String mailAddress;
//
//    private String organizationAddress;
//
//    private String village;
//
//    private String district;
//
//    private String province;
//
//    private String codeEnter;
}
