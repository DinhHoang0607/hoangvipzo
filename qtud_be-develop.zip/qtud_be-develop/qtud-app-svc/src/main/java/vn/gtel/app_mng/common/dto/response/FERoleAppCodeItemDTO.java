package vn.gtel.app_mng.common.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FERoleAppCodeItemDTO {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Column(name = "MA_QUYEN")
    private String permissionCode;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Column(name = "MA_CHUC_NANG")
    private String menu;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Column(name = "MA_HANH_DONG")
    private String action;
}
