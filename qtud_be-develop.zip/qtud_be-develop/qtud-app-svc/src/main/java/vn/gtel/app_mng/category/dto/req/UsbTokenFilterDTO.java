package vn.gtel.app_mng.category.dto.req;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.dto.request.PageFilter;

import java.io.Serializable;
import java.time.Instant;

@Data
@AllArgsConstructor
public class UsbTokenFilterDTO extends PageFilter implements Serializable {

    private String textSearch;
    private String code;
    private String account;
    private String organization;
    private Long status;
    private Instant expiredDateFrom;
    private Instant expiredDateTo;
    private Long typeDate;

    public UsbTokenFilterDTO(Integer page, Integer size, String textSearch,String code, String account,String organization, Long status, Instant expiredDateFrom, Instant expiredDateTo,Long typeDate) {
        super(page, size);
        this.textSearch = textSearch;
        this.code = code;
        this.account = account;
        this.organization= organization;
        this.status = status;
        this.expiredDateFrom = expiredDateFrom;
        this.expiredDateTo = expiredDateTo;
        this.typeDate = typeDate;
    }
}
