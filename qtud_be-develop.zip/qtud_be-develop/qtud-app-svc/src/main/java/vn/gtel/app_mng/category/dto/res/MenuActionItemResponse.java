package vn.gtel.app_mng.category.dto.res;

import lombok.Data;

import javax.persistence.Column;

@Data
public class MenuActionItemResponse {
    @Column(name = "ID")
    private String id;
    @Column(name = "MA")
    private String code;
    @Column(name = "MA_KHAC")
    private String codeOther;
    @Column(name = "TEN")
    private String name;
    @Column(name = "CHUC_NANG_CHA")
    private String parentMenuCode;
    @Column(name = "TEN_TRANG_THAI")
    private String statusName;

    @Column(name = "TEN_CHUC_NANG_CHA")
    private String parentMenuName;

    @Column(name = "TRANG_THAI")
    private String status;
}
