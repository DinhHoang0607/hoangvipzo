package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountFilter extends TextFilter {
    private String organization;
    private String organizationParent;
    private Integer type;
    private String account;
    private String accountName;
    private String name;
    private String policeNumber;
    private String position;
    private String military;
    private String status;
    private String organizationLevel;
    private String typeEmployee;
    private Integer onlyLocalAccount;
    private Long statusConfirmInfo;
    private List<String> policeNumbers;
    private List<String> accounts;


    public AccountFilter(Integer page, Integer size, String keySearch, String organization, Integer type, String account, String name
            , String policeNumber, String position, String military, String status, String organizationLevel) {
        super(page, size, keySearch);
        this.organization = organization;
        this.type = type;
        this.account = account;
        this.name = name;
        this.policeNumber = policeNumber;
        this.position = position;
        this.military = military;
        this.status = status;
        this.organizationLevel = organizationLevel;
    }

    public AccountFilter(Integer page, Integer size, String keySearch, String organization, Integer type, String account, String name
            , String policeNumber, String position, String military, String status, String organizationLevel, String typeEmployee, Integer onlyLocalAccount, Long statusConfirmInfo) {
        super(page, size, keySearch);
        this.organization = organization;
        this.type = type;
        this.account = account;
        this.name = name;
        this.policeNumber = policeNumber;
        this.position = position;
        this.military = military;
        this.status = status;
        this.organizationLevel = organizationLevel;
        this.typeEmployee = typeEmployee;
        this.onlyLocalAccount = onlyLocalAccount;
        this.statusConfirmInfo = statusConfirmInfo;
    }

    public AccountFilter(Integer page, Integer size, String keySearch, String organization, Integer type, String account, String name
            , String policeNumber, String position, String military, String status, String organizationLevel, String typeEmployee, Integer onlyLocalAccount, Long statusConfirmInfo, String accountName) {
        super(page, size, keySearch);
        this.organization = organization;
        this.type = type;
        this.account = account;
        this.name = name;
        this.policeNumber = policeNumber;
        this.position = position;
        this.military = military;
        this.status = status;
        this.organizationLevel = organizationLevel;
        this.typeEmployee = typeEmployee;
        this.onlyLocalAccount = onlyLocalAccount;
        this.statusConfirmInfo = statusConfirmInfo;
        this.accountName = accountName;
    }

    public AccountFilter(Integer page, Integer size, String keySearch, String organization, Integer type) {
        super(page, size, keySearch);
        this.organization = organization;
        this.type = type;
    }

    public AccountFilter(Integer page, Integer size, String keySearch, String position, String status, String organizationParent) {
        super(page, size, keySearch);
        this.position = position;
        this.status = status;
        this.organizationParent = organizationParent;
    }

    public AccountFilter(Integer page, Integer size, String keySearch, String organization, Integer type, String account, String name
            , String policeNumber, String position, String military, String status, String organizationLevel, String typeEmployee, Integer onlyLocalAccount, Long statusConfirmInfo, List<String> policeNumbers) {
        super(page, size, keySearch);
        this.organization = organization;
        this.type = type;
        this.account = account;
        this.name = name;
        this.policeNumber = policeNumber;
        this.position = position;
        this.military = military;
        this.status = status;
        this.organizationLevel = organizationLevel;
        this.typeEmployee = typeEmployee;
        this.onlyLocalAccount = onlyLocalAccount;
        this.statusConfirmInfo = statusConfirmInfo;
        this.policeNumbers = policeNumbers;
    }

    public AccountFilter(Integer page, Integer size, String keySearch, String organization, Integer type, String name
            , String policeNumber, String position, String military, String status, String organizationLevel, String typeEmployee, Integer onlyLocalAccount, Long statusConfirmInfo, List<String> accounts) {
        super(page, size, keySearch);
        this.organization = organization;
        this.type = type;
        this.name = name;
        this.policeNumber = policeNumber;
        this.position = position;
        this.military = military;
        this.status = status;
        this.organizationLevel = organizationLevel;
        this.typeEmployee = typeEmployee;
        this.onlyLocalAccount = onlyLocalAccount;
        this.statusConfirmInfo = statusConfirmInfo;
        this.accounts = accounts;
    }

    public AccountFilter(int page, int size, String keySearch, String organization, String name, String policeNumber, String military, String status, List<String> accounts, String typeEmployee) {
        super(page, size, keySearch);
        this.organization = organization;
        this.name = name;
        this.policeNumber = policeNumber;
        this.military = military;
        this.status = status;
        this.accounts = accounts;
        this.typeEmployee = typeEmployee;
    }
}
