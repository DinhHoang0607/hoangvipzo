package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_DM_LINH_VUC_PHU_TRACH")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldManage extends AuditModelBase {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "THU_TU")
    private Long order;

    @Basic
    @Column(name = "MO_TA")
    private String desc;


    @Basic
    @Column(name = "MA_DO_MAT")
    private String secureCode;

    @Basic
    @Column(name = "PHAN_HE")
    private String subSystem;
}