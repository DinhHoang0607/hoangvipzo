package vn.gtel.app_mng.category.dto.req;

import lombok.Getter;
import lombok.Setter;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Getter
@Setter
public class ProfileStatusRequestDto {
    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "ValidationException.error.profile.status.id.max.size")
    private String id;

    @NotEmpty(message = "ValidationException.error.profile.status.type.empty")
    private String typeCode;

    @NotEmpty(message = "ValidationException.error.profile.status.code.empty")
    @Size(max = 6, message = "ValidationException.error.profile.status.code.max.size")
    @Size(min = 3, message = "ValidationException.error.profile.status.code.min.size")
    @Pattern(regexp = Constants.Regex.CODE, message = "ValidationException.error.profile.status.code.regex")
    private String code;

    @NotEmpty(message = "ValidationException.error.profile.status.name.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "ValidationException.error.profile.status.name.max.size")
    @Pattern(regexp = Constants.Regex.NAME, message = "ValidationException.error.profile.status.name.regex")
    private String name;

    @NotNull(message = "ValidationException.error.profile.status.value.empty")
    private String value;

    private String description;

    private Integer status;
}
