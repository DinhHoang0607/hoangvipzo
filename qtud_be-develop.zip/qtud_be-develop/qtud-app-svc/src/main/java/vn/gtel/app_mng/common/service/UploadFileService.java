package vn.gtel.app_mng.common.service;

import io.minio.errors.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public interface UploadFileService {
    ResponseBase uploadFile(MultipartFile file , String minioBucket);

    InputStream download(String fileName, String minioBucket) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException;
}
