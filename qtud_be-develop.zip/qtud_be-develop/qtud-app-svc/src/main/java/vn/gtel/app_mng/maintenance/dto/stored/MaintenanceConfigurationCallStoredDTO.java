package vn.gtel.app_mng.maintenance.dto.stored;

import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.maintenance.dto.filter.MaintenanceConfigurationFilterDTO;
import vn.gtel.app_mng.maintenance.model.MaintenanceConfiguration;

import java.util.HashMap;
import java.util.Map;

public class MaintenanceConfigurationCallStoredDTO extends ICallStoredObj {
    private static final String PACKAGE_NAME = "PKG_CAU_HINH_BAO_TRI";
    private static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_LICH_BAO_TRI";
    private static final String IN_DESCRIPTION = "PI_MO_TA";
    private static final String IN_STARTED_FROM = "PI_BAT_DAU_TU";
    private static final String IN_STARTED_TO = "PI_BAT_DAU_DEN";
    private static final String IN_FINISHED_FROM = "PI_KET_THUC_TU";
    private static final String IN_FINISHED_TO = "PI_KET_THUC_DEN";
    private static final String IN_MIN_DURATION = "PI_THOI_GIAN_TOI_THIEU";
    private static final String IN_MAX_DURATION = "PI_THOI_GIAN_TOI_DA";
    private static final String IN_STATUS = "PI_TRANG_THAI";
    private static final String IN_DELETED = "PI_XOA";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_SIZE = "PI_SIZE";

    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(MaintenanceConfiguration.class);
    }

    public MaintenanceConfigurationCallStoredDTO(MaintenanceConfigurationFilterDTO filterDTO) {
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_DESCRIPTION, filterDTO.getDescription());
        params.put(IN_STARTED_FROM, filterDTO.getStartedDateBegin());
        params.put(IN_STARTED_TO, filterDTO.getStartedDateEnd());
        params.put(IN_FINISHED_FROM, filterDTO.getFinishedDateBegin());
        params.put(IN_FINISHED_TO, filterDTO.getFinishedDateEnd());
        params.put(IN_MIN_DURATION, filterDTO.getMinDuration());
        params.put(IN_MAX_DURATION, filterDTO.getMaxDuration());
        params.put(IN_STATUS, filterDTO.getStatus());
        params.put(IN_DELETED, filterDTO.getDeleted());
        params.put(IN_PAGE, filterDTO.getPageNumber());
        params.put(IN_SIZE, filterDTO.getSizeNumber());
        setParams(params);
    }
}
