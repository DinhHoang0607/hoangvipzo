/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleItemDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/14/22, 9:52 AM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountGroupRoleItemDTO {
    private String id;
    private String groupRole;
}