/**
 * @author tronglm
 * app-mng
 * Dec 6, 2021
 */
package vn.gtel.app_mng.category.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditBaseDTO;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CodeNameDTO {

    private String id;
    private String code;
    private String name;

    public CodeNameDTO(String code, String name) {
        this.code = code;
        this.name = name;
    }
}
