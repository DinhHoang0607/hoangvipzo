package vn.gtel.app_mng.role.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

@Entity
@Table(name = "TBL_Q_NHOM_QUYEN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRole extends AuditModelBase {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

	@Basic
	@Column(name = "MA")
	private String code;

	@Basic
	@Column(name = "TEN")
	private String name;

	@Basic
	@Column(name = "PHAN_LOAI")
	private int type;

	@Basic
	@Column(name = "MO_TA")
	private String description;
	@Basic
	@Column(name = "MA_CHA")
	private String codeParent;

}
