 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 9, 2021
 */
package vn.gtel.app_mng.category.dto.res;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MenuActionList {
	
	private List<MenuActionRes> lstMenuActionRes;
	
	private List<ActionNameIdRes> lstActionAll;
	
	private Long total;

}
