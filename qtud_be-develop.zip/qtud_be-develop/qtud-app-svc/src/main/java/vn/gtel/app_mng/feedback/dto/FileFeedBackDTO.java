package vn.gtel.app_mng.feedback.dto;

import lombok.Data;

@Data
public class FileFeedBackDTO {
    private String file;

    private String fileName;

}
