package vn.gtel.app_mng.category.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TBL_DM_LOAI_HO_SO")
public class ProfileType extends AuditModel {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MA_CHA", referencedColumnName = "MA", insertable = false, updatable = false)
    private ProfileType parent;

    @Basic
    @Column(name = "MA_CHA")
    private String parentCode;
}