/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/22/22, 3:27 PM
 *
 */

package vn.gtel.app_mng.account.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import javassist.NotFoundException;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.dto.*;
import vn.gtel.app_mng.account.dto.request.AdminGeneratorReq;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferReq;
import vn.gtel.app_mng.account.filter.*;
import vn.gtel.app_mng.account.service.AccountService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.xml.bind.ValidationException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Validated
@Tag(name = "Tài khoản người dùng version 2", description = "Tài khoản người dùng v2")
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v2/account")
public class AccountV2Controller {

    @Autowired
    private AccountService accountService;

    @Operation(summary = "Kết xuất thống tin tài khoản ban đầu và sau khi lấy lại mật khẩu")
    @GetMapping(value = "/export_reset")
    public ResponseEntity exportReset(
            @Valid
            @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character")
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "account") String account,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
            @RequestParam(name = "passWord") String passWord
    ) throws Exception {
        return accountService.exportAccountV2(account, passWord);
    }

}
