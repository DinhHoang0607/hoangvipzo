package vn.gtel.app_mng.feedback.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.Instant;

@Data
@Entity
@Table(name = "TBL_PHAN_ANH_LICH_SU",  catalog = "")
@EntityListeners(AuditingEntityListener.class)
public class FeedbackHistory {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "ID_PHAN_ANH")
    private String feedbackId;

    @Basic
    @Column(name = "NOI_DUNG_TRAO_DOI")
    private String comment;

    @Basic
    @Column(name = "NGUOI_GUI")
    private String sender;

    @Basic
    @Column(name = "DON_VI_XU_LY")
    private String organization;

    @Basic
    @Column(name = "NGUOI_XY_LY")
    private String processor;

    @Basic
    @Column(name = "HANH_DONG")
    private String action;

    @Basic
    @Column(name = "TRANG_THAI")
    private Integer status;

    @Column(name = "NGAY_TAO")
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

}
