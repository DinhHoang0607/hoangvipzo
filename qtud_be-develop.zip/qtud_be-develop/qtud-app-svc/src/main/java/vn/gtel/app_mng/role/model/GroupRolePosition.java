//package vn.gtel.app_mng.role.model;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.hibernate.annotations.GenericGenerator;
//import vn.gtel.app_mng.common.model.AuditModelBase;
//
//import javax.persistence.*;
//
//@Entity
//@Table(name = "TBL_Q_NHOM_QUYEN_CHUC_VU")
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class GroupRolePosition extends AuditModelBase {
//	/**
//	 *
//	 */
//	private static final long serialVersionUID = 1L;
//
//	@Id
//	@GeneratedValue(generator = "uuid2")
//	@GenericGenerator(name = "uuid2", strategy = "uuid2")
//	@Column(name = "ID")
//	private String id;
//
//	@Basic
//	@Column(name = "CHUC_VU")
//	private String position;
//
//	@Basic
//	@Column(name = "NHOM_QUYEN")
//	private String groupRole;
//
//	public GroupRolePosition(String groupRole, String position, Long status) {
//		super(status);
//		this.position = position;
//		this.groupRole = groupRole;
//	}
//}
