package vn.gtel.app_mng.category.dto.res;

import lombok.Data;

import javax.persistence.Column;

@Data
public class OrganizationComboboxResponse {
    @Column(name = "ID")
    private String id ;
    @Column(name = "TEN")
    private String name;
    @Column(name = "MA")
    private String code;
}
