/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceExcelObj.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 10:52 AM
 *
 */

package vn.gtel.app_mng.account.dto.excelObj;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;
import java.util.Map;

@Data
@AllArgsConstructor
public class AccountServiceExcelObj extends IExcelMapperObj {
    private Map<String, Integer> fieldToIndexMap = new HashMap<>();

    public AccountServiceExcelObj(int stt) {
        fieldToIndexMap.put("account", stt + 1);
        fieldToIndexMap.put("name", stt + 2);
        fieldToIndexMap.put("password", stt + 3);
        fieldToIndexMap.put("organization",stt + 4);
        fieldToIndexMap.put("organizationName", stt + 5);
        fieldToIndexMap.put("accountTypeService", stt + 6);

        fieldToIndexMap.put("representativeName", stt + 7);
        fieldToIndexMap.put("representativePhone",stt +8 );
//        fieldToIndexMap.put("representativeMilitary",stt + 9);
//        fieldToIndexMap.put("representativePosition",stt + 10);
        fieldToIndexMap.put("representativeMilitaryText",stt + 9);
        fieldToIndexMap.put("representativePositionText",stt + 10);

//        fieldToIndexMap.put("representativeDescription", 9);
        fieldToIndexMap.put("representativePoliceNumber",stt + 11);
        fieldToIndexMap.put("relationName",stt + 12);
        fieldToIndexMap.put("relationPhone",stt + 13);
        fieldToIndexMap.put("relationMilitaryText",stt +  14);
        fieldToIndexMap.put("relationPositionText",stt + 15);

//        fieldToIndexMap.put("relationMilitary",stt +  14);
//        fieldToIndexMap.put("relationPosition",stt + 15);
//        fieldToIndexMap.put("relationDescription", 15);
        fieldToIndexMap.put("relationPoliceNumber",stt +  16);
        fieldToIndexMap.put("resultColumn",stt + 17);
        setFieldToIndexMap(fieldToIndexMap);
    }

}
