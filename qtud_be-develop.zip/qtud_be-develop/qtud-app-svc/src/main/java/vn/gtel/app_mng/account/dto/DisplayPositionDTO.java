package vn.gtel.app_mng.account.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DisplayPositionDTO {
    @NotNull
    private String account;

    private String displayPosition;
}
