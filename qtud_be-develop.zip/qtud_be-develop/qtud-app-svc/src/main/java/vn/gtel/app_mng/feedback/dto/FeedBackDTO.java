package vn.gtel.app_mng.feedback.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.persistence.Basic;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.time.Instant;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeedBackDTO {

    @Basic
    private String id;

//    @NotNull(message = "error.common.validate.not.null")
//    @Basic
//    private Long typeFeedBack;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_CONTENT, message = "error.common.validate.max.size.40000")
    @Basic
    private String content;


    //    @Basic
//    @NotEmpty(message = "error.common.validate.not.empty")
    private String phoneNumber;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String applicationCode;
    private String orgFeedbackCode;
    private String sender;

    @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
    @Size(max = Constants.VALID.MAX_LENGTH_TITLE, message = "error.common.validate.max.size.250")
    @Basic
    private String title;

    private List<FileFeedBackDTO> files;

    //    @Basic
//    @NotNull(message = "error.common.validate.not.null")
    private Integer level;
//
//    // type 1 save draft 2 waiting processing
//    //@NotNull(message = "error.common.validate.not.null")
//    private Integer type;
//
//    private int hideType;
//
//    // list id phản ánh liên quan phục vụ cho việc gộp phản ánh
//    private List<String> ids;


    @Basic
    private Integer classify;

}
