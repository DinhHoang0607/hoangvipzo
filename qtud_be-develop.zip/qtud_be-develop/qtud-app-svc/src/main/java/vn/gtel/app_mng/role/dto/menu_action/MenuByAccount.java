/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.role.dto.menu_action;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.category.model.Menu;

import javax.persistence.Column;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MenuByAccount {

    @Column(name = "ID")
    private String id;

    @Column(name = "TEN")
    private String name;

    @Column(name = "MA")
    private String code;

    @Column(name = "DUONG_DAN")
    private String url;

    @Column(name = "THU_TU")
    private Integer order;

    @Column(name = "BIEU_TUONG")
    private String iconCls;

    @Column(name = "LOAI_CHUC_NANG")
    private Integer typeMenu;

    @Column(name = "THANH_PHAN")
    private String component;

    @Column(name = "CHUC_NANG_CHA")
    private String parentCode;

    private Boolean leaf;

    private Boolean selectable;

    private List<MenuByAccount> children;

    private String codeOther;

    public MenuByAccount(MenuByAccount menuByAccount) {
        this.id = menuByAccount.id;
        this.name = menuByAccount.name;
        this.code = menuByAccount.code;
        this.url = menuByAccount.url;
        this.order = menuByAccount.order;
        this.iconCls = menuByAccount.iconCls;
        this.component = menuByAccount.component;
        this.parentCode = menuByAccount.parentCode;
        this.typeMenu = menuByAccount.typeMenu;
        this.leaf = menuByAccount.leaf;
        this.selectable = menuByAccount.selectable;
        this.codeOther = menuByAccount.codeOther;
    }

    public MenuByAccount(Menu e) {
        this.id = e.getId();
        this.name = e.getName();
        this.code = e.getCode();
        this.url = e.getUrl();
        this.order = e.getOrder();
        this.iconCls = e.getIcon();
        this.component = e.getComponent();
        this.parentCode = e.getParentMenuCode();
        this.typeMenu = e.getTypeMenu();
        this.codeOther = e.getCodeOther();
    }

//     @Column(name = "NGAY_TAO")
//     private Instant createdDate;
//
//     @Column(name = "NGUOI_TAO")
//     private String createdBy;
//
//     @Column(name = "NGAY_SUA")
//     private Instant lastModifiedDate;
//
//     @Column(name = "NGUOI_SUA")
//     private String lastModifiedBy;
//
//     @Column(name = "TRANG_THAI")
//     private Long status;

//     @Column(name = "MA_QUYEN_CHUC_NANG")
//     private String functionRoleCode;


    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
