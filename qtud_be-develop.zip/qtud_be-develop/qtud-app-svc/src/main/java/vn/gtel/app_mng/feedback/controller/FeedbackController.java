/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  FeedbackController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  4/16/22, 9:45 AM
 *
 */

package vn.gtel.app_mng.feedback.controller;

//import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;

import io.swagger.annotations.Api;
import lombok.AllArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.feedback.dto.*;
import vn.gtel.app_mng.feedback.service.FeedbackService;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.ValidationException;
import java.time.Instant;
import java.util.Optional;

@Api(description = "Phản ánh")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/feedback")
@Validated
@AllArgsConstructor
public class FeedbackController {

    private final FeedbackService feedbackService;

    @Operation(summary = "Tìm kiếm danh sách phản ánh")
    @GetMapping(value = "/search")
    public ResponseBase search(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "view", required = true) Long view,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_FEEDBACK, message = "error.common.validate.max.size.3")
            @RequestParam(name = "level", required = false) String level,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "code", required = false) String code,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "orgCode", required = false) String orgCode,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_FEEDBACK, message = "error.common.validate.max.size.3")
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "startDate", required = false) Instant startDate,
            @RequestParam(name = "endDate", required = false) Instant endDate,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size,
            @RequestParam(name = "fixPage", required = false) Optional<Integer> fixPage
    ) throws IllegalAccessException {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE) + fixPage.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        FeedBackTextFilter feedBackTextFilter = new FeedBackTextFilter(pageNumber, sizeNumber, keySearch, view, level, status, startDate, endDate, orgCode, code);
        return new ResponseBase(feedbackService.list(feedBackTextFilter));
    }

    @Operation(summary = "Thêm phản ánh")
    @PostMapping
    public ResponseBase createFeedBack(@RequestBody @Valid FeedBackDTO feedbackDTO) throws Exception {
        return feedbackService.save(feedbackDTO);
    }

    //    @Operation(summary = "sửa phản ánh")
    @PutMapping
    public ResponseBase updateFeedBack(@RequestBody @Valid FeedBackDTO feedbackDTO) throws Exception {

        return feedbackService.save(feedbackDTO);
    }

    //    @Operation(summary = "Xóa phản ánh ")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        feedbackService.deleteAction(id);
        return new ResponseBase(id);
    }

    //    @Operation(summary = "Xem chi tiet  phản ánh ")
    @GetMapping(value = "/{id}")
    public ResponseBase detailFeedBackDraft(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {

        return feedbackService.getOneFeedBack(id);
    }

    //    @Operation(summary = "chuyển xử lý phản ánh")
    @PostMapping(value = "/remove")
    public ResponseBase removeFeedBack(@RequestBody @Valid RemoveFeedBackDTO removeFeedBackDTO) throws Exception {
        return feedbackService.removeFeedBack(removeFeedBackDTO);
    }

    //    @Operation(summary = "Phản hồi phản ánh")
    @PostMapping(value = "/reply")
    public ResponseBase reply(@RequestBody @Valid ReplyDTO replyDTO) throws Exception {
        return feedbackService.reply(replyDTO);
    }

    //    @Operation(summary = "Đóng phản ánh")
    @PostMapping(value = "/close")
    public ResponseBase closeFeedBack(@RequestBody @Valid RemoveFeedBackDTO removeFeedBackDTO) throws ValidationException {
        return feedbackService.closeFeedBack(removeFeedBackDTO);
    }

    //    @Operation(summary = "Gửi xử lý lại phản ánh")
    @PostMapping(value = "/reprocess")
    public ResponseBase reprocess(@RequestBody @Valid IdeaDTO relyDTO) throws Exception {
        return feedbackService.reprocess(relyDTO);
    }

    //    @Operation(summary = "danh sách lịch sử phản ánh ")
    @GetMapping(value = "/histories/{id}")
    public ResponseBase listHistory(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id,
                                    @RequestParam(name = "status", required = false) Integer status
    ) throws IllegalAccessException {
        int page = Constants.DEFAULT_PAGE;
        int size = Constants.MAX_ROW_SELECT;
        return feedbackService.list(id, page, size, status);
    }

    //    @Operation(summary = "tiếp nhận phản ánh")
    @PutMapping(value = "/received")
    public ResponseBase received(@RequestBody @Valid ReceivedDTO receivedDTO) throws Exception {
        return feedbackService.received(receivedDTO.getId());
    }
}
