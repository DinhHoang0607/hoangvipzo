package vn.gtel.app_mng.account.dto.request;

import lombok.Data;
import vn.gtel.app_mng.account.dto.GeneralConfigDTO;

import java.util.List;

@Data
public class GeneralConfigRequest {
    private List<GeneralConfigDTO> configs;
}
