 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 7, 2021
 */
package vn.gtel.app_mng.category.service;

import java.io.IOException;
import java.security.InvalidParameterException;
import java.sql.SQLException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.req.AppTextFilter;
import vn.gtel.app_mng.category.dto.req.MenuReq;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

 public interface MenuActionService {
	
	public String create(MenuReq req) throws Exception;
	
	public String update(MenuReq req) throws Exception;
	
	public Object list(AppTextFilter appTextFilter) throws InvalidParameterException, SQLException, Exception;
	
	public Object changeStatus(String id) throws Exception;
	
	public Object detail(String id) throws Exception;
	
	public Object listMenuAction(AppTextFilter appTextFilter) throws Exception;

	 ResponseBase importExcel(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;

	 ResponseBase setActiveDeActive(String id) throws Exception;

	 ResponseEntity importExcelReturnResult(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;

	 ResponseEntity createTemplate() throws Exception;

}
