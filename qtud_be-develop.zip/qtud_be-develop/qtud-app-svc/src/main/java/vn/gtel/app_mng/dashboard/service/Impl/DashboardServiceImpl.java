/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  DashboardServiceImpl.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/1/22, 10:30 AM
 *
 */

package vn.gtel.app_mng.dashboard.service.Impl;

import com.aspose.cells.Workbook;
import com.aspose.words.net.System.Data.DataTable;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CommonService;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.dashboard.dto.req.GridFilter;
import vn.gtel.app_mng.dashboard.dto.res.AccountDashboardResponse;
import vn.gtel.app_mng.dashboard.dto.res.CountItemResponseDTO;
import vn.gtel.app_mng.dashboard.dto.res.CountResponseDTO;
import vn.gtel.app_mng.dashboard.service.DashboardService;
import vn.gtel.app_mng.dashboard.storeObj.DashboardCallStoredDTO;
import vn.gtel.common.config.constants.ReportCommon;
import vn.gtel.common.service.AsposeReportService;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@AllArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final CallStoredRepository callStoredRepository;
    private final TrimSpaceUtil trimSpaceUtil;
    private final AsposeReportService asposeReportService;

    @Override
    public ResponseBase onlineCurrent() {
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(DashboardCallStoredDTO.PROC_COUNT_ONLINE, CountResponseDTO.class);
        Object response = callStoredRepository.getNumber(callStoredObj);
        return new ResponseBase(new CountResponseDTO((Long) response));
    }

    @Override
    public ResponseBase sumAccessByTime() {
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(DashboardCallStoredDTO.PROC_SUM_LOGIN);
        Object response = callStoredRepository.getList(callStoredObj);
        return new ResponseBase(response);
    }

    @Override
    public ResponseBase countAccessByApp(FilterChart filterChart) throws IllegalAccessException {
        trimSpaceUtil.validate(filterChart);
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(filterChart);
        Object response = callStoredRepository.getList(callStoredObj);
        return new ResponseBase(response);
    }

    @Override
    public ResponseBase countOnlineByCity(GridFilter gridFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(gridFilter);
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(gridFilter, CountItemResponseDTO.class);
        List<CountItemResponseDTO> response = (List<CountItemResponseDTO>) callStoredRepository.getList(callStoredObj);
        return new ResponseBase(response);
    }

    @Override
    public ResponseEntity onlineByCityExport(GridFilter gridFilter) throws Exception {
        trimSpaceUtil.validate(gridFilter);
        Map<String, Object> dataMap = new HashMap<>();
        String fileOutPut = ReportCommon.TEMPLATE.TK_SL_TK_theo_tinh;
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(gridFilter, CountItemResponseDTO.class);
        List<CountItemResponseDTO> response = (List<CountItemResponseDTO>) callStoredRepository.getList(callStoredObj);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        Date fromDate = null;
        if (gridFilter.getFromDateTime() != null) {
            fromDate = java.sql.Date.valueOf(LocalDate.parse(String.valueOf(gridFilter.getFromDateTime()), formatter));
        } else {
            LocalDate localDate = LocalDate.of(2024, 1, 1);
            fromDate = Date.from(localDate.atStartOfDay(ZoneId.of("UTC")).toInstant());
        }

        Date toDate = null;
        if (gridFilter.getToDateTime() != null) {
            toDate = java.sql.Date.valueOf(LocalDate.parse(String.valueOf(gridFilter.getToDateTime()), formatter));
        } else {
            toDate = new Date();
        }

        dataMap.put("fromDate", asposeReportService.getSdf().format(fromDate));
        dataMap.put("toDate", asposeReportService.getSdf().format(toDate));

        DataTable dataTable = new DataTable("lst");
        dataTable.getColumns().add("stt");
        dataTable.getColumns().add(CountItemResponseDTO.Fields.code);
        dataTable.getColumns().add(CountItemResponseDTO.Fields.name);
        dataTable.getColumns().add(CountResponseDTO.Fields.countNumber);
        AtomicInteger stt = new AtomicInteger();
        for (CountItemResponseDTO e : response) {
            Object[] objs = {stt.incrementAndGet(), e.getCode(), e.getName(), e.getCountNumber()};
            dataTable.getRows().add(objs);
        }
        String fileInput = ReportCommon.TEMPLATE.TK_SL_TK_theo_tinh.concat(ReportCommon.TEMPLATE.EXT_XLSX);// "Thong_ke_sl_tk_theo_tinh.xlsx";
        InputStream is = CommonService.getReport(fileInput);// CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
        Workbook workbook = new Workbook(is);
        return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut,null);
    }

    @Override
    public ResponseBase getChartValue(FilterChart filterChart) throws IllegalAccessException {
        trimSpaceUtil.validate(filterChart);
        List lstTime = getAllTimeBetween(filterChart);
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(filterChart);
        List<CountItemResponseDTO> response = (List<CountItemResponseDTO>) callStoredRepository.getList(callStoredObj);
        if (filterChart.isOrderWithName() && !Constants.AggType.year.toString().equals(filterChart.getAggType())) {
            List zeroList = (List) lstTime.stream().filter(time -> !response.stream().map(o -> o.getName()).collect(Collectors.toList()).contains(time)).collect(Collectors.toList());
            List zeroChartList = new ArrayList();
            zeroList.stream().map(o -> {
                return zeroChartList.add(new CountItemResponseDTO(o.toString()));
            }).collect(Collectors.toList());
            response.addAll(zeroChartList);

            List<CountItemResponseDTO> responseCurrent = response.stream()
                    .sorted(Comparator.comparing(CountItemResponseDTO::getName)).collect(Collectors.toList());
            // convert kieu tra ra cho ten
            for (CountItemResponseDTO item : responseCurrent) {
                item.setName(convertNameResponse(item.getName()));
            }
            return new ResponseBase(responseCurrent);
        } else {
            return new ResponseBase(response);
        }
    }


    @Override
    public ResponseBase getCountAccount() {
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO();
        Object response = callStoredRepository.getList(callStoredObj);
        return new ResponseBase(response);
    }

    @Override
    public ResponseBase getCountAccountByOrg(String orgCode) {
        ICallStoredObj callStoredObj = new DashboardCallStoredDTO(AccountDashboardResponse.class, orgCode);
        Object response = callStoredRepository.getList(callStoredObj);
        return new ResponseBase(response);
    }

    private List getAllTimeBetween(FilterChart filterChart) throws IllegalAccessException {
//    Period.
        trimSpaceUtil.validate(filterChart);
        if (Constants.AggType.day.toString().equals(filterChart.getAggType())) {
            DateTimeFormatter sdf = DateTimeFormatter.ofPattern(Constants.DATE_FM_PATTERN);
            LocalDate fromLocalDate = LocalDate.parse(filterChart.getFromDateTime().toString(), sdf);
            LocalDate toLocalDate = LocalDate.parse(filterChart.getToDateTime().toString(), sdf);
            long numOfDayBetween = ChronoUnit.DAYS.between(fromLocalDate, toLocalDate);
            List<LocalDate> lstDate = Stream.iterate(fromLocalDate, date -> date.plusDays(1)).limit(numOfDayBetween + 1).collect(Collectors.toList());
            return lstDate.stream().map(o -> {
                return o.format(sdf);
            }).collect(Collectors.toList());
        }

        if (Constants.AggType.month.toString().equals(filterChart.getAggType())) {
            DateTimeFormatter sdf = DateTimeFormatter.ofPattern(Constants.DATE_FM_PATTERN);
            LocalDate fromLocalDate = LocalDate.parse(filterChart.getFromDateTime().toString() + "01", sdf);
            LocalDate toLocalDate = LocalDate.parse(filterChart.getToDateTime().toString() + "01", sdf);
            long numOfMonthBetween = ChronoUnit.MONTHS.between(fromLocalDate, toLocalDate);
            List<LocalDate> lstDate = Stream.iterate(fromLocalDate, date -> date.plusMonths(1)).limit(numOfMonthBetween + 1).collect(Collectors.toList());
            return lstDate.stream().map(o -> {
                return o.format(sdf).substring(0, o.format(sdf).length() - 2);
            }).collect(Collectors.toList());
        }

//        if (Constants.AggType.quarter.toString().equals(filterChart.getAggType())) {
//            DateTimeFormatter sdf = DateTimeFormatter.ofPattern(Constants.DATE_FM_PATTERN);
//            LocalDate fromLocalDate = LocalDate.parse(filterChart.getFromDateTime().toString() +"01", sdf);
//            LocalDate toLocalDate = LocalDate.parse(filterChart.getToDateTime().toString()+"01", sdf);
//            long numOfMonthBetween = ChronoUnit.MONTHS.between(fromLocalDate, toLocalDate);
//            List<LocalDate> lstDate = Stream.iterate(fromLocalDate, date -> date.plusMonths(1)).limit(numOfMonthBetween + 1).collect(Collectors.toList());
//            return lstDate.stream().map(o -> {
//                return o.format(sdf).substring(0,o.format(sdf).length()-2);
//            }).collect(Collectors.toList());
//        }

        if (Constants.AggType.year.toString().equals(filterChart.getAggType())) {
            DateTimeFormatter sdf = DateTimeFormatter.ofPattern(Constants.DATE_FM_PATTERN);
            LocalDate fromLocalDate = LocalDate.parse(filterChart.getFromDateTime().toString() + "0101", sdf);
            LocalDate toLocalDate = LocalDate.parse(filterChart.getToDateTime().toString() + "0101", sdf);
            long numOfYearBetween = ChronoUnit.YEARS.between(fromLocalDate, toLocalDate);
            List<LocalDate> lstDate = Stream.iterate(fromLocalDate, date -> date.plusYears(1)).limit(numOfYearBetween + 1).collect(Collectors.toList());
            return lstDate.stream().map(o -> {
                return o.format(sdf).substring(0, o.format(sdf).length() - 4);
            }).collect(Collectors.toList());
        }
        return new ArrayList();
    }

    public String convertNameResponse(String name) {
        String var = "";
        String name_current = "";
        for (int i = 0; i < name.length(); i++) {
            var += name.charAt(i);
            if (i == 3 || i == 5) {
                var += "/";
            }
        }

        String[] arr = var.split("/");
        for (int i = arr.length - 1; i >= 0; i--) {
            if (i == 0) {
                name_current += arr[i];
            } else {
                name_current += arr[i] + "/";
            }
        }

        return name_current;
    }
}
