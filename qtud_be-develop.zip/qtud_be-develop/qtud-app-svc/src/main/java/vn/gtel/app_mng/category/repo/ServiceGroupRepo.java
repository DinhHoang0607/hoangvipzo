package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.ServiceGroup;

@Repository
public interface ServiceGroupRepo extends JpaRepository<ServiceGroup, String>{

}
