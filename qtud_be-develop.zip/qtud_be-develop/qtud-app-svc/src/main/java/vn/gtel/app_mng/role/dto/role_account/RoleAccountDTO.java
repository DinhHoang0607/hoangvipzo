package vn.gtel.app_mng.role.dto.role_account;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditBaseDTO;
import vn.gtel.app_mng.common.dto.AuditCodeDTO;
import vn.gtel.app_mng.role.dto.RoleItemDTO;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleAccountDTO implements Serializable {
	@NotEmpty(message = "error.common.validate.not.empty")
	@Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32")
	private String account;

	@NotEmpty(message = "error.common.validate.not.empty")
	@Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32")
	private String groupRole;
//	private List<String> groupAccount;
	private List<String> applications;
	private List<RoleItemDTO> roles;
	private  Long checkRole;
}
