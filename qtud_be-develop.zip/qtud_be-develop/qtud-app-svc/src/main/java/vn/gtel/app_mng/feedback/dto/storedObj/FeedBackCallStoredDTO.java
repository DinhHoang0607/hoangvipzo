package vn.gtel.app_mng.feedback.dto.storedObj;

import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.feedback.dto.FeedBackHistoryResponse;
import vn.gtel.app_mng.feedback.dto.FeedBackResponse;
import vn.gtel.app_mng.feedback.dto.FeedBackTextFilter;
import vn.gtel.common.dto.AccountDTO;
import vn.gtel.common.userinfo.AccountLogonContext;
import java.util.HashMap;
import java.util.Map;

public class FeedBackCallStoredDTO extends ICallStoredObj {

    public static final String PACKAGE_NAME = "PKG_PHAN_ANH";
    public static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_PHAN_ANH";
    public static final String  PROC_FIND_FEED_BACK_HISTORY = "PROC_TIM_PHAN_ANH_LICH_SU";
    public static final String PROC_TIM_KIEM_PHAN_ANH_LICH_SU = "PROC_TIM_KIEM_PHAN_ANH_LICH_SU";

    public static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    public static final String IN_PAGE = "PI_PAGE";
    public static final String IN_SIZE = "PI_SIZE";
    public static final String IN_CODE = "PI_MA";
    public static final String IN_LOGIN_ACC = "PI_TK_DANG_NHAP";
    public static final String IN_SEARCH_ACC = "PI_TK_TIM_KIEM";
    public static final String IN_ORG = "PI_DON_VI";
    public static final String IN_VIEW = "PI_VIEW";
    public static final String IN_CLASSIFY = "PI_PHAN_LOAI";
    public static final String IN_MUC_DO= "PI_MUC_DO";
    public static final String IN_STATUS= "PI_TRANG_THAI";
    public static final String IN_START_DATE= "PI_START_DATE";
    public static final String IN_END_DATE= "PI_END_DATE";
    public static final String IN_ID = "PI_ID";
    public static final String IN_STATUS1 = "PI_STATUS1";
    public static final String IN_STATUS2 = "PI_STATUS2";
    public static final String IN_ACCOUNT = "PI_ACCOUNT";
    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(FeedBackResponse.class);
    };

    public FeedBackCallStoredDTO(FeedBackTextFilter feedBackTextFilter){
        AccountDTO account = AccountLogonContext.currentUser();
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, feedBackTextFilter.getKeySearch());
        params.put(IN_START_DATE, CommonUtils.yyyyMMddInstant(feedBackTextFilter.getStartDate()));
        params.put(IN_END_DATE, CommonUtils.yyyyMMddInstant(feedBackTextFilter.getEndDate()));
        params.put(IN_LOGIN_ACC, account.getAccount());
        params.put(IN_SEARCH_ACC, feedBackTextFilter.getAccount());
        params.put(IN_ORG, feedBackTextFilter.getOrgCode());
        params.put(IN_CODE, feedBackTextFilter.getCode());
        params.put(IN_CLASSIFY, feedBackTextFilter.getClassify());
        params.put(IN_VIEW, feedBackTextFilter.getView());
        params.put(IN_STATUS, feedBackTextFilter.getStatus());
        params.put(IN_PAGE, feedBackTextFilter.getPage());
        params.put(IN_SIZE, feedBackTextFilter.getSize());
        setParams(params);
    }

    public FeedBackCallStoredDTO(String idFeedBack, int page, int size, Integer status){
        setBase();
        setResponseType(FeedBackHistoryResponse.class);
        setStoredName(PROC_TIM_KIEM_PHAN_ANH_LICH_SU);
        params.put(IN_ID,idFeedBack);
        params.put(IN_PAGE,page);
        params.put(IN_SIZE,size);
        params.put(IN_STATUS,status);
        setParams(params);

    }

    public FeedBackCallStoredDTO(String idFeedBack, Integer status1, Integer status2){
    setBase();
    setResponseType(FeedBackHistoryResponse.class);
    setStoredName(PROC_FIND_FEED_BACK_HISTORY);
    params.put(IN_ID,idFeedBack);
    params.put(IN_STATUS1,status1);
    params.put(IN_STATUS2,status2);
    setParams(params);
    }
}
