package vn.gtel.app_mng.category.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "TBL_TK_USB_TOKEN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsbTokenHistory extends AuditModelBase {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;
	@Basic
	@Column(name = "TAI_KHOAN")
	private String account;
	@Basic
	@Column(name = "NGAY_BAT_DAU")
	private Instant startDate;
	@Basic
	@Column(name = "NGAY_KET_THUC")
	private Instant endDate;
	@Basic
	@Column(name = "KI_HIEU")
	private String code;
}
