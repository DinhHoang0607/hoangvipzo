package vn.gtel.app_mng.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@FieldNameConstants
public abstract class AuditModel extends AuditModelBase implements Serializable {

    @Basic
    @Column(name = "MO_TA")
    private String description;

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "TEN")
    private String name;

}
