package vn.gtel.app_mng.maintenance.dto.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaintenanceConfigurationFilterDTO {
    private String description;
    private Instant startedDateBegin;
    private Instant startedDateEnd;
    private Instant finishedDateBegin;
    private Instant finishedDateEnd;
    private Long minDuration; // Minute
    private Long maxDuration; // Minute
    private Long status;
    private Long deleted;
    private Long pageNumber;
    private Long sizeNumber;
}

