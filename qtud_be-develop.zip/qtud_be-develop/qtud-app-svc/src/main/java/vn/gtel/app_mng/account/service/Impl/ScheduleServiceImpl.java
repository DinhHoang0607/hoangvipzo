package vn.gtel.app_mng.account.service.Impl;

import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.service.AccountService;
import vn.gtel.app_mng.account.service.ScheduleService;
import vn.gtel.app_mng.system.service.NotificationService;

@Service
@AllArgsConstructor
public class ScheduleServiceImpl implements ScheduleService {

    private final AccountService accountService;
    private final AccountServiceImpl accountServiceImpl;
    private final NotificationService notificationService;

    @Scheduled(cron = "0 0 0 * * *")
    @Scheduled(cron = "0 0 12 * * *")
    @Override
    public void everyDay() {
        accountService.changeStatusPW();
    }

    @Scheduled(fixedDelay = 10 * 60 * 1000)
    @Override
    public void every10minus() {

    }


    //    @Scheduled(fixedDelay = 2 * 60 * 1000)
    @Override
    public void every15Minute() {
        accountService.changeStatusPW();
//        accountServiceImpl.clearAllAccountCache();
//        accountServiceImpl.clearDetailAccountCache();
    }

    //        @Scheduled(cron = "0 0 0 * * *")
//    @Scheduled(fixedDelay = 60 * 60 * 1000)
    @Override
    public void TwelveHoursEveryDay() {
        accountService.deleteAccountAfter30Days();
    }
}
