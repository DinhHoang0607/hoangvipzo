package vn.gtel.app_mng.role.dto.service;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.PageFilter;

@Data
public class RoleServiceFiler extends PageFilter {

    private String keySearch;

    public RoleServiceFiler(Integer page, Integer size, String keySearch) {
        super(page, size);
        this.keySearch = keySearch;
    }
}
