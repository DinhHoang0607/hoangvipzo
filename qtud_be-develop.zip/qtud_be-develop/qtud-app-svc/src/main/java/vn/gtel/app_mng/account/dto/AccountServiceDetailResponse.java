package vn.gtel.app_mng.account.dto;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccountServiceDetailResponse {
    @Column(name = "TAI_KHOAN")
    private String account;
    @Column(name = "TEN")
    private String name;
    @Column(name = "DON_VI")
    private String organization;
    @Column(name = "TEN_DON_VI")
    private String organizationName;
    //    @Column(name = "MAT_KHAU")
//    private String password;
    @Column(name = "MO_TA")
    private String description;
    @Column(name = "HO_TEN_LH")
    private String relationName;
    @Column(name = "DIEN_THOAI_LH")
    private String relationPhone;
    @Column(name = "CAP_BAC_LH")
    private String relationMilitary;
    @Column(name = "SO_HIEU_CAND_LH")
    private String relationPoliceNumber;
    @Column(name = "CHUC_VU_LH")
    private String relationPosition;
    @Column(name = "GHI_CHU_LD")
    private String relationDescription;
    @Column(name = "HO_TEN_DD")
    private String representativeName;
    @Column(name = "SO_HIEU_CAND_DD")
    private String representativePoliceNumber;
    @Column(name = "DIEN_THOAI_DD")
    private String representativePhone;
    @Column(name = "CAP_BAC_DD")
    private String representativeMilitary;
    @Column(name = "CHUC_VU_DD")
    private String representativePosition;
    @Column(name = "GHI_CHU_DD")
    private String representativeDescription;
    @Column(name = "PHAN_LOAI")
    private Long serviceType;
}
