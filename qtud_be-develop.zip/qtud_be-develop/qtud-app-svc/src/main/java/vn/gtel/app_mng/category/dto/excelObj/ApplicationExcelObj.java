package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;
import java.util.Map;

@Data
public class ApplicationExcelObj extends IExcelMapperObj {

    public ApplicationExcelObj(int stt) {
        setFieldToIndexMap(new HashMap<>());
        getFieldToIndexMap().put("code", stt + 1);
        getFieldToIndexMap().put("name", stt + 2);
        getFieldToIndexMap().put("clientSecret", stt + 3);
        getFieldToIndexMap().put("grantType", stt + 4);
        getFieldToIndexMap().put("accessTokenValidity", stt + 5);
        getFieldToIndexMap().put("refreshTokenValidity", stt + 6);
        getFieldToIndexMap().put("url", stt + 7);
        getFieldToIndexMap().put("description", stt + 8);
        getFieldToIndexMap().put("parentCode", stt + 9);
        getFieldToIndexMap().put("sortName", stt + 10);
        getFieldToIndexMap().put("type", stt + 11);
        getFieldToIndexMap().put("isWebsite", stt + 12);
        getFieldToIndexMap().put("order", stt + 13);
        getFieldToIndexMap().put("resultColumn", stt + 14);
        setFieldToIndexMap(getFieldToIndexMap());
    }
}
