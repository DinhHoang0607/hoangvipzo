package vn.gtel.app_mng.account.reponse;

import lombok.Data;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Column;

@Data
public class AccountResponse extends AuditItemResponse {

    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "MAT_KHAU")
    private String password;

    @Column(name = "HO_TEN")
    private String name;

    @Column(name = "CCCD")
    private String citizenID;

    @Column(name = "DIEN_THOAI")
    private String phone;

    @Column(name = "PHAN_LOAI")
    private Integer type;

    @Column(name = "DON_VI")
    private String organization;

    @Column(name = "MA_DON_VI_MOI")
    private String organizationNew;

    @Column(name = "TEN_DON_VI")
    private String organizationName;

    @Column(name = "CHUC_VU")
    private String position;

    @Column(name = "CAP_BAC")
    private String military;

    @Column(name = "TEN_CHUC_VU")
    private String positionName;

    @Column(name = "TEN_CAP_BAC")
    private String militaryName;

    @Column(name = "SO_HIEU_CAND")
    private String policeNumber;

    @Column(name = "CAP_DON_VI")
    private String organizationLevel;

    @Column(name = "TEN_DV_CHA")
    private String organizationNameSuperior;

    @Column(name = "KY_HIEU")
    private String signOrganization;

    @Column(name = "TEN_HIEN_THI")
    private String nameDisplay;

    @Column(name = "THAO_TAC")
    private Long action;

    @Column(name = "TEN_CAP_DON_VI")
    private String nameOrganizationLevel;

    @Column(name = "TAI_KHOAN_HIEN_THI")
    private String accountDisplay;

    @Column(name = "HANH_DONG_KET_XUAT")
    private Integer actionExport;

    @Column(name = "TRANG_THAI_XAC_NHAN")
    private String confirmStatus;

    @Column(name = "HANH_DONG_XOA")
    private Integer actionRemove;

    @Column(name = "THUOC_CQDT")
    private Integer investigativeAgencyType;
}
