package vn.gtel.app_mng.category.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.dto.res.OrganizationResponseDTO;
import vn.gtel.app_mng.category.model.Organization;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrganizationRepo extends JpaRepository<Organization, String> {
    Optional<Organization> findByOrganizationParent(String organization);

    Organization findByCode(String organizationOld);
//    @Query(value= "SELECT o.code FROM Organization o WHERE o.countryCode = :countryCode")
//    String findByV06Code(String countryCode );

    Organization findByCodeAndStatus(String organization, Integer status);

    List<Organization> findByOrganizationParentAndStatus(String organization, Integer status);

    @Query(
            value = " select new vn.gtel.app_mng.category.dto.res.OrganizationResponseDTO(org) from Organization as org " +
                    " left join IntegrationSync as intSyn on org.code = intSyn.orgCode " +
                    " and intSyn.status <> -1 " +
                    " where intSyn is null " +
                    " and org.status = 1 " +
                    " and ( " +
                    "      :keySearch is null or " +
                    "      upper(org.code) like concat('%',upper(:keySearch),'%') or " +
                    "      upper(org.name) like concat('%',upper(:keySearch),'%') or " +
                    "      upper(org.fullName) like concat('%',upper(:keySearch),'%') " +
                    "     ) " +
                    " order by org.code asc "
    )
    Page<OrganizationResponseDTO> findUnusedInIntegrationSync(String keySearch, Pageable pageable);

    boolean existsByCodeAndStatusNot(String appCode, Integer active);

    boolean existsByCode(String orgFeedbackCode);
}
