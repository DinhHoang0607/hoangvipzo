package vn.gtel.app_mng.feedback.dto;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class RemoveFeedBackDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    private String idFeedBack;
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String comment;
   // 1 V06 , 2 V01
    private Integer classify;

    private List<FileFeedBackDTO> files;
}
