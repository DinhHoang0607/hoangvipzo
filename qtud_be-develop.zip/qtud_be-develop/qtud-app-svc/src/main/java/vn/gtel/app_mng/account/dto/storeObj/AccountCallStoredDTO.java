/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  SystemParamCallStoredDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/6/21, 11:33 AM
 */

package vn.gtel.app_mng.account.dto.storeObj;

import org.apache.commons.collections4.CollectionUtils;
import vn.gtel.common.dto.AccountDTO;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.app_mng.account.dto.AccountLeadResponseDTO;
import vn.gtel.app_mng.account.dto.AccountOrganizationDTO;
import vn.gtel.app_mng.account.dto.AccountServiceDetailResponse;
import vn.gtel.app_mng.account.dto.ResultDTO;
import vn.gtel.app_mng.account.filter.*;
import vn.gtel.app_mng.account.reponse.*;
import vn.gtel.app_mng.category.dto.res.AccountGroupRoleMenuItemResponseDTO;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.util.HashMap;
import java.util.Map;

public class AccountCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_TK_TAI_KHOAN";
    private static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_TK_NGUOI_DUNG";
    private static final String PROC_SEARCH_ACCOUNT_UNRESTRICTED = "PROC_TIM_KIEM_DS_TAI_KHOAN";
    private static final String PROC_SEARCH_ACCOUNT_EXPLOIT = "PROC_TIM_KIEM_TK_KHAI_THAC";
    private static final String PROC_SEARCH_ACCOUNT_MANAGE = "PROC_DS_CAP_TREN_CAP_DUOI";
    private static final String PROC_SEARCH_ORG_MANAGE = "PROC_DS_DON_VI_PHU_TRACH";
    private static final String PROC_SEARCH_FIELD_MANAGE = "PROC_DS_LINH_VUC_PHU_TRACH";
    private static final String PROC_SEARCH_ACCOUNT_SERVICE = "PROC_TIM_KIEM_TK_HE_THONG";
    private static final String PROC_SEARCH_ACCOUNT_GROUP_ROLE = "PROC_TIM_KIEM_TK_THEO_NHOM_QUYEN";
    private static final String PROC_SEARCH_ACCOUNT_GROUP_ROLE_THDB = "PROC_TIM_KIEM_TK_THEO_NHOM_QUYEN_THDB";
    private static final String PROC_SEARCH_ACCOUNT_NOT_IN_GROUP_ROLE = "PROC_TIM_KIEM_TK_KHONG_TRONG_NQ";
    private static final String PROC_SEARCH_ACCOUNT_WITHOUT_GROUP_ROLE = "PROC_TIM_KIEM_TK_CHUA_GAN_NQ";
    private static final String PROC_SEARCH_ACCOUNT_ORG = "PROC_TIM_KIEM_TK_DON_VI_HO_SO_THEO_DON_VI_NGHIEP_VU";
    private static final String PROC_SEARCH_ACCOUNt_BY_REQUIRE_PURPOSE = "PROC_TIM_KIEM_TAI_KHOAN_THEO_MUC_DICH_YEU_CAU";
    private static final String PROC_SEARCH_NAME_LEAD = "PROC_TIM_KIEM_TK_NGUOI_DUNG_LANH_DAO";
    private static final String PROC_SEARCH_ACC_QLTT = "PROC_TIM_KIEM_DS_TK_QLTT_VA_CUNG_DON_VI";
    private static final String PROC_QL_TRUC_TIEP = "PROC_QL_TRUC_TIEP";
    private static final String PROC_DS_QL_TRUC_TIEP = "PROC_TIM_KIEM_DS_TAI_KHOAN_QL_CAP_TREN";
    private static final String PROC_GENERATE_ADMIN = "PROC_SINH_TAI_KHOAN_ADMIN";
    private static final String PROC_MANAGED_ORGS_BY_ADMIN = "PROC_DS_DON_VI_QUAN_LY_THEO_ADMIN";
    private static final String IN_PERSISION = "PI_MA";
    private static final String PROC_LEAD = "PROC_TIM_KIEM_TK_LANH_DAO";
    private static final String PROC_TRANSFER_ORG = "PROC_TIM_KIEM_TK_CHUYEN_DV";
    private static final String PROC_LEAD_EM_AN = "PROC_TIM_KIEM_TK_LANH_DAO_CAN_BO_AN";
    private static final String PROC_GROUP_TRANSFER = "PROC_NHOM_CHUYEN_DON_VI";
    private static final String PROC_FIND_ACC_WITH_POS_TYPE_IN_ORG = "PROC_TIM_TK_CB_LD_TRONG_DV";
    private static final String PROC_ACCOUNT_HISTORY = "PROC_LICH_SU_TAI_KHOAN";

    private static final String PROC_SEARCH_ORGANIZATION_BY_USERNAME = "PROC_SEARCH_ORGANIZATION_BY_USERNAME";
    private static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    private static final String IN_ORGANIZATION = "PI_DON_VI";
    private static final String IN_ORGANIZATION_PARENT = "PI_DON_VI_CHA";
    private static final String IN_TYPE = "PI_TYPE";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_POSITION_A = "pi_chuc_vu";
    private static final String IN_ORG = "pi_don_vi";
    private static final String IN_NOT_ACC = "PI_NOT_IN_ACC";
    private static final String IN_SIZE = "PI_SIZE";
    private static final String IN_ACCOUNT = "PI_TAI_KHOAN";
    private static final String IN_FIND_ACCOUNT = "PI_TIM_KIEM_TK";
    private static final String IN_NAME = "PI_HO_TEN";
    private static final String IN_POLICE_NUMBER = "PI_SO_HIEU_CAND";
    private static final String IN_POSITION = "PI_CHUC_VU";
    private static final String IN_POSITIONS = "PI_DS_SO_HIEU_CAND";
    private static final String IN_POSITION_TYPE = "PI_LOAI_CHUC_VU";
    private static final String IN_MILITARY = "PI_CAP_BAC";
    private static final String IN_STATUS = "PI_TRANG_THAI";
    private static final String IN_ORGANIZATION_LEVEL = "PI_CAP_DON_VI";
    private static final String PI_USER_NAME = "PI_USER_NAME";
    private static final String PROC_FIND_ACCOUNT_EMPLOYEE = "PROC_CHI_TIET_TK_NGUOI_DUNG";
    private static final String PROC_FIND_ACCOUNT_SERVICE = "PROC_CHI_TIET_TK_HE_THONG";
    private static final String PROC_FIND_ACCOUNT_ORG = "PROC_LICH_SU_CHUYEN_DV";
    private static final String IN_PI_ID = "PI_ID";
    private static final String IN_GROUP_ROLE = "PI_NHOM_QUYEN";
    private static final String IN_GROUP_ROLE_TYPE = "PI_LOAI_NHOM_QUYEN";
    private static final String IN_ACCOUNT_TYPE = "PI_LOAI_TAI_KHOAN";
    private static final String IN_REQUIRE_PURPOSE = "PI_REQUIRE_PURPOSE";
    private static final String IN_FLAG = "PI_FLAG";
    private static final String IN_ACCOUNT_COPY = "PI_TK_NHAN_BAN";
    private static final String IN_MA_DV = "PI_MA_DON_VI";
    private static final String IN_LOCAL_FILTER = "PI_TK_DUOI_QUYEN";
    private static final String IN_PASSWORD = "PI_MAT_KHAU";
    private static final String IN_ORG_LOGIN = "PI_ORG_LOGIN";
    private static final String IN_CONFIRM_INFO = "pi_xac_nhan_thong_tin";
    private static final String IN_LEADER = "PI_TK_LANH_DAO";
    private static final String IN_STAFF = "PI_TK_CAN_BO";
    private static final String IN_ACCOUNT_NAME = "PI_TEN_TAI_KHOAN";

    private static final String PROC_GET_DEFAULT_PW_ACCOUNT = "PROC_LAY_MAT_KHAU_MAC_DINH";

    private static final String PROC_KIEM_TRA_DAU_VAO_TK = "PROC_KIEM_TRA_DAU_VAO_TK";
    private static final String IN_ID_TAI_KHOAN = "PI_ID_TAI_KHOAN";
    private static final String IN_PHAN_LOAI = "PI_PHAN_LOAI";
    private static final String IN_DON_VI = "PI_DON_VI";


    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(AccountResponse.class);
    }

    private void setBaseExploit() {
        setPackageName(PACKAGE_NAME);
        setResponseType(AccountExploitResponse.class);
    }

    private void setBaseService() {
        setPackageName(PACKAGE_NAME);
        setResponseType(AccountServiceResponse.class);
    }


    public AccountCallStoredDTO(TextFilter textFilter) {
        AccountDTO account = AccountLogonContext.currentUser();
        if (textFilter instanceof AccountExploitFilter) {
            AccountExploitFilter accountExploitFilter = (AccountExploitFilter) textFilter;
            setBaseExploit();
            setStoredName(PROC_SEARCH_ACCOUNT_EXPLOIT);
            params.put(IN_ORGANIZATION, accountExploitFilter.getOrganization());
            params.put(IN_TYPE, accountExploitFilter.getType());
        } else if (textFilter instanceof AccountServiceFilter) {
            AccountServiceFilter accountServiceFilter = (AccountServiceFilter) textFilter;
            setBaseService();
            setStoredName(PROC_SEARCH_ACCOUNT_SERVICE);
            params.put(IN_ACCOUNT, accountServiceFilter.getCode());
            params.put(IN_TYPE, accountServiceFilter.getType());
            params.put(IN_NAME, accountServiceFilter.getName());
            params.put(IN_STATUS, accountServiceFilter.getStatus());
            params.put(IN_ORGANIZATION, accountServiceFilter.getOrganization());
        } else if (textFilter instanceof AccountFilter) {
            AccountFilter accountFilter = (AccountFilter) textFilter;
            setBase();
            setStoredName(PROC_SEARCH_NAME);
            params.put(IN_ACCOUNT, accountFilter.getAccount());
            params.put(IN_ACCOUNT_NAME, accountFilter.getAccountName());
            params.put(IN_NAME, accountFilter.getName());
            params.put(IN_POLICE_NUMBER, accountFilter.getPoliceNumber());
            params.put(IN_POSITION, accountFilter.getPosition());
            params.put(IN_MILITARY, accountFilter.getMilitary());
            params.put(IN_STATUS, accountFilter.getStatus());
            params.put(IN_ORGANIZATION, accountFilter.getOrganization());
            params.put(IN_ORGANIZATION_LEVEL, accountFilter.getOrganizationLevel());
            params.put(IN_ACCOUNT_TYPE, accountFilter.getTypeEmployee());
            params.put(IN_LOCAL_FILTER, accountFilter.getOnlyLocalAccount());
            params.put(IN_CONFIRM_INFO, accountFilter.getStatusConfirmInfo());
            if (accountFilter.getPoliceNumbers() != null && accountFilter.getPoliceNumbers().size() > 0) {
                params.put(IN_POSITIONS, String.join("','", accountFilter.getPoliceNumbers()));
            } else {
                params.put(IN_POSITIONS, null);
            }
        } else if (textFilter instanceof AccountGroupRoleFilter) {
            setBase();
            AccountGroupRoleFilter accountGroupRoleFilter = (AccountGroupRoleFilter) textFilter;
            setResponseType(AccountGroupRoleMenuItemResponseDTO.class);
            setStoredName(PROC_SEARCH_ACCOUNT_GROUP_ROLE);
            params.put(IN_GROUP_ROLE, accountGroupRoleFilter.getGroupRole());
            params.put(IN_DON_VI, accountGroupRoleFilter.getOrg());
            params.put(IN_POSITION, accountGroupRoleFilter.getPosition());
            if (accountGroupRoleFilter instanceof WithoutGroupRoleFilter) {
                WithoutGroupRoleFilter withoutGroupRoleFilter = (WithoutGroupRoleFilter) accountGroupRoleFilter;
                setResponseType(AccountGroupRoleMenuItemResponseDTO.class);
                params.put(IN_GROUP_ROLE, withoutGroupRoleFilter.getGroupRole());
                params.put(IN_GROUP_ROLE_TYPE, withoutGroupRoleFilter.getType());
                params.put(IN_DON_VI, withoutGroupRoleFilter.getOrg());
                params.put(IN_POSITION, withoutGroupRoleFilter.getPosition());
                setStoredName(PROC_SEARCH_ACCOUNT_NOT_IN_GROUP_ROLE);
            }
        } else if (textFilter instanceof AccountGroupRoleTHDBFilter) {
            setBase();
            AccountGroupRoleTHDBFilter accountGroupRoleFilter = (AccountGroupRoleTHDBFilter) textFilter;
            setResponseType(AccountGroupRoleMenuItemResponseDTO.class);
            setStoredName(PROC_SEARCH_ACCOUNT_GROUP_ROLE_THDB);
            params.put(IN_GROUP_ROLE, accountGroupRoleFilter.getGroupRole());
            params.put(IN_DON_VI, accountGroupRoleFilter.getOrg());
            params.put(IN_POSITION, accountGroupRoleFilter.getPosition());
        } else if (textFilter instanceof AccountWithoutGroupRoleFilter) {
            setBase();
            AccountWithoutGroupRoleFilter accountWithoutGroupRoleFilter = (AccountWithoutGroupRoleFilter) textFilter;
            setResponseType(AccountGroupRoleMenuItemResponseDTO.class);
            params.put(IN_GROUP_ROLE_TYPE, accountWithoutGroupRoleFilter.getType());
            params.put(IN_DON_VI, accountWithoutGroupRoleFilter.getOrg());
            params.put(IN_POSITION, accountWithoutGroupRoleFilter.getPosition());
            params.put(IN_ACCOUNT_COPY, accountWithoutGroupRoleFilter.getEmployee());
            params.put(IN_MA_DV, accountWithoutGroupRoleFilter.getCodeUnit());
//            params.put(IN_ORGANIZATION_LEVEL,accountWithoutGroupRoleFilter.getUnitLevel());
            if (CollectionUtils.isNotEmpty(accountWithoutGroupRoleFilter.getNotAcc())) {
                params.put(IN_NOT_ACC, String.join(",", accountWithoutGroupRoleFilter.getNotAcc()));
            } else {
                params.put(IN_NOT_ACC, null);
            }
            setStoredName(PROC_SEARCH_ACCOUNT_WITHOUT_GROUP_ROLE);
        } else {
            setBase();
            setStoredName(PROC_SEARCH_ACCOUNT_ORG);
        }
        params.put(getPiCurrentAccountId(), account != null ? account.getId() : null);
        params.put(getPiCurrentOrg(), account != null ? account.getOrganization() : null);
        params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
        params.put(IN_PAGE, textFilter.getPage());
        params.put(IN_SIZE, textFilter.getSize());
        setParams(params);
    }

    public AccountCallStoredDTO(AccountFilter accountFilter) {// print
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_ACCOUNT, accountFilter.getAccount());
        params.put(IN_NAME, accountFilter.getName());
        params.put(IN_POLICE_NUMBER, accountFilter.getPoliceNumber());
        params.put(IN_POSITION, accountFilter.getPosition());
        params.put(IN_MILITARY, accountFilter.getMilitary());
        params.put(IN_STATUS, accountFilter.getStatus());
        params.put(IN_ORGANIZATION, accountFilter.getOrganization());
        params.put(IN_ORGANIZATION_LEVEL, accountFilter.getOrganizationLevel());
        params.put(IN_ACCOUNT_TYPE, accountFilter.getTypeEmployee());
        params.put(getPiCurrentAccountId(), null);// get all acc not by acc login
        params.put(getPiCurrentOrg(), null);
        params.put(IN_KEY_SEARCH, accountFilter.getKeySearch());
        params.put(IN_PAGE, accountFilter.getPage());
        params.put(IN_SIZE, accountFilter.getSize());
        params.put(IN_LOCAL_FILTER, accountFilter.getOnlyLocalAccount());
        params.put(IN_CONFIRM_INFO, accountFilter.getStatusConfirmInfo());
        params.put(IN_POSITIONS, null);
        params.put(IN_ACCOUNT_NAME, null);
        setParams(params);
    }

    public AccountCallStoredDTO(AccountExploitFilter accountExploitFilter) {
        setBase();
        setStoredName(PROC_SEARCH_ACCOUNT_UNRESTRICTED);
        params.put(IN_ORGANIZATION, accountExploitFilter.getOrganization());
        params.put(IN_KEY_SEARCH, accountExploitFilter.getKeySearch());
        params.put(IN_PAGE, accountExploitFilter.getPage());
        params.put(IN_SIZE, accountExploitFilter.getSize());
        setParams(params);
    }

    public AccountCallStoredDTO(String id, int type) {
        setBase();
        setResponseType(AccountDetailResponse.class);
        if (type == 1) {
            setStoredName(PROC_FIND_ACCOUNT_EMPLOYEE);
        } else if (type == 2) {
            setStoredName(PROC_SEARCH_ACCOUNT_MANAGE);
            setResponseType(AccountDetailOrg.class);
        } else if (type == 3) {
            setStoredName(PROC_SEARCH_ORG_MANAGE);
            setResponseType(OrganizationManage.class);
        } else {
            setStoredName(PROC_SEARCH_FIELD_MANAGE);
            setResponseType(FieldManageResponse.class);
        }

        params.put(IN_PI_ID, id);
        setParams(params);
    }

    public AccountCallStoredDTO(String username, String type) {
        if (type.equals("1")) {
            setPackageName(PACKAGE_NAME);
            setResponseType(AccountOrganizationDTO.class);
            setStoredName(PROC_SEARCH_ORGANIZATION_BY_USERNAME);
            params.put(PI_USER_NAME, username);
            setParams(params);
        }
//        else if(type.equals("2")){
//            setPackageName(PACKAGE_NAME);
//            setResponseType(AccountOrganizationDTO.class);
//            setStoredName(PROC_QL_TRUC_TIEP);
//            params.put(IN_ORGANIZATION, username);
//            setParams(params);
//        }
    }

    public AccountCallStoredDTO(String code, String parentCode, int type) {
        setPackageName(PACKAGE_NAME);
        setResponseType(AccountOrganizationDTO.class);
        setStoredName(PROC_QL_TRUC_TIEP);
        params.put(IN_PERSISION, code);
        params.put(IN_ORGANIZATION, parentCode);
        setParams(params);
    }

    public AccountCallStoredDTO(TextFilter textFilter, String position, String org) {
        setPackageName(PACKAGE_NAME);
        setResponseType(AccountOrganizationDTO.class);
        setStoredName(PROC_DS_QL_TRUC_TIEP);
        params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
        params.put(IN_PAGE, textFilter.getPage());
        params.put(IN_SIZE, textFilter.getSize());
        params.put(IN_POSITION, position);
        params.put(IN_ORGANIZATION, org);
        setParams(params);
    }

    public AccountCallStoredDTO(GroupTransferOrgFilter filter) {
        setPackageName(PACKAGE_NAME);
        setResponseType(GroupTransferOrgResponse.class);
        setStoredName(PROC_GROUP_TRANSFER);
        params.put(IN_KEY_SEARCH, filter.getKeySearch());
        params.put(IN_PAGE, filter.getPage());
        params.put(IN_SIZE, filter.getSize());
        params.put(IN_POLICE_NUMBER, filter.getPoliceNumber());
        params.put(IN_POSITION_TYPE, filter.getPositionType());
        params.put(IN_ORGANIZATION, filter.getOrganization());
        params.put(IN_FIND_ACCOUNT, filter.getAccount());
        params.put(IN_ACCOUNT, AccountLogonContext.currentUser().getAccount());
        setParams(params);
    }

    public AccountCallStoredDTO(String id, Long type) {
        setBase();
        setStoredName(PROC_FIND_ACCOUNT_SERVICE);
        setResponseType(AccountServiceDetailResponse.class);
        params.put(IN_PI_ID, id);
        setParams(params);
    }

    public AccountCallStoredDTO(AccountGroupRoleFilter accountGroupRoleFilter) {
        setBase();
        setResponseType(AccountGroupRoleMenuItemResponseDTO.class);
        setStoredName(PROC_SEARCH_ACCOUNT_GROUP_ROLE);
        params.put(IN_GROUP_ROLE, accountGroupRoleFilter.getGroupRole());
        params.put(IN_KEY_SEARCH, accountGroupRoleFilter.getKeySearch());
        params.put(IN_PAGE, accountGroupRoleFilter.getPage());
        params.put(IN_SIZE, accountGroupRoleFilter.getSize());
        setParams(params);
    }

    public AccountCallStoredDTO(TextFilter textFilte, String requirePurposeCode, Long flag) {
        setBase();
        setStoredName(PROC_SEARCH_ACCOUNt_BY_REQUIRE_PURPOSE);
        setResponseType(AccountServiceByRequirePurposeReponse.class);
        params.put(IN_REQUIRE_PURPOSE, requirePurposeCode);
        params.put(IN_KEY_SEARCH, textFilte.getKeySearch());
        params.put(IN_PAGE, textFilte.getPage());
        params.put(IN_SIZE, textFilte.getSize());
        params.put(IN_FLAG, flag);
        params.put(getPiCurrentAccountId(), AccountLogonContext.currentUser().getId());
        params.put(getPiCurrentOrg(), AccountLogonContext.currentUser().getOrganization());
        setParams(params);
    }

    public AccountCallStoredDTO(String account, Boolean historyOrg) {
        setBase();
        setResponseType(AccountOrgResponse.class);
        setStoredName(PROC_FIND_ACCOUNT_ORG);
        params.put(IN_ACCOUNT, account);
        setParams(params);
    }

    public AccountCallStoredDTO() {
        setBase();
        setStoredName(PROC_GET_DEFAULT_PW_ACCOUNT);
    }

    public AccountCallStoredDTO(TextFilter textFilter, String status, String orgLead, String typeAcc) {
        setBase();
        setResponseType(AccountLeadResponseDTO.class);
        setStoredName(PROC_SEARCH_NAME_LEAD);
        params.put(IN_ORGANIZATION, orgLead);
        //params.put(IN_POSITION,accountFilter.getPosition());
        params.put(IN_TYPE, typeAcc);
        params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
        params.put(IN_PAGE, textFilter.getPage());
        params.put(IN_SIZE, textFilter.getSize());
        params.put(IN_STATUS, status);
        //params.put(IN_ORGANIZATION_PARENT,accountFilter.getOrganizationParent());
        setParams(params);
    }

    public AccountCallStoredDTO(String idAccount, int typeAccount, String organization) {
        setBase();
        setResponseType(ResultDTO.class);
        setStoredName(PROC_KIEM_TRA_DAU_VAO_TK);
        params.put(IN_ID_TAI_KHOAN, idAccount);
        params.put(IN_PHAN_LOAI, typeAccount);
        params.put(IN_DON_VI, organization);
        params.put(getPiCurrentOrg(), AccountLogonContext.currentUser().getOrganization());
        setParams(params);
    }

    public AccountCallStoredDTO(TextFilter textFilter, int type) {
        setBase();
        if (type == 1) {
            setResponseType(AccountQLTT.class);
            setStoredName(PROC_SEARCH_ACC_QLTT);
            params.put(IN_ACCOUNT, AccountLogonContext.currentUser().getAccount());
        } else {
            setStoredName(PROC_LEAD);
            params.put(IN_ORGANIZATION, AccountLogonContext.currentUser().getOrganization());
        }
        params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
        params.put(IN_PAGE, textFilter.getPage());
        params.put(IN_SIZE, textFilter.getSize());
        setParams(params);
    }

    public AccountCallStoredDTO(String organization, String password, String account) {
        setBase();
        setStoredName(PROC_GENERATE_ADMIN);
        params.put(IN_ORGANIZATION, organization);
        params.put(IN_PASSWORD, password);
        params.put(IN_ACCOUNT, account);
        setParams(params);
    }

    public AccountCallStoredDTO(String account, Integer page, Integer size) {
        setBase();
        setStoredName(PROC_MANAGED_ORGS_BY_ADMIN);
        setResponseType(Organization.class);
        params.put(IN_ACCOUNT, account);
        params.put(IN_PAGE, page);
        params.put(IN_SIZE, size);
        setParams(params);
    }

    public AccountCallStoredDTO(AccountTransferOrgFilter accountTransferOrgFilter) {
        setBase();
        setStoredName(PROC_TRANSFER_ORG);
        setResponseType(AccountTransferOrgResponse.class);
        params.put(IN_ORGANIZATION, accountTransferOrgFilter.getOrganization());
        params.put(IN_POLICE_NUMBER, accountTransferOrgFilter.getPoliceNumber());
        params.put(IN_ACCOUNT, accountTransferOrgFilter.getAccount());
        params.put(IN_NAME, accountTransferOrgFilter.getFullName());
        params.put(IN_ORG_LOGIN, AccountLogonContext.currentUser().getOrganization());
        params.put(IN_KEY_SEARCH, accountTransferOrgFilter.getKeySearch());
        params.put(IN_PAGE, accountTransferOrgFilter.getPage());
        params.put(IN_SIZE, accountTransferOrgFilter.getSize());
        params.put(IN_TYPE, accountTransferOrgFilter.getType());
        params.put(IN_STATUS, accountTransferOrgFilter.getStatus());
        setParams(params);
    }

    public AccountCallStoredDTO(AccountLeadOrEmFilter accountLeadOrEmFilter) {
        setBase();
        setStoredName(PROC_LEAD_EM_AN);
        params.put(IN_ORGANIZATION, accountLeadOrEmFilter.getOrg());
        params.put(IN_KEY_SEARCH, accountLeadOrEmFilter.getKeySearch());
        params.put(IN_PAGE, accountLeadOrEmFilter.getPage());
        params.put(IN_SIZE, accountLeadOrEmFilter.getSize());
        params.put(IN_TYPE, accountLeadOrEmFilter.getType());
        params.put(IN_POSITION, accountLeadOrEmFilter.getPositionType());
        setParams(params);
    }

    public AccountCallStoredDTO(AccountWithPositionTypeInOrgFilter filter) {
        setBase();
        setStoredName(PROC_FIND_ACC_WITH_POS_TYPE_IN_ORG);
        params.put(IN_ORGANIZATION, filter.getOrganization());
        params.put(IN_KEY_SEARCH, filter.getKeySearch());
        params.put(IN_PAGE, filter.getPage());
        params.put(IN_SIZE, filter.getSize());
        params.put(IN_POSITION, filter.getPosition());
        params.put(IN_POSITION_TYPE, filter.getPositionType());
        params.put(IN_LEADER, filter.getLeader());
        params.put(IN_STAFF, filter.getStaff());
        params.put(IN_TYPE, filter.getType());
        setParams(params);
    }

    public AccountCallStoredDTO(Integer page, Integer size, String account) {
        setBase();
        setStoredName(PROC_ACCOUNT_HISTORY);
        setResponseType(AccountHistoryResponse.class);
        params.put(IN_ACCOUNT, account);
        params.put(IN_PAGE, page);
        params.put(IN_SIZE, size);
        setParams(params);
    }
}
