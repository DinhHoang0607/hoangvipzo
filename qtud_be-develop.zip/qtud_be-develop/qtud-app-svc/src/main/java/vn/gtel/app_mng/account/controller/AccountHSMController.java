package vn.gtel.app_mng.account.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.account.dto.AccountHSMDTO;
import vn.gtel.app_mng.account.dto.AccountSignImgDTO;
import vn.gtel.app_mng.account.service.AccountHSMService;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.validation.Valid;

@Validated
@Tag(name = "Tài khoản người dùng kí số", description = "Tài khoản người dùng kí số")
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/account-hsm")
public class AccountHSMController {

    @Autowired
    private AccountHSMService accountHSMService;

    @Operation(summary = "Thông tin tài khoản")
    @GetMapping(value = "")
    public ResponseBase get() {
        return accountHSMService.getMe();
    }

    @Operation(summary = "Thông tin ảnh ký")
    @GetMapping(value = "/{account}")
    public ResponseBase getSignImg(@PathVariable String account) {
        return accountHSMService.getSignImg(account);
    }

    @Operation(summary = "Thêm mới tài khoản")
    @PostMapping(value = "", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseBase createAccountHSM(@ModelAttribute AccountHSMDTO accountHSMDTO)
            throws Exception {
        ResponseBase res = accountHSMService.save(accountHSMDTO);
        return res;
    }

    @Operation(summary = "Sửa tài khoản")
    @PutMapping(value = "", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseBase updateAccountHSM(@ModelAttribute AccountHSMDTO accountHSMDTO)
            throws Exception {
        return accountHSMService.save(accountHSMDTO);
    }

    @Operation(summary = "Thêm/ Cập nhật ảnh chân ký")
    @PostMapping(value = "/sign-img", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseBase updateSignImg(@Valid @ModelAttribute AccountSignImgDTO accountSignImgDTO)
            throws Exception {
        return accountHSMService.saveImgSign(accountSignImgDTO);
    }

    @Operation(summary = "Xóa thông tin tài khoản kí số")
    @DeleteMapping(value = "/{account}")
    public ResponseBase deleteAccountHSM(@PathVariable String account)
            throws Exception {
        return accountHSMService.delete(account);
    }

    @Operation(summary = "Xóa ảnh chân ký")
    @DeleteMapping(value = "/img/{account}")
    public ResponseBase deleteImgAccountHSM(@PathVariable String account)
            throws Exception {
        return accountHSMService.deleteImg(account);
    }

}

