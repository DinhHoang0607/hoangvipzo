package vn.gtel.app_mng.account.reponse;

import javax.persistence.Column;

import lombok.Data;

@Data
public class GroupAccountByAccountIdReponse {
	@Column(name = "ID")
	private String id;
	@Column(name = "TEN")
	private String name;
	@Column(name = "ID_NHOM_TAI_KHOAN")
	private String groupAccountId;
}
