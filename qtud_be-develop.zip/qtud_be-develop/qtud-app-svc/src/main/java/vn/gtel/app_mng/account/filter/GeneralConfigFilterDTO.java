package vn.gtel.app_mng.account.filter;

import lombok.Data;
import vn.gtel.app_mng.account.dto.GeneralConfigDTO;
import vn.gtel.app_mng.common.dto.request.PageFilter;

import java.util.List;

@Data
public class GeneralConfigFilterDTO extends PageFilter {
    private List<String> keys;
    public GeneralConfigFilterDTO(Integer page, Integer size) {
        super(page, size);
    }
}
