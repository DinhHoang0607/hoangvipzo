package vn.gtel.app_mng.role.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.role.dto.role_account.RoleAccountDTO;
import vn.gtel.app_mng.role.service.RoleService;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Validated
@Tag(name = "Phân quyền chức năng")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/role/menu")
public class RoleMenuController {
	private static final Logger LOGGER = LogManager.getLogger(RoleMenuController.class);

	@Autowired
	private RoleService roleService;

	@Operation(summary = "Phân quyền tài khoản tài khoản hệ thống")
	@PostMapping(value = "")
	public ResponseBase createRole(
			@RequestBody
			@Valid RoleAccountDTO roleAccountDTO
	) throws Exception{
		return roleService.saveRole(roleAccountDTO);
	}

	@Operation(summary = "Xem chi tiết quyền")
	@GetMapping("/{account}")
	public ResponseBase detail(
			@Valid
			@NotEmpty(message = "error.common.validate.not.empty")
			@Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.size.max.20")
			@PathVariable(name = "account") String account
	) throws Exception {
		return roleService.detail(account, Constants.GROUP_ROLE_TYPE.MENU_ACTION);
	}
}
