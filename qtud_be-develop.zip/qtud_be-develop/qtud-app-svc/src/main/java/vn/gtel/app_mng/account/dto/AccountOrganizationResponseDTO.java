package vn.gtel.app_mng.account.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.account.reponse.AccountDetailResponse;
import vn.gtel.app_mng.account.reponse.AccountResponse;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountOrganizationResponseDTO implements Serializable {
    private String code;
    private String name;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String displayName;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String organizationDependent;
    private String organizationParent;

    private List<AccountResponse> accountResponses;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String organizationDependentName;
    private String organizationParentName;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private AccountOrganizationResponseDTO parent;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<AccountOrganizationResponseDTO> children;

}
