/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleTempServiceDTO.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 12:18 PM
 *  * LastModified  :  12/15/21, 12:18 PM
 *
 */

package vn.gtel.app_mng.role.dto.service;

import javax.persistence.Column;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.role.dto.RoleItemDTO;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonTypeName("service")
public class RoleServiceItemDTO extends RoleItemDTO {

	@NotNull(message = "error.common.validate.not.null")
	@Min(value = Constants.VALID.MIN_VAL_0, message = "error.common.validate.min.value.0")
	@Max(value = Constants.VALID.MAX_VAL_ORDER, message = "error.common.validate.max.value.100000")
	@Column(name = "SO_LUONG_TRUY_CAP")
	private Long accessReqNumber;

	@Size(max = 18, message = "error.common.validate.max.size.18")
	@Size(min = 3, message = "error.common.validate.min.size.3")
	@NotEmpty(message = "error.common.validate.not.empty")
//	@Pattern(regexp = Constants.Regex.NUMBER_CHARACTER,message = "error.common.validate.character.number")
	@Column(name = "DICH_VU")
	private String service;

	@NotEmpty(message = "error.common.validate.not.empty")
	@Column(name = "PHUONG_THUC")
	private String method;

}
