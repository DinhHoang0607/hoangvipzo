/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleTempMenuDTO.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 11:05 AM
 *  * LastModified  :  12/15/21, 10:38 AM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.role.dto.RoleItemDTO;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonTypeName("menuAction")
public class RoleMenuItemDTO extends RoleItemDTO {

    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
//    @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER,message = "error.common.validate.character.number")
    @Column(name = "HANH_DONG")
    private String action;

    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
//    @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER,message = "error.common.validate.character.number")
    @Column(name = "CHUC_NANG")
    private String menu;

//    @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER,message = "error.common.validate.character.number")
    @Column(name = "NHOM_QUYEN")
    private String groupRole;
//    @Column(name = "BOX")
//    private Long box;
//    @Column(name = "CHECKED")
//    private Long check;
}
