//package vn.gtel.app_mng.account.service.Impl;
//
//import com.google.gson.Gson;
//import javassist.NotFoundException;
//import net.sf.jasperreports.engine.JRDataSource;
//import net.sf.jasperreports.engine.JREmptyDataSource;
//import net.sf.jasperreports.engine.JRException;
//import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.modelmapper.ModelMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.springframework.web.multipart.MultipartFile;
//import vn.gtel.app_mng.account.dto.AccountRequestDTO;
//import vn.gtel.app_mng.account.dto.AccountDetailServiceRequestDTO;
//import vn.gtel.app_mng.account.dto.excelObj.AccountServiceExcelItemObj;
//import vn.gtel.app_mng.account.dto.excelObj.AccountServiceExcelObj;
//import vn.gtel.app_mng.account.filter.AccountFilter;
//import vn.gtel.app_mng.account.model.Account;
//import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
//import vn.gtel.app_mng.account.model.AccountUnit;
//import vn.gtel.app_mng.account.reponse.AccountDetailReponse;
//import vn.gtel.app_mng.account.reponse.GroupAccountByAccountIdReponse;
//import vn.gtel.app_mng.account.repository.AccountEmployeeDetailRepository;
//import vn.gtel.app_mng.account.repository.AccountRepository;
//import vn.gtel.app_mng.account.repository.AccountUnitRepository;
//import vn.gtel.app_mng.account.service.AccountDetailService;
//import vn.gtel.app_mng.account.dto.storeObj.AccountCallStoredDTO;
//import vn.gtel.app_mng.account.dto.storeObj.GroupAccountCallStoredDTO;
//import vn.gtel.app_mng.common.config.constant.Constants;
//import vn.gtel.app_mng.common.config.constant.Messages;
//import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
//import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;
//import vn.gtel.app_mng.common.dto.response.DetailResponse;
//import vn.gtel.app_mng.common.dto.response.ListResponse;
//import vn.gtel.app_mng.common.dto.response.ResponseBase;
//import vn.gtel.app_mng.common.model.AuditModel;
//import vn.gtel.app_mng.common.repository.CallStoredRepository;
//import vn.gtel.app_mng.common.service.CommonService;
//import vn.gtel.app_mng.common.service.StatusSettingService;
//import vn.gtel.app_mng.common.util.CommonUtils;
//import vn.gtel.app_mng.common.util.ExcelObjectMapper;
//import vn.gtel.app_mng.common.util.UserLogonUtils;
//import vn.gtel.app_mng.system.dto.request.ActionLogDTO;
//import vn.gtel.app_mng.system.log.LogImportDatabase;
//import vn.gtel.app_mng.system.log.LogUtils;
//import vn.gtel.app_mng.system.model.SystemParam;
//import vn.gtel.app_mng.system.repository.SystemParamRepository;
//import vn.gtel.app_mng.system.service.ActionLogService;
//
//import javax.transaction.Transactional;
//import javax.xml.bind.ValidationException;
//import java.io.ByteArrayOutputStream;
//import java.io.FileNotFoundException;
//import java.text.SimpleDateFormat;
//import java.util.*;
//
//@Service
//@Transactional
//public class AccountDetailServiceImpl implements AccountDetailService {
//
//    private static final Logger LOGGER = LogManager.getLogger(AccountDetailServiceImpl.class);
//
//    @Autowired
//    private AccountEmployeeDetailRepository accountEmployeeDetailRepository;
//
//    @Autowired
//    private AccountRepository accountRepository;
//
//    @Autowired
//    private ModelMapper modelMapper;
//
//    @Autowired
//    private CallStoredRepository callStoredRepository;
//
//    @Autowired
//    private AccountUnitRepository accountUnitRepository;
//
//    @Autowired
//    private StatusSettingService statusSettingService;
//
//    @Autowired
//    private SystemParamRepository systemParamRepository;
//
//    @Autowired
//    private ActionLogService actionLogService;
//
//    @Autowired
//    private LogImportDatabase logImportDatabase;
//
//    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//
//    @Autowired
//    private Gson gson;
//
//    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
//
//    @Override
//    public ResponseBase submitAccount(AccountRequestDTO accountDetailDTO) throws Exception {
//        AccountEmployeeDetail accountEmployeeDetail = new AccountEmployeeDetail();
//        AuditModel auditModel = new Account();
//        statusSettingService.setStatus(auditModel, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                Constants.ACCOUNT_STATUS.ACTIVE);
//        Account account = new Account();
//        AccountUnit accountUnit = new AccountUnit();
//        String oldValue;
//        switch (accountDetailDTO.getTypeAction()) {
//            case Constants.ACCOUNT_ACTION.INSERT:
//                oldValue = null;
//                SystemParam param = systemParamRepository.findByNameAndValue("MAT_KHAU", CommonUtils.longToString(1L));
//                if (param == null) {
//                    throw new ValidationException("Mật khẩu mặc định chưa cấu hình");
//                }
//                Account accountVali = accountRepository.findByAccount(accountDetailDTO.getAccount().getAccount()).orElse(null);
//                if (accountVali != null) {
//                    throw new ValidationException("Tài khoản đã tồn tại");
//                }
//                accountDetailDTO.getAccount().setPassword(param.getDescription());
//                account = modelMapper.map(accountDetailDTO.getAccount(), Account.class);
//                account.setStatus(auditModel.getStatus());
//                account.setStatusId(auditModel.getStatusId());
//                account.setStatusName(auditModel.getStatusName());
//                accountRepository.save(account);
//                accountDetailDTO.getAccount().setId(account.getId());
//                accountDetailDTO.getAccount().getAccountDetail().setAccountId(account.getId());
//                accountEmployeeDetail = modelMapper.map(accountDetailDTO.getAccount().getAccountDetail(), AccountEmployeeDetail.class);
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getDescription())) {
//                    accountEmployeeDetail.setDescription(accountDetailDTO.getAccount().getDescription());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getPhone())) {
//                    accountEmployeeDetail.setPhone(accountDetailDTO.getAccount().getPhone());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getName())) {
//                    accountEmployeeDetail.setFullName(accountDetailDTO.getAccount().getName());
//                }
//                accountEmployeeDetail.setStatus(auditModel.getStatus());
//                accountEmployeeDetail.setStatusId(auditModel.getStatusId());
//                accountEmployeeDetail.setStatusName(auditModel.getStatusName());
//                accountEmployeeDetailRepository.save(accountEmployeeDetail);
//                account.setAccDetailId(accountEmployeeDetail.getId());
//                if (accountDetailDTO.getAccount().getUnitId() != null) {
//                    accountUnit.setAccountDetailId(accountEmployeeDetail.getId());
//                    accountUnit.setAccountId(account.getId());
//                    accountUnit.setUnitId(accountDetailDTO.getAccount().getUnitId());
//                    accountUnit.setStatus(auditModel.getStatus());
//                    accountUnit.setStatusId(auditModel.getStatusId());
//                    accountUnit.setStatusName(auditModel.getStatusName());
//                    accountUnitRepository.save(accountUnit);
//                }
//                accountRepository.save(account);
////			saveAccountGroupAccount(accountDetailDTO, auditModel);
//                break;
//            case Constants.ACCOUNT_ACTION.UPDATE:
//                AccountUnit accountUnitNew = new AccountUnit();
//                account = accountRepository.findById(accountDetailDTO.getAccount().getId()).orElse(null);
//                oldValue = account.toString();
//                accountEmployeeDetail = accountEmployeeDetailRepository.findById(accountDetailDTO.getAccount().getAccountDetail().getId())
//                        .orElse(null);
//                accountUnit = accountUnitRepository
//                        .findByAccountIdAndAccountDetailIdAndStatus(accountDetailDTO.getAccount().getId(),
//                                accountDetailDTO.getAccount().getAccountDetail().getId(), 1L)
//                        .orElse(null);
//                if (account == null && accountEmployeeDetail == null) {
//                    throw new ValidationException(Messages.getString("ResponseError.Account.IsNull"));
//                }
//                if (accountUnit == null) {
//                    if (accountDetailDTO.getAccount().getUnitId() != null) {
//                        accountUnitNew.setAccountDetailId(accountEmployeeDetail.getId());
//                        accountUnitNew.setAccountId(account.getId());
//                        accountUnitNew.setUnitId(accountDetailDTO.getAccount().getUnitId());
//                        accountUnitNew.setStatus(auditModel.getStatus());
//                        accountUnitNew.setStatusId(auditModel.getStatusId());
//                        accountUnitNew.setStatusName(auditModel.getStatusName());
//                        accountUnitRepository.save(accountUnitNew);
//                    }
//                } else {
//                    if (accountDetailDTO.getAccount().getUnitId() != null
//                            && accountUnit.getUnitId() != accountDetailDTO.getAccount().getUnitId()) {
//                        statusSettingService.setStatus(accountUnit, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                                Constants.ACCOUNT_STATUS.INACTIVE);
//                        accountUnitRepository.save(accountUnit);
//                        accountUnitNew.setAccountDetailId(accountEmployeeDetail.getId());
//                        accountUnitNew.setAccountId(account.getId());
//                        accountUnitNew.setUnitId(accountDetailDTO.getAccount().getUnitId());
//                        accountUnitNew.setStatus(auditModel.getStatus());
//                        accountUnitNew.setStatusId(auditModel.getStatusId());
//                        accountUnitNew.setStatusName(auditModel.getStatusName());
//                        accountUnitRepository.save(accountUnitNew);
//                    }
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getDescription())) {
//                    account.setDescription(accountDetailDTO.getAccount().getDescription());
//                    accountEmployeeDetail.setDescription(accountDetailDTO.getAccount().getDescription());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getPhone())) {
//                    account.setPhone(accountDetailDTO.getAccount().getPhone());
//                    accountEmployeeDetail.setPhone(accountDetailDTO.getAccount().getPhone());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getName())) {
//                    accountEmployeeDetail.setFullName(accountDetailDTO.getAccount().getName());
//                    account.setName(accountDetailDTO.getAccount().getName());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getPoliceNumber())) {
//                    accountEmployeeDetail.setPoliceNumber(accountDetailDTO.getAccount().getAccountDetail().getPoliceNumber());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getGender())) {
//                    accountEmployeeDetail.setGender(accountDetailDTO.getAccount().getAccountDetail().getGender());
//                }
//                if (accountDetailDTO.getAccount().getAccountDetail().getGenderId() != null) {
//                    accountEmployeeDetail.setGenderId(accountDetailDTO.getAccount().getAccountDetail().getGenderId());
//                }
//                if (accountDetailDTO.getAccount().getAccountDetail().getPositionId() != null) {
//                    accountEmployeeDetail.setPositionId(accountDetailDTO.getAccount().getAccountDetail().getPositionId());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getPosition())) {
//                    accountEmployeeDetail.setPosition(accountDetailDTO.getAccount().getAccountDetail().getPosition());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getMilitary())) {
//                    accountEmployeeDetail.setMilitary(accountDetailDTO.getAccount().getAccountDetail().getMilitary());
//                }
//                if (accountDetailDTO.getAccount().getAccountDetail().getMilitaryId() != null) {
//                    accountEmployeeDetail.setMarriageId(accountDetailDTO.getAccount().getAccountDetail().getMilitaryId());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getLitigationDignity())) {
//                    accountEmployeeDetail
//                            .setLitigationDignity(accountDetailDTO.getAccount().getAccountDetail().getLitigationDignity());
//                }
//                if (accountDetailDTO.getAccount().getAccountDetail().getLitigationDignityId() != null) {
//                    accountEmployeeDetail.setLitigationDignityId(
//                            accountDetailDTO.getAccount().getAccountDetail().getLitigationDignityId());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getAcademicLevel())) {
//                    accountEmployeeDetail.setAcademicLevel(accountDetailDTO.getAccount().getAccountDetail().getAcademicLevel());
//                }
//                if (accountDetailDTO.getAccount().getAccountDetail().getAcademicLevelId() != null) {
//                    accountEmployeeDetail.setAcademicLevelId(accountDetailDTO.getAccount().getAccountDetail().getAcademicLevelId());
//                }
//                if (!StringUtils.isEmpty(accountDetailDTO.getAccount().getAccountDetail().getPoliticalLevel())) {
//                    accountEmployeeDetail.setPoliticalLevel(accountDetailDTO.getAccount().getAccountDetail().getPoliticalLevel());
//                }
//                if (accountDetailDTO.getAccount().getAccountDetail().getPoliticalLevelId() != null) {
//                    accountEmployeeDetail
//                            .setPoliticalLevelId(accountDetailDTO.getAccount().getAccountDetail().getPoliticalLevelId());
//                }
//                accountEmployeeDetailRepository.save(accountEmployeeDetail);
////			saveAccountGroupAccount(accountDetailDTO, auditModel);
//                break;
//            case Constants.ACCOUNT_ACTION.RESETPASS:
//                account = accountRepository.findById(accountDetailDTO.getAccount().getId()).orElse(null);
//                oldValue = account.toString();
//                if (account == null) {
//                    throw new ValidationException(Messages.getString("ResponseError.Account.IsNull"));
//                }
//                account.setPassword(passwordEncoder.encode(accountDetailDTO.getAccount().getPassword()));
//                accountRepository.save(account);
//                break;
//            default:
//                return new ResponseBase(new DetailResponse(account));
//        }
//
//        String action = accountDetailDTO.getTypeAction();
//        String newValue = account.toString();
//        ActionLogDTO actionLog = new ActionLogDTO(Constants.MODULES.ACCOUNT, action, oldValue, newValue);
//        actionLogService.saveActionLog(actionLog);
//
//        return new ResponseBase(new DetailResponse(account));
//    }
//
//    @Override
//    public ResponseBase actionAccount(String id, String type, String url, String method) {
//        Account account = new Account();
//        Map<String, String> mapInput = new HashMap<>();
//        mapInput.put("id", id.toString());
//        mapInput.put("type", type);
//        try {
//            account = accountRepository.findById(id).orElse(null);
//            if (account == null) {
//                throw new ValidationException(Messages.getString("ResponseError.Account.IsNull"));
//            }
//            String oldValue = gson.toJson(account);
//            switch (type) {
//                case Constants.ACCOUNT_ACTION.DELETE:
//                    statusSettingService.setStatus(account, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                            Constants.ACCOUNT_STATUS.DELETE);
//                    break;
//                case Constants.ACCOUNT_ACTION.ACTIVE:
//                    statusSettingService.setStatus(account, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                            Constants.ACCOUNT_STATUS.ACTIVE);
//                    break;
//                case Constants.ACCOUNT_ACTION.INACTIVE:
//                    statusSettingService.setStatus(account, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                            Constants.ACCOUNT_STATUS.INACTIVE);
//                    break;
//                case Constants.ACCOUNT_ACTION.RESETPASS:
//                    SystemParam param = systemParamRepository.findByNameAndValue("MAT_KHAU", CommonUtils.longToString(1L));
//                    if (param.getId() == null) {
//                        throw new ValidationException("Mật khẩu mặc định chưa cấu hình");
//                    }
//                    account.setPassword(param.getDescription());
//                    break;
//                default:
//                    return new ResponseBase(new DetailResponse(account));
//            }
//            accountRepository.save(account);
//// Ghi du lieu lich su khi save thanh cong
//            logImportDatabase.info("TBL_ACCOUNT", oldValue, newValue);
//        } catch (ValidationException e) {
//            String message = LogUtils.createLogException(Constants.ERROR_CODE.VALIDATION, e.getMessage());
//            log.error(message);
//// Ghi log khi exception API
//            logImportDatabase.info(UserLogonUtils.getUsername(), null, url, method, "505", gson.toJson(mapInput),
//                    null, null);
//            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, e.getMessage());
//        } catch (Exception e) {
//            String message = LogUtils.createLogException(Constants.ERROR_CODE.EXCEPTION, e.getMessage());
//            log.error(message);
//// Ghi log khi exception API
//            logImportDatabase.info(UserLogonUtils.getUsername(), null, url, method, "505", gson.toJson(mapInput),
//                    null, null);
//            return new ResponseBase(Constants.ERROR_CODE.EXCEPTION, e.getMessage());
//        }
//// Ghi log khi ket qua tra ve thanh cong (log API)
//        logImportDatabase.info(UserLogonUtils.getUsername(), null, url, method, "200", gson.toJson(mapInput),
//                gson.toJson(account), null);
//        return new ResponseBase(new DetailResponse(account));
//    }
//
//    @Override
//    public ResponseBase listAccount(AccountFilter textFilter) {
//        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
//        Object res = callStoredRepository.list(callStoredObj);
//        return new ResponseBase(res);
//    }
//
////	/**
////	 * lưu tài khoản với nhóm tài khoản
////	 *
////	 * @param accountDetailDTO
////	 * @param auditModel
////	 */
////	@Transactional
////	public void saveAccountGroupAccount(AccountDetailRquestDTO accountDetailDTO, AuditModel auditModel) {
////		List<AccountGroupAccount> inAccountGroupAccounts = new ArrayList<>();
////		List<Long> delAccountGroupAccounts = new ArrayList<>();
////		if (!CollectionUtils.isEmpty(accountDetailDTO.getInAccountGroupAccount())) {
////			accountDetailDTO.getInAccountGroupAccount().forEach(action -> {
////				AccountGroupAccount accountGroupAccount = new AccountGroupAccount();
////				accountGroupAccount = modelMapper.map(action,
////						AccountGroupAccount.class);
////				accountGroupAccount.setAccountId(accountDetailDTO.getAccount().getId());
////				accountGroupAccount.setStatus(auditModel.getStatus());
////				accountGroupAccount.setStatusId(auditModel.getStatusId());
////				accountGroupAccount.setStatusName(auditModel.getStatusName());
////				inAccountGroupAccounts.add(accountGroupAccount);
////			});
////			accountGroupAccountRepository.saveAll(inAccountGroupAccounts);
////		}
////		if (!CollectionUtils.isEmpty(accountDetailDTO.getDelAccountGroupAccount())) {
////			accountDetailDTO.getDelAccountGroupAccount().forEach(action -> {
////				delAccountGroupAccounts.add(action.getId());
////			});
////			accountGroupAccountRepository.deleteAllById(delAccountGroupAccounts);
////		}
////	}
//
//    @Override
//    public ResponseBase detailAccount(String id) throws Exception {
//        ICallStoredObj callStoredObj = new AccountCallStoredDTO(id);
//        Object response = callStoredRepository.findById(callStoredObj);
//        AccountDetailReponse accountDetailReponse = (AccountDetailReponse) response;
//        ICallStoredObj callStoredList = new GroupAccountCallStoredDTO(id, "DETAIL_ACCOUNT");
//        Object res = callStoredRepository.list(callStoredList);
//        ListResponse listResponse = (ListResponse) res;
//        List<GroupAccountByAccountIdReponse> accountByAccountIdReponse = (List<GroupAccountByAccountIdReponse>) listResponse
//                .getList();
//        accountDetailReponse.setGroupAccount(accountByAccountIdReponse);
//        return new ResponseBase(new DetailResponse(accountDetailReponse));
//    }
//
//    @Override
//    public ResponseBase submitAccount(AccountDetailServiceRequestDTO accountDetailServiceRequestDTO) throws Exception {
//        AccountEmployeeDetail accountEmployeeDetail = null;
//        AuditModel auditModel = new Account();
//        statusSettingService.setStatus(auditModel, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                Constants.ACCOUNT_STATUS.ACTIVE);
//        Account account = new Account();
//        AccountUnit accountUnit = new AccountUnit();
//        PasswordEncoder encoder = new BCryptPasswordEncoder();
//        switch (accountDetailServiceRequestDTO.getAction()) {
//            case Constants.ACCOUNT_ACTION.INSERT:
////                SystemParam param = systemParamRepository.findByNameAndValue("MAT_KHAU", CommonUtils.longToString(1L));
////                if (param == null) {
////                    throw new ValidationException("Mật khẩu mặc định chưa cấu hình");
////                }
//                Account accountVali = accountRepository.findByAccount(accountDetailServiceRequestDTO.getAccount().getAccount()).orElse(null);
//                if (accountVali != null) {
//                    throw new ValidationException("Tài khoản đã tồn tại");
//                }
//
//                account = modelMapper.map(accountDetailServiceRequestDTO.getAccount(), Account.class);
//                account.setStatus(auditModel.getStatus());
//                account.setStatusId(auditModel.getStatusId());
//                account.setStatusName(auditModel.getStatusName());
//                account = accountRepository.save(account);
//                accountEmployeeDetail.setAccountId(account.getId());
//                accountEmployeeDetail.setDescription(new Gson().toJson(accountDetailServiceRequestDTO.getRepresentative()));
//                accountEmployeeDetail.setStatus(auditModel.getStatus());
//                accountEmployeeDetail.setStatusId(auditModel.getStatusId());
//                accountEmployeeDetail.setStatusName(auditModel.getStatusName());
//                accountEmployeeDetailRepository.save(accountEmployeeDetail);
//                account.setAccDetailId(accountEmployeeDetail.getId());
//                if (accountDetailServiceRequestDTO.getAccount().getUnitId() != null) {
//                    accountUnit.setAccountDetailId(accountEmployeeDetail.getId());
//                    accountUnit.setAccountId(account.getId());
//                    accountUnit.setUnitId(accountDetailServiceRequestDTO.getAccount().getUnitId());
//                    accountUnit.setStatus(auditModel.getStatus());
//                    accountUnit.setStatusId(auditModel.getStatusId());
//                    accountUnit.setStatusName(auditModel.getStatusName());
//                    accountUnitRepository.save(accountUnit);
//                }
//                accountRepository.save(account);
//                break;
//            case Constants.ACCOUNT_ACTION.UPDATE:
//                AccountUnit accountUnitNew = new AccountUnit();
//                account = accountRepository.findById(accountDetailServiceRequestDTO.getAccount().getId()).orElse(null);
//                accountEmployeeDetail = accountEmployeeDetailRepository.findById(accountDetailServiceRequestDTO.getAccount().getAccDetailId()).orElse(null);
//                accountUnit = accountUnitRepository.findByAccountIdAndAccountDetailIdAndStatus(accountDetailServiceRequestDTO.getAccount().getId(),
//                                accountDetailServiceRequestDTO.getAccount().getAccDetailId(), 1L).orElse(null);
//                if (account == null && accountEmployeeDetail == null) {
//                    throw new ValidationException(Messages.getString("ResponseError.Account.IsNull"));
//                }
//                if (accountUnit == null) {
//                    if (accountDetailServiceRequestDTO.getAccount().getUnitId() != null) {
//                        accountUnitNew.setAccountDetailId(accountEmployeeDetail.getId());
//                        accountUnitNew.setAccountId(account.getId());
//                        accountUnitNew.setUnitId(accountDetailServiceRequestDTO.getAccount().getUnitId());
//                        accountUnitNew.setStatus(auditModel.getStatus());
//                        accountUnitNew.setStatusId(auditModel.getStatusId());
//                        accountUnitNew.setStatusName(auditModel.getStatusName());
//                        accountUnitRepository.save(accountUnitNew);
//                    }
//                } else {
//                    if (accountDetailServiceRequestDTO.getAccount().getUnitId() != null
//                            && accountUnit.getUnitId() != accountDetailServiceRequestDTO.getAccount().getUnitId()) {
//                        statusSettingService.setStatus(accountUnit, Constants.ACCOUNT_STATUS.GROUP_ACTION,
//                                Constants.ACCOUNT_STATUS.INACTIVE);
//                        accountUnitRepository.save(accountUnit);
//                        accountUnitNew.setAccountDetailId(accountEmployeeDetail.getId());
//                        accountUnitNew.setAccountId(account.getId());
//                        accountUnitNew.setUnitId(accountDetailServiceRequestDTO.getAccount().getUnitId());
//                        accountUnitNew.setStatus(auditModel.getStatus());
//                        accountUnitNew.setStatusId(auditModel.getStatusId());
//                        accountUnitNew.setStatusName(auditModel.getStatusName());
//                        accountUnitRepository.save(accountUnitNew);
//                    }
//                }
//                accountEmployeeDetailRepository.save(accountEmployeeDetail);
//                break;
//            case Constants.ACCOUNT_ACTION.RESETPASS:
//                account = accountRepository.findById(accountDetailServiceRequestDTO.getAccount().getId()).orElse(null);
//                if (account == null) {
//                    throw new ValidationException(Messages.getString("ResponseError.Account.IsNull"));
//                }
//                account.setPassword(encoder.encode(accountDetailServiceRequestDTO.getAccount().getPassword()));
//                accountRepository.save(account);
//                break;
//            default:
//                return new ResponseBase(new DetailResponse(account));
//        }
//
//        return new ResponseBase(new DetailResponse(account));
//    }
//
//    @Override
//    public ResponseBase detailAccountService(String id) throws Exception {
//        Account account = accountRepository.findById(id).orElse(null);
//        if (account == null) {
//            throw new NotFoundException("Khong tim thay tai khoan id = " + id);
//        }
//
//        AccountDetailServiceRequestDTO responseDTO = new AccountDetailServiceRequestDTO();
//        responseDTO.setAccount(modelMapper.map(account, AccountDetailServiceRequestDTO.AccountServiceDTO.class));
//
//        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccountId(id);
//        responseDTO.setExtraDataJson(accountEmployeeDetail.getDescription());
//
//        return new ResponseBase(new DetailResponse(responseDTO));
//    }
//
//    @Override
//    public ResponseEntity export(String type) throws FileNotFoundException, JRException {
//        JRDataSource dataSource = new JREmptyDataSource();
//
//        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
//        String templatePath = "Tai_khoan_tich_hop.jasper";
//        String fileName = "Tai_khoan_tich_hop";
//        String mimeType = "."+type.toLowerCase();
//        Map<String, Object> reportParams = new HashMap<>();
//
//        AccountFilter textFilter = new AccountFilter(0, 999999999, null, null,null);
//        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
//        Object res = callStoredRepository.list(callStoredObj);
//        List<AccountDetailReponse> lstResults = (List<AccountDetailReponse>) ((ListResponse) res).getList();
//        // insert empty into 0 index
//        lstResults.add(0,new AccountDetailReponse());
//        dataSource = new JRBeanCollectionDataSource(lstResults);
//        reportParams.put("dataSource", dataSource);
//
//        oStream = CommonService.generateReport(dataSource,templatePath, reportParams, type.toLowerCase());
//        return CommonUtils.downloadFileJasper(oStream,fileName+"_"+sdf.format(new Date())+mimeType);
//    }
//
//    @Override
//    public ResponseBase importExcel(MultipartFile file) throws Exception {
//        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
//        IExcelMapperObj iExcelMapperObj = new AccountServiceExcelObj();
//        List<AccountServiceExcelItemObj> lst = excelObjectMapper.map(AccountServiceExcelItemObj.class, 0 , iExcelMapperObj);
//        return new ResponseBase(insertImport(lst));
//    }
//
//    private List<Account> insertImport(List<AccountServiceExcelItemObj> lst) throws Exception {
//        List<Account> insertAccount = new ArrayList<>();
//        AuditModel auditModel = (AuditModel) statusSettingService.setStatus(new Account(), Constants.ACCOUNT_STATUS.GROUP_ACTION,Constants.ACCOUNT_STATUS.ACTIVE);
//        lst.stream().forEach(iAccount->{
//            Account existAccount = accountRepository.findByAccount(iAccount.getAccount()).orElse(null);
//            if (existAccount != null) {
//                try {
//                    throw new ValidationException("Tài khoản đã tồn tại");
//                } catch (ValidationException e) {
//                    e.printStackTrace();
//                }
//            }
//            Account account = modelMapper.map(iAccount, Account.class);
//            account.setStatus(auditModel.getStatus());
//            account.setStatusId(auditModel.getStatusId());
//            account.setStatusName(auditModel.getStatusName());
//            account.setPassword(passwordEncoder.encode(account.getPassword()));
//            account = accountRepository.save(account);
//            AccountEmployeeDetail accountEmployeeDetail = new AccountEmployeeDetail();
//            accountEmployeeDetail.setAccountId(account.getId());
////            accountDetail.setDescription(new Gson().toJson(accountDetailServiceRequestDTO.getRepresentative()));
//            accountEmployeeDetail.setStatus(auditModel.getStatus());
//            accountEmployeeDetail.setStatusId(auditModel.getStatusId());
//            accountEmployeeDetail.setStatusName(auditModel.getStatusName());
//            accountEmployeeDetailRepository.save(accountEmployeeDetail);
//            account.setAccDetailId(accountEmployeeDetail.getId());
//            if (iAccount.getUnitId() != null) {
//                AccountUnit accountUnit = new AccountUnit();
//                accountUnit.setAccountDetailId(accountEmployeeDetail.getId());
//                accountUnit.setAccountId(account.getId());
//                accountUnit.setUnitId(iAccount.getUnitId());
//                accountUnit.setStatus(auditModel.getStatus());
//                accountUnit.setStatusId(auditModel.getStatusId());
//                accountUnit.setStatusName(auditModel.getStatusName());
//                accountUnitRepository.save(accountUnit);
//            }
//            insertAccount.add(account);
//        });
//        return accountRepository.saveAll(insertAccount);
//    }
//
//}
