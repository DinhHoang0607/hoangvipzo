/*
 *  ResponseBase.java
 *  Copyright (c) 2021.
 *  Modification Logs:
 *  DATE                AUTHOR             DESCRIPTION
 *  8/10/21, 8:45 AM    TuanNP             File is created
 *
 */

package vn.gtel.app_mng.common.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.gtel.app_mng.common.config.constant.Messages;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class ResponseBase implements Serializable {

  private static final long serialVersionUID = 2537552770157631523L;
  private String messageCode = Messages.getString("response.message.success.code");
  private String message = Messages.getString("response.message.success");
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Long totalRecords = null;
//  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private Object data;// = CommonMessages.getString("response.message.success");

  public ResponseBase(Object data) {
    this.data = data;
  }

  public ResponseBase(String messageCode, String message, Object data, Long totalRecords) {
    this.messageCode = messageCode;
    this.message = message;
    this.totalRecords = totalRecords;
    this.data = data;
  }

  public ResponseBase(String messageCode, String message, Object data) {
    this.messageCode = messageCode;
    this.message = message;
    this.data = data;
  }

  public ResponseBase(String messageCode, String message) {
    this.messageCode = messageCode;
    String prefix = Messages.getString("response.message.error."+messageCode) + ": ";
    this.message = prefix+message;
  }

//  public ResponseBase() {
//    this.data = "OK";
//  }
}
