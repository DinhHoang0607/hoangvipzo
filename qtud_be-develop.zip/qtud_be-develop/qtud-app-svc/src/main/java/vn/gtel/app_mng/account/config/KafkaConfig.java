//package vn.gtel.app_mng.account.config;
//
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.producer.ProducerConfig;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.apache.kafka.common.serialization.StringSerializer;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
//import org.springframework.kafka.core.*;
//import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
//import org.springframework.kafka.support.serializer.JsonDeserializer;
//import org.springframework.kafka.support.serializer.JsonSerializer;
//import vn.gtel.common.config.KafkaMessageErrorHandler;
//import vn.gtel.app_mng.account.dto.request.OrganizationTransferByGroupReq;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Configuration
//public class KafkaConfig {
//
//    @Value("${spring.kafka.bootstrap-servers}")
//    private String bootstrapServer;
//
//    @Bean
//    public ProducerFactory<String, OrganizationTransferByGroupReq> transferProducerFactory() {
//        HashMap<String, Object> conMap = new HashMap<>();
//        conMap.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
//        conMap.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
//        conMap.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
//        return new DefaultKafkaProducerFactory<>(conMap);
//    }
//
//    @Bean
//    public KafkaTemplate<String, OrganizationTransferByGroupReq> transferKafkaTemplate() {
//        return new KafkaTemplate<>(transferProducerFactory());
//    }
//
//    @Bean
//    public ConsumerFactory<String, Object> transferConsumerFactory() {
//        Map<String, Object> conMap = new HashMap<>();
//        conMap.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
//        conMap.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//        conMap.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
//        conMap.put(JsonDeserializer.TYPE_MAPPINGS, "OrganizationTransferByGroupReq:vn.gtel.app_mng.account.dto.request.OrganizationTransferByGroupReq");
//        conMap.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, JsonDeserializer.class);
//        conMap.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
//        conMap.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//        return new DefaultKafkaConsumerFactory<>(conMap);
//    }
//
//    @Bean
//    public ConcurrentKafkaListenerContainerFactory<String, Object> transferContainerFactory() {
//        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
//        factory.setConsumerFactory(transferConsumerFactory());
//        factory.setCommonErrorHandler(new KafkaMessageErrorHandler());
//        return factory;
//    }
//
//}
