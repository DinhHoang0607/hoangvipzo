/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleTempDatabaseDTO.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 11:15 AM
 *  * LastModified  :  12/9/21, 1:28 PM
 *
 */

package vn.gtel.app_mng.role.dto.field;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleTempFieldDTO {
	
	@Column(name = "XEM")
	private Long view;
	
	@Column(name = "TAO_MOI")
	private Long add;
	
	@Column(name = "SUA")
	private Long update;
	
	@Column(name = "XOA")
	private Long delete;
	
	@Column(name = "ID_COT_DU_LIEU")
	private String fieldId;
}
