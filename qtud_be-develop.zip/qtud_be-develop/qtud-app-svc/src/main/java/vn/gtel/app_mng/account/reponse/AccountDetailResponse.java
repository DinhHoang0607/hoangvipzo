package vn.gtel.app_mng.account.reponse;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.account.dto.AccountDetailOrgDTO;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;
import vn.gtel.app_mng.account.dto.FieldManageDTO;
import vn.gtel.app_mng.account.dto.OrganizationManageDTO;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountDetailResponse {

    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "CCCD")
    private String citizenID;

    @Basic
    @Column(name = "HO_TEN")
    private String fullName;

    @Basic
    @Column(name = "NGAY_SINH")
    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    private Instant birthDate;

    @Basic
    @Column(name = "DIA_CHI")
    private String address;

    @Basic
    @Column(name = "TRINH_DO_HOC_VAN")
    private String academicLevel;

    @Basic
    @Column(name = "CHUC_VU")
    private String position;

    @Basic
    @Column(name = "TEN_CHUC_VU")
    private String positionName;

    @Basic
    @Column(name = "MA_PHAN_LOAI")
    private String positionType;

    @Basic
    @Column(name = "TEN_PHAN_LOAI")
    private String positionTypeName;

    @Basic
    @Column(name = "CHUC_DANH")
    private String dignity;

    @Basic
    @Column(name = "TRINH_DO_CHINH_TRI")
    private String politicalLevel;

    @Basic
    @Column(name = "SO_HIEU_CAND")
    private String policeNumber;

    @Basic
    @Column(name = "CAP_BAC")
    private String military;
    @Basic
    @Column(name = "TEN_CAP_BAC")
    private String militaryName;

    @Basic
    @Column(name = "DIEN_THOAI")
    private String phone;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

    @Basic
    @Column(name = "TEN_DON_VI")
    private String organizationName;

    @Basic
    @Column(name = "MA_DON_VI_CHA")
    private String organizationParent;

    @Basic
    @Column(name = "TEN_DON_VI_CHA")
    private String organizationParentName;

    @Basic
    @Column(name = "CAP_DON_VI")
    private String organizationLevel;

    @Basic
    @Column(name = "MA_CAP_DON_VI")
    private String organizationLevelCode;

    @Basic
    @Column(name = "GIOI_TINH")
    private String gender;

    @Basic
    @Column(name = "TEN_GIOI_TINH")
    private String genderName;

    @Basic
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "KY_HIEU")
    private String sign;

    @Basic
    @Column(name = "CHU_KY")
    private String signature;

    @Basic
    @Column(name = "ANH_KY_SO")
    private String pictureDigitalSign;

    private byte[] signImg;

    @Column(name = "DIA_PHUONG")
    private Integer isLocal;

    @Column(name = "MA_TINH")
    private String provinceCode;

    @Column(name = "TINH")
    private String province;

    @Column(name = "BDS_T")
    private String bds_province;

    @Column(name = "MA_HUYEN")
    private String districtCode;

    @Column(name = "HUYEN")
    private String district;

    @Column(name = "BDS_H")
    private String bds_district;

    @Column(name = "MA_XA")
    private String villageCode;

    @Column(name = "XA")
    private String village;

    @Column(name = "BDS_X")
    private String bds_village;

    @Column(name = "PHAN_LOAI")
    private Integer leaderCadres;

    @Column(name = "PHAN_LOAI_TAI_KHOAN")
    private Integer accountType;

    @Column(name = "CBQL_TRUC_TIEP")
    private String directManager;

    @Column(name = "ORGFB")
    private Integer orgFb;

    @Column(name = "ma_nhom_quyen")
    private String groupCode;

    @Column(name = "ten_viet_tat")
    private String nameAcronym;

    @Column(name = "ten_viet_tat_cha")
    private String nameAcronymD;

    @Column(name = "ngay_sua")
    private String updateAt;

    private List<AccountOrgResponse> orgsHistories;
    private List<AccountDetailOrgDTO> listAccountDetailOrgTop;
    private List<AccountDetailOrg> listAccountDetailOrgBottom;
    private List<OrganizationManageDTO> listOrganizationManage;
    private List<FieldManageDTO> listFieldManage;
    private String timeOut;

    private Integer roleMap;

    @Column(name = "MAT_KHAU_BAN_DAU")
    private String passwordStart;

    @Column(name = "THOI_GIAN_THONG_BAO_DOI_MAT_KHAU")
    private Instant expiredNotificationDate;

    @Column(name = "THOI_HAN_MAT_KHAU")
    private Instant expirationDate;

    @Column(name = "XAC_NHAN_THONG_TIN")
    private Long statusConfirmInfo;

    @Column(name = "LY_DO")
    private String reasonRefuse;

    @Column(name = "THUOC_CQDT")
    private Integer investigativeAgencyType;

    private List<CodeItemWithActionDTO> groups;

    @Column(name = "DON_VI_TRUC_THUOC")
    private String organizationDependent;

    @Column(name = "TEN_DON_VI_TRUC_THUOC")
    private String organizationDependentName;

    @Basic
    @Column(name = "MA_DON_VI_MOI")
    private String newOrganizationCode;
}
