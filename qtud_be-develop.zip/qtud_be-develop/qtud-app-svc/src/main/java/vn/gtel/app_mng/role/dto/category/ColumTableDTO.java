 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 16, 2021
 */
package vn.gtel.app_mng.role.dto.category;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ColumTableDTO {
	
	@Column(name = "ma_ung_dung")
	private String appCode;
	
	@Column(name = "app_name")
	private String appName;
	
	@Column(name = "ma_bang")
	private String tableCode;
	
	@Column(name = "table_name")
	private String tableName;
	
	@Column(name = "colum_id")
	private String fieldId;
	
	@Column(name = "ma_cot")
	private String columnCode;
	
	@Column(name = "colum_name")
	private String columnName;
	

}
