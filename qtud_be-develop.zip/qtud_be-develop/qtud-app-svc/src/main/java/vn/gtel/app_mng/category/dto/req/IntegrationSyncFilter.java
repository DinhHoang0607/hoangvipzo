package vn.gtel.app_mng.category.dto.req;

import lombok.Getter;
import lombok.Setter;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
public class IntegrationSyncFilter extends TextFilter {
    private String application;
    private String organization;
    private String organizationName;
    private Integer status;
    private Instant fromDate;
    private Instant toDate;
    private List<String> notCodeList;
    private List<String> inCodeList;
    private Integer applicationType;
    private Integer organizationType;

    public IntegrationSyncFilter(Integer page, Integer size, String keySearch, String application, String organization, String organizationName, Integer status) {
        super(page, size, keySearch);
        this.application = application;
        this.organization = organization;
        this.organizationName = organizationName;
        this.status = status;
    }

    public IntegrationSyncFilter(Integer page, Integer size, String keySearch, String application, String organization, String organizationName, Integer status, Integer applicationType, Integer organizationType, Instant fromDate, Instant toDate) {
        super(page, size, keySearch);
        this.application = application;
        this.organization = organization;
        this.organizationName = organizationName;
        this.status = status;
        this.applicationType = applicationType;
        this.organizationType = organizationType;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public IntegrationSyncFilter(int page, int size, String keySearch, String application, String organization, String organizationName, Integer status, List<String> notCodeList) {
        super(page, size, keySearch);
        this.application = application;
        this.organization = organization;
        this.organizationName = organizationName;
        this.status = status;
        this.notCodeList = notCodeList;
    }

    public IntegrationSyncFilter(int page, int size, String keySearch, String application, String organization, String organizationName, Integer status, List<String> notCodeList, List<String> inCodeList) {
        super(page, size, keySearch);
        this.application = application;
        this.organization = organization;
        this.organizationName = organizationName;
        this.status = status;
        this.notCodeList = notCodeList;
        this.inCodeList = inCodeList;
    }

    public IntegrationSyncFilter(int page, int size, String keySearch, String application, String organization,
                                 String organizationName, Integer status, List<String> notCodeList,
                                 List<String> inCodeList, Integer applicationType, Integer organizationType, Instant fromDate, Instant toDate) {
        super(page, size, keySearch);
        this.application = application;
        this.organization = organization;
        this.organizationName = organizationName;
        this.status = status;
        this.notCodeList = notCodeList;
        this.inCodeList = inCodeList;
        this.applicationType = applicationType;
        this.organizationType = organizationType;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public IntegrationSyncFilter(int page, int size, String keySearch, String application, String organization, String organizationName, Integer status, List<String> notCodeList, List<String> inCodeList, Instant fromDate, Instant toDate) {
        super(page, size, keySearch);
        this.application = application;
        this.organization = organization;
        this.organizationName = organizationName;
        this.status = status;
        this.notCodeList = notCodeList;
        this.inCodeList = inCodeList;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }
}
