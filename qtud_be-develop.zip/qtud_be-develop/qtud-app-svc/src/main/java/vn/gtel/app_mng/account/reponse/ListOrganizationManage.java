package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.util.List;

@Data
public class ListOrganizationManage {
    private List<OrganizationManage> organizationManages;
}
