package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountChangeOrgDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 20, message = "error.common.validate.max.size.50")
    private String account;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 18, message = "error.common.validate.max.size.18")
    private String organization;
}
