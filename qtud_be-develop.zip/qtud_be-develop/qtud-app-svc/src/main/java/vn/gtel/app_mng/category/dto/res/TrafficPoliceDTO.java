package vn.gtel.app_mng.category.dto.res;

import lombok.Data;
import vn.gtel.app_mng.account.reponse.AccountResponse;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

@Data
public class TrafficPoliceDTO {
    private String code;
    private String name;
    private String organizationDependent;
    private List<AccountResponse> accountResponses;
    private String organizationParent;
    private String displayName;
    private String displayParentName;
    private String displayDependentName;

    public TrafficPoliceDTO(LinkedHashMap<String, String> map) {
        this.code = map.get("code");
        this.name = map.get("name");
        this.organizationDependent = map.get("organizationDependent");
        this.organizationParent = map.get("organizationParent");
        this.displayName = map.get("displayName");
        this.displayParentName = map.get("displayParentName");
        this.displayDependentName = map.get("displayDependentName");
        this.accountResponses = new ArrayList<>();
    }
}
