/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleMenuFilter.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 2:48 PM
 *  * LastModified  :  12/15/21, 2:48 PM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.PageFilter;

@Data
public class RoleMenuByAppFilter extends PageFilter {

    private String application;
    private String roleGroupCode;

    public RoleMenuByAppFilter(Integer page, Integer size, String application,String roleGroupCode ) {
        super(page, size);
        this.application = application;
        this.roleGroupCode = roleGroupCode;
    }
}
