package vn.gtel.app_mng.account.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;
import vn.gtel.app_mng.common.model.AuditModelBase;

@Entity
@Table(name = "TBL_TK_NHOM_QUYEN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountGroupRole extends AuditModelBase {
	/**
	 * 
	 */
	private static final Long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

	@Basic
	@Column(name = "NHOM_QUYEN")
	private String groupRole;

	@Basic
	@Column(name = "TAI_KHOAN")
	private String account;

	public AccountGroupRole(String groupRole, String account, Integer status) {
		super(status);
		this.groupRole = groupRole;
		this.account = account;
	}


}
