package vn.gtel.app_mng.common.dto;

import lombok.Data;
import lombok.experimental.FieldNameConstants;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Data
@FieldNameConstants
public class AuditBaseDTO implements Serializable {

    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
    private String id;

    private @NotNull(message = "error.common.validate.not.null")
    @Max(value = Constants.VALID.MAX_VAL_STATUS, message = "error.common.validate.max.value.20")
    Integer status;

}
