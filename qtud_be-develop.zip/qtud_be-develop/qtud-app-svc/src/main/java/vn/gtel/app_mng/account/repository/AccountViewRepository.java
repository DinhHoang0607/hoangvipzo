package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import vn.gtel.app_mng.account.model.AccountView;

import java.util.List;


public interface AccountViewRepository extends JpaRepository<AccountView, String> {

    @Query(value = "select a from AccountView a where a.organization in (:orgs) and a.status = 1 order by a.organization, a.fullName asc ")
    List<AccountView> findByListOrg(List<String> orgs);

}
