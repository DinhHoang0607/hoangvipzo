package vn.gtel.app_mng.account.dto;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountOrganizationDTO {
	@Column(name = "ID")
	private String accountId;
	@Column(name = "TEN")
	private String accountName;
	@Column(name = "TAI_KHOAN")
	private String username;
	@Column(name = "ID_DON_VI")
	private String organizationId;
	@Column(name = "DON_VI")
	private String organizationCode;
	@Column(name = "TEN_DON_VI")
	private String organizationName;
	@Column(name = "TEN_CHUC_VU")
	private String positionName;
	@Column(name = "CHUC_VU")
	private String positionCode;
	@Column(name = "TEN_CAP_BAC")
	private String militaryName;
	@Column(name = "MA_CAP_BAC")
	private String militaryCode;
}
