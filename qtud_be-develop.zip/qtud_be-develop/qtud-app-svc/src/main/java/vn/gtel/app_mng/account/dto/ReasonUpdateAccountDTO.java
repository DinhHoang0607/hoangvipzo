package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ReasonUpdateAccountDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 36, message = "error.common.validate.max.size.36")
    private String id;
    @Size(max = 200, message = "error.common.validate.max.size.200")
    private String reason;
    @Size(max = 200, message = "error.common.validate.max.size.18")
    private String reasonCode;
}
