package vn.gtel.app_mng.feedback.service;

import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.feedback.dto.*;

import javax.xml.bind.ValidationException;

public interface FeedbackService {

    ResponseBase search();

    ResponseBase save(FeedBackDTO feedBackDTO) throws Exception;

    public void deleteAction(String id) throws ValidationException;

    ResponseBase getOneFeedBack(String id) throws Exception;

    Object list(FeedBackTextFilter FeedBackTextFilter) throws IllegalAccessException;

    ResponseBase removeFeedBack(RemoveFeedBackDTO removeFeedBackDTO) throws Exception;

    ResponseBase reply(ReplyDTO replyDTO) throws Exception;

    ResponseBase closeFeedBack(RemoveFeedBackDTO removeFeedBackDTO) throws ValidationException;

    ResponseBase reprocess(IdeaDTO relyDTO) throws Exception;

    ResponseBase list(String idFeedBack, int page, int size, Integer status) throws IllegalAccessException;

    ResponseBase received(String id) throws Exception;
}
