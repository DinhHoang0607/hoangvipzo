package vn.gtel.app_mng.account.dto.request;

import lombok.Data;

@Data
public class TransferCheckNvcbProfileRequest {
    private String taiKhoan;
    private String maChucVu;
}
