/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 7, 2021
 */
package vn.gtel.app_mng.category.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.req.AppTextFilter;
import vn.gtel.app_mng.category.dto.req.MenuReq;
import vn.gtel.app_mng.category.service.MenuActionService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.CommonService;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.io.IOException;

@Validated
@Tag(name = "Quản lý chức năng")
@RestController
@CrossOrigin("*")
@RequestMapping(Constants.MenuAction.URL)
public class MenuActionController {

    @Autowired
    private MenuActionService menuActioneServiceImpl;

    @Operation(summary = "Tạo mới chức năng")
    @PostMapping(value = "")
    public ResponseBase create(@RequestBody @Valid MenuReq req) throws Exception {
        return new ResponseBase(menuActioneServiceImpl.create(req));
    }

    @Operation(summary = "Sửa chức năng")
    @PutMapping(value = "")
    public ResponseBase update(@RequestBody @Valid MenuReq req) throws Exception {
        return new ResponseBase(menuActioneServiceImpl.update(req));
    }

    @Operation(summary = "Danh sách chức năng")
    @GetMapping(value = "/list")
    public ResponseBase getList(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
                                @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "keySearch", required = false) String keySearch,
                                @Valid @Size(max = 18, message = "error.common.validate.max.size.18")
                                @Size(min = 3, message = "error.common.validate.min.size.3")
                                @Pattern(regexp = Constants.Regex.CATEGORY_CODE, message = "error.common.validate.only.number") @RequestParam(name = "app") String app,
                                @Valid @Size(max = 24, message = "error.common.validate.max.size.24")
                                @Size(min = 3, message = "error.common.validate.min.size.3")
                                @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character") @RequestParam(name = "menu", required = false) String menuCode,
                                @Valid @Size(max = 100, message = "error.common.validate.max.size.100")
                                @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "name", required = false) String name,
                                @Valid @Size(max = 24, message = "error.common.validate.max.size.24")
                                @Size(min = 3, message = "error.common.validate.min.size.3")
                                @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character") @RequestParam(name = "parentMenuCode", required = false) String parentMenuCode,
                                @Valid @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2") @RequestParam(name = "status", required = false) String status,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page" , required = false) Integer page,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size",required = false) Integer size) throws Exception {
        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.MAX_ROW_SELECT;
        }

        AppTextFilter appTextFilter = new AppTextFilter(page, size, keySearch, app, menuCode, name, parentMenuCode, String.valueOf(Constants.MENU_GROUP_STATUS.ACTIVE));
        return new ResponseBase(menuActioneServiceImpl.list(appTextFilter));
    }

    @Operation(summary = "Danh sách tìm kiếm chức năng")
    @GetMapping(value = "")
    public ResponseBase search(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
                                @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "keySearch", required = false) String keySearch,
                                @Valid @Size(max = 18, message = "error.common.validate.max.size.18")
                                @Size(min = 3, message = "error.common.validate.min.size.3")
                                @Pattern(regexp = Constants.Regex.CATEGORY_CODE, message = "error.common.validate.only.number") @RequestParam(name = "app") String app,
                                @Valid @Size(max = 24, message = "error.common.validate.max.size.24")
                                @Size(min = 3, message = "error.common.validate.min.size.3")
                                @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character") @RequestParam(name = "menuCode", required = false) String menuCode,
                                @Valid @Size(max = 100, message = "error.common.validate.max.size.100")
                                @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "name", required = false) String name,
                                @Valid @Size(max = 24, message = "error.common.validate.max.size.24")
                                @Size(min = 3, message = "error.common.validate.min.size.3")
                                @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER, message = "error.common.validate.not.special-character") @RequestParam(name = "parentMenuCode", required = false) String parentMenuCode,
                                @Valid @Size(max = Constants.VALID.MAX_LENGTH_SEARCH_STATUS, message = "error.common.validate.max.size.2") @RequestParam(name = "status", required = false) String status,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws Exception {
        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.DEFAULT_SIZE;
        }

        AppTextFilter appTextFilter = new AppTextFilter(page, size, keySearch, app, menuCode, name, parentMenuCode, status);
        return new ResponseBase(menuActioneServiceImpl.list(appTextFilter));
    }

    @Operation(summary = "Chi tiết chức năng")
    @GetMapping(value = "/{id}")
    public ResponseBase detailAction(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                         @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")@PathVariable String id) throws Exception {
        return new ResponseBase(menuActioneServiceImpl.detail(id));
    }


    @Operation(summary = "Xóa chức năng")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                   @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return new ResponseBase(menuActioneServiceImpl.changeStatus(id));
    }

    @Operation(summary = "Tải template import chức năng ")
    @GetMapping(value = "/template")
    public ResponseEntity template() throws Exception {
//        return CommonService.downloadTemplate("IMPORT_CHUC_NANG_TEMPLATE.xlsx", "template_import_chuc_nang.xlsx");
        return menuActioneServiceImpl.createTemplate();
    }
    //	@Operation(summary = "Danh sách chức năng hành động")
//	@GetMapping(value="action-list")
//	public ResponseBase getListMenuAction(@RequestParam(name = "keySearch", required = false) String keySearch,
//								@RequestParam(name = "appId") Long appId,
//					            @RequestParam(name = "page") Optional<Integer> page,
//					            @RequestParam(name = "size") Optional<Integer> size) throws Exception {
//		int pageNumber = page.orElse(0);
//        int sizeNumber = size.orElse(10);
//        AppTextFilter appTextFilter = new AppTextFilter(pageNumber, sizeNumber, keySearch, appId);
//		return new ResponseBase(menuActioneServiceImpl.listMenuAction(appTextFilter));
//	}
    @Operation(summary = "Import chức năng")
    @PostMapping(value = "/import")
    public ResponseEntity importTemplate(MultipartFile file) throws Exception {
        return menuActioneServiceImpl.importExcelReturnResult(file);
    }

    @Operation(summary = "Kích hoạt/ hủy kích hoạt")
    @PutMapping(value = "/{id}")
    public ResponseBase setActiveDeActive( @Valid @NotEmpty(message = "error.common.validate.not.empty")
                                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return menuActioneServiceImpl.setActiveDeActive(id);
    }

    @Operation(summary = "import chức năng trả kết quả ")
    @PostMapping(value = "/import-return-result")
    public ResponseEntity importReturnResult(MultipartFile file) throws Exception {
        return  menuActioneServiceImpl.importExcelReturnResult(file);
    }
}
