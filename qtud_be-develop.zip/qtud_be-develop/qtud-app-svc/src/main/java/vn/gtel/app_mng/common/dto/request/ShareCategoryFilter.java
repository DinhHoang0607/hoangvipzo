/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  TextFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/6/21, 2:10 PM
 */

package vn.gtel.app_mng.common.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ShareCategoryFilter extends PageFilter {
    private String code;
    private String keySearch;
    private String parentCode;
    private String type;

    public ShareCategoryFilter(Integer page, Integer size, String code, String parentCode, String keySearch, String type) {
        super(page, size);
        this.code = code;
        this.keySearch = keySearch;
        this.parentCode = parentCode;
        this.type = type;
    }
}
