/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  PageFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/4/21, 9:26 AM
 */

package vn.gtel.app_mng.common.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Valid
public class PageFilter {
    private Integer page;
    private Integer size;
}
