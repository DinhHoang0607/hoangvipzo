package vn.gtel.app_mng.common.config.constant;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum StatusEnum {
    ACTIVE(Constants.COMMON_STATUS.ACTIVE, "Hoạt động"),
    INACTIVE(Constants.COMMON_STATUS.INACTIVE, "Vô hiệu hóa"),
    DELETED(Constants.COMMON_STATUS.DELETED, "Đã xóa"),
    ;

    private final int code;
    private final String name;

    public static StatusEnum parseByCode(Integer code) {
        if (code == null) {
            return null;
        }
        for (StatusEnum value : StatusEnum.values()) {
            if (value.code == code) {
                return value;
            }
        }
        return null;
    }

    @JsonValue
    public String getName() {
        return name;
    }
}
