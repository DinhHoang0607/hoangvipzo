/*
 * Copyright (c) 2021.
 * Project  :  sso
 * File  :  CustomAccessDeniedHandler.java
 * Created By :  tuannp
 * Created at :  12/21/21, 11:15 AM
 * LastModified  :  12/21/21, 11:15 AM
 */

package vn.gtel.app_mng.common.exception;

import org.modelmapper.ModelMapper;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import vn.gtel.app_mng.common.dto.response.ResponseBase;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomAccessDeniedHandler implements AccessDeniedHandler {
    @Override
    public void handle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AccessDeniedException e) throws IOException, ServletException {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.map(httpServletResponse.getOutputStream(), new ResponseBase());
    }
}
