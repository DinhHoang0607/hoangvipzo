package vn.gtel.app_mng.account.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

@Data
public class AccountGroupRoleExcelItemObj extends IExcelItem {

    private String account;
    private String groupRole;
}
