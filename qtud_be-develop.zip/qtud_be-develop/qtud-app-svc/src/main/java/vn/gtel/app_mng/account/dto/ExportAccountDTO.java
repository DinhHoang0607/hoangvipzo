package vn.gtel.app_mng.account.dto;

import lombok.*;
import vn.gtel.app_mng.role.reponse.GroupRoleResponse;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ExportAccountDTO {

    private String fullName;

    private String policeNumber;

    private String orgName;

    private String account;

    private String passwordStart;

    private List<ExportRoleAccountDTO> exportRoleAccountDTOS;


}
