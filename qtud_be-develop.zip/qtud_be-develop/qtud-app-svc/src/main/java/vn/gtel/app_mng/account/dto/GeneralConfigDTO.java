package vn.gtel.app_mng.account.dto;

import lombok.*;
import vn.gtel.app_mng.account.model.GeneralConfig;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GeneralConfigDTO {

    private String id;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 100, message = "error.common.validate.max.size.100")
    private String key;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 100, message = "error.common.validate.max.size.100")
    private String value;

    public GeneralConfigDTO(GeneralConfig c) {
        this.id = c.getId();
        this.value = c.getValue();
        this.key = c.getKey();
    }
}
