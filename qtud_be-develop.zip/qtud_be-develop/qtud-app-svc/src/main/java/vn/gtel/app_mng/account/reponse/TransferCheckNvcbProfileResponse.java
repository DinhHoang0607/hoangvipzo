package vn.gtel.app_mng.account.reponse;

import lombok.Data;
import vn.gtel.app_mng.account.dto.TransferCheckNvcbProfileDetailDTO;

@Data
public class TransferCheckNvcbProfileResponse {
    private String code;
    private String message;
    private String status;
    private TransferCheckNvcbProfileDetailDTO data;
}
