package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import java.util.List;

@Data
public class ListAccountDetailOrg {
    private List<AccountDetailOrg> accountDetailOrgs;
}
