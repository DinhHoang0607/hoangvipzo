package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountBasicInfoDTO {
    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

    @Basic
    @Column(name = "CHUC_VU")
    private String position;

    @Basic
    @Column(name = "CAP_BAC")
    private String military;

    @Basic
    @Column(name = "CHUC_DANH")
    private String dignity;
}
