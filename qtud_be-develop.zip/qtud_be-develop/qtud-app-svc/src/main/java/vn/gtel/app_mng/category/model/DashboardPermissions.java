package vn.gtel.app_mng.category.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TBL_PHAN_QUYEN_TRANG_CHU")
@NoArgsConstructor
@AllArgsConstructor
public class DashboardPermissions extends AuditModelBase {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "THAO_TAC")
    private String action;
}
