package vn.gtel.app_mng.feedback.dto;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class ReplyDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    private String idFeedBack;
    @Size(max = Constants.VALID.MAX_LENGTH_1000, message = "error.common.validate.max.size.500")
    @NotEmpty(message = "error.common.validate.not.empty")
    private String comment;

    private List<FileFeedBackDTO> files;
}
