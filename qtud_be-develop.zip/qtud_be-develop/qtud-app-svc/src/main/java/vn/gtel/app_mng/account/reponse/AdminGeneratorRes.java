package vn.gtel.app_mng.account.reponse;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AdminGeneratorRes {
    private Object total;
    private String password;
}
