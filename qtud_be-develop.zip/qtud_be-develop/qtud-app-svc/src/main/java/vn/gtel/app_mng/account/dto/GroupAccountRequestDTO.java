package vn.gtel.app_mng.account.dto;

import java.util.List;

import lombok.Data;

@Data
public class GroupAccountRequestDTO {
	private AccountGroupDTO groupAccount;
	private List<GroupAccountGroupRoleCodeDTO> InAccountGroupRole;
	private List<GroupAccountGroupRoleCodeDTO> DelAccountGroupRole;
}
