package vn.gtel.app_mng.account.dto;

import lombok.Data;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.common.util.StringUtils;
import vn.gtel.app_mng.account.reponse.GeneralConfigResponseDTO;
import vn.gtel.app_mng.common.config.constant.Constants;

import java.util.List;

@Data
public class PasswordRuleDTO {
    private String key;
    private String text;
    private String description;
    private String filter;

    public PasswordRuleDTO(GeneralConfigResponseDTO config) {
        this.text = config.getText();
        this.key = config.getKey();
        this.description = StringUtils.isNotEmpty(config.getDescription()) ? String.format(config.getDescription(), config.getValue()) : null;
        String subFilter = getFilterByConfigKey(config.getKey(), config.getValue(), config.getDatatypes(), true);
        this.filter = subFilter.length() > 0 ? String.format("^%s$", subFilter) : null;
    }

    public PasswordRuleDTO(List<GeneralConfigResponseDTO> configs) {
        this.text = "Password Regex Filter";
        this.description = "";
        String subFilter = "";
        for (GeneralConfigResponseDTO config : configs) {
            subFilter += Integer.valueOf(config.getStatus()).equals(Constants.STATUS_CATEGORY_ACTIVE) ? getFilterByConfigKey(config.getKey(), config.getValue(), config.getDatatypes(),false) : "";
        }
        this.filter = subFilter.length() > 0 ? String.format("^%s$", subFilter) : null;
    }

    private String getFilterByConfigKey(String configKey, String configValue, String datatypes, Boolean singleFilter) {
        String subFilter;
        String conditionalFilter = singleFilter ? "(.*)" : "";
        switch (configKey) {
            case "security.password.lower_case":
                subFilter = String.format("(?=([^a-z]*[a-z]){%s,})%s", configValue, conditionalFilter);
                break;
            case "security.password.upper_case":
                subFilter = String.format("(?=([^A-Z]*[A-Z]){%s,})%s", configValue, conditionalFilter);
                break;
            case "security.password.special":
                subFilter = String.format("(?=([^`~!@#$%%^*|{}<>]*[`~!@#$%%^*|{}<>]){%s,})%s", configValue, conditionalFilter);
                break;
            case "security.password.number":
                subFilter = String.format("(?=([^0-9]*[0-9]){%s,})%s", configValue, conditionalFilter);
                break;
            case "security.password.exclude_username":
                String account = AccountLogonContext.getUsername();
                subFilter = String.format("((?!.*%s.*).*)", account);
                break;
            case "security.password.min_length":
                subFilter = String.format("(.{%s,})", configValue);
                break;
            default:
                subFilter = "";
        }
        switch (datatypes.toUpperCase()) {
            case Constants.GENERAL_CONFIG_DATATYPES.BOOLEAN:
                if (!Boolean.parseBoolean(configValue)) subFilter = "";
                break;
            case Constants.GENERAL_CONFIG_DATATYPES.NUMBER:
                if (Integer.valueOf(configValue).equals(0)) subFilter = "";
                break;
            default:
                if (StringUtils.isEmpty(configValue)) subFilter = "";
        }
        return subFilter;
    }
}
