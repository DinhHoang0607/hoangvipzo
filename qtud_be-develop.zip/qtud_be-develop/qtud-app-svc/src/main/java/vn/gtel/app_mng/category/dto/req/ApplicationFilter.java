package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ApplicationFilter extends TypeFilter {
    private Integer status;

    public ApplicationFilter(Integer page, Integer size, String keySearch, Integer type, Integer status) {
        super(page, size, keySearch, type);
        this.status = status;
    }
}
