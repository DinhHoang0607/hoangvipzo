package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.DashboardPermissions;

import java.util.List;

@Repository
public interface DashboardPermissionsRepo extends JpaRepository<DashboardPermissions, String> {
    List<DashboardPermissions> getAllByAccount(String account);
}
