package vn.gtel.app_mng.common.dto.i;

import lombok.Data;

import java.util.List;

@Data
public class IExcelItem {

    public int row;

}
