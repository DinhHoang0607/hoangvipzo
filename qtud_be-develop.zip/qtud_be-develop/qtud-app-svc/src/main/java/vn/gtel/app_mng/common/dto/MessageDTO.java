/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  MessageDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  1/26/22, 2:27 PM
 *
 */

package vn.gtel.app_mng.common.dto;

import lombok.Data;

@Data
public class MessageDTO {
    private String from;
    private String to;
    private String content;
}
