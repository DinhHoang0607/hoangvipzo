package vn.gtel.app_mng.account.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.dto.functionObj.AccountCallFuncDTO;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallFuncObj;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.util.CommonUtils;

@Service
@AllArgsConstructor
public class AccountCommonService {

    private final CallStoredRepository callStoredRepository;

    public boolean isAdmin(String id, String account) {
        ICallFuncObj callFuncObj = new AccountCallFuncDTO(id, account);
        String checkAdmin = callStoredRepository.getString(callFuncObj);
        return CommonUtils.equalsEnum(Constants.KEY_CHECK.ADMIN, checkAdmin);
    }

    public boolean isAdminV06(String id, String account) {
        ICallFuncObj callFuncObj = new AccountCallFuncDTO(id, account);
        ((AccountCallFuncDTO) callFuncObj).checkAdminV06();
        String checkAdmin = callStoredRepository.getString(callFuncObj);
        return CommonUtils.equalsEnum(Constants.KEY_CHECK.ADMIN_V06, checkAdmin);
    }

}
