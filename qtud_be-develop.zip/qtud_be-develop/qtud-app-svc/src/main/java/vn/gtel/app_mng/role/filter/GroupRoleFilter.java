package vn.gtel.app_mng.role.filter;

import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
@NoArgsConstructor
public class GroupRoleFilter extends TextFilter {
    private int type;
    private Integer status;
    private String app;

    public GroupRoleFilter(Integer page, Integer size, String keySearch, int type, Integer status, String app) {
        super(page, size, keySearch);
        this.type = type;
        this.status = status;
        this.app = app;
    }
}
