/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  ChangePWRequestDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/3/22, 11:37 AM
 *
 */

package vn.gtel.app_mng.account.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
public class ChangePWRequestDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String oldPassword;
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String newPassword;
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String newPasswordAgain;
}
