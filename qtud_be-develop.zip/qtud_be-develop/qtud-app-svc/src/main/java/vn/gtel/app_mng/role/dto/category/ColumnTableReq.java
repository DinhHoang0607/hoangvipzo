 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 16, 2021
 */
package vn.gtel.app_mng.role.dto.category;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ColumnTableReq {
	
	private String appId;
	
	private List<String> lstTableId ;

}
