 /**
 * @author tronglm
 * app-mng
 * Dec 6, 2021
 */
package vn.gtel.app_mng.category.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.category.dto.res.ActionNameIdRes;
import vn.gtel.app_mng.category.model.Action;

@Repository
public interface ActionCatRepo extends JpaRepository<Action, String> {
	
	Optional<Action> findByName(String name);
/*
	@Query("select new vn.gtel.app_mng.category.dto.res.ActionNameIdRes(a.id, a.name) from Action a where a.status = :status")
	List<ActionNameIdRes> findAllActionByStatus(@Param("status") Long status);*/
	
/*
	@Query("select new vn.gtel.app_mng.category.dto.res.ActionNameIdRes(hd.id, hd.name) from Action hd join MenuAction nb on hd.id = nb.actionId " +
							" join Menu td on td.id = nb.menuId " +
							"  where td.appId = :appId  ")
	List<ActionNameIdRes> findAllActionApp(@Param("appId") String appId);
*/

	Action findByCodeAndName(String code , String name);

	Optional<Action> findByCode(String code);

	List<Action> findByStatusOrderByCodeAsc(Integer status);


}
