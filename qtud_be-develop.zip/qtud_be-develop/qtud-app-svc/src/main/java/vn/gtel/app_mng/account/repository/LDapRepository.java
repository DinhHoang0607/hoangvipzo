//package vn.gtel.app_mng.account.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import vn.gtel.app_mng.account.model.LDap;
//
//@Repository
//public interface LDapRepository extends JpaRepository<LDap, String>{
//
//}
