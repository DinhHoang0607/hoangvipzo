package vn.gtel.app_mng.category.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

@Entity
@Table(name = "TBL_DM_HANH_DONG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Action extends AuditCategoryModel{

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;


/*    @Column(name = "PHUONG_THUC")
    private String method;*/

}
