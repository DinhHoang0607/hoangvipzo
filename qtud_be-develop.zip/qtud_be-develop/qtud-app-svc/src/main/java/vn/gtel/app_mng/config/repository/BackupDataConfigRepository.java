package vn.gtel.app_mng.config.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.config.model.BackupDataConfig;

@Repository
public interface BackupDataConfigRepository extends JpaRepository<BackupDataConfig, String> {

    BackupDataConfig findByType(String type);

}
