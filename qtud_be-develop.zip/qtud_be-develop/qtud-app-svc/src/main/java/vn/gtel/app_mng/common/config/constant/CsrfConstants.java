package vn.gtel.app_mng.common.config.constant;

public interface CsrfConstants {
    String CSRF_TOKEN = "730579f5-f1e9-44e5-80f3-8de666077843";
    String CSRF_FIELD_HEADER = "csrf";
    String CSRF_FIELD_PARAM = "_csrf";
}
