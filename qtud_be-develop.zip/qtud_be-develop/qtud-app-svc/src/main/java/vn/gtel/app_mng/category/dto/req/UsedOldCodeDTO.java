package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.validation.constraints.*;

@Data
public class UsedOldCodeDTO  {


    private String codeSecurity;

    private String codePolice;

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String englishName;

    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 2, message = "error.common.validate.min.size.2")
    @NotEmpty(message = "error.common.validate.not.empty")
    @Pattern(regexp = Constants.Regex.NUMBER_CHARACTER,message = "error.common.validate.only.number")
    private String code;

    @NotNull(message = "error.common.validate.not.null")
    @Max(value = Constants.VALID.MAX_VAL_ORDER, message = "error.common.validate.max.value.100000")
    private Long order;

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String description;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String name;

    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
    private String id;

    @NotNull(message = "error.common.validate.not.null")
    @Max(value = Constants.VALID.MAX_VAL_STATUS, message = "error.common.validate.max.value.20")
    private Long status;

}
