package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.model.AccountSecurity;

import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public interface AccountSecurityRepository extends JpaRepository<AccountSecurity, String> {
    Optional<AccountSecurity> findByAccount(String account);

    @Transactional
    @Modifying
    @Query(value = "update tbl_tk_tai_khoan u set u.yc_doi_mk = 1,u.ngay_sua = current_timestamp where u.tai_khoan in :accounts", nativeQuery = true)
    void updateChangeStatusPw(@Param("accounts") List<String> accounts);

    @Transactional
    @Modifying
    @Query(value = "select a.tai_khoan from tbl_tk_bao_mat a where a.thoi_han_mat_khau < current_timestamp and trang_thai = 1", nativeQuery = true)
    List<String> getListAccountWithExpiredPW();

    @Transactional
    @Modifying
    @Query(value = "select a.tai_khoan from tbl_tk_bao_mat a where a.thoi_gian_thong_bao_doi_mat_khau < current_timestamp and trang_thai = 1", nativeQuery = true)
    List<String> getListAccountWithNotiExpiredPW();

    @Transactional
    void deleteByAccount(String account);
}
