
/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  CallRestAPIService.java
 *  * Created By :  tuannp
 *  * Created at :  12/13/21, 9:13 AM
 *  * LastModified  :  12/13/21, 9:07 AM
 *
 */

package vn.gtel.app_mng.common.service;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import vn.gtel.app_mng.account.dto.AccountChangeOrgDTO;
import vn.gtel.app_mng.account.dto.AccountChangeOrgResponseDTO;
import vn.gtel.app_mng.account.dto.request.AccountTransferReq;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.servlet.http.Cookie;
import java.util.Map;

public interface CallRestAPIService {

    ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap,
                                String body, String authorizationString, AccountEmployeeDetail accountEmployeeDetail, int actionType);


    ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap,
                                String body, String authorizationString, Map<String, String> params);

    ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap,
                                String body, String username, String password, String authorizationString);

    ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Cookie[] cookies);

    ResponseEntity<ResponseBase> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, String body);

    ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap,
                                String body, String username, String password);


    ResponseEntity<String> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap,
                                String body, String authorizationString);

    ResponseEntity<AccountChangeOrgResponseDTO> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, AccountChangeOrgDTO accountChangeOrgDTO, String authorizationString, String appName) throws Exception;

    ResponseEntity<AccountChangeOrgResponseDTO> call(String restUrl, HttpMethod httpMethod, Map<String, String> headerMap, AccountTransferReq request, String authorizationString, String appName) throws Exception;


}