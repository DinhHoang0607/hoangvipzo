/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleMenuFilter.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 2:48 PM
 *  * LastModified  :  12/15/21, 2:48 PM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.PageFilter;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
public class RoleMenuFilter extends TextFilter {

    private String groupRoleId;

    public RoleMenuFilter(Integer page, Integer size, String keySearch, String groupRoleId) {
        super(page, size, keySearch);
        this.groupRoleId = groupRoleId;
    }
}
