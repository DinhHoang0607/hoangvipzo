/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleMenuDTO.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 11:15 AM
 *  * LastModified  :  12/9/21, 1:28 PM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleMenuDTO {
	@Column(name = "TEN")
	private String name;
	@Column(name = "MA")
	private String menu;
	@Column(name = "CHUC_NANG_CHA")
	private String parentMenu;
	@Column(name = "TEN_CHUC_NANG_CHA")
	private String parentMenuName;
}
