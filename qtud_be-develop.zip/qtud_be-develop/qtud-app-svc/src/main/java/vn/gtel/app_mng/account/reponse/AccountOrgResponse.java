package vn.gtel.app_mng.account.reponse;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import vn.gtel.app_mng.account.model.AccountOrganization;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.time.Instant;
import java.util.List;

@Data
public class AccountOrgResponse {
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "SO_QUYET_DINH")
    private String decisionNumber;

    @Basic
    @Column(name = "NGAY_CHUYEN")
    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    private Instant createdDate;

    @Basic
    @Column(name = "DON_VI_CU")
    private String oldOrg;

    @Basic
    @Column(name = "DON_VI_MOI")
    private String newOrg;
}
