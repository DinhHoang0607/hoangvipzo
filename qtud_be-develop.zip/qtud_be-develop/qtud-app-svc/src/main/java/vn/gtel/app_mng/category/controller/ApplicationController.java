package vn.gtel.app_mng.category.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.req.ApplicationFilter;
import vn.gtel.app_mng.category.dto.req.ApplicationRequestCodeDTO;
import vn.gtel.app_mng.category.dto.req.ChangeSecretReqDTO;
import vn.gtel.app_mng.category.dto.req.TypeFilter;
import vn.gtel.app_mng.category.service.ApplicationService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.CommonService;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.io.IOException;

@Validated
@Tag(name = "Quản lý phần mềm")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/application")
@AllArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;

    @Operation(summary = "Danh sách phần mềm")
    @GetMapping(value = "/list")
    public ResponseBase list(@Valid @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters") @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250") @RequestParam(name = "keySearch", required = false) String keySearch,
                             @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                             @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page", required = false) Integer page,
                             @Valid @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
                             @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size", required = false) Integer size,
                             @RequestParam(name = "type", required = false) Integer type) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.MAX_ROW_SELECT : size;
        TypeFilter textFilter = new TypeFilter(pageNumber, sizeNumber, keySearch, type);
        return applicationService.list(textFilter, Constants.APPLICATION_STATUS.ACTIVE);
    }

    @Operation(summary = "Tìm kiếm danh sách phần mềm")
    @GetMapping(value = "")
    public ResponseBase search(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "status", required = false) Integer status,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "type", required = false) Integer type) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        TypeFilter textFilter = new TypeFilter(pageNumber, sizeNumber, keySearch, type);
        return applicationService.list(textFilter, status);
    }

    @Operation(summary = "Chi tiết phần mềm")
    @GetMapping(value = "/{id}")
    public ResponseBase detail(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return applicationService.detail(id);
    }

    @Operation(summary = "Thêm mới phần mềm")
    @PostMapping(value = "")
    public ResponseBase create(@RequestBody @Valid ApplicationRequestCodeDTO applicationRequestDTO) throws Exception {
        return applicationService.save(applicationRequestDTO);
    }

    @Operation(summary = "Cập nhật phần mềm")
    @PutMapping(value = "")
    public ResponseBase update(@RequestBody @Valid ApplicationRequestCodeDTO applicationRequestDTO) throws Exception {
        return applicationService.save(applicationRequestDTO);
    }

    @Operation(summary = "Xóa phần mềm")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return applicationService.delete(id);
    }

    @Operation(summary = "Tải template import phần mềm")
    @GetMapping(value = "/template")
    public ResponseEntity template() throws IOException {
        return CommonService.downloadTemplate("IMPORT_UNG_DUNG_TEMPLATE.xlsx", "template_import_ung_dung.xlsx");
    }

    @Operation(summary = "Import phần mềm")
    @PostMapping(value = "/import")
    public ResponseEntity importTemplate(@RequestParam("file") MultipartFile file) throws Exception {
        return applicationService.importExcel(file);
    }

    @Operation(summary = "Kích hoạt/ hủy kích hoạt")
    @PutMapping(value = "/{id}")
    public ResponseBase setActiveDeActive(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                          @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return applicationService.setActiveDeActive(id);
    }

    @Operation(summary = "Đổi Client Secret")
    @PutMapping(value = "/change-cs")
    public ResponseBase changePw(@RequestBody @Valid ChangeSecretReqDTO changePWRequestDTO) throws Exception {
        return applicationService.changeCs(changePWRequestDTO);
    }

    @Operation(summary = "Tìm kiếm danh sách phần mềm không theo tài khoản")
    @GetMapping(value = "/search-not-by-account")
    public ResponseBase searchNotByAccount(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "status", required = false) Integer status,
            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,
            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "type", required = false) Integer type) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        ApplicationFilter filter = new ApplicationFilter(pageNumber, sizeNumber, keySearch, type, status);
        return applicationService.list(filter);
    }
}
