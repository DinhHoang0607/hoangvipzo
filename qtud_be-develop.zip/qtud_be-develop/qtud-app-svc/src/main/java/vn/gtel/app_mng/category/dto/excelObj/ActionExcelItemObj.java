package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

@Data
@NoArgsConstructor
public class ActionExcelItemObj extends IExcelItem {
    private String code;
    private String name;
    private String pooledCode;
    private String description;
    private Long order;

    public ActionExcelItemObj(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public ActionExcelItemObj(String code, String name, String pooledCode) {
        this.code = code;
        this.name = name;
        this.pooledCode = pooledCode;
    }
}
