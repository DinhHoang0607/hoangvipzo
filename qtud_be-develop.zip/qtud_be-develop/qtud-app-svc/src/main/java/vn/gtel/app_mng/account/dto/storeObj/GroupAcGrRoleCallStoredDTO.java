package vn.gtel.app_mng.account.dto.storeObj;

import java.util.HashMap;
import java.util.Map;

import vn.gtel.app_mng.account.reponse.GroupAccountByAccountIdReponse;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;

public class GroupAcGrRoleCallStoredDTO extends ICallStoredObj{
	private static final String PACKAGE_NAME = "PKG_GROUP_ACCOUNT";
    private static final String PROC_SEARCH_FIND = "PROC_FIND_GROUP_ACCOUNT_ROLE";
    private static final String IN_PI_ID = "PI_ID";
    Map<String, Object> params = new HashMap<>();
    private void setBase(){
        setPackageName(PACKAGE_NAME);
        setResponseType(GroupAccountByAccountIdReponse.class);
    };
    
    public GroupAcGrRoleCallStoredDTO(String id) {
    	setBase();
        setStoredName(PROC_SEARCH_FIND);
        params.put(IN_PI_ID, id);
        setParams(params);
}
}
