 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 17, 2021
 */
package vn.gtel.app_mng.role.filter;

import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.PageFilter;

@Data
@NoArgsConstructor
public class ServiceFilter extends PageFilter{

	private String organization;
	private String groupService;

    public ServiceFilter(Integer page, Integer size, String organization, String groupService) {
        super(page, size);
        this.organization = organization;
        this.groupService = groupService;
    }
}
