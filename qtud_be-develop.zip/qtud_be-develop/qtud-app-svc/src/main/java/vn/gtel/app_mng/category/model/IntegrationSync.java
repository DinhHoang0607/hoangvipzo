package vn.gtel.app_mng.category.model;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;
import javax.validation.constraints.Future;

@Getter
@Setter
@Entity
@FieldNameConstants
@Table(name = "TBL_DV_TICH_HOP_DONG_BO")
public class IntegrationSync extends AuditModelBase {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @ManyToOne
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name = "DON_VI", referencedColumnName = "MA", insertable = false, updatable = false)
    private Organization org;

    @Column(name = "DON_VI")
    private String orgCode;

    @Column(name = "TEN_DON_VI")
    private String orgName;

    @ManyToOne
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name = "UNG_DUNG", referencedColumnName = "MA", insertable = false, updatable = false)
    private Application app;

    @Formula(value = "(select ud.ten from TBL_DM_UNG_DUNG ud where ud.ma = UNG_DUNG )")
    private String appName;

    @Column(name = "UNG_DUNG")
    private String appCode;

    @Column(name = "MUC_DICH")
    private String purpose;

    @Column(name = "MO_TA")
    private String description;

    @Column(name = "HO_TEN_LH")
    private String relationName;

    @ManyToOne
    @JoinColumn(name = "CHUC_VU_LH", referencedColumnName = "MA", insertable = false, updatable = false)
    private Position relationPosition;

    @Column(name = "CHUC_VU_LH")
    private String relationPositionCode;

    @Column(name = "SO_HIEU_CAND_LH")
    private String relationPoliceNumber;

    @Column(name = "DIEN_THOAI_LH")
    private String relationPhone;

    @ManyToOne
    @JoinColumn(name = "CAP_BAC_LH", referencedColumnName = "MA", insertable = false, updatable = false)
    private Rank relationMilitary;

    @Column(name = "CAP_BAC_LH")
    private String relationMilitaryCode;

    @Column(name = "GHI_CHU_LD")
    private String relationDescription;

    @Column(name = "HO_TEN_DD")
    private String representativeName;

    @ManyToOne
    @JoinColumn(name = "CHUC_VU_DD", referencedColumnName = "MA", insertable = false, updatable = false)
    private Position representativePosition;

    @Column(name = "CHUC_VU_DD")
    private String representativePositionCode;

    @Column(name = "SO_HIEU_CAND_DD")
    private String representativePoliceNumber;

    @Column(name = "DIEN_THOAI_DD")
    private String representativePhone;

    @ManyToOne
    @JoinColumn(name = "CAP_BAC_DD", referencedColumnName = "MA", insertable = false, updatable = false)
    private Rank representativeMilitary;

    @Column(name = "CAP_BAC_DD")
    private String representativeMilitaryCode;

    @Column(name = "GHI_CHU_DD")
    private String representativeDescription;

//    @Column(name = "TRANG_THAI")
//    private Integer status;
//
//    @PreUpdate
//    @PrePersist
//    public void prePersist() {
//        if (this.status == null) {
//            this.status = 1;
//        }
//    }
}
