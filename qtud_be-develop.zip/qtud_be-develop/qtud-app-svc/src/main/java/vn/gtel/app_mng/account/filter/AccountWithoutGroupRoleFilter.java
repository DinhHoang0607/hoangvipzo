/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/23/22, 4:23 PM
 *
 */

package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountWithoutGroupRoleFilter extends TextFilter {

    private int type;
    private String position;
    private String org;
    private List<String> notAcc;
    private String employee;
//    private String unitLevel;
    private String codeUnit;

//    public AccountWithoutGroupRoleFilter(Integer page, Integer size, String keySearch, int type) {
//        super(page, size, keySearch);
//        this.type = type;
//    }

    public AccountWithoutGroupRoleFilter(Integer page, Integer size, String keySearch, int type,String position,String org,List<String> notAcc) {
        super(page, size, keySearch);
        this.type = type;
        this.position=position;
        this.org = org;
        this.notAcc = notAcc;
    }
}
