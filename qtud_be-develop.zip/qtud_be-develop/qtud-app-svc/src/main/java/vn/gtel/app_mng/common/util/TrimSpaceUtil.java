package vn.gtel.app_mng.common.util;

import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class TrimSpaceUtil {

    public void validate(Object target) throws IllegalAccessException {
        List<Field> fileds = new ArrayList<>();
        Class clazz = target.getClass();
        while(clazz != Object.class){
            fileds.addAll(Arrays.asList(clazz.getDeclaredFields()));
            clazz = clazz.getSuperclass();
        }
        for (Field item : fileds) {
            if(item.getType().equals(String.class) ){
                ReflectionUtils.makeAccessible(item);
                String value = (String)item.get(target);
                if(value != null){
                    value = value.trim();
                    item.set(target,value);
                }
            }
        }

    }
}
