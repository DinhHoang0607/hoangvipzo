 /**
 * @author tronglm
 * app-mng
 * Dec 6, 2021
 */
package vn.gtel.app_mng.category.service;

import java.io.IOException;
import java.sql.SQLException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.ActionCodeDTO;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;


 public interface ActionService {
	
	public String createAction(ActionCodeDTO req) throws Exception;
	
	public String updateAction(ActionCodeDTO req) throws Exception;
	
	public void deleteAction(String id) throws Exception;
	
	public Object listAction(TextFilter textFilter, Integer status) throws SQLException, IllegalAccessException;
	
	public Object detailAction(String id) throws Exception;

	 ResponseEntity importExcel(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;

	 ResponseBase setActiveDeActive(String id) throws Exception;

	 ResponseEntity importExcelReturnResult(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception;


}
