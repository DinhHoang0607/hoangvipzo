package vn.gtel.app_mng.category.dto.res;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsbTokenHisResponseDTO {


    @Column(name = "TAI_KHOAN")
    private String account;

    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    @Column(name = "NGAY_KET_THUC")
    private Instant endDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    @Column(name = "NGAY_BAT_DAU")
    private Instant startDate;

    @Column(name = "MA")
    private String code;

    @Column(name = "HO_VA_TEN")
    private String fullName;

    @Column(name = "TEN_DON_VI")
    private String organizationName;
}
