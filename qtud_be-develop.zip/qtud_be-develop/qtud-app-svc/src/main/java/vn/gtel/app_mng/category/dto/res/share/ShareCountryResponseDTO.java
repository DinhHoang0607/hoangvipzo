/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  ShareCountryResponseDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/28/22, 9:22 AM
 *
 */

package vn.gtel.app_mng.category.dto.res.share;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShareCountryResponseDTO {

//    @Column(name = "ID")
//    private String id;

    @Column(name = "MA")
    private String code;

    @Column(name = "MO_TA")
    private String description;

    @Basic
    @Column(name = "MA_ISO")
    private String codeISO;

    @Basic
    @Column(name = "MA_VUNG_DIEN_THOAI")
    private String codeAreaPhone;

    @Basic
    @Column(name = "MA_BUU_CHINH")
    private String codeTelecomunication;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "NGAY_THANH_LAP")
    private Date establish;

    @Basic
    @Column(name = "MA_QUOC_GIA")
    private String codeCountry;

}
