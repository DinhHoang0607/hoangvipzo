 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.category.dto.res;

import java.util.List;

import lombok.Data;

@Data
public class MenuActionDetailRes {
	
	private MenuActionRes menuActionRes;
	
	//private List<ActionNameIdRes> lstActionAll;

}
