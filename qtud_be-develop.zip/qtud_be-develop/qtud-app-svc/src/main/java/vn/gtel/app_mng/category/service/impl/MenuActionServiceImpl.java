/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 7, 2021
 */
package vn.gtel.app_mng.category.service.impl;

import com.google.gson.Gson;
import javassist.NotFoundException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.category.dto.excelObj.*;
import vn.gtel.app_mng.category.dto.req.AppTextFilter;
import vn.gtel.app_mng.category.dto.req.MenuActionDTO;
import vn.gtel.app_mng.category.dto.req.MenuReq;
import vn.gtel.app_mng.category.dto.res.ActionNameIdRes;
import vn.gtel.app_mng.category.dto.res.MenuActionDetailRes;
import vn.gtel.app_mng.category.dto.res.MenuActionRes;
import vn.gtel.app_mng.category.dto.storedObj.MenuActionCallStoredDTO;
import vn.gtel.app_mng.category.model.Action;
import vn.gtel.app_mng.category.model.Application;
import vn.gtel.app_mng.category.model.Menu;
import vn.gtel.app_mng.category.model.MenuAction;
import vn.gtel.app_mng.category.repo.*;
import vn.gtel.app_mng.category.service.MenuActionService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.i.IExcelItem;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;
import vn.gtel.app_mng.common.dto.response.PermissionForLogDTO;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CommonService;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.ExcelObjectMapper;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.role.model.GroupRoleApplication;
import vn.gtel.app_mng.role.service.RoleService;
//import vn.gtel.app_mng.system.model.File;
import vn.gtel.app_mng.system.repository.FileRepository;
import vn.gtel.common.constants.ActionCode;
import vn.gtel.common.dto.LogActionDTO;
import vn.gtel.common.service.LoggingService;
import vn.gtel.common.util.LogUtil;

import javax.xml.bind.ValidationException;
import java.io.IOException;
import java.security.InvalidParameterException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class MenuActionServiceImpl implements MenuActionService {
    @Autowired
    private RoleService roleService;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private MenuCatRepo menuCatRepo;
    @Autowired
    private MenuActionRepo menuActionRepo;
    @Autowired
    private FileRepository fileRepository;
    @Autowired
    private CallStoredRepository callStoredRepository;
    @Autowired
    private ApplicationRepo applicationRepo;
    @Autowired
    private ActionCatRepo actionCatRepo;
    @Autowired
    private TrimSpaceUtil trimSpaceUtil;
    @Autowired
    private OrganizationRepo organizationRepo;
    @Autowired
    private ServiceRepo serviceRepo;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private LoggingService loggingService;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");

    private static final String PREFIX_ERR_CONSTRAINT_MESSAGE = "ConstraintViolationException.";

    @Override
    @Transactional
    public String create(MenuReq req) throws Exception {
        trimSpaceUtil.validate(req);

        Menu menu = mapper.map(req, Menu.class);
        Integer status = 1;
        if (req.getStatus() != null) {
            status = req.getStatus();
        }
        menu.setStatus(status);
        saveIcon(req);
        menuCatRepo.save(menu);
        String menuCode = menu.getCode();
        String menuId = menu.getId();
        if (!req.getListAction().isEmpty()) {
            for (MenuActionDTO element : req.getListAction()) {
                MenuAction menuAction = mapper.map(element, MenuAction.class);
                menuAction.setMenu(menuCode);
                menuAction.setStatus(Constants.MENU_GROUP_STATUS.ACTIVE);
                //menuAction.setEndPoint(req.getEndPoint()+element.getEndPoint());
                menuActionRepo.save(menuAction);
            }
        }

        Application application = applicationRepo.findByCode(req.getAppCode());
        String appName = null;
        String content = null;
        if (application != null && application.getName() != null) {
            appName = application.getName();
        }

        if (appName != null) {
            content = String.format("Trong phần mềm có mã là %s và tên là %s đã thêm mới chức năng có tên là %s và mã là %s", application.getCode(), appName, menu.getName(), menu.getCode());
        } else {
            content = String.format("Đã thêm mới chức năng có tên là %s và mã là %s", menu.getName(), menu.getCode());
        }

        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.menu, ActionCode.ADD, content, Instant.now()));
        return menuId;
    }

    @Override
    @Transactional
    public String update(MenuReq req) throws Exception {
        updatePermissionForLogToRedis(req);
        trimSpaceUtil.validate(req);
        int flag = 0;
        if (req.getId() == null) {
            throw new InvalidParameterException("Đầu vào không hợp lệ!");
        }

        Application application = applicationRepo.findByCode(req.getAppCode());
        String appName = null;
        String content = null;
        if (application != null && application.getName() != null) {
            appName = application.getName();
        }

        Menu menu = menuCatRepo.findById(req.getId()).orElse(null);

        if (appName != null) {
            content = String.format("Trong phần mềm có mã là %s và tên là %s đã sửa chức năng có mã là %s ,", application.getCode(), appName, menu.getCode());
        } else {
            content = String.format("Đã sửa chức năng có mã là %s ,", menu.getCode());
        }
        String logMess = this.getDetailMenu(content, req, menu);

        mapper.getConfiguration().setSkipNullEnabled(true);
        mapper.map(req, menu);
        saveIcon(req);
        menuCatRepo.saveAndFlush(menu);
        List<MenuAction> currentMenuActions = new ArrayList<>();
        List<MenuAction> menuActions = new ArrayList<>();
        List<MenuAction> listMenuAction = menuActionRepo.findByMenu(menu.getCode());
        if (CollectionUtils.isNotEmpty(listMenuAction)) {
            for (MenuAction menuaction : listMenuAction) {
                menuaction.setStatus(Constants.MENU_GROUP_STATUS.INACTIVE);
                menuActions.add(menuaction);
            }
        }
        menuActionRepo.saveAll(menuActions);
        if (CollectionUtils.isNotEmpty(req.getListAction())) {
            req.getListAction().stream().forEach(menuActionDTO -> {
                if (StringUtils.isEmpty(menuActionDTO.getId())) {
                    MenuAction menuAction = menuActionRepo.findByCode(menuActionDTO.getCode());
                    if (menuAction == null) {
                        menuAction = new MenuAction();
                    }
                    menuActionDTO.setId(null);
                    mapper.getConfiguration().setSkipNullEnabled(true);
                    mapper.map(menuActionDTO, menuAction);
                    menuAction.setMenu(req.getCode());
                    menuAction.setStatus(Constants.MENU_GROUP_STATUS.ACTIVE);
                    //menuAction.setEndPoint(req.getEndPoint()+menuActionDTO.getEndPoint());
                    currentMenuActions.add(menuAction);
                } else {
                    MenuAction menuAction = menuActionRepo.findById(menuActionDTO.getId()).orElse(null);
                    mapper.getConfiguration().setSkipNullEnabled(true);
                    mapper.map(menuActionDTO, menuAction);
                    menuAction.setMenu(req.getCode());
                    menuAction.setStatus(Constants.MENU_GROUP_STATUS.ACTIVE);
                    // menuAction.setEndPoint(req.getEndPoint()+menuActionDTO.getEndPoint());
                    currentMenuActions.add(menuAction);
                }
            });
        }
        // cap nhat cache quyen phuc vu log thao tac
//        Application application = applicationRepo.findByCode(req.getAppCode());
//        String appName = null;
//        String content = null;
//        if (application != null && application.getName() != null) {
//            appName = application.getName();
//        }

//        if (appName != null) {
//            content = String.format("Trong phần mềm có mã là %s và tên là %s đã sửa chức năng có tên là %s và mã là %s", application.getCode(), appName, menu.getName(), menu.getCode());
//        } else {
//            content = String.format("Đã sửa chức năng có tên là %s và mã là %s", menu.getName(), menu.getCode());
//        }
//        String logMess = this.getDetailMenu(content, req, application);
        if (!logMess.equals(content)) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.menu, ActionCode.EDIT, logMess, Instant.now()));
        }
        // ketthuc
        menuActionRepo.saveAll(currentMenuActions);

        String appCode = "";
        if (req != null && req.getAppCode() != null) {
            appCode = req.getAppCode();
        }
        List<Account> accounts = accountRepository.findAll();
        if (accounts != null && accounts.size() > 0) {
            for (Account entity : accounts) {
                redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + appCode + "_" + entity.getAccount());
            }
        }

        return req.getId();
    }

    private String getDetailMenu(String logContent, MenuReq req, Menu menu) {
        if (req == null || menu == null) {
            return null;
        }

        StringBuilder logMessage = new StringBuilder();
        logMessage.append(logContent);
        LogUtil.compareAndLog(logMessage, "[Tên chức năng] ", req.getName(), menu.getName());
        LogUtil.compareAndLog(logMessage, "[Đường dẫn] ", req.getUrl(), menu.getUrl());
        LogUtil.compareAndLog(logMessage, "[Thành phần] ", req.getComponent(), menu.getComponent());
        LogUtil.compareAndLog(logMessage, "[Thứ tự] ", req.getOrder(), menu.getOrder());
        LogUtil.compareAndLog(logMessage, "[Trạng thái] ", req.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa", menu.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa");
        LogUtil.compareAndLog(logMessage, "[Biểu tượng] ", req.getIcon(), menu.getIcon());
        LogUtil.compareAndLog(logMessage, "[Mô tả] ", req.getDescription(), menu.getDescription());
        LogUtil.compareAndLog(logMessage, "[Loại chức năng] ", req.getTypeMenu() == 1 ? "Chức năng" : (req.getTypeMenu() == 2 ? "Màn hình" : "Thành phần"), menu.getTypeMenu() == 1 ? "Chức năng" : (menu.getTypeMenu() == 2 ? "Màn hình" : "Thành phần"));
        LogUtil.compareAndLog(logMessage, "[Mã khác] ", req.getCodeOther(), menu.getCodeOther());
        return logMessage.toString();
    }

    @Override
    public Object list(AppTextFilter appTextFilter) throws Exception {
        trimSpaceUtil.validate(appTextFilter);
        ICallStoredObj callStoredObj = new MenuActionCallStoredDTO(appTextFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return res;
    }

    //    @Override
    public Object detail_store(String id) throws Exception {
        ICallStoredObj callStoredObj = new MenuActionCallStoredDTO(id);
        List<MenuActionRes> menus = (List<MenuActionRes>) callStoredRepository.getList(callStoredObj);
        List<MenuActionDetailRes> menuActionDetailReses = new ArrayList<>();
        if (menus != null) {
            for (MenuActionRes menu : menus) {
                if (menu.getLstAction() != null) {
                    ICallStoredObj callStoreLstAction = new MenuActionCallStoredDTO(menu.getCode(), Constants.STATUS_CATEGORY_ACTIVE);
                    List<ActionNameIdRes> lstAction = (List<ActionNameIdRes>) callStoredRepository.getList(callStoreLstAction);
                    menu.setLstAction(lstAction);
                }
                MenuActionDetailRes res = new MenuActionDetailRes();
                res.setMenuActionRes(menu);
                menuActionDetailReses.add(res);
                break;
            }

            return menuActionDetailReses;
        }

        throw new NotFoundException(String.format("Khong tim thay doi tuong voi : %s", id.toString()));
    }

    @Override
    public Object listMenuAction(AppTextFilter appTextFilter) throws Exception {
	/*	ICallStoredObj callStoredObj = new MenuActionCallStoredDTO(appTextFilter, true);
		ListResponse lstRes = (ListResponse) callStoredRepository.list(callStoredObj);
		if (lstRes.getTotal() != null) {
			List<MenuActionRes> lstMenuActionCall = (List<MenuActionRes>) lstRes.getList();
			List<MenuActionRes> lstMenuActionRes = new ArrayList<>();
			String menuIdLast = null;
			List<ActionNameIdRes> lstAction = new ArrayList<>();
			MenuActionRes menuActionRes = null;
			for (MenuActionRes menuAction : lstMenuActionCall) {
				if (menuIdLast == null) {
					menuIdLast = menuAction.getId();
					menuActionRes = menuAction;
					if (menuAction.getActionCode() != null) {
						lstAction.add(new ActionNameIdRes(menuAction.getActionCode()));
					}
				} else if (!menuAction.getId().equals(menuIdLast)) {
					menuActionRes.setLstAction(lstAction);
					lstMenuActionRes.add(menuActionRes);
					lstAction = new ArrayList<>();
					menuActionRes = menuAction;
					menuIdLast = menuAction.getId();
				} else {
					if (menuAction.getActionCode() != null) {
						lstAction.add(new ActionNameIdRes(menuAction.getActionCode()));
					}
				}
			}
			if (menuActionRes != null) {
				lstAction.add(new ActionNameIdRes(menuIdLast));
				menuActionRes.setLstAction(lstAction);
				lstMenuActionRes.add(menuActionRes);
			}
			Long total = lstRes.getTotal();
			//ICallStoredObj callStoredObjLst = new ActionCallStoredDTO(null, appTextFilter.getAppId()); //se fix
			ICallStoredObj callStoredObjLst = new ActionCallStoredDTO(null);// thay the de chay
			List<ActionNameIdRes> lstAllAction = (List<ActionNameIdRes>) callStoredRepository.getList(callStoredObjLst);
			return MenuActionList.builder()
					.lstActionAll(lstAllAction)
					.lstMenuActionRes(lstMenuActionRes)
					.total(total)
					.build();
		}
		return lstRes;*/
        return "";
    }

    @Override
    public Object changeStatus(String id) throws Exception {
        Menu menu = menuCatRepo.findById(id).orElse(null);
        //	mapper.getConfiguration().setSkipNullEnabled(true);
        if (menu == null) {
            throw new NotFoundException(String.format("Khong tim thay doi tuong voi id: %s", id.toString()));
        }
//        List<File> files = fileRepository.findByRelativeCodeAndTable(menu.getCode(), Constants.TBL_NAME.APPLICATION);
//        if (CollectionUtils.isNotEmpty(files)) {
//            File file = files.get(0);
//            file.setStatus(Constants.MENU_GROUP_STATUS.DELETED);
//            fileRepository.save(file);
//        }
        if (menuCatRepo.existsByParentMenuCodeAndStatusNot(menu.getCode(), Constants.COMMON_STATUS.DELETED)) {
            throw new ValidationException(Messages.getString("ValidationException.error.exists.category.parent.delete"));
        }
        menu.setStatus(Constants.MENU_GROUP_STATUS.DELETED);
        menuCatRepo.save(menu);
        Application application = applicationRepo.findByCode(menu.getAppCode());
        String appName = null;
        String content = null;
        if (application != null && application.getName() != null) {
            appName = application.getName();
        }

        if (appName != null) {
            content = String.format("Trong phần mềm có mã là %s và tên là %s đã xóa chức năng có tên là %s và mã là %s", application.getCode(), appName, menu.getName(), menu.getCode());
        } else {
            content = String.format("Đã xóa chức năng có tên là %s và mã là %s", menu.getName(), menu.getCode());
        }
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.menu, ActionCode.DEL, content, Instant.now()));
        return menu;

    }


    private void saveIcon(MenuReq menuReq) throws Exception {
        if (StringUtils.isEmpty(menuReq.getFile())) {
            return;
        }
//        if (menuReq.getId() == null) {
//            fileRepository.save(newInstanceFromBase64(menuReq.getFile(), menuReq.getFileName(), menuReq.getCode(), Constants.TBL_NAME.MENU));
//        } else {
//            // Update application
//            Menu menuAction = menuCatRepo.findById(menuReq.getId()).orElse(new Menu());
//            if (menuAction.getId() != null) {
//                List<File> files = fileRepository.findByRelativeCodeAndTable(menuAction.getCode(), Constants.TBL_NAME.MENU);
//                if (CollectionUtils.isEmpty(files)) {
//                    fileRepository.save(newInstanceFromBase64(menuReq.getFile(), menuReq.getFileName(), menuAction.getCode(), Constants.TBL_NAME.MENU));
//                } else {
//                    File file = files.get(0);
//                    file.setContent(Base64.getDecoder().decode(menuReq.getFile()));
//                    file.setFileName(menuReq.getFileName());
//                    fileRepository.save(file);
//                }
//            }
//        }
    }

//    private File newInstanceFromBase64(String base64Str, String fileType, String appCode, String appTblName) throws Exception {
//        File file = new File(Base64.getDecoder().decode(base64Str), fileType, appCode, appTblName);
//        file.setStatus(Constants.FILE_STATUS.ACTIVE);
//        return file;
//    }


    @Override
    public ResponseBase importExcel(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception {
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj = new MenuExcelObj(0);
        List<MenuExcelItemObj> listMenuExcelItemObj = excelObjectMapper.map(MenuExcelItemObj.class, 0, iExcelMapperObj, 4);
        List<Menu> menus = saveMenu(listMenuExcelItemObj);
        // menu action
        IExcelMapperObj menuActionExcelObj = new MenuActionExcelObj(0);
        List<MenuActionExcelItemObj> listMenuActionExcelObj = excelObjectMapper.map(MenuActionExcelItemObj.class, 1, menuActionExcelObj, 4);
        List<MenuAction> menuActions = saveMenuAction(listMenuActionExcelObj);
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.menu, ActionCode.UPLOAD,
                null, Instant.now()));
        return new ResponseBase(menus);
    }

    @Override
    public ResponseBase setActiveDeActive(String id) throws Exception {
        Menu menu = menuCatRepo.findById(id).orElse(null);
        if (menu == null) {
            throw new NotFoundException("Khong tim thay tai khoan : id = " + id);
        }

        String actionCode = null;
        if (menu.getStatus().equals(Constants.MENU_GROUP_STATUS.ACTIVE) || menu.getStatus().equals(Constants.MENU_GROUP_STATUS.INACTIVE)) {
            if (menu.getStatus().equals(Constants.MENU_GROUP_STATUS.INACTIVE)) {
                if (menuCatRepo.existsByCodeAndStatus(menu.getParentMenuCode(), Constants.COMMON_STATUS.INACTIVE)) {
                    throw new ValidationException(Messages.getString("ValidationException.error.exists.category.not.parent"));
                }
                menu.setStatus(Constants.MENU_GROUP_STATUS.ACTIVE);
                actionCode = ActionCode.ACTIVE;
            } else {
                if (menuCatRepo.existsByParentMenuCodeAndStatus(menu.getCode(), Constants.COMMON_STATUS.ACTIVE)) {
                    throw new ValidationException(Messages.getString("ValidationException.error.exists.category.parent"));
                }
                actionCode = ActionCode.INACTIVE;
                menu.setStatus(Constants.MENU_GROUP_STATUS.INACTIVE);
            }
            Application application = applicationRepo.findByCode(menu.getAppCode());
            String appName = null;
            String content = null;
            if (application != null && application.getName() != null) {
                appName = application.getName();
            }

            if (actionCode.equals(ActionCode.INACTIVE)) {
                if (appName != null) {
                    content = String.format("Trong phần mềm có mã là %s và tên là %s đã vô hiệu hóa chức năng có tên là %s và mã là %s", application.getCode(), appName, menu.getName(), menu.getCode());
                } else {
                    content = String.format("Đã vô hiệu hóa chức năng có tên là %s và mã là %s", menu.getName(), menu.getCode());
                }
            } else if (actionCode.equals(ActionCode.ACTIVE)) {
                if (appName != null) {
                    content = String.format("Trong phần mềm có mã là %s và tên là %s đã kích hoạt chức năng có tên là %s và mã là %s", application.getCode(), appName, menu.getName(), menu.getCode());
                } else {
                    content = String.format("Đã kích hoạt chức năng có tên là %s và mã là %s", menu.getName(), menu.getCode());
                }
            }
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.menu, actionCode, content, Instant.now()));
            return new ResponseBase(menuCatRepo.save(menu));
        } else return new ResponseBase("Do not anything!");

    }

    @Override
    public ResponseEntity importExcelReturnResult(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception {
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        int sheetAtMenu = 0;
        int firstRowMenu = 4;
        int sheetAtMenuAction = 1;
        int firstRowMenuAction = 4;
        IExcelMapperObj iExcelMapperObj = new MenuExcelObj(0);
        List<MenuExcelItemObj> listMenuExcelItemObj = excelObjectMapper.map(MenuExcelItemObj.class, sheetAtMenu, iExcelMapperObj, firstRowMenu);
        saveMenuReturnRes(excelObjectMapper, sheetAtMenu, firstRowMenu, listMenuExcelItemObj);

        // menu action
        IExcelMapperObj menuActionExcelObj = new MenuActionExcelObj(0);
        List<MenuActionExcelItemObj> listMenuActionExcelObj = excelObjectMapper.map(MenuActionExcelItemObj.class, sheetAtMenuAction, menuActionExcelObj, firstRowMenuAction);
        String content = String.format("%s chức năng mã %s và tên %s", Constants.COMMON_STATUS
                .getNameByStatus(1), "001003002008", "import danh sách chức năng");
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.menu, ActionCode.UPLOAD, content, Instant.now()));
        return saveMenuActionReturnRes(excelObjectMapper, sheetAtMenuAction, firstRowMenuAction, listMenuActionExcelObj);
    }

    private ResponseEntity saveMenuActionReturnRes(ExcelObjectMapper excelObjectMapper, int sheetAtMenuAction, int firstRowMenuAction, List<MenuActionExcelItemObj> listMenuActionExcelObj) throws IOException {
        Map<Integer, String> errMap = new HashMap<>();
        List<MenuAction> menuActions = new ArrayList<>();
        for (MenuActionExcelItemObj menuActionExcelItemObj : listMenuActionExcelObj) {
            String messageError = "";

            if (StringUtils.isNotEmpty(menuActionExcelItemObj.getCode())
                    && StringUtils.isNotEmpty(menuActionExcelItemObj.getMenu())
                    && StringUtils.isNotEmpty(menuActionExcelItemObj.getAction())) {
                int flag = 0;
                if (StringUtils.isEmpty(menuActionExcelItemObj.getCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.menu.action.code");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCodeMsg(menuActionExcelItemObj.getCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(menuActionExcelItemObj.getMenu())) {
                    messageError += Messages.getString("ValidationException.error.not.null.menu.code");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCodeMsg(menuActionExcelItemObj.getMenu());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(menuActionExcelItemObj.getAction())) {
                    messageError += Messages.getString("ValidationException.error.not.null.action.code");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCodeActionMsg(menuActionExcelItemObj.getAction());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                Menu menu = menuCatRepo.findByCode(menuActionExcelItemObj.getMenu());
                if (menu == null) {
                    messageError += Messages.getString("ValidationException.error.not.exist.menu.code");
                    flag++;
                }
                Action action = actionCatRepo.findByCode(menuActionExcelItemObj.getAction()).orElse(null);
                if (action == null) {
                    // messageError += Messages.getString("ValidationException.error.not.exist.action.code");
                    messageError += Messages.getString("ValidationException.error.not.exist.action.code");
                    flag++;
                }
                MenuAction menuActionByMenuAction = menuActionRepo.findByMenuAndAction(menuActionExcelItemObj.getMenu(),
                        menuActionExcelItemObj.getAction()).orElse(null);
                MenuAction menuActionByMenuEndPointMethod = menuActionRepo.findByMenuAndEndPointAndMethod(menuActionExcelItemObj.getMenu(),
                        menuActionExcelItemObj.getEndPoint(), menuActionExcelItemObj.getMethod()).orElse(null);

                if (menuActionByMenuAction != null) {
                    messageError += Messages.getString("ValidationException.error.existed.menu.code.action.code");
                    flag++;
                }
                if (menuActionByMenuEndPointMethod != null) {
                    messageError += Messages.getString("ValidationException.error.existed.menu.end.point.method");
                    flag++;
                }

                MenuAction menuAction = new MenuAction();
                menuAction = (MenuAction) mapper.map(menuActionExcelItemObj, MenuAction.class);
                MenuAction currentMenuAction = menuActionRepo.findByCodeAndMenu(menuActionExcelItemObj.getCode(), menuActionExcelItemObj.getMenu());
                if (currentMenuAction != null && flag == 0) {
                    mapper.getConfiguration().setSkipNullEnabled(true);
                    mapper.map(menuActionExcelItemObj, currentMenuAction);

                    try {
                        menuActionRepo.save(currentMenuAction);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError += String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                                ;
                            }
                        }
                    }
                } else {
                    MenuAction MenuActionByCode = menuActionRepo.findByCodeAndMenuAndAction(menuActionExcelItemObj.getCode(),
                            menuActionExcelItemObj.getMenu(), menuActionExcelItemObj.getAction()).orElse(null);
                    if (MenuActionByCode != null) {
                        messageError += Messages.getString("ValidationException.error.existed.menu.action.code");
                        flag++;
                    }
                    if (flag == 0) {
//                        menuActions.add(menuAction);
                        try {
                            menuActionRepo.save(menuAction);
                        } catch (Exception ex) {
                            if (ex instanceof DataIntegrityViolationException) {
                                if (ex.getCause() instanceof ConstraintViolationException) {
                                    messageError += String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                                    ;
                                }
                            }
                        }
                    }
                }
                errMap.put(menuActionExcelItemObj.getRow(), messageError);
            }
        }
//        if (CollectionUtils.isNotEmpty(menuActions)) {
//            menuActionRepo.saveAll(menuActions);
//        }

        return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAtMenuAction, firstRowMenuAction, null), "Loi_import_chuc_nang.xlsx");
    }

    private ResponseEntity saveMenuReturnRes(ExcelObjectMapper excelObjectMapper, int sheetAtMenu, int firstRowMenu, List<MenuExcelItemObj> list) throws IOException {
        Map<Integer, String> errMap = new HashMap<>();
        List<Menu> menus = new ArrayList<>();
        for (MenuExcelItemObj menuExcelItemObj : list) {
            String messageError = "";
            if (menuExcelItemObj != null && StringUtils.isNotEmpty(menuExcelItemObj.getCode()) && StringUtils.isNotEmpty(menuExcelItemObj.getAppCode()) && StringUtils.isNotEmpty(menuExcelItemObj.getName())) {
                int flag = 0;

                if (StringUtils.isEmpty(menuExcelItemObj.getCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.app.code");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCodeMsg(menuExcelItemObj.getCode());
                    messageError += messageError1;

                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(menuExcelItemObj.getAppCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.app.code");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCodeActionMsg(menuExcelItemObj.getAppCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(menuExcelItemObj.getParentMenuCode())) {
                    String messageError1 = CommonUtils.errorCodeMsg(menuExcelItemObj.getParentMenuCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(menuExcelItemObj.getName())) {
                    messageError += Messages.getString("ValidationException.error.not.null.menu.name");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorActionNameMsg(menuExcelItemObj.getName());
                    messageError += messageError1;
                    //flag = messageError1.isEmpty() ? 0 : flag++;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(menuExcelItemObj.getComponent())) {
                    Menu existedComponent = menuCatRepo.findByComponentAndAppCode(menuExcelItemObj.getComponent(), menuExcelItemObj.getAppCode());
                    if (existedComponent != null) {
                        messageError += Messages.getString("ValidationException.error.duplicated.menu.component");
                        flag++;
                    }
                }

                if (Objects.isNull(menuExcelItemObj.getOrder()) || menuExcelItemObj.getOrder() == 0) {
                    messageError += Messages.getString("ValidationException.error.not.null.order");
                    flag++;
                }

                if (StringUtils.isEmpty(menuExcelItemObj.getEndPoint())) {
                    messageError += Messages.getString("ValidationException.error.not.null.end.point");
                    flag++;
                }

                if (menuExcelItemObj.getType() == null) {
                    messageError += Messages.getString("ValidationException.error.not.null.menu.type");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorActionTypeMsg(menuExcelItemObj.getType());
                    messageError += messageError1;
                    //flag = messageError1.isEmpty() ? 0 : flag++;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(menuExcelItemObj.getAppCode())) {
                    Application application = applicationRepo.findByCode(menuExcelItemObj.getAppCode());
                    if (application == null) {
                        messageError += Messages.getString("ValidationException.error.not.exist.app.code");
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(menuExcelItemObj.getParentMenuCode())) {
                    Menu parentMenu = menuCatRepo.findByCode(menuExcelItemObj.getParentMenuCode());
                    if (parentMenu == null) {
                        messageError += Messages.getString("ValidationException.error.not.exist.parent.menu.code");
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(menuExcelItemObj.getDescription())) {
                    String messageError1 = CommonUtils.errorDescriptionMsg(menuExcelItemObj.getDescription());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                Menu menu = new Menu();
                menu = mapper.map(menuExcelItemObj, Menu.class);
                menu.setTypeMenu(menuExcelItemObj.getType());
                menu.setStatus(Constants.MENU_GROUP_STATUS.ACTIVE);
                Menu currentMenu = menuCatRepo.findByCodeAndName(menuExcelItemObj.getCode(), menuExcelItemObj.getName());
                if (currentMenu != null && flag == 0) {
                    mapper.getConfiguration().setSkipNullEnabled(true);
                    mapper.map(menuExcelItemObj, currentMenu);
                    currentMenu.setTypeMenu(menuExcelItemObj.getType());
                    try {
                        menuCatRepo.save(currentMenu);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError += Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName());
                                ;
                            }
                        }
                    }
                } else {
                    Menu menuByCode = menuCatRepo.findByCode(menuExcelItemObj.getCode());
                    if (menuByCode != null) {
                        messageError += Messages.getString("ValidationException.error.exist.menu.code");
                        flag++;
                    }
                    if (flag == 0) {
                        menus.add(menu);
                        try {
                            menuCatRepo.save(menu);
                        } catch (Exception ex) {
                            if (ex instanceof DataIntegrityViolationException) {
                                if (ex.getCause() instanceof ConstraintViolationException) {
                                    messageError += Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName());
                                    ;
                                }
                            }
                        }
                    }
                }
                errMap.put(menuExcelItemObj.getRow(), messageError);
            }
        }
        return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAtMenu, firstRowMenu, null), "Ket_qua_import_chuc_nang_" + sdf.format(new Date()) + ".xlsx");
    }


    public List<Menu> saveMenu(List<MenuExcelItemObj> list) throws Exception {
        List<Menu> menus = new ArrayList<>();
        for (MenuExcelItemObj menuExcelItemObj : list) {
            if (menuExcelItemObj != null && StringUtils.isNotEmpty(menuExcelItemObj.getCode())) {
                Menu menu = new Menu();
                menu = mapper.map(menuExcelItemObj, Menu.class);
                menu.setStatus(Constants.MENU_GROUP_STATUS.ACTIVE);
//				if (menuExcelItemObj.getParentMenuCode() != null){
//					Menu current_menu = menuCatRepo.findByCode(menuExcelItemObj.getParentMenuCode());
//					if(current_menu == null){
//						//throw  new ValidationException("mã cha không tồn tại"+ menuExcelItemObj.getParentMenuCode());
//					}
//				}
//				if(menuExcelItemObj.getAppCode() != null ){
//					Application application = applicationRepo.findByCode(menuExcelItemObj.getAppCode());
//					if ( application == null){
//						//throw  new ValidationException("mã ứng dụng không tồn tại"+ menuExcelItemObj.getAppCode());
//					}
//				}
                menus.add(menu);
            }
        }
        return menuCatRepo.saveAllAndFlush(menus);
    }

    public List<MenuAction> saveMenuAction(List<MenuActionExcelItemObj> listMenuActionExcelItemObj) {
        List<MenuAction> menuActions = new ArrayList<>();
        for (MenuActionExcelItemObj menuActionExcelItemObj : listMenuActionExcelItemObj) {
            if (menuActionExcelItemObj != null && StringUtils.isNotEmpty(menuActionExcelItemObj.getCode())) {
                MenuAction menuAction = new MenuAction();
                menuAction = (MenuAction) mapper.map(menuActionExcelItemObj, MenuAction.class);
//			if(menuAcionExcelItemObj.getMenu() == null || menuAcionExcelItemObj.getAction() == null){
//				//throw  new ValidationException("mã chức năng , mã hành động không được để trống");
//			}
                menuActions.add(menuAction);
            }
        }

        return menuActionRepo.saveAll(menuActions);
    }

    @Override
    public ResponseEntity createTemplate() throws Exception {
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(CommonService.pathTemp("IMPORT_CHUC_NANG_TEMPLATE.xlsx"));
        List<Action> activeActions = actionCatRepo.findByStatusOrderByCodeAsc(1);
        List<IExcelItem> data = activeActions.stream().map(e -> new ActionExcelItemObj(e.getCode(), e.getName())).collect(Collectors.toList());
        int sheetAt = 2;
        int startRowAt = 4;
        IExcelMapperObj actionExcelObj = new ActionExcelObj(0);
        return CommonUtils.downloadFile(excelObjectMapper.getTemplateWithData(data, ActionExcelItemObj.class, actionExcelObj, sheetAt, startRowAt), "template_import_chuc_nang.xlsx");
    }

    public void updatePermissionForLogToRedis(MenuReq req) {
        for (MenuActionDTO menuActionDTOS : req.getListAction()) {
            MenuAction menuActionOld = menuActionRepo.findByCode(menuActionDTOS.getCode());
            Menu menuOld = menuCatRepo.findByCode(req.getCode());
            String keyOld = "";
            if (menuActionOld != null && menuOld != null) {
                keyOld = req.getAppCode() + "_" + menuActionOld.getMethod() + "_" + menuOld.getEndPoint() + menuActionOld.getEndPoint();
            }

            String key = req.getAppCode() + "_" + menuActionDTOS.getMethod() + "_" + req.getEndPoint() + menuActionDTOS.getEndPoint();
            Application app = applicationRepo.findByCode(req.getAppCode());
            PermissionForLogDTO forLogNew = new PermissionForLogDTO();
            forLogNew.setAppCode(req.getAppCode());
            forLogNew.setAppName(app.getName());
            forLogNew.setMenuCode(req.getCode());
            forLogNew.setMenuName(req.getName());
            forLogNew.setActionCode(menuActionDTOS.getAction());
            forLogNew.setActionName(menuActionDTOS.getActionName());
            forLogNew.setPermissionCode(menuActionDTOS.getCode());
            forLogNew.setMethod(menuActionDTOS.getMethod());
            forLogNew.setEndpoint(req.getEndPoint() + menuActionDTOS.getEndPoint());
            redisTemplate.delete(keyOld);
            redisTemplate.opsForValue().set(key, new Gson().toJson(forLogNew));
        }
    }

    @Override
    public Object detail(String id) throws Exception {

        List<MenuActionRes> menus = menuCatRepo.getMenuActionById(id);
        List<MenuActionDetailRes> menuActionDetailReses = new ArrayList<>();
        if (menus != null) {
            for (MenuActionRes menu : menus) {
                if (menu.getLstAction() != null) {
                    List<ActionNameIdRes> lstAction = menuActionRepo.getActionNameIdResByMenu(menu.getCode(), Constants.STATUS_CATEGORY_ACTIVE);
                    menu.setLstAction(lstAction);
                }
                MenuActionDetailRes res = new MenuActionDetailRes();
                res.setMenuActionRes(menu);
                menuActionDetailReses.add(res);
                break;
            }

            return menuActionDetailReses;
        }

        throw new NotFoundException(String.format("Khong tim thay doi tuong voi : %s", id.toString()));
    }
}
