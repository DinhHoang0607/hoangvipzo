 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 17, 2021
 */
package vn.gtel.app_mng.role.dto.category;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceDTO {
	
	@Column(name = "dvu_id")
	private String serviceId;
	
	@Column(name = "ma_ndv")
	private String groupServiceCode;
	
	@Column(name = "ten_ndv")
	private String groupServiceName;
	
	@Column(name = "ma_dvu")
	private String serviceCode;
	
	@Column(name = "ten_dvu")
	private String serviceName;

	@Column(name ="URI")
	private String uri;
	
	
	
	
	
	
	
}
