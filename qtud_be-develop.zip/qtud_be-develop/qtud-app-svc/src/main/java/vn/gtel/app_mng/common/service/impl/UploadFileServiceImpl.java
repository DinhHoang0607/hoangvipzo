package vn.gtel.app_mng.common.service.impl;

import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.errors.*;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.UploadFileService;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

@Service
public class UploadFileServiceImpl implements UploadFileService {
    private final MinioClient minioClient;

    public UploadFileServiceImpl(@Value("${minio.url}") String minioUrl,
                                 @Value("${minio.secret-key}") String minioSecretKey,
                                 @Value("${minio.access-key}") String minioAccessKey) {
        this.minioClient = MinioClient.builder()
                .endpoint(minioUrl)
                .credentials(minioAccessKey, minioSecretKey)
                .build();
    }

    @Override
    public ResponseBase uploadFile(MultipartFile file, String minioBucket) {
        try (InputStream fileInputStream = file.getInputStream()) {
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String uuidFileName = UUID.randomUUID().toString() + extension;
            minioClient.putObject(PutObjectArgs.builder()
                    .bucket(minioBucket)
                    .object(uuidFileName)
                    .stream(fileInputStream, file.getSize(), -1)
                    .contentType(file.getContentType()).build());
            return new ResponseBase(uuidFileName);
        } catch (Exception e) {
            e.getStackTrace();
            return new ResponseBase("500", e.getMessage());
        }
    }

    @Override
    public InputStream download(String fileName, String minioBucket) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        return minioClient.getObject(
                GetObjectArgs.builder()
                        .bucket(minioBucket)
                        .object(fileName)
                        .build()
        );
    }
}
