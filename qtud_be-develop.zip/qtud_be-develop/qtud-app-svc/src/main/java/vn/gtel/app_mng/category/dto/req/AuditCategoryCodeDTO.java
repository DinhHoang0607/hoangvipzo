package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditDTO;

import javax.validation.constraints.*;

@Data
public class AuditCategoryCodeDTO extends AuditDTO {

    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
    @Pattern(regexp = Constants.Regex.CATEGORY_CODE,message = "error.common.validate.only.number")
    private String code;

    private @NotNull(message = "error.common.validate.not.null")
    @Max(value = Constants.VALID.MAX_VAL_ORDER, message = "error.common.validate.max.value.100000")
    Integer order;

}
