package vn.gtel.app_mng.account.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.dto.response.AccountGroupResDTO;
import vn.gtel.app_mng.account.model.AccountGroup;

import java.util.List;

@Repository
public interface AccountGroupRepository extends JpaRepository<AccountGroup, String> {

    @Query(value = "select new vn.gtel.app_mng.account.dto.response.AccountGroupResDTO(ag.id, ag.code, ag.name, ag.description, ag.status, ag.statusName) " +
            " from AccountGroup ag " +
            " where (:keySearch is null or upper(ag.code) like :keySearch or upper(ag.name) like :keySearch) " +
            " and (:status is null and ag.status > 0 or ag.status = :status) " +
            " and ((:accountName is null or ag.createdBy = :accountName) or (:organizationCode is null or ag.createdBy like UPPER(CONCAT('%', :organizationCode, '%'))))"
            , countQuery = "select count(ag) from AccountGroup ag where (:keySearch is null or upper(ag.code) like :keySearch or upper(ag.name) like :keySearch) " +
            " and (:status is null and ag.status > 0 or ag.status = :status) " +
            " and ((:accountName is null or ag.createdBy = :accountName) or (:organizationCode is null or ag.createdBy like UPPER(CONCAT('%', :organizationCode, '%')))) ")
    Page<AccountGroupResDTO> findByKeySearch(String keySearch, Integer status, Pageable p, String accountName, String organizationCode);

    @Query(value = "select new vn.gtel.app_mng.account.dto.response.AccountGroupResDTO(ag.id, ag.code, ag.name, ag.description, ag.status, ag.statusName) " +
            " from AccountGroup ag where ag.id = :id and ag.status <> -1 ")
    AccountGroupResDTO getDetail(String id);

    boolean existsByCode(String code);

    AccountGroup findFirstByOrderByCodeDesc();
}
