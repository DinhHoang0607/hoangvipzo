package vn.gtel.app_mng.feedback.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.Instant;

@Data
@Entity
@Table(name = "TBL_PHAN_ANH_LIEN_QUAN",  catalog = "")
@EntityListeners(AuditingEntityListener.class)
public class FeedbackRelateTo {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "ID_PHAN_ANH")
    private String feedbackId;

    @Basic
    @Column(name = "ID_PHAN_ANH_LIEN_QUAN")
    private String feedbackIdRelateTo;

    @Basic
    @Column(name = "TRANG_THAI")
    private Long status;

    @Column(name = "NGAY_TAO")
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

}
