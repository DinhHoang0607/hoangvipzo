package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.Title;

@Repository
public interface TitleRepo extends JpaRepository<Title,String> {
    Title findByCode(String code);
}
