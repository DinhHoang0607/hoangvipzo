package vn.gtel.app_mng.account.service;

import org.springframework.http.ResponseEntity;
import vn.gtel.app_mng.account.dto.AccountGroupDTO;
import vn.gtel.app_mng.common.dto.request.StatusTextFilter;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

public interface GroupAccountService {
    ResponseBase save(AccountGroupDTO groupAccountRequestDTO) throws Exception;

    ResponseBase active(String id) throws Exception;

    ResponseBase delete(String id) throws Exception;

    ResponseBase list(StatusTextFilter statusTextFilter) throws Exception;

    ResponseBase detail(String id) throws Exception;

    ResponseBase selectList(String id, String type, String status, TextFilter textFilter);

    ResponseEntity export(Integer status, String keySearch, String id) throws Exception;

    ResponseBase newCode();
}
