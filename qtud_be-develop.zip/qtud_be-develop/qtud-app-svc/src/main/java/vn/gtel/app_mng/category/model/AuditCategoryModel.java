/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AuditCategoryModel.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/17/22, 11:42 AM
 *
 */

package vn.gtel.app_mng.category.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class AuditCategoryModel extends AuditModel implements Serializable {

    @Basic
    @Column(name = "THU_TU")
    private Long order;
}
