package vn.gtel.app_mng.account.dto;

import lombok.Data;

@Data
public class TransferCheckNvcbProfileDetailDTO {
    private String message;
    private Long total;
}
