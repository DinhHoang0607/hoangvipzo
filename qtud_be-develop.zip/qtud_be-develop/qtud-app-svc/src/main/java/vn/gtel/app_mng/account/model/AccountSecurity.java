package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.account.service.GeneralConfigService;
import vn.gtel.app_mng.account.service.Impl.GeneralConfigServiceImpl;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "TBL_TK_BAO_MAT")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountSecurity extends AuditModelBase {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "THOI_GIAN_CAP_NHAT_MAT_KHAU")
    private Instant refreshed_date;

    @Basic
    @Column(name = "THOI_HAN_MAT_KHAU")
    private Instant expiration_date;

    @Basic
    @Column(name = "THOI_GIAN_THONG_BAO_DOI_MAT_KHAU")
    private Instant expired_notification_date;

    @Basic
    @Column(name = "SO_LAN_DANG_NHAP_SAI")
    private Long incorrectCounter;

    public void resetSecurity(GeneralConfigService generalConfigService) {
        this.refreshed_date = Instant.now();
        this.expiration_date = generalConfigService.generatePasswordExpirationDate(Instant.now(), 1);
        this.expired_notification_date = generalConfigService.generatePasswordExpirationDate(Instant.now(), 2);
        this.incorrectCounter = 0L;
    }

    public void resetLockoutCounter() {
        this.incorrectCounter = 0L;
    }
}
