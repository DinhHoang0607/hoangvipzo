package vn.gtel.app_mng.account.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountResDTO {
    private String id;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String code;
    private String name;
    @Max(3)
    @Min(-1)
    private int action;
    private String policeNumber;
    private String militaryName;
    private String positionName;

    public AccountResDTO(@NotEmpty(message = "error.common.validate.not.empty") String code, String name, String policeNumber, String militaryName, String positionName) {
        this.code = code;
        this.name = name;
        this.policeNumber = policeNumber;
        this.militaryName = militaryName;
        this.positionName = positionName;
    }
}
