package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.category.model.UsbToken;

import java.util.Optional;

@Repository
public interface UsbTokenRepository extends JpaRepository<UsbToken, String>{
    UsbToken findByCode(String code);
    Optional<UsbToken> findByAccountCode(String accountCode);

    Optional<UsbToken> findByDigitalCertificate(String digitalCertificate);

    @Query(value = "select MA from TBL_DM_DIA_GIOI_HANH_CHINH where MA_CHA is null  and UPPER(TEN) like  '%' || Upper (?1)||'%'",nativeQuery = true)
    String findCodeAreaAdministrativeByName(String name);
}
