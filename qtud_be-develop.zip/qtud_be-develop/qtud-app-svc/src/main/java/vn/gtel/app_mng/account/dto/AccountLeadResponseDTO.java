package vn.gtel.app_mng.account.dto;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccountLeadResponseDTO {
        @Column(name = "ID")
        private String id;
        @Column(name = "TAI_KHOAN")
        private String account;
        @Column(name = "HO_TEN")
        private String name;
        @Column(name = "DON_VI")
        private String organization;
        @Column(name = "TEN_DON_VI")
        private String organizationName;
        @Column(name = "CHUC_VU")
        private String position;
        @Column(name = "TEN_CHUC_VU")
        private String positionName;
        @Column(name = "MA_CAP_BAC")
        private String military;
        @Column(name = "TEN_CAP_BAC")
        private String militaryName;
        @Column(name = "TRANG_THAI")
        private String status;
        @Column(name = "TRANG_THAI_HIEN_THI")
        private String statusName;
}
