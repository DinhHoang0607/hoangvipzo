package vn.gtel.app_mng.category.service;

import vn.gtel.app_mng.category.dto.req.ProfileStatusFilter;
import vn.gtel.app_mng.category.dto.req.ProfileStatusRequestDto;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

public interface ProfileStatusService {
    ResponseBase search(ProfileStatusFilter dto) throws Exception;

    ResponseBase detail(String id) throws Exception;

    ResponseBase save(ProfileStatusRequestDto dto) throws Exception;

    ResponseBase delete(String id) throws Exception;

    ResponseBase activeInActive(String id) throws Exception;
}
