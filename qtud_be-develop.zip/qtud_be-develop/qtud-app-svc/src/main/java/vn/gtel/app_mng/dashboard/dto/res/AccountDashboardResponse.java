package vn.gtel.app_mng.dashboard.dto.res;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccountDashboardResponse {
    @Column(name = "SO_LUONg")
    private Long total;
    @Column(name = "TRANG_THAI_TAI_KHOAN")
    private String accountStatus;
    @Column(name = "GIA_TRI_TRANG_THAI_TAI_KHOAN")
    private String accountStatusValue;
}
