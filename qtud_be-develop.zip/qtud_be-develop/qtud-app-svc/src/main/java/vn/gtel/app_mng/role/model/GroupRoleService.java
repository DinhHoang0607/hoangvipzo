package vn.gtel.app_mng.role.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

@Entity
@Table(name = "TBL_Q_NHOM_QUYEN_DICH_VU")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleService extends AuditModelBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

/*	@Basic
	@Column(name = "MA")
	private String ma;*/

	@Basic
	@Column(name = "SO_LUONG_TRUY_CAP")
	private Integer accessReqNumber;

	@Basic
	@Column(name = "NHOM_QUYEN")
	private String groupRole;

	@Basic
	@Column(name = "DICH_VU")
	private String service;

	@Basic
	@Column(name = "PHUONG_THUC")
	private String method;


}
