/*
 * Copyright (c) 2021.
 * Project  :  sso
 * File  :  AccountUserDetails.java
 * Created By :  tuannp
 * Created at :  12/2/21, 10:23 AM
 * LastModified  :  12/2/21, 10:19 AM
 *
 *
 *
 */

package vn.gtel.app_mng.common.config;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.common.config.constant.Constants;

import java.util.Collection;

public class AccountUserDetailsImpl implements UserDetails {
    private final Account account;

    public AccountUserDetailsImpl(Account account) {
//        account.setPassword(Constants.PasswordEncoder.BCRYPT + account.getPassword());
    	account.setPassword(account.getPassword());
        this.account = account;
    }

    public Account getAccount() {
        return account;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return AuthorityUtils.createAuthorityList("ROLE_USER");
    }

    @Override
    public String getPassword() {
        return this.account.getPassword();
    }

    @Override
    public String getUsername() {
        return this.account.getAccount();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
