package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import vn.gtel.app_mng.account.dto.AccountBasicInfoDTO;
import vn.gtel.app_mng.account.model.AccountHistory;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface AccountHistoryRepository extends JpaRepository<AccountHistory, String> {
    @Query(value = "SELECT * \n" +
                   "FROM tbl_tk_lich_su ls \n" +
                   "WHERE ls.thoi_gian_ket_thuc IS NULL AND ls.tai_khoan = ?", nativeQuery = true)
    Optional<AccountHistory> findCurrentHistory(String account);

    List<AccountHistory> findAllByAccount(String account, Pageable pageable);

    @Query(name = "findBasicInfo", nativeQuery = true)
    AccountBasicInfoDTO findBasicInfo(String account);
}
