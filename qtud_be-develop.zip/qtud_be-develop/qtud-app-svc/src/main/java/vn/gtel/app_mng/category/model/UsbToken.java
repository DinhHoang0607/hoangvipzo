package vn.gtel.app_mng.category.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import java.time.Instant;

@Entity
@Table(name = "TBL_DM_USB_TOKEN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsbToken extends AuditModelBase {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;
	@Basic
	@Column(name = "TAI_KHOAN")
	private String accountCode;
	@Basic
	@Column(name = "SO_CHUNG_THU")
	private String digitalCertificate;
	@Basic
	@Column(name = "MA")
	private String code;
	@Basic
	@Column(name = "LOAI_CHUNG_THU_SO")
	private Integer digitalCertificateType;
	@Basic
	@Column(name = "SO_CMND_CCCD_HO_CHIEU")
	private String cmndCccd;
	@Basic
	@Column(name = "NGAY_CAP")
	private Instant dateOfIssue;
	@Column(name = "NOI_CAP")
	private String placeOfIssue;
	@Basic
	@Column(name = "DIA_CHI_THU")
	private String address;
	@Basic
	@Column(name = "NGAY_SINH")
	private Instant dateOfBirth;
	@Basic
	@Column(name = "CO_QUAN")
	private String agency;
	@Basic
	@Column(name = "DIA_CHI_THU_DIEN_TU")
	private String mailAddress;
	@Basic
	@Column(name = "DIA_CHI_CO_QUAN")
	private String organizationAddress;
	@Basic
	@Column(name = "PHUONG_XA")
	private String village;
	@Basic
	@Column(name = "QUAN_HUYEN")
	private String district;
	@Basic
	@Column(name = "TINH_TP")
	private String province;
	@Basic
	@Column(name = "NHAP_MA")
	private String codeEnter;
}
