package vn.gtel.app_mng.category.dto.res.share;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShareServiceResponseDTO {

    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "MA")
    private String code;

//    @Basic
//    @Column(name = "ID_NHOM_DICH_VU")
//    private String groupId;
//
//    @Basic
//    @Column(name = "ID_DON_VI")
//    private String departmentId;
//
//    @Basic
//    @Column(name = "ID_DICH_VUCU")
//    private String oldId;

    @Basic
    @Column(name = "MA_DICH_VU")
    private String serviceCode;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "TEN_NHOM_DICH_VU")
    private String groupServiceName;

    @Basic
    @Column(name = "TEN_DON_VI")
    private String departmentName;

    @Basic
    @Column(name = "URI")
    private String uri;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Long type;

    @Basic
    @Column(name = "TEN_PHAN_LOAI")
    private String typeName;

//    @Basic
//    @Column(name = "ID_PHAN_LOAI")
//    private String typeId;
//
//    @Basic
//    @Column(name = "THU_TU")
//    private Long order;
}
