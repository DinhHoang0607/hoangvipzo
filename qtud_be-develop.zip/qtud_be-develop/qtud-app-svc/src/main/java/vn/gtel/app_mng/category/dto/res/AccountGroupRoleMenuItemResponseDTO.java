package vn.gtel.app_mng.category.dto.res;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccountGroupRoleMenuItemResponseDTO {
        @Column(name = "ID")
        private String id;
        @Column(name = "TAI_KHOAN")
        private String account;
        @Column(name = "TEN")
        private String name;
        @Column(name = "DON_VI")
        private String organization;
        @Column(name = "TEN_DON_VI")
        private String organizationName;
        @Column(name = "CHUC_VU")
        private String position;
        @Column(name = "TEN_CHUC_VU")
        private String positionName;
        @Column(name = "CAP_DON_VI")
        private String organizationLevel;
        @Column(name = "TEN_CAP_DON_VI")
        private String nameOrganizationLevel;
        @Column(name = "HIEN_THI_TAI_KHOAN")
        private String displayAccount;
}
