package vn.gtel.app_mng.account.reponse;

import lombok.Data;

@Data
public class GeneralConfigResponseDTO {
    private String key;
    private String text;
    private String value;
    private String default_value;
    private String datatypes;
    private String unit;
    private String description;
    private String status;
}
