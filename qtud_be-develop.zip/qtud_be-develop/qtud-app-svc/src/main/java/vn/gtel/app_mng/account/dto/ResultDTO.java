package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ResultDTO {
    @Column(name = "KET_QUA")
    private String  result;
}
