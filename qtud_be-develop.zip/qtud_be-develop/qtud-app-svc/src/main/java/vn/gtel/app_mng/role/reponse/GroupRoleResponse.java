package vn.gtel.app_mng.role.reponse;

import lombok.Data;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Column;

@Data
public class GroupRoleResponse extends AuditItemResponse {

    @Column(name = "MA")
    private String code;

    @Column(name = "TEN")
    private String name;

    @Column(name = "MO_TA")
    private String description;

    @Column(name = "ID_NHOM_QUYEN")
    private String idGroup;

    @Column(name = "MA_UNG_DUNG")
    private String app;

    @Column(name = "TEN_UNG_DUNG")
    private String appName;

    @Column(name = "NGUON_DICH_VU")
    private Integer serviceSource;

}
