package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
public class OrganizationManage {
    @Basic
    @Column(name = "MA")
    private String organizationCode;

    @Basic
    @Column(name = "TEN")
    private String organizationName;

}
