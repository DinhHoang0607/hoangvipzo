
/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationService.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 10:43 AM
 */

package vn.gtel.app_mng.category.service;

import javassist.NotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.req.ApplicationFilter;
import vn.gtel.app_mng.category.dto.req.ApplicationRequestCodeDTO;
import vn.gtel.app_mng.category.dto.req.ChangeSecretReqDTO;
import vn.gtel.app_mng.category.dto.req.TypeFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.xml.bind.ValidationException;


public interface ApplicationService {

    ResponseBase list(TypeFilter textFilter, Integer status) throws IllegalAccessException;

    ResponseBase detail(String id) throws Exception;

    ResponseBase save(ApplicationRequestCodeDTO applicationRequestDTO) throws Exception;

    ResponseBase delete(String id) throws Exception;

    ResponseEntity importExcel(MultipartFile file) throws Exception;

    ResponseBase setActiveDeActive(String id) throws Exception;

    ResponseBase changeCs(ChangeSecretReqDTO changePWRequestDTO) throws IllegalAccessException, ValidationException, NotFoundException;

    ResponseBase list(ApplicationFilter filter) throws IllegalAccessException;
}