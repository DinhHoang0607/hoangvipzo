package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountTransferOrgFilter extends TextFilter {

    private String organization;
    private String fullName;
    private String account;
    private String policeNumber;
    private Integer type;
    private Integer status;

    public AccountTransferOrgFilter(Integer page, Integer size, String keySearch, String organization, String fullName, String account, String policeNumber, Integer type,Integer status) {
        super(page, size, keySearch);
        this.organization = organization;
        this.fullName = fullName;
        this.account = account;
        this.policeNumber = policeNumber;
        this.type = type;
        this.status = status;
    }
}
