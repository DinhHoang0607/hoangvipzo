 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
@NoArgsConstructor
public class AppTextFilter extends TextFilter{
	
	private String app;
	private String menu;
	private String name;
	private String parentMenuCode;
	private String status;
	
    public AppTextFilter(Integer page, Integer size, String keySearch, String app) {
        super(page, size, keySearch);
        this.app = app;
    }

    public AppTextFilter(Integer page, Integer size, String keySearch, String app, String menu, String name, String parentMenuCode, String status ) {
        super(page, size, keySearch);
        this.app = app;
        this.menu = menu;
        this.name = name;
        this.parentMenuCode = parentMenuCode;
        this.status = status;
    }
}
