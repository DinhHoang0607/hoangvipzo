package vn.gtel.app_mng.account.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import javassist.NotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.account.dto.GeneralConfigDTO;
import vn.gtel.app_mng.account.dto.request.GeneralConfigRequest;
import vn.gtel.app_mng.account.filter.GeneralConfigFilterDTO;
import vn.gtel.app_mng.account.service.GeneralConfigService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Tag(name = "Cấu hình chung ")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/general-config")
@AllArgsConstructor
public class GeneralConfigController {

    private final GeneralConfigService generalConfigService;

    @Operation(summary = "Thêm mới / chỉnh sửa cấu hình cấu hình chung ")
    @PostMapping
    public ResponseBase insertOrUpdateGeneralConfig(@RequestBody GeneralConfigDTO generalConfigDTO) throws IllegalAccessException {
        return generalConfigService.insertOrUpdateGeneralConfig(generalConfigDTO);
    }

    @Operation(summary = "Xóa cấu hình chung")
    @GetMapping("/{id}")
    public ResponseBase deleteGeneralConfig(@PathVariable(name = "id") String id) {
        return generalConfigService.deleteGeneralConfig(id);
    }

    @Operation(summary = "dạnh sách cấu hình chung")
    @GetMapping
    public ResponseBase listGeneralConfig(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        TextFilter textFilter = new TextFilter(page, size, keySearch);
        return generalConfigService.listGeneralConfig(textFilter);
    }

    @Operation(summary = "Dạnh sách cấu hình chung 2")
    @PostMapping("/list")
    public ResponseBase list(@RequestBody GeneralConfigFilterDTO filter) throws IllegalAccessException {
        return generalConfigService.list(filter);
    }

    @Operation(summary = "Lưu nhiều cấu hình")
    @PostMapping("/save")
    public ResponseBase saveAll(@RequestBody GeneralConfigRequest request) throws IllegalAccessException {
        return generalConfigService.saveAll(request);
    }

    @Operation(summary = "")
    @GetMapping("/password-rules")
    public ResponseBase passwordRules() throws IllegalAccessException {
        return generalConfigService.getPasswordRules();
    }

    @Operation(summary = "")
    @GetMapping("/get-by-key")
    public ResponseBase getByKey(@RequestParam String key) throws NotFoundException {
        return generalConfigService.getByKey(key);
    }

//    @Operation(summary = "Danh sách hướng dẫn sử dụng")
//    @GetMapping(value = "/instruction-manual/list")
//    public ResponseBase instructionManualList() throws Exception {
//        return generalConfigService.showInstructionManualList();
//    }
//
//    @Operation(summary = "Tải template doc")
//    @GetMapping(value = "/instruction-manual")
//    public ResponseEntity instructionManual(@RequestParam(name = "type", required = false) Optional<Integer> type) throws Exception {
//        return generalConfigService.getInstructionManual(type.orElse(0));
//    }
}
