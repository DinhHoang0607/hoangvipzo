package vn.gtel.app_mng.role.reponse.roleAccount;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.account.reponse.GroupAccountReponse;
import vn.gtel.app_mng.role.dto.RoleItemDTO;
import vn.gtel.app_mng.role.dto.role_account.RoleDTO;
import vn.gtel.app_mng.role.reponse.GroupRoleResponse;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleAccountResponse {
	private String groupRole;
	private String groupRoleId;
	private List<String> applications;
	private List<RoleItemDTO> roles;
}
