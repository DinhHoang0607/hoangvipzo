package vn.gtel.app_mng.category.dto.res;

import lombok.Data;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Column;

@Data
public class AuditCategoryResponseDTO extends AuditItemResponse {

    @Column(name = "THU_TU")
    private Long order;
}
