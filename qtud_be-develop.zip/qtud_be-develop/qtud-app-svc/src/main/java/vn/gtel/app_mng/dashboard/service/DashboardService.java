/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  DashboardService.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/1/22, 10:30 AM
 *
 */

package vn.gtel.app_mng.dashboard.service;

import org.springframework.http.ResponseEntity;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.dashboard.dto.req.GridFilter;

public interface DashboardService {
    ResponseBase onlineCurrent();
    ResponseBase sumAccessByTime();
    ResponseBase countAccessByApp(FilterChart filterChart) throws IllegalAccessException;
    ResponseBase countOnlineByCity(GridFilter gridFilter) throws IllegalAccessException;
    ResponseBase getChartValue(FilterChart filterChart) throws IllegalAccessException;
    ResponseBase getCountAccount();

    ResponseEntity onlineByCityExport(GridFilter gridFilter) throws Exception;

    ResponseBase getCountAccountByOrg(String orgCode);
}
