package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Column;
import java.time.Instant;
import java.util.List;

@Data
public class AccountHistoryResponse {
    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "THOI_GIAN_BAT_DAU")
    private Instant startDate;

    @Column(name = "THOI_GIAN_KET_THUC")
    private Instant endDate;

    @Column(name = "DON_VI")
    private String organization;

    @Column(name = "HIEN_THI_DON_VI")
    private String displayOrganization;

    @Column(name = "CHUC_VU")
    private String position;

    @Column(name = "HIEN_THI_CHUC_VU")
    private String displayPosition;

    @Column(name = "CAP_BAC")
    private String military;

    @Column(name = "HIEN_THI_CAP_BAC")
    private String displayMilitary;

    @Column(name = "CHUC_DANH")
    private String dignity;

    @Column(name = "HIEN_THI_CHUC_DANH")
    private String displayDignity;

    private List<String> changeField;
}
