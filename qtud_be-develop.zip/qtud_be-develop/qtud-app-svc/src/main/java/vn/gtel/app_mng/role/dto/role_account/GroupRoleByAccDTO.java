package vn.gtel.app_mng.role.dto.role_account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.role.dto.RoleItemDTO;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GroupRoleByAccDTO implements Serializable {
	@Size(max = Constants.VALID.MAX_LENGTH_CODE, message = "error.common.validate.max.size.32")
	private String acc;


	private List<String> apps;
//	private List<String> groups;
	private String notAcc;
    private Integer page;
    private Integer size;
	private String keySearch;
	private String position;
}
