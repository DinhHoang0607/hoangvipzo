package vn.gtel.app_mng.maintenance.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;

import java.time.Instant;

@Data
@AllArgsConstructor
public class ServerStatusDTO {
    private Long status;
    private String statusName;
    private String message;
    private Instant startedDate;
    private Instant finishedDate;
    private Instant currentDate;
    private Long countDown;

    public ServerStatusDTO() {
        this.status = Constants.SERVER_STATUS.NORMAL_CODE;
        this.statusName = Constants.SERVER_STATUS.NORMAL;
        this.currentDate = Instant.now();
    }
}
