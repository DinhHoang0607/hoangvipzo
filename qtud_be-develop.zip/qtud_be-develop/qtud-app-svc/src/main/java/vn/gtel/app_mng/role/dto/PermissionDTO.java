package vn.gtel.app_mng.role.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PermissionDTO {
    @Column(name = "MA_QUYEN")
    private String permissionCode;

    @Column(name = "MA_QUYEN_KHAC")
    private String permissionCodeOther;
}
