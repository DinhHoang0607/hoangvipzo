package vn.gtel.app_mng.role.reponse;

import javax.persistence.Column;

import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

public class RoleTempAppReponse extends AuditItemResponse {
	@Column(name = "ID_UNG_DUNG")
	private String applicationId;
	
	@Column(name = "ID_NHOM_QUYEN")
	private String groupRoleId;
	
	@Column(name = "TEN_NHOM_QUYEN")
	private String groupRoleName;
}
