package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_TK_TAI_KHOAN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountView {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
//    @Column(name = "HO_TEN")
    @Formula(value = "(select nd.HO_TEN from TBL_TK_NGUOI_DUNG nd where nd.TAI_KHOAN = TAI_KHOAN )")
    private String fullName;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Long type;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

    @Formula(value = "(select dv.TEN from syn_TBL_DM_DON_VI dv " +
            "where dv.MA = DON_VI )")
    private String organizationName;

    //    @Column(name = "CHUC_VU")
    @Formula(value = "(select nd.CHUC_VU from TBL_TK_NGUOI_DUNG nd where nd.TAI_KHOAN = TAI_KHOAN )")
    private String position;

    //    @Column(name = "CAP_BAC")
    @Formula(value = "(select nd.CAP_BAC from TBL_TK_NGUOI_DUNG nd where nd.TAI_KHOAN = TAI_KHOAN )")
    private String military;

    @Formula(value = "(select cv.TEN from TBL_DM_CHUC_VU cv " +
            "left join TBL_TK_NGUOI_DUNG nd on nd.CHUC_VU = cv.MA and cv.TRANG_THAI = 1 " +
            "where nd.TAI_KHOAN = TAI_KHOAN )")
    private String positionName;

    @Formula(value = "(select cb.TEN from TBL_DM_CAP_BAC cb " +
            "left join TBL_TK_NGUOI_DUNG nd on nd.CAP_BAC = cb.MA and cb.TRANG_THAI = 1 " +
            "where nd.TAI_KHOAN = TAI_KHOAN )")
    private String militaryName;

    @Basic
//    @Column(name = "SO_HIEU_CAND")
    @Formula(value = "(select nd.SO_HIEU_CAND from TBL_TK_NGUOI_DUNG nd where nd.TAI_KHOAN = TAI_KHOAN )")
    private String policeNumber;


    @Basic
//    @Column(name = "DIEN_THOAI")
    @Formula(value = "(select nd.DIEN_THOAI from TBL_TK_NGUOI_DUNG nd where nd.TAI_KHOAN = TAI_KHOAN )")
    private String phone;

    @Basic
    @Column(name = "TRANG_THAI")
    private Long status;
}
