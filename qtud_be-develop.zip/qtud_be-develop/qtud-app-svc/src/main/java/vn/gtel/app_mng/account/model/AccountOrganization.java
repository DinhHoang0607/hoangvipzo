package vn.gtel.app_mng.account.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import vn.gtel.app_mng.account.dto.request.AccountTransferReq;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferReq;
import vn.gtel.app_mng.common.model.AuditModel;
import vn.gtel.app_mng.common.model.AuditModelBase;

import java.time.Instant;

@Entity
@Table(name = "TBL_TK_CHUYEN_DON_VI")
@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class AccountOrganization extends AuditModelBase {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "SO_QUYET_DINH")
    private String decisionNo;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "DON_VI_CU")
    private String oldOrganization;

    @Basic
    @Column(name = "DON_VI_MOI")
    private String newOrganization;

    @Basic
    @Column(name = "GHI_CHU")
    private String note;

    @Basic
    @Column(name = "NGAY_QUYET_DINH")
    private Instant decisionDate;

    @Basic
    @Column(name = "NGUOI_KY")
    private String decisionSigner;

    @Basic
    @Column(name = "LOAI_DIEU_CHUYEN")
    private Integer transferType;

    @Basic
    @Column(name = "CHUC_VU")
    private String position;

    @Basic
    @Column(name = "CAP_BAC")
    private String military;

    public AccountOrganization(String account, String oldOrganization, String newOrganization, String note) {
        this.account = account;
        this.oldOrganization = oldOrganization;
        this.newOrganization = newOrganization;
        this.note = note;
    }

    public AccountOrganization(OrganizationTransferReq request) {
        this.decisionNo = request.getDecisionNo();
        this.account = request.getAccount();
        this.oldOrganization = request.getOldOrganization();
        this.newOrganization = request.getNewOrganization();
        this.decisionDate = request.getDecisionDate();
        this.decisionSigner = request.getDecisionSigner();
        this.note = note;
        this.position = request.getPosition();
        this.military = request.getMilitary();
    }

    public AccountOrganization(AccountTransferReq request, String decisionNo, Instant decisionDate, String decisionSigner) {
        this.decisionNo = decisionNo;
        this.account = request.getAccount();
        this.oldOrganization = request.getOldOrganization();
        this.newOrganization = request.getNewOrganization();
        this.decisionDate = decisionDate;
        this.decisionSigner = decisionSigner;
    }

    public AccountOrganization(AccountTransferReq request, Integer transferType) {
        this.transferType = transferType;
        this.account = request.getAccount();
        this.oldOrganization = request.getOldOrganization();
        this.newOrganization = request.getNewOrganization();
    }
}
