package vn.gtel.app_mng.account.filter;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
public class AccountWithPositionTypeInOrgFilter extends TextFilter {
    private String position;
    private String positionType;
    private String organization;
    private String leader;
    private String staff;
    private Integer type;

    public AccountWithPositionTypeInOrgFilter(String position, String positionType, String organization, String leader, String staff, String keySearch, Integer page, Integer size,Integer type) {
        super(page, size, keySearch);
        this.position = position;
        this.positionType = positionType;
        this.organization = organization;
        this.leader = leader;
        this.staff = staff;
        this.type=type;
    }
}
