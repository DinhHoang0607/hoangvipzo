package vn.gtel.app_mng.common.dto.response;

import lombok.Data;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;

@Data
public class PermissionForLogDTO {

    @Column(name = "MA_UNG_DUNG")
    private String appCode;

    @Column(name = "TEN_UNG_DUNG")
    private String appName;

    @Column(name = "MA_CHUC_NANG")
    private String menuCode;

    @Column(name = "TEN_CHUC_NANG")
    private String menuName;

    @Column(name = "MA_HANH_DONG")
    private String actionCode;

    @Column(name = "TEN_HANH_DONG")
    private String actionName;

    @Column(name = "MA_QUYEN")
    private String permissionCode;

    @Column(name = "PHUONG_THUC")
    private String method;

    @Column(name = "DUONG_DAN")
    private String endpoint;


}
