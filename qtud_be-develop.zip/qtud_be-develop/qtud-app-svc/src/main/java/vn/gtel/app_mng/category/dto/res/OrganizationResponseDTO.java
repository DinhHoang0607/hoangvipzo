package vn.gtel.app_mng.category.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.common.dto.response.AuditCategoryResponseDTO;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationResponseDTO extends AuditCategoryResponseDTO {

    @Basic
    @Column(name = "MA_CHUAN_QG")
    private String countryCode;
    @Basic
    @Column(name = "DON_VI_TRUC_THUOC")
    private String organizationTop;
    @Basic
    @Column(name = "DON_VI_CU")
    private String organizationOld;
    @Basic
    @Column(name = "DON_VI_CHA")
    private String organizationParent;
    @Basic
    @Column(name = "CUM")
    private String cluster;
    @Basic
    @Column(name = "NHOM_DON_VI")
    private String organizationGroup;
    @Basic
    @Column(name = "LOAI_DON_VI")
    private String organizationType;
    @Basic
    @Column(name = "CAP_DON_VI")
    private String organizationLevel;
    @Basic
    @Column(name = "HE_LUC_LUONG")
    private String cardinality;
    @Basic
    @Column(name = "DIA_CHI")
    private String address;
    @Basic
    @Column(name = "PHUONG_XA")
    private String village;
    @Basic
    @Column(name = "QUAN_HUYEN")
    private String district;
    @Basic
    @Column(name = "TINH_TP")
    private String country;
    @Basic
    @Column(name = "VUNG")
    private String area;
    @Basic
    @Column(name = "MIEN")
    private String region;
    @Basic
    @Column(name = "THONG_KE")
    private Long statistic;
    @Basic
    @Column(name = "NGAY_THANH_LAP")
    private Date establish;
    @Basic
    @Column(name = "THU_TU")
    private Long order;
    @Basic
    @Column(name = "TEN_DON_VI_CHA")
    private String organizationName;
    @Basic
    @Column(name = "TEN_CAP_DON_VI")
    private String organizationLevelName;
    private String fullName;

    public OrganizationResponseDTO(Organization entity) {
        this.setId(entity.getId());
        this.setCode(entity.getCode());
        this.setName(entity.getName());
        this.setFullName(entity.getFullName());
    }
}
