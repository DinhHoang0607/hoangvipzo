/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  ReportController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/1/22, 5:00 PM
 *
 */

package vn.gtel.app_mng.report.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.dashboard.storeObj.DashboardCallStoredDTO;
import vn.gtel.app_mng.report.dto.filter.StatisticFilter;
import vn.gtel.app_mng.report.service.ReportService;
import vn.gtel.app_mng.report.storeObj.ReportCallStoredDTO;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.io.IOException;
import java.time.Instant;

@Tag(name = "Báo cáo")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/report")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @Operation(summary = "Kết xuất báo cáo thống kê số lượng tài khoản")
    @GetMapping(value = "/sum-account/export")
    public ResponseEntity exportSumAccount(@RequestParam(name = "statisticType", required = false) Integer statisticType,
                                           @RequestParam(name = "accountName", required = false) String accountName,
                                           @RequestParam(name = "orderBy", required = false) String orderBy,
                                           @RequestParam(name = "displayNameMode", required = false) String displayNameMode,
                                           @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
                                           @RequestParam(name = "organization", required = false) String organization,
                                           @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
                                           @RequestParam(name = "originOrganization", required = false) String originOrganization,
                                           @RequestParam(name = "app", required = false) String app,
                                           @RequestParam(name = "groupRole", required = false) String groupRole,
                                           @RequestParam(name = "manager", required = false) String manager,
                                           @RequestParam(name = "provinceCode", required = false) String provinceCode,
                                           @RequestParam(name = "from", required = false) Instant fromDate,
                                           @RequestParam(name = "to", required = false) Instant toDate) throws Exception {
        StatisticFilter filter = new StatisticFilter(statisticType, accountName, orderBy, displayNameMode, organization, originOrganization, app, groupRole, manager, provinceCode, fromDate, toDate);
        return reportService.sumAccount(filter, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "In báo cáo thống kê số lượng tài khoản")
    @GetMapping(value = "/sum-account/print")
    public ResponseEntity printSumAccount(@RequestParam(name = "statisticType", required = false) Integer statisticType,
                                          @RequestParam(name = "accountName", required = false) String accountName,
                                          @RequestParam(name = "orderBy", required = false) String orderBy,
                                          @RequestParam(name = "displayNameMode", required = false) String displayNameMode,
                                          @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
                                              @RequestParam(name = "organization", required = false) String organization,
                                          @Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
                                              @RequestParam(name = "originOrganization", required = false) String originOrganization,
                                          @RequestParam(name = "app", required = false) String app,
                                          @RequestParam(name = "groupRole", required = false) String groupRole,
                                          @RequestParam(name = "manager", required = false) String manager,
                                          @RequestParam(name = "provinceCode", required = false) String provinceCode,
                                          @RequestParam(name = "from", required = false) Instant fromDate,
                                          @RequestParam(name = "to", required = false) Instant toDate) throws Exception {
        StatisticFilter filter = new StatisticFilter(statisticType, accountName, orderBy, displayNameMode, organization, originOrganization, app, groupRole, manager, provinceCode, fromDate, toDate);
        return reportService.sumAccount(filter, Constants.EXPORT_TYPE.PDF.toString());
    }

    @Operation(summary = "Kết xuất số lượt truy cập theo phần mềm")
    @GetMapping(value = "/access-by-app/export")
    public ResponseEntity exportAccessByApp(@NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime, @NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime, @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType, @RequestParam(name = "orgCode", required = false) String orgCode) throws Exception {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_COUNT_BY_APP, true, orgCode);
        return reportService.sumAccessByApp(filterChart, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "Kết xuất số lượt truy cập theo đơn vị")
    @GetMapping(value = "/access-by-org/export")
    public ResponseEntity exportAccessByOrg(@NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime, @NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime, @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType, @RequestParam("orgCode") String orgCode) throws Exception {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_COUNT_BY_ORG, true, orgCode);
        return reportService.sumAccessByOrg(filterChart, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "In số lượt truy cập theo phần mềm")
    @GetMapping(value = "/access-by-app/print")
    public ResponseEntity printAccessByApp(@NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime, @NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime, @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType, @RequestParam(name = "orgCode", required = false) String orgCode) throws Exception {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_COUNT_BY_APP, true, orgCode);
        return reportService.sumAccessByApp(filterChart, Constants.EXPORT_TYPE.PDF.toString());
    }

    @Operation(summary = "In số lượt truy cập theo đơn vị")
    @GetMapping(value = "/access-by-org/print")
    public ResponseEntity printAccessByOrg(@NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime, @NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime, @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType, @RequestParam("orgCode") String orgCode) throws Exception {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_COUNT_BY_ORG, true, orgCode);
        return reportService.sumAccessByOrg(filterChart, Constants.EXPORT_TYPE.PDF.toString());
    }


    @Operation(summary = "Kết xuất báo cáo thống kê tài khoản")
    @GetMapping(value = "/sum-account/total")
    public ResponseEntity exportSumAccountTotal(@RequestParam(name = "from", required = false) Instant fromDate, @RequestParam(name = "to", required = false) Instant toDate) throws IOException, JRException, IllegalAccessException {
        return reportService.sumAccountTotal(fromDate, toDate, Constants.EXPORT_TYPE.XLSX.toString());
    }

    @Operation(summary = "BC sl cảnh báo")
    @GetMapping(value = "/count-warning/{type}")
    public ResponseEntity countWarning(@NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime, @NotNull(message = "error.common.validate.not.null") @Min(value = 2022L, message = "error.common.validate.min.value.2022") @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime, @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType, @PathVariable String type) throws Exception {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, ReportCallStoredDTO.PROC_COUNT_WARNING);
        return reportService.countWarning(filterChart, type);
    }

    @Operation(summary = "BC sl tài khoản chuyển đơn vị")
    @GetMapping(value = "/account-organization/print")
    public ResponseEntity printAccountOrganization(@Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
                                              @RequestParam(name = "originOrganization", required = false) String originOrganization,
                                              @RequestParam(name = "from", required = false) Instant fromDate,
                                              @RequestParam(name = "to", required = false) Instant toDate) throws Exception {
        StatisticFilter filter = new StatisticFilter(null, null, null, null, null,
                originOrganization, null, null, null, null, fromDate, toDate);

        return reportService.reportAccountTransfer(filter, Constants.EXPORT_TYPE.PDF.toString());
    }

    @Operation(summary = "BC sl tài khoản chuyển đơn vị")
    @GetMapping(value = "/account-organization/export")
    public ResponseEntity accountOrganization(@Valid @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
                                              @RequestParam(name = "originOrganization", required = false) String originOrganization,
                                              @RequestParam(name = "from", required = false) Instant fromDate,
                                              @RequestParam(name = "to", required = false) Instant toDate) throws Exception {
        StatisticFilter filter = new StatisticFilter(null, null, null, null, null,
                originOrganization, null, null, null, null, fromDate, toDate);

        return reportService.reportAccountTransfer(filter, Constants.EXPORT_TYPE.XLSX.toString());
    }
}
