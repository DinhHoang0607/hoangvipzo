package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.account.model.AccountServiceDetail;

import java.util.List;

@Repository
public interface AccountEmployeeDetailRepository extends JpaRepository<AccountEmployeeDetail, String>{

    AccountEmployeeDetail findByAccount(String account);
    AccountEmployeeDetail findByPoliceNumberAndFullName(String policeNumber,String fullName);
    @Query(value = "select count(*) from TBL_TK_NGUOI_DUNG where tai_khoan = :account ", nativeQuery = true)
    int checkExist(String account);
    @Query(value = "select count(*) from tbl_dm_chuc_danh where ma in (select ma from tbl_dm_chuc_danh where ma = :code) and ma in (008,015,019,005) ", nativeQuery = true)
    int checkCategory(String code);
    @Query(value = "select count(*) from tbl_dm_don_vi where ma_don_vi_H05 in (select ma_don_vi_H05 from tbl_dm_chuc_danh where ma_don_vi_H05 = :userName) and ma_don_vi_H05 in (select ma_don_vi_H05 from tbl_dm_don_vi where ma_don_vi_H05 is not null)", nativeQuery = true)
    int checkMaDVH05 (String userName);

//    @Query(value = "select case when count(a) > 0 then false else true end from AccountEmployeeDetail a where a.phone = :phone ");
    boolean existsByPhone(String phone);

    @Query(value = "select * from TBL_TK_TAI_KHOAN tk JOIN\n" +
            "TBL_TK_NGUOI_DUNG nd\n" +
            "on tk.TAI_KHOAN = nd.TAI_KHOAN\n" +
            "where nd.TRANG_THAI_CHUYEN <0 and tk.DON_VI like ?1 || '%'", nativeQuery = true)
    List<AccountEmployeeDetail> findAccountByStatus(String organization);

    AccountEmployeeDetail findByPoliceNumber(String policeNumber);
    AccountEmployeeDetail findByPhone(String phoneNumber);
    void deleteAllByAccount(String account);

    boolean existsByPoliceNumber(String encrypt);

    @Query(value = "select case when nd.PHAN_LOAI = 1 then 'ADMIN' else 'USER' end as role from TBL_TK_NGUOI_DUNG nd\n" +
            " left join TBL_TK_TAI_KHOAN tk on tk.TAI_KHOAN = nd.TAI_KHOAN where tk.TAI_KHOAN = :userName", nativeQuery = true)
    String checkAdminAccount(String userName);

}
