package vn.gtel.app_mng.feedback.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.feedback.model.Feedback;

import javax.transaction.Transactional;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, String> {

    @Transactional
    @Modifying
    @Query(value = "update Feedback set classify = :classify,status = :status, organization = :organization where id = :id  ", nativeQuery = false)
    int updateStatusAndOrganizationById(Integer classify,Integer status, String organization , String id);

    @Transactional
    @Modifying
    @Query(value = "update Feedback set status = :status, organization = :organization, processor = :processor  where id = :id ", nativeQuery = false)
    int updateStatusAndOrganizationAndProcessorById(Integer status, String organization , String processor,String id);

    @Transactional
    @Modifying
    @Query(value = "update Feedback set status = :status  where id = :id ", nativeQuery = false)
    int updateCloseStatusById(Integer status, String id);

    @Transactional
    @Modifying
    @Query(value = "update Feedback set status = :status where id = :id ", nativeQuery = false)
    void updateStatusById(Integer status,String id);



}
