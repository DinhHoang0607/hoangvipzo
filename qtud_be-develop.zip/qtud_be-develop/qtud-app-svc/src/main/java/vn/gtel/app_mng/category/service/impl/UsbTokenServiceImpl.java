
/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  UsbTokenServiceImpl.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  1/17/22, 4:46 PM
 *
 */

package vn.gtel.app_mng.category.service.impl;

import javassist.NotFoundException;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.hibernate.exception.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.service.AccountService;
import vn.gtel.app_mng.category.dto.excelObj.UsbTokenExcelItemObj;
import vn.gtel.app_mng.category.dto.excelObj.UsbTokenExcelObj;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterV2DTO;
import vn.gtel.app_mng.category.dto.res.UsbTokenResponseDTO;
import vn.gtel.app_mng.category.model.UsbToken;
import vn.gtel.app_mng.account.repository.UsbTokenRepository;
import vn.gtel.app_mng.category.dto.req.UsbTokenFilterDTO;
import vn.gtel.app_mng.category.dto.req.UsbTokenRequestDTO;
import vn.gtel.app_mng.category.dto.storedObj.UsbTokenCallStoredDTO;
import vn.gtel.app_mng.category.repo.UsbTokenHistoryRepository;
import vn.gtel.app_mng.category.service.UsbTokenService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;
import vn.gtel.app_mng.common.dto.response.DetailResponse;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CommonService;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.ExcelObjectMapper;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

@Service
public class UsbTokenServiceImpl implements UsbTokenService {

    @Autowired
    private UsbTokenRepository usbTokenRepository;

    @Autowired
    private UsbTokenHistoryRepository usbTokenHistoryRepository;

    @Autowired
    private CallStoredRepository callStoredRepository;

    @Autowired
    private ModelMapper mapper;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    private static final String PREFIX_ERR_CONSTRAINT_MESSAGE = "ConstraintViolationException.";

    @Autowired
    private TrimSpaceUtil trimSpaceUtil;
    @Autowired
    private AccountService accountService;

    @Override
    public ResponseBase list(UsbTokenFilterV2DTO usbTokenFilterDTO) throws IllegalAccessException {
        trimSpaceUtil.validate(usbTokenFilterDTO);
        ICallStoredObj callStoredObj = new UsbTokenCallStoredDTO(usbTokenFilterDTO);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase detail(String id) throws Exception {
        ICallStoredObj callStoredObj = new UsbTokenCallStoredDTO(id);
        Object res = callStoredRepository.findById(callStoredObj);
        UsbTokenResponseDTO usbTokenResponseDTO = (UsbTokenResponseDTO) res;

//        ICallStoredObj callHisStoredObj = new UsbTokenCallStoredDTO(((UsbTokenResponseDTO) res).getCode(), true);
//        List<UsbTokenHisResponseDTO> histories = (List<UsbTokenHisResponseDTO>) callStoredRepository.getList(callHisStoredObj);
        //usbTokenResponseDTO.setUsbTokenHistories(histories);
        return new ResponseBase(new DetailResponse(usbTokenResponseDTO));
    }

    @Override
    public ResponseBase save(UsbTokenRequestDTO usbTokenRequestDTO) throws Exception {
        trimSpaceUtil.validate(usbTokenRequestDTO);
        boolean isUpdate = false;
        UsbToken usbToken = null;
        if(usbTokenRequestDTO.getAccountCode() != null){
            usbToken = usbTokenRepository.findByAccountCode(usbTokenRequestDTO.getAccountCode()).orElse(null);
        }
        if (usbToken == null){
            usbToken = new UsbToken();
        }

        usbToken.setAccountCode(usbTokenRequestDTO.getAccountCode());
        String decode = accountService.enPassWordAES(usbTokenRequestDTO.getDigitalCertificate());
        UsbToken digitalCertificate = usbTokenRepository.findByDigitalCertificate(decode).orElse(null);
        if(digitalCertificate != null && digitalCertificate.getAccountCode() != null
                && !digitalCertificate.getAccountCode().equals(usbTokenRequestDTO.getAccountCode())){
            return new ResponseBase("404", "USB token đã được gán với một tài khoản khác");
        }
        usbToken.setDigitalCertificate(decode);
//        if (usbTokenRequestDTO.getId() != null && !usbTokenRequestDTO.getId().isEmpty()) {
//            isUpdate = true;
//        }
//
//        if (isUpdate) {
//            usbToken = usbTokenRepository.findById(usbTokenRequestDTO.getId()).orElse(new UsbToken());
//            String oldAccount = usbToken.getAccountCode();
//            if (!oldAccount.equals(usbTokenRequestDTO.getAccountCode())) {
//                // Thay doi nguoi su dung
//                UsbTokenHistory usbTokenHistory = mapper.map(usbToken, UsbTokenHistory.class);
//                usbTokenHistory.setAccount(usbToken.getAccountCode());
//                usbTokenHistoryRepository.save(usbTokenHistory);
//            }
//            mapper.getConfiguration().setSkipNullEnabled(true);
//            mapper.map(usbTokenRequestDTO, usbToken);
//        } else {
//            // 2 la to chuc
////                Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse(usbTokenRequestDTO.getDateOfIssue());
////                Instant startInstant = startDate.toInstant();
//                usbToken = mapper.map(usbTokenRequestDTO, UsbToken.class);
////            usbToken.setDateOfIssue(startInstant);
//
//        }
        return new ResponseBase(new DetailResponse(usbTokenRepository.save(usbToken)));
    }


    @Override
    public ResponseBase delete(String id) throws Exception {
        UsbToken usbToken = usbTokenRepository.findById(id).orElse(new UsbToken());
        if (usbToken.getId() == null) {
            throw new NotFoundException(String.format("Khong tim thay usb token %s !", id));
        }
        usbToken.setStatus(Constants.USB_TOKEN_STATUS.DELETED);

        return new ResponseBase(new DetailResponse(usbTokenRepository.save(usbToken)));
    }

    @Override
    public ResponseBase deleteDB(String id) throws Exception {
        UsbToken usbToken = usbTokenRepository.findById(id).orElse(new UsbToken());
        if (usbToken.getId() == null) {
            throw new NotFoundException(String.format("Khong tim thay usb token %s !", id));
        }
        usbTokenRepository.delete(usbToken);
        return new ResponseBase("Xóa thành công " + id);
    }

    @Override
    public ResponseBase activeInActive(String id) throws Exception {
        UsbToken usbToken = usbTokenRepository.findById(id).orElse(new UsbToken());
        if (usbToken.getId() == null) {
            throw new NotFoundException(String.format("Khong tim thay usb token %s !", id));
        }
        if (usbToken.getStatus().equals(Constants.USB_TOKEN_STATUS.INACTIVE) || usbToken.getStatus().equals(Constants.USB_TOKEN_STATUS.ACTIVE)) {
            Integer tobeUpdateStatus = Constants.USB_TOKEN_STATUS.INACTIVE;
            if (usbToken.getStatus().equals(Constants.USB_TOKEN_STATUS.INACTIVE)) {
                tobeUpdateStatus = Constants.USB_TOKEN_STATUS.ACTIVE;
            }
            usbToken.setStatus(tobeUpdateStatus);

            return new ResponseBase(new DetailResponse(usbTokenRepository.save(usbToken)));
        } else return new ResponseBase("Do not anything!");
    }

    @Override
    public ResponseEntity export(UsbTokenFilterDTO usbTokenFilterDTO, String type) throws FileNotFoundException, JRException {
        JRDataSource dataSource = new JREmptyDataSource();
        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
        String templatePath = "dm_usb_token.jasper";
        String fileName = "danh_muc_usb_token";
        String mimeType = "." + type.toLowerCase(Locale.ENGLISH);
        Map<String, Object> reportParams = new HashMap<>();

        ICallStoredObj callStoredObj = new UsbTokenCallStoredDTO(usbTokenFilterDTO);
        Object res = callStoredRepository.list(callStoredObj);
        List<UsbTokenResponseDTO> lstResults = (List<UsbTokenResponseDTO>) ((ListResponse) res).getList();
        // insert empty into 0 index
        lstResults.add(0, new UsbTokenResponseDTO());
        dataSource = new JRBeanCollectionDataSource(lstResults);
        reportParams.put("dataSource", dataSource);

        oStream = CommonService.generateReport(dataSource, templatePath, reportParams, type.toLowerCase(Locale.ENGLISH));
        return CommonUtils.downloadFileJasper(oStream, fileName + "_" + sdf.format(new Date()) + mimeType);
    }

    @Override
    public ResponseEntity importExcel(MultipartFile file) throws Exception {
        int sheetAt = 0;
        int firstRow = 1;
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj = new UsbTokenExcelObj(0);
        List<UsbTokenExcelItemObj> list = excelObjectMapper.map(UsbTokenExcelItemObj.class, sheetAt, iExcelMapperObj, firstRow);

        saveDataExcel1(excelObjectMapper, sheetAt, firstRow, list);

        //sheet 2
        IExcelMapperObj iExcelMapperObj1 = new UsbTokenExcelObj(0,2);
        List<UsbTokenExcelItemObj> list1 = excelObjectMapper.map(UsbTokenExcelItemObj.class, 1, iExcelMapperObj1, 2);
        return saveDataExcel(excelObjectMapper, 1, 2, list1);
    }

    public ResponseEntity saveDataExcel(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<UsbTokenExcelItemObj> list) throws Exception {
        List<UsbToken> usbTokens = new ArrayList<>();
        Map<Integer, String> errMap = new HashMap<>();
        for (UsbTokenExcelItemObj usbTokenExcelItemObj : list) {
            if (!isEmptyObj1(usbTokenExcelItemObj)) {
                String messageError = "";
                int flag = 0;
                int checkDate = 0;
                if (StringUtils.isEmpty(usbTokenExcelItemObj.getCmmdDatePlace())) {
                    messageError += Messages.getString("ValidationException.error.not.null.cmnd.date.place");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCmndDatePlace(usbTokenExcelItemObj.getCmmdDatePlace());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(usbTokenExcelItemObj.getAccountCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.tk.name");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorAccountMsg(usbTokenExcelItemObj.getAccountCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(usbTokenExcelItemObj.getAreaAdministrative())) {
                    messageError += Messages.getString("ValidationException.error.not.null.city");
                    flag++;
                    checkDate++;
                } else {
                    String messageError1 = CommonUtils.errorCity(usbTokenExcelItemObj.getAreaAdministrative());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                        checkDate++;
                    }
                }
                if(StringUtils.isNotEmpty(usbTokenExcelItemObj.getCode())) {
                    String messageError1 = CommonUtils.errorDigitalCertificate(usbTokenExcelItemObj.getCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                        checkDate++;
                    }
                }
                if (!StringUtils.isEmpty(usbTokenExcelItemObj.getSim())) {
                    String messageError1 = CommonUtils.errorSim(usbTokenExcelItemObj.getSim());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if(StringUtils.isNotEmpty(usbTokenExcelItemObj.getAddress())){
                    String messageError1 = CommonUtils.errorAddress(usbTokenExcelItemObj.getAddress());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                UsbToken usbToken = mapper.map(usbTokenExcelItemObj, UsbToken.class);
                usbToken.setStatus(Constants.APPLICATION_STATUS.ACTIVE);
                usbToken.setDigitalCertificateType(Constants.DiGITAL_CERTIFICATE_TYPE.INDIVIDUAL);
                // cắt chuỗi cmnn date place
                String[] arrOfStr = usbTokenExcelItemObj.getCmmdDatePlace().split(";");
               for(int i=0 ; i < arrOfStr.length ; i ++){
                   if(i == 0 ){
                       usbToken.setCmndCccd(arrOfStr[0]);
                   }
                   else if (i == 1){
                       arrOfStr[1] = replaceAndTrim(arrOfStr[1]);
                       try {
                           Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse(arrOfStr[1]);
                           Instant startInstant = startDate.toInstant();
                           usbToken.setDateOfIssue(startInstant);
                       }catch (Exception exception){
                           // chi có cccd với nơi cấp sẽ xuống case này
                           usbToken.setPlaceOfIssue(arrOfStr[1]);
                       }
                   }
                   else {
                       arrOfStr[1] = replaceAndTrim(arrOfStr[1]);
                       usbToken.setPlaceOfIssue(arrOfStr[2]);
                   }
               }
               String codeAreaAdministrative  = usbTokenRepository.findCodeAreaAdministrativeByName(usbTokenExcelItemObj.getAreaAdministrative());
               usbToken.setProvince(codeAreaAdministrative);
                UsbToken existUsbToken = usbTokenRepository.findByCode(usbToken.getCode());
//                if(checkDate==0) {
//                    Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse(usbTokenExcelItemObj.getStartDate());
//                    Instant startInstant = startDate.toInstant();
//                    Date endDate = new SimpleDateFormat("dd/MM/yyyy").parse(usbTokenExcelItemObj.getEndDate());
//                    Instant endInstant = endDate.toInstant();
//                    if (startDate.after(endDate)) {
//                        messageError += Messages.getString("ValidationException.error.not.null.compare.date");
//                        flag++;
//                    }
////                    usbToken.setStartDate(startInstant);
////                    usbToken.setEndDate(endInstant);
//                }


                if (existUsbToken == null && flag == 0) {


                    try {
                        usbTokenRepository.save(usbToken);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError +=  Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName());
                            }
                        }
                    }

                }
                if(existUsbToken!=null){
                    messageError += Messages.getString("ValidationException.error.existed.usb.token.code");
                }
                errMap.put(usbTokenExcelItemObj.getRow(), messageError);
            }
        }

            return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, null), "Ket_qua_import_usb_token_" + sdf.format(new Date()) + ".xlsx");
    }



    public Workbook saveDataExcel1(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<UsbTokenExcelItemObj> list) throws Exception {
        List<UsbToken> usbTokens = new ArrayList<>();
        Map<Integer, String> errMap = new HashMap<>();
        for (UsbTokenExcelItemObj usbTokenExcelItemObj : list) {
            if (!isEmptyObj1(usbTokenExcelItemObj)) {
                String messageError = "";
                int flag = 0;
                int checkDate = 0;
                if (StringUtils.isEmpty(usbTokenExcelItemObj.getCmmdDatePlace())) {
                    messageError += Messages.getString("ValidationException.error.not.null.cmnd.date.place");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCmndDatePlace(usbTokenExcelItemObj.getCmmdDatePlace());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(usbTokenExcelItemObj.getAccountCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.tk.name");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorAccountMsg(usbTokenExcelItemObj.getAccountCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(usbTokenExcelItemObj.getAreaAdministrative())) {
                    messageError += Messages.getString("ValidationException.error.not.null.city");
                    flag++;
                    checkDate++;
                } else {
                    String messageError1 = CommonUtils.errorCity(usbTokenExcelItemObj.getAreaAdministrative());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                        checkDate++;
                    }
                }
                if(StringUtils.isNotEmpty(usbTokenExcelItemObj.getCode())) {
                    String messageError1 = CommonUtils.errorDigitalCertificate(usbTokenExcelItemObj.getCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                        checkDate++;
                    }
                }
                if (!StringUtils.isEmpty(usbTokenExcelItemObj.getSim())) {
                    String messageError1 = CommonUtils.errorSim(usbTokenExcelItemObj.getSim());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if(StringUtils.isNotEmpty(usbTokenExcelItemObj.getAddress())){
                    String messageError1 = CommonUtils.errorAddress(usbTokenExcelItemObj.getAddress());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                UsbToken usbToken = mapper.map(usbTokenExcelItemObj, UsbToken.class);
                usbToken.setStatus(Constants.APPLICATION_STATUS.ACTIVE);
                usbToken.setDigitalCertificateType(Constants.DiGITAL_CERTIFICATE_TYPE.INDIVIDUAL);
                // cắt chuỗi cmnn date place
                String[] arrOfStr = usbTokenExcelItemObj.getCmmdDatePlace().split(";");
                for(int i=0 ; i < arrOfStr.length ; i ++){
                    if(i == 0 ){
                        usbToken.setCmndCccd(arrOfStr[0]);
                    }
                    else if (i == 1){
                        arrOfStr[1] = replaceAndTrim(arrOfStr[1]);
                        try {
                            Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse(arrOfStr[1]);
                            Instant startInstant = startDate.toInstant();
                            usbToken.setDateOfIssue(startInstant);
                        }catch (Exception exception){
                            // chi có cccd với nơi cấp sẽ xuống case này
                            usbToken.setPlaceOfIssue(arrOfStr[1]);
                        }
                    }
                    else {
                        arrOfStr[1] = replaceAndTrim(arrOfStr[1]);
                        usbToken.setPlaceOfIssue(arrOfStr[2]);
                    }
                }
                String codeAreaAdministrative  = usbTokenRepository.findCodeAreaAdministrativeByName(usbTokenExcelItemObj.getAreaAdministrative());
                usbToken.setProvince(codeAreaAdministrative);
                UsbToken existUsbToken = usbTokenRepository.findByCode(usbToken.getCode());


                if (existUsbToken == null && flag == 0) {


                    try {
                        usbTokenRepository.save(usbToken);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError +=  Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName());
                            }
                        }
                    }

                }
                if(existUsbToken!=null){
                    messageError += Messages.getString("ValidationException.error.existed.usb.token.code");
                }
                errMap.put(usbTokenExcelItemObj.getRow(), messageError);
            }
        }

        return excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, null);
    }





//    private boolean isEmptyObj(UsbTokenExcelItemObj usbTokenExcelItemObj) {
//        if (usbTokenExcelItemObj == null || (StringUtils.isEmpty(usbTokenExcelItemObj.getCode())) && StringUtils.isEmpty(usbTokenExcelItemObj.getAccountCode())&& StringUtils.isEmpty(usbTokenExcelItemObj.getEndDate())&& StringUtils.isEmpty(usbTokenExcelItemObj.getStartDate())&& StringUtils.isEmpty(usbTokenExcelItemObj.getDescription())) {
//            return true;
//        }
//        return false;
//    }

    private boolean isEmptyObj1(UsbTokenExcelItemObj usbTokenExcelItemObj) {
        if (usbTokenExcelItemObj == null) {
            return true;
        }
        return false;
    }

    private  String replaceAndTrim(String element){
        element = element.replaceAll("\n","");
        element = element.trim();
        return  element;
    }

}
