
/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationCallStoredDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 10:43 AM
 */

package vn.gtel.app_mng.category.dto.storedObj;

import vn.gtel.app_mng.category.dto.req.TypeFilter;
import vn.gtel.app_mng.category.dto.res.ApplicationItemResponseDTO;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.common.userinfo.AccountLogonContext;

import java.util.HashMap;
import java.util.Map;

public class ApplicationCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_DM_UNG_DUNG";
    private static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_UNG_DUNG";
    private static final String PROC_FIND_BY_ID_NAME = "PROC_CHI_TIET_UNG_DUNG";

    private static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    private static final String IN_STATUS = "PI_TRANG_THAI";
    private static final String IN_TYPE = "PI_PHAN_LOAI";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_SIZE = "PI_SIZE";
    private static final String IN_ID = "PI_ID";
    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(ApplicationItemResponseDTO.class);
    }

    public ApplicationCallStoredDTO(TypeFilter typeFilter, Integer status) {
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, typeFilter.getKeySearch());
        params.put(IN_STATUS, status);
        params.put(IN_TYPE, typeFilter.getType());
        params.put(IN_PAGE, typeFilter.getPage());
        params.put(IN_SIZE, typeFilter.getSize());
        params.put(getPiCurrentAccountId(), AccountLogonContext.currentUser().getId());
        setParams(params);
    }

    public ApplicationCallStoredDTO(String id) {
        setBase();
        setStoredName(PROC_FIND_BY_ID_NAME);
        params.put(IN_ID, id);
        setParams(params);
    }

}
