/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceImpl.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 3:24 PM
 *
 */

package vn.gtel.app_mng.account.service.Impl;

import com.aspose.words.Document;
import com.google.gson.Gson;
import javassist.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.UrlValidator;
import org.hibernate.exception.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;
import vn.gtel.app_mng.account.dto.*;
import vn.gtel.app_mng.account.dto.excelObj.*;
import vn.gtel.app_mng.account.dto.request.AccountTransferReq;
import vn.gtel.app_mng.account.dto.request.ForgetPWRequestDTO;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferByGroupReq;
import vn.gtel.app_mng.account.dto.request.OrganizationTransferReq;
import vn.gtel.app_mng.account.dto.storeObj.AccountCallStoredDTO;
import vn.gtel.app_mng.account.filter.*;
import vn.gtel.app_mng.account.model.*;
import vn.gtel.app_mng.account.reponse.*;
import vn.gtel.app_mng.account.repository.*;
import vn.gtel.app_mng.account.service.AccountService;
import vn.gtel.app_mng.account.service.GeneralConfigService;
import vn.gtel.app_mng.category.dto.excelObj.ActionExcelItemObj;
import vn.gtel.app_mng.category.dto.excelObj.ActionExcelObj;
import vn.gtel.app_mng.category.dto.res.TrafficPoliceDTO;
import vn.gtel.app_mng.category.model.*;
import vn.gtel.app_mng.category.repo.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.CatSheetDTO;
import vn.gtel.app_mng.common.dto.ExcelItemDto;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.i.IExcelItem;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.DetailResponse;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CallRestAPIService;
import vn.gtel.app_mng.common.service.CommonService;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.EncryptAndDecryptTheDatabaseUtil;
import vn.gtel.app_mng.common.util.ExcelObjectMapper;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.role.model.GroupRole;
import vn.gtel.app_mng.role.model.GroupRoleApplication;
import vn.gtel.app_mng.role.reponse.GroupRoleResponse;
import vn.gtel.app_mng.role.repository.GroupRoleApplicationRepository;
import vn.gtel.app_mng.role.repository.GroupRoleRepository;
import vn.gtel.app_mng.role.storeObj.GroupRoleCallStoredDTO;
import vn.gtel.app_mng.system.dto.storedObj.KafkaLogCallStoredDTO;
import vn.gtel.app_mng.system.model.LoginLog;
import vn.gtel.app_mng.system.model.Notification;
import vn.gtel.app_mng.system.model.NotificationAccount;
import vn.gtel.app_mng.system.repository.LoginLogRepository;
import vn.gtel.app_mng.system.repository.NotificationAccountRepository;
import vn.gtel.app_mng.system.repository.NotificationRepository;
import vn.gtel.app_mng.system.service.NotificationService;
import vn.gtel.app_mng.system.service.SendEventService;
import vn.gtel.common.config.security.GetTokenService;
import vn.gtel.common.constants.ActionCode;
import vn.gtel.common.dto.LogActionDTO;
import vn.gtel.common.dto.LogContentDTO;
import vn.gtel.common.dto.NotificationRqDTO;
import vn.gtel.common.service.AsposeReportService;
import vn.gtel.common.service.LoggingService;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.common.util.LogUtil;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import javax.xml.bind.ValidationException;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static vn.gtel.app_mng.common.config.constant.Constants.APPLICATION_CODE.QTUD;

@Slf4j
@Service
@Transactional
public class AccountServiceImpl implements AccountService {

    private static String PREFIX_ERR_CONSTRAINT_MESSAGE = "ConstraintViolationException.";
    private final GeneralConfigService generalConfigService;
    private PositionCatRepo positionCatRepo;
    private GroupRoleApplicationRepository groupRoleApplicationRepository;
    private TitleRepo titleRepo;
    private RankCatRepo rankCatRepo;
    private GenderRepo genderRepo;
    private AccountEmployeeDetailRepository accountEmployeeDetailRepository;
    private AccountForManageOrganizationRepository accountForManageOrganizationRepository;
    private AccountForManageFieldRepository accountForManageFieldRepository;
    private GeneralConfigRepository generalConfigRepository;
    private AccountServiceDetailRepository accountServiceDetailRepository;
    private AccountGroupRoleRepository accountGroupRoleRepository;
    private AccountRepository accountRepository;
    private AccountSecurityRepository accountSecurityRepository;
    private AccountHistoryRepository accountHistoryRepository;
    private ModelMapper modelMapper;
    private CallStoredRepository callStoredRepository;
    private AccountOrganizationRepository accountOrganizationRepository;
    private ReasonRepo reasonRepo;
    private RedisTemplate redisTemplate;
    private PasswordEncoder passwordEncoder;
    private Gson gson;
    private FieldManageRepository fieldManageRepo;
    private TrimSpaceUtil trimSpaceUtil;
    private OrganizationRepo organizationRepo;
    private GroupRoleRepository groupRoleRepository;
    private LoginLogRepository loginLogRepository;
    private AccountReasonUpdateRepository accountReasonUpdateRepository;
    private NotificationAccountRepository notificationAccountRepository;
    private AccountViewRepository accountViewRepository;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    private CallRestAPIService callRestAPIServiceImpl;
    private AccountGroupAccountRepository accountGroupAccountRepository;
    private LoggingService loggingService;
    private AsposeReportService asposeReportService;
    private NotificationRepository notificationRepository;
    private GetTokenService getTokenService;
    private SendEventService sendEventService;
    private NotificationService notificationService;
    private EntityManager entityManager;
    private CacheManager cacheManager;
    @Autowired
    private ModelMapper mapper;
    private static final Integer cacheTimeoutHours = 24;
    @Value("${url-config.app:NO_CONFIG}")
    private String APP_URL;
    @Value("${url-config.category:NO_CONFIG}")
    private String CATE_URL;
    private CallRestAPIService callRestAPIService;
    @Autowired
    private EncryptAndDecryptTheDatabaseUtil encryptAndDecryptTheDatabaseUtil;

    private JdbcTemplate jdbcTemplate;

    @Value("${secret_key.value:http}")
    private String secret_key;

    @Value("${security.protection.password-lock:http}")
    private String passwordLock;

    @Value("${url-config.category:NO_CONFIG}")
    private String CATEGORY_URL;

    @Value("${toggle.cache.dghc.search:1}")
    private Long enableSearchCache;

    public AccountServiceImpl(GeneralConfigService generalConfigService, PositionCatRepo positionCatRepo, GroupRoleApplicationRepository groupRoleApplicationRepository,
                              TitleRepo titleRepo, RankCatRepo rankCatRepo, AccountEmployeeDetailRepository accountEmployeeDetailRepository,
                              AccountForManageOrganizationRepository accountForManageOrganizationRepository, AccountForManageFieldRepository accountForManageFieldRepository,
                              GeneralConfigRepository generalConfigRepository, AccountServiceDetailRepository accountServiceDetailRepository,
                              AccountGroupRoleRepository accountGroupRoleRepository, AccountRepository accountRepository,
                              AccountSecurityRepository accountSecurityRepository, AccountHistoryRepository accountHistoryRepository,
                              ModelMapper modelMapper, CallStoredRepository callStoredRepository, AccountOrganizationRepository accountOrganizationRepository,
                              ReasonRepo reasonRepo, RedisTemplate redisTemplate, PasswordEncoder passwordEncoder, Gson gson,
                              FieldManageRepository fieldManageRepo, TrimSpaceUtil trimSpaceUtil, OrganizationRepo organizationRepo,
                              GroupRoleRepository groupRoleRepository, LoginLogRepository loginLogRepository, AccountReasonUpdateRepository accountReasonUpdateRepository,
                              NotificationAccountRepository notificationAccountRepository, AccountViewRepository accountViewRepository,
                              CallRestAPIService callRestAPIServiceImpl, AccountGroupAccountRepository accountGroupAccountRepository,
                              LoggingService loggingService, AsposeReportService asposeReportService, NotificationRepository notificationRepository,
                              GetTokenService getTokenService, SendEventService sendEventService, JdbcTemplate jdbcTemplate, NotificationService notificationService,
                              EntityManager entityManager, CallRestAPIService callRestAPIService, GenderRepo genderRepo, CacheManager cacheManager) {
        this.generalConfigService = generalConfigService;
        this.positionCatRepo = positionCatRepo;
        this.groupRoleApplicationRepository = groupRoleApplicationRepository;
        this.titleRepo = titleRepo;
        this.rankCatRepo = rankCatRepo;
        this.accountEmployeeDetailRepository = accountEmployeeDetailRepository;
        this.accountForManageOrganizationRepository = accountForManageOrganizationRepository;
        this.accountForManageFieldRepository = accountForManageFieldRepository;
        this.generalConfigRepository = generalConfigRepository;
        this.accountServiceDetailRepository = accountServiceDetailRepository;
        this.accountGroupRoleRepository = accountGroupRoleRepository;
        this.accountRepository = accountRepository;
        this.accountSecurityRepository = accountSecurityRepository;
        this.accountHistoryRepository = accountHistoryRepository;
        this.modelMapper = modelMapper;
        this.callStoredRepository = callStoredRepository;
        this.accountOrganizationRepository = accountOrganizationRepository;
        this.reasonRepo = reasonRepo;
        this.redisTemplate = redisTemplate;
        this.passwordEncoder = passwordEncoder;
        this.gson = gson;
        this.fieldManageRepo = fieldManageRepo;
        this.trimSpaceUtil = trimSpaceUtil;
        this.organizationRepo = organizationRepo;
        this.groupRoleRepository = groupRoleRepository;
        this.loginLogRepository = loginLogRepository;
        this.accountReasonUpdateRepository = accountReasonUpdateRepository;
        this.notificationAccountRepository = notificationAccountRepository;
        this.accountViewRepository = accountViewRepository;
        this.callRestAPIServiceImpl = callRestAPIServiceImpl;
        this.accountGroupAccountRepository = accountGroupAccountRepository;
        this.loggingService = loggingService;
        this.asposeReportService = asposeReportService;
        this.notificationRepository = notificationRepository;
        this.getTokenService = getTokenService;
        this.sendEventService = sendEventService;
        this.jdbcTemplate = jdbcTemplate;
        this.notificationService = notificationService;
        this.entityManager = entityManager;
        this.callRestAPIService = callRestAPIService;
        this.genderRepo = genderRepo;
        this.cacheManager = cacheManager;
    }


    @Transactional(rollbackOn = Exception.class)
    @Override
    public ResponseBase save(AccountRequestDTO accountRequestDTO) throws IllegalAccessException, ValidationException {

        String actionLog = ActionCode.ADD;
        trimSpaceUtil.validate(accountRequestDTO);

//        vn.gtel.common.dto.AccountDTO accountLogin = AccountLogonContext.currentUser();
//        if (accountRequestDTO.getAccount().getType().equals(Constants.ACCOUNT_TYPE.EMPLOYEE)) {
//            if (accountLogin.getAccount().equals(Constants.USERNAME.ADMIN)) {
//                if (accountRequestDTO.getDetails().get(0) instanceof AccountEmployeeDetailDTO)
//                    if ( ( (AccountEmployeeDetailDTO) accountRequestDTO.getDetails().get(0)).getAccountType() == Constants.ACC_EMPLOYEE_TYPE.EMPLOYEE )
//                        throw new ValidationException("Admin hệ thống không được thêm tài khoản người dùng!");
//            }
//        }

        // check mã đơn vị của người dùng là cán bộ thì không được trùng với mã đơn vị là admin
//        if (checkPositionEmployee(accountRequestDTO, null))
//            throw new ValidationException("Không được nhập đơn vị này cho cán bộ!");

        // kthuc check

        Account account = new Account();
        AccountSecurity accountSecurity = new AccountSecurity();
        Account accountLog = accountRepository.findByAccount(accountRequestDTO.getAccount().getAccount()).orElse(null);
        AccountEmployeeDetail accountEmployeeDetailLog = accountEmployeeDetailRepository.findByAccount(accountRequestDTO.getAccount().getAccount());
        if (accountEmployeeDetailLog != null) {
            entityManager.detach(accountEmployeeDetailLog);
        }
        if (accountLog != null) {
            entityManager.detach(accountLog);
        }
        Long timeBegin = System.currentTimeMillis();
        if (StringUtils.isEmpty(accountRequestDTO.getAccount().getAccount())) {
            AccountEmployeeDetailDTO accountEmployeeDetail = (AccountEmployeeDetailDTO) accountRequestDTO.getDetails().get(0);
            String fullName = CommonUtils.rmVNString(accountEmployeeDetail.getFullName().toLowerCase(Locale.ENGLISH));
            String[] strTen = fullName.split(" ");
            List<String> firstS = Stream.of(strTen).map(e -> getFirst(e)).collect(Collectors.toList()).subList(0, strTen.length - 1);
            String ten = String.format("%s%s", strTen[strTen.length - 1], String.join("", firstS));
            String cand = accountEmployeeDetail.getPoliceNumber().replace("-", "");
            accountRequestDTO.getAccount().setAccount(ten + cand);
        }

        //to lower accountCode
        accountRequestDTO.getAccount().setAccount(accountRequestDTO.getAccount().getAccount().toLowerCase(Locale.ENGLISH));
        timeBegin = System.currentTimeMillis();
        try {
            if (CollectionUtils.isNotEmpty(accountRequestDTO.getDetails()))
                for (AccountDetailDTO accountDetailDTO : accountRequestDTO.getDetails())
                    if (accountDetailDTO instanceof AccountEmployeeDetailDTO) {
                        // validate account (new)
//                        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountLogin.getId(), ((AccountEmployeeDetailDTO) accountDetailDTO).getAccountType(), accountRequestDTO.getAccount().getOrganization());
//                        LinkedCaseInsensitiveMap object = (LinkedCaseInsensitiveMap) callStoredRepository.getObject(callStoredObj);
//                        String result = (String) object.get("RESPONSE");
//
//                        if (StringUtils.isNotEmpty(result))
//                            throw new ValidationException(result);

                        if (((AccountEmployeeDetailDTO) accountDetailDTO).getAccountType() == Constants.ACC_EMPLOYEE_TYPE.EMPLOYEE) {
                            if (StringUtils.isEmpty(((AccountEmployeeDetailDTO) accountDetailDTO).getPosition()))
                                throw new ValidationException("Chức vụ không được trống!");

                            if (StringUtils.isEmpty(((AccountEmployeeDetailDTO) accountDetailDTO).getPoliceNumber()))
                                throw new ValidationException("Số hiệu CAND không được trống!");
                            else if (Constants.ACCOUNT_ACTION.INSERT.equals(accountRequestDTO.getTypeAction()) && existSoHieuCAND(((AccountEmployeeDetailDTO) accountDetailDTO).getPoliceNumber()))
                                throw new ValidationException("Số hiệu CAND không được trùng!");
                            if (((AccountEmployeeDetailDTO) accountDetailDTO).getPhone() != null) {
                                if (Constants.ACCOUNT_ACTION.INSERT.equals(accountRequestDTO.getTypeAction()) && existPhoneNumber(((AccountEmployeeDetailDTO) accountDetailDTO).getPhone()))
                                    throw new ValidationException("Số điện thoại không được trùng!");
                            }
                        }
                    }

            String oldValue;
            AtomicBoolean isEmployeeAccount = new AtomicBoolean(false);
            if (CollectionUtils.isNotEmpty(accountRequestDTO.getDetails()))
                accountRequestDTO.getDetails().forEach(aDetail -> {
                    if (aDetail instanceof AccountEmployeeDetailDTO) isEmployeeAccount.set(true);
                });
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
            switch (accountRequestDTO.getTypeAction()) {
                case Constants.ACCOUNT_ACTION.INSERT:
                    timeBegin = System.currentTimeMillis();
                    oldValue = null;
                    Account accountVali = accountRepository.findByAccount(accountRequestDTO.getAccount().getAccount()).orElse(null);
                    if (accountVali != null) {
                        throw new ValidationException("Tài khoản đã tồn tại");
                    }
                    account = modelMapper.map(accountRequestDTO.getAccount(), Account.class);
                    if (isEmployeeAccount.get()) {
//                        String pass = getRandomPw();
//                        account.setPasswordStart(enPassWordAES(pass));
                        account.setPassword(passwordEncoder.encode("123456"));
                    } else {
                        if (StringUtils.isEmpty(accountRequestDTO.getAccount().getPassword()) || StringUtils.isEmpty(accountRequestDTO.getAccount().getReTypePassword())) {
                            throw new ValidationException("ValidationException.error.not.empty.password");
                        } else {
                            if (!accountRequestDTO.getAccount().getPassword().equals(accountRequestDTO.getAccount().getReTypePassword())) {
                                throw new ValidationException("ValidationException.error.not.match.new.password");
                            } else {
                                account.setPassword(passwordEncoder.encode(accountRequestDTO.getAccount().getPassword()));
//                                account.setPassword(passwordEncoder.encode(Base64.getEncoder().encodeToString((defaultPrefixEnc + accountRequestDTO.getAccount().getPassword()).getBytes())));
                            }
                        }
                    }
                    account.setStatus(Constants.ACCOUNT_STATUS.ACTIVE);
                    account.setRqChangePw(Constants.ACCOUNT_RQ_CHANGE_PW.REQUIRED);
                    account.setLastModifiedDate(Instant.now());
                    account.setConfirmInformation(Constants.ACCOUNT_RQ_CONFIRM_INFORMATION.NOT_RQ);
                    AccountSecurity existAccountSecurity = accountSecurityRepository.findByAccount(account.getAccount()).orElse(null);
                    account = accountRepository.save(account);

                    if (existAccountSecurity == null) {
                        accountSecurity.setAccount(account.getAccount());
                        accountSecurity.resetSecurity(generalConfigService);
                        accountSecurityRepository.save(accountSecurity);
                    } else {
                        existAccountSecurity.resetSecurity(generalConfigService);
                        accountSecurityRepository.save(existAccountSecurity);
                    }
                    break;
                case Constants.ACCOUNT_ACTION.UPDATE:
                    timeBegin = System.currentTimeMillis();
                    actionLog = ActionCode.EDIT;
                    account = accountRepository.findById(accountRequestDTO.getAccount().getId()).orElse(null);
                    String oldOrg = account.getOrganization();
                    modelMapper.getConfiguration().setSkipNullEnabled(true);
                    modelMapper.map(accountRequestDTO.getAccount(), account);
                    if (!isEmployeeAccount.get()) {
                        if (StringUtils.isEmpty(accountRequestDTO.getAccount().getPassword()) && StringUtils.isEmpty(accountRequestDTO.getAccount().getReTypePassword())) {

                        } else {
                            if (StringUtils.isEmpty(accountRequestDTO.getAccount().getPassword()) && StringUtils.isNotEmpty(accountRequestDTO.getAccount().getReTypePassword())
//                                || StringUtils.isNotEmpty(accountRequestDTO.getAccount().getPassword()) && StringUtils.isEmpty(accountRequestDTO.getAccount().getReTypePassword())
                                    || !accountRequestDTO.getAccount().getPassword().equals(accountRequestDTO.getAccount().getReTypePassword())) {
                                throw new ValidationException("ValidationException.error.not.match.new.password");
                            } else {
                                account.setPassword(passwordEncoder.encode(accountRequestDTO.getAccount().getPassword()));
                            }
                        }
                    } else {
                        String newOrg = account.getOrganization();
                        if (StringUtils.isNotEmpty(oldOrg) && StringUtils.isNotEmpty(newOrg) && !oldOrg.equals(newOrg)) {
                            // Chuyen don vi
                            AccountOrganization accountOrganization = new AccountOrganization(account.getAccount(), oldOrg, newOrg, null);
                            accountOrganizationRepository.save(accountOrganization);
                        }
                    }
                    account.setLastModifiedDate(Instant.now());
                    if (account.getConfirmInformation() != null && account.getConfirmInformation().equals(Constants.CONFIRM_INFO.REFUSE)) {
                        account.setConfirmInformation(Constants.CONFIRM_INFO.WAITING);
                    }
                    account = accountRepository.save(account);
                    break;
                default:
                    return new ResponseBase(new DetailResponse(account));
            }

            Instant current = Instant.now();
            LogContentDTO logContentDTO = new LogContentDTO("Account", account.getId());
            saveAccountDetail(accountRequestDTO, actionLog, current, logContentDTO);
            if (actionLog.equals(ActionCode.EDIT)) {
                String logContent = "Đã sửa tài khoản là : " + accountLog.getAccount() + " ,";
                String logMess = this.getDetailUpdateAccount(logContent, accountRequestDTO, accountLog, accountEmployeeDetailLog);
                String menuLog = Constants.ACCOUNT_EMP_TYPE.ADMIN.equals(accountEmployeeDetailLog.getAccountType()) ? Constants.MENU_CODE.ACCOUNT.admin : Constants.MENU_CODE.ACCOUNT.emp;
                if (!logMess.equals(logContent)) {
                    loggingService.successLog(new LogActionDTO(QTUD, menuLog, ActionCode.EDIT, logMess, current));
                }
            }
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//            Cache cacheDetailUser = cacheManager.getCache("detailUser");
//            cacheDetailUser.clear();
//            Cache cacheAllAccount = cacheManager.getCache("userCache");
//            cacheAllAccount.clear();
//            this.clearDetailAccountCache();
//            this.clearAllAccountCache();
            clearCache(Constants.REDIS_KEY.GET_ME + account.getAccount());
        } catch (ValidationException e) {
            log.error(e.getMessage());
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, e.getMessage());
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
        return new ResponseBase(accountRequestDTO.getDetails());
    }

    private String getDetailUpdateAccount(String logContent, AccountRequestDTO accountRequestDTO, Account account, AccountEmployeeDetail accountEmployeeDetail) {
        if (account == null || accountEmployeeDetail == null) {
            return null;
        }

        List<AccountEmployeeDetailDTO> accountEmployeeDetailDTOS = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(accountRequestDTO.getDetails())) {
            accountRequestDTO.getDetails().forEach(aDetail -> {
                if (aDetail instanceof AccountEmployeeDetailDTO) {
                    accountEmployeeDetailDTOS.add(setAccountInOrganization(accountRequestDTO, (AccountEmployeeDetailDTO) aDetail));
                }
            });
        }
        AccountEmployeeDetailDTO accountEmployeeDetailDTO = accountEmployeeDetailDTOS.get(0);
        StringBuilder logMessage = new StringBuilder();
        logMessage.append(logContent);
        LogUtil.compareAndLog(logMessage, "[Ảnh ký số] ", accountRequestDTO.getAccount().getPictureDigitalSign(), account.getPictureDigitalSign());
        LogUtil.compareAndLog(logMessage, "[Họ và tên] ", accountEmployeeDetailDTO.getFullName(), accountEmployeeDetail.getFullName());
        LogUtil.compareAndLog(logMessage, "[Căn cước công dân] ", accountEmployeeDetailDTO.getCitizenID(), accountEmployeeDetail.getCitizenID());
        LogUtil.compareAndLog(logMessage, "[Chức vụ] ", accountEmployeeDetailDTO.getMilitaryName(), accountEmployeeDetail.getMilitaryName());
        LogUtil.compareAndLog(logMessage, "[Cấp bậc] ", accountEmployeeDetailDTO.getPositionName(), accountEmployeeDetail.getPositionName());
        LogUtil.compareAndLog(logMessage, "[Giới tính] ", accountEmployeeDetailDTO.getGenderName(), accountEmployeeDetail.getGenderName());
        return logMessage.toString();
    }

    private boolean checkPositionEmployee(AccountRequestDTO accountRequestDTO, AccountTransferReq accountTransferReq) {
        List<String> restrictedPositions = positionCatRepo.findRestrictedPosition();
        if (accountRequestDTO != null) {
            AccountEmployeeDetailDTO accountDetail = null;
            if (CollectionUtils.isNotEmpty(accountRequestDTO.getDetails()))
                if (accountRequestDTO.getDetails().get(0) instanceof AccountEmployeeDetailDTO)
                    accountDetail = (AccountEmployeeDetailDTO) accountRequestDTO.getDetails().get(0);

            if (accountDetail != null) {
                Organization org = organizationRepo.findByCode(accountRequestDTO.getAccount().getOrganization());
                return StringUtils.isNotEmpty(accountDetail.getPosition()) && restrictedPositions.contains(accountDetail.getPosition()) && org != null && List.of("001", "002", "006", "007", "008").contains(org.getOrganizationLevel());
            }
        } else if (accountTransferReq != null) {
            AccountEmployeeDetail accountDetail = accountEmployeeDetailRepository.findByAccount(accountTransferReq.getAccount());
            if (accountDetail != null) {
                Organization org = organizationRepo.findByCode(accountTransferReq.getNewOrganization());
                return StringUtils.isNotEmpty(accountDetail.getPosition()) && restrictedPositions.contains(accountDetail.getPosition()) && org != null && List.of("001", "002", "006", "007", "008").contains(org.getOrganizationLevel());
            }
        }

        return false;
    }

    @Override
    public String enPassWordAES(String pass) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, ValidationException {
        if (secret_key.length() == 16 || secret_key.length() == 24 || secret_key.length() == 32) {
            SecretKeySpec secretKeySpec = new SecretKeySpec(secret_key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            byte[] byteEncrypted = cipher.doFinal(pass.getBytes());
            String enPass = Base64.getEncoder().encodeToString(byteEncrypted);
            return enPass;
        } else {
            throw new ValidationException("ValidationException.length.key");
        }
    }

    private String dePassWordAES(String strPass) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, ValidationException {
        if (secret_key.length() == 16 || secret_key.length() == 24 || secret_key.length() == 32) {
            SecretKeySpec secretKeySpec = new SecretKeySpec(secret_key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
            byte[] byteEncrypted = Base64.getDecoder().decode(strPass);
            byte[] byteDecrypted = cipher.doFinal(byteEncrypted);
            String dePass = new String(byteDecrypted);
            return dePass;
        } else {
            throw new ValidationException("ValidationException.length.key");
        }
    }

    private boolean existPhoneNumber(String phone) {
        return accountEmployeeDetailRepository.existsByPhone(encryptAndDecryptTheDatabaseUtil.encrypt(phone));
    }

    private boolean existSoHieuCAND(String soHieu) {
        return accountEmployeeDetailRepository.existsByPoliceNumber(encryptAndDecryptTheDatabaseUtil.encrypt(soHieu));
    }

    private String getFirst(String e) {
        return String.valueOf(e.charAt(0));
    }

    private void saveAccountDetail(AccountRequestDTO accountRequestDTO, String actionLog, Instant current, LogContentDTO logAccount) throws Exception {
        // get account by account
        List<AccountEmployeeDetailDTO> accountEmployeeDetailDTOS = new ArrayList<>();
        List<AccountServiceExtraInfoDTO> accountServiceExtraInfoDTOS = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(accountRequestDTO.getDetails())) {
            accountRequestDTO.getDetails().forEach(aDetail -> {
                if (aDetail instanceof AccountEmployeeDetailDTO) {
                    accountEmployeeDetailDTOS.add(setAccountInOrganization(accountRequestDTO, (AccountEmployeeDetailDTO) aDetail));
                }
                if (aDetail instanceof AccountServiceExtraInfoDTO) {
                    accountServiceExtraInfoDTOS.add((AccountServiceExtraInfoDTO) aDetail);
                }
            });
        }
        if (CollectionUtils.isNotEmpty(accountEmployeeDetailDTOS)) {
            saveAccountEmployeeDetail(accountEmployeeDetailDTOS, accountRequestDTO.getAccount().getAccount(), accountRequestDTO.getAccount(), actionLog, current, logAccount);
        }
        if (CollectionUtils.isNotEmpty(accountServiceExtraInfoDTOS)) {
            saveAccountServiceExtra(accountServiceExtraInfoDTOS, accountRequestDTO.getAccount().getAccount());
        }

    }

    public AccountEmployeeDetailDTO setAccountInOrganization(AccountRequestDTO accountRequestDTO, AccountEmployeeDetailDTO accountEmployeeDetailDTO) {
        Organization organization = organizationRepo.findByCodeAndStatus(accountRequestDTO.getAccount().getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        // xu ly phan loai don vi
        if (organization.getOrganizationDependent() != null) {
            if (organization.getOrganizationDependent().equals(Constants.ORGANIZATION_CODE.V06)) {
                accountEmployeeDetailDTO.setAccountInOrganization(2);
            } else {
                accountEmployeeDetailDTO.setAccountInOrganization(3);
            }
        } else {
            if (accountRequestDTO.getAccount().getOrganization().equals(Constants.ORGANIZATION_CODE.V06)) {
                accountEmployeeDetailDTO.setAccountInOrganization(1);
            } else {
                accountEmployeeDetailDTO.setAccountInOrganization(3);
            }
        }

        return accountEmployeeDetailDTO;
    }

    private void saveAccountServiceExtra(List<AccountServiceExtraInfoDTO> accountServiceExtraInfoDTOS, String account) throws Exception {
        for (AccountServiceExtraInfoDTO ser : accountServiceExtraInfoDTOS) {
            String oldValue = null;
            AccountServiceDetail accountServiceDetail = accountServiceDetailRepository.findByAccount(account);
            if (accountServiceDetail != null) {
                oldValue = gson.toJson(accountServiceDetail);
                modelMapper.getConfiguration().setSkipNullEnabled(true);
                modelMapper.map(ser, accountServiceDetail);
                accountServiceDetail.setAccount(account);
                accountServiceDetailRepository.save(accountServiceDetail);
            } else {
                accountServiceDetail = modelMapper.map(ser, AccountServiceDetail.class);
                accountServiceDetail.setAccount(account);
                accountServiceDetailRepository.save(accountServiceDetail);
            }
        }
    }


    private void saveAccountEmployeeDetail(List<AccountEmployeeDetailDTO> accountEmployeeDetailDTOS, String account, vn.gtel.app_mng.account.dto.AccountDTO accountObject, String actionLog, Instant current, LogContentDTO logAccount) throws Exception {
        for (AccountEmployeeDetailDTO emp : accountEmployeeDetailDTOS) {
            String menuLog = Constants.ACCOUNT_EMP_TYPE.ADMIN.equals(emp.getAccountType()) ? Constants.MENU_CODE.ACCOUNT.admin : Constants.MENU_CODE.ACCOUNT.emp;
            AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account);
            String oldValue = "";
            if (accountEmployeeDetail != null) {
                oldValue = gson.toJson(accountEmployeeDetail);
                // nếu là điều tra hình sự đẩy account sang  sẽ cho nhập trung số điện thoại
                //-2 là trạng thái điều tra hình sự đẩy sang
                if (accountObject.getStatus() != -2) {
                    if (StringUtils.isNotEmpty(emp.getPhone()) && !emp.getPhone().equals(accountEmployeeDetail.getPhone()) && existPhoneNumber(emp.getPhone())) {
                        throw new ValidationException("Số điện thoại không được trùng!");
                    }
                }
                modelMapper.getConfiguration().setSkipNullEnabled(true);
                modelMapper.map(emp, accountEmployeeDetail);
                accountEmployeeDetail.setAccount(account);
                accountEmployeeDetail.setMilitary(emp.getMilitary());
                accountEmployeeDetail.setPhone(emp.getPhone());
                accountEmployeeDetail.setDirectManager(emp.getDirectManager());
                accountEmployeeDetail.setInvestigativeAgencyType(emp.getInvestigativeAgencyType());
                if (StringUtils.isNotEmpty(emp.getDisplayPosition())) {
                    accountEmployeeDetail.setDisplayPosition(emp.getDisplayPosition());
                }
            } else {
                accountEmployeeDetail = modelMapper.map(emp, AccountEmployeeDetail.class);
                accountEmployeeDetail.setAccount(account);
                if (emp.getAccountType() == 1) {
                    accountEmployeeDetail.setPoliceNumber(account);
                }
                Position pos = positionCatRepo.findByCode(emp.getPosition());
                if (pos != null) {
                    accountEmployeeDetail.setPosition(pos.getCode());
                    accountEmployeeDetail.setDisplayPosition(pos.getName());
                }
                accountEmployeeDetail.setInvestigativeAgencyType(emp.getInvestigativeAgencyType());
                accountEmployeeDetailRepository.save(accountEmployeeDetail);
            }
            List<String> accountHistoryList = List.of(account);
            updateAccountHistory(accountHistoryList);

            // luu don vi quan ly
            int insert = 0;
            int delete = 0;
            List<AccountForManageOrganization> accountForManageOrganizations = accountForManageOrganizationRepository.findByAccountAndStatus(account, Constants.STATUS_CATEGORY_ACTIVE);
            if (emp.getOrgManage().size() != 0) {
                for (String org : emp.getOrgManage()) {
                    if (accountForManageOrganizations.size() != 0) {
                        for (AccountForManageOrganization accountFor : accountForManageOrganizations) {
                            if (org.equals(accountFor.getOrganization())) {
                                insert++;
                                break;
                            }
                        }
                    }
                    if (insert == 0) {
                        AccountForManageOrganization accountFMO = accountForManageOrganizationRepository.findByAccountAndOrganization(account, org);
                        if (accountFMO != null) {
                            accountFMO.setStatus(Constants.STATUS_CATEGORY_ACTIVE);
                            accountForManageOrganizationRepository.save(accountFMO);
                        } else {
                            AccountForManageOrganization accountForManageOrganization = new AccountForManageOrganization();
                            accountForManageOrganization.setAccount(account);
                            accountForManageOrganization.setOrganization(org);
                            accountForManageOrganization.setStatus(Constants.STATUS_CATEGORY_ACTIVE);
                            accountForManageOrganizationRepository.save(accountForManageOrganization);
                        }
                    }
                    insert = 0;
                }
            } else {
                for (AccountForManageOrganization accF : accountForManageOrganizations) {
                    accF.setStatus(Constants.DELETED);
                    accountForManageOrganizationRepository.save(accF);
                }
            }
            if (accountForManageOrganizations.size() != 0) {
                for (AccountForManageOrganization accountForManage : accountForManageOrganizations) {
                    if (emp.getOrgManage().size() != 0) {
                        for (String org : emp.getOrgManage()) {
                            if (accountForManage.getOrganization().equals(org)) {
                                delete++;
                            }
                        }
                    }
                    if (delete == 0) {
                        accountForManage.setStatus(Constants.DELETED);
                        accountForManageOrganizationRepository.save(accountForManage);
                    }
                    delete = 0;
                }
            }

            // luu linh vuc phu trach

            int insertField = 0;
            int deleteField = 0;

            List<AccountForManageField> accountForManageFields = accountForManageFieldRepository.findByAccountAndStatus(account, Constants.STATUS_CATEGORY_ACTIVE);
            if (emp.getFieldManage().size() != 0) {
                for (String field : emp.getFieldManage()) {
                    if (accountForManageFields.size() != 0) {
                        for (AccountForManageField accountField : accountForManageFields) {
                            if (field.equals(accountField.getField())) {
                                insertField++;
                                break;
                            }
                        }
                    }
                    if (insertField == 0) {
                        AccountForManageField accountFMF = accountForManageFieldRepository.findByAccountAndField(account, field);
                        if (accountFMF != null) {
                            accountFMF.setStatus(Constants.STATUS_CATEGORY_ACTIVE);
                            accountForManageFieldRepository.save(accountFMF);
                        } else {
                            AccountForManageField accountForManageField = new AccountForManageField();
                            accountForManageField.setAccount(account);
                            accountForManageField.setField(field);
                            accountForManageField.setStatus(Constants.STATUS_CATEGORY_ACTIVE);
                            accountForManageFieldRepository.save(accountForManageField);
                        }
                    }
                    insertField = 0;
                }
            } else {
                for (AccountForManageField accountField : accountForManageFields) {
                    accountField.setStatus(Constants.DELETED);
                    accountForManageFieldRepository.save(accountField);
                }
            }

            if (accountForManageFields.size() != 0) {
                for (AccountForManageField accountForManage : accountForManageFields) {
                    if (emp.getFieldManage().size() != 0) {
                        for (String field : emp.getFieldManage()) {
                            if (accountForManage.getField().equals(field)) {
                                deleteField++;
                            }
                        }
                    }
                    if (deleteField == 0) {
                        accountForManage.setStatus(Constants.DELETED);
                        accountForManageFieldRepository.save(accountForManage);
                    }
                    deleteField = 0;
                }
            }

//            // Save log
            String logContent = null;
            if (actionLog.equals(ActionCode.ADD)) {
                logContent = "Đã thêm mới tài khoản: ".concat(account).concat(", họ tên cán bộ: ").concat(accountEmployeeDetail.getFullName());
            }
//            else if (actionLog.equals(ActionCode.EDIT)) {
//                logContent = "Đã sửa tài khoản: ".concat(account).concat(", họ tên cán bộ: ").concat(accountEmployeeDetail.getFullName());
//            }
//
            if (!actionLog.equals(ActionCode.EDIT)) {
                loggingService.successLog(new LogActionDTO(QTUD, menuLog, actionLog, logContent, current));
            }

            // Save log file
            log.info("BUSSINESS_LOG", loggingService.buildData(new Gson().toJson(accountEmployeeDetailDTOS)));

            // kets thucs xuw ly luu don vi quan ly
            // Luu nhom nguoi dung
            if (emp.getGroups() != null) {
                List<AccountGroupAccount> accountGroupAccounts = accountGroupAccountRepository.findByAccount(account);
                List<AccountGroupAccount> allInsert = emp.getGroups().stream().filter(e -> CollectionUtils.isEmpty(accountGroupAccounts)).map(e -> new AccountGroupAccount(account, e)).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(allInsert)) {
                    accountGroupAccountRepository.saveAll(allInsert);
                } else {
                    Stream<AccountGroupAccount> insertList = emp.getGroups().stream().filter(e -> accountGroupAccounts.stream().noneMatch(el -> el.getGroupAccount().equals(e))).map(e -> new AccountGroupAccount(account, e));

                    Stream<AccountGroupAccount> updateList = accountGroupAccounts.stream().filter(e -> Constants.COMMON_STATUS.DELETED.equals(e.getStatus()) && emp.getGroups().stream().anyMatch(el -> el.equals(e.getGroupAccount()))).map(e -> new AccountGroupAccount(e, Constants.COMMON_STATUS.ACTIVE));

                    Stream<AccountGroupAccount> deleteList = accountGroupAccounts.stream().filter(e -> CollectionUtils.isEmpty(emp.getGroups()) || Constants.COMMON_STATUS.ACTIVE.equals(e.getStatus()) && emp.getGroups().stream().noneMatch(el -> el.equals(e.getGroupAccount()))).map(e -> new AccountGroupAccount(e, Constants.COMMON_STATUS.DELETED));
                    List<AccountGroupAccount> saveList = Stream.concat(Stream.concat(insertList, updateList), deleteList).collect(Collectors.toList());
                    accountGroupAccountRepository.saveAll(saveList);
                }
            }
        }
    }

    @Override
//    @Cacheable(value = "userCache", keyGenerator = "CustomKeyGenerator")
    public ResponseBase listAccount(AccountFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);

        if (textFilter instanceof AccountFilter) {
            AccountFilter accountFilter = (AccountFilter) textFilter;
            if (!Constants.ACCOUNT_EMP_TYPE.ADMIN.toString().equals(accountFilter.getTypeEmployee())) {
                if (enableSearchCache != null && enableSearchCache.equals(1L)) {
                    log.info("------------cache----------------");
                    List<AccountResponse> employees = cacheAll();
                    List<AccountResponse> resultRes = new ArrayList<>();
                    if (accountFilter.getOrganization() != null) {
                        resultRes = employees.stream().filter(e -> e.getOrganization() != null && e.getOrganization().equals(accountFilter.getOrganization())).collect(Collectors.toList());
                    } else {
                        resultRes = employees;
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getKeySearch())) {
                        resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getAccount(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getPoliceNumber(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganization(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationName(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getSignOrganization(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getName(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationNew(), accountFilter.getKeySearch())).collect(Collectors.toList());
                    }

//                    if (StringUtils.isNotEmpty(accountFilter.getAccount()) && !"admin".equals(accountFilter.getAccount())) {
//                        resultRes = resultRes.stream().filter(e -> e.getCreatedBy() != null && e.getCreatedBy()
//                                .equalsIgnoreCase(accountFilter.getAccount())).collect(Collectors.toList());
//                    }

                    if (StringUtils.isNotEmpty(accountFilter.getAccount()) && !"admin".equals(accountFilter.getAccount())) {
                        resultRes = resultRes.stream().filter(e -> validAccountOfSubAdmin(e, accountFilter)).collect(Collectors.toList());

                    }

                    if (StringUtils.isNotEmpty(accountFilter.getAccountName())) {
                        resultRes = resultRes.stream().filter(e -> e.getAccount() != null && e.getAccount().equalsIgnoreCase(accountFilter.getAccountName())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getName())) {
                        resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getName(), accountFilter.getName())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getPoliceNumber())) {
                        resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && e.getPoliceNumber().equalsIgnoreCase(accountFilter.getPoliceNumber())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getPosition())) {
                        resultRes = resultRes.stream().filter(e -> e.getPosition() != null && e.getPosition().equalsIgnoreCase(accountFilter.getPosition())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getMilitary())) {
                        resultRes = resultRes.stream().filter(e -> e.getMilitary() != null && e.getMilitary().equalsIgnoreCase(accountFilter.getMilitary())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getStatus())) {
                        resultRes = resultRes.stream().filter(e -> e.getStatus() != null && e.getStatus().toString().equalsIgnoreCase(accountFilter.getStatus())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getOrganizationLevel())) {
                        resultRes = resultRes.stream().filter(e -> e.getOrganizationLevel() != null && e.getOrganizationLevel().equalsIgnoreCase(accountFilter.getOrganizationLevel())).collect(Collectors.toList());
                    }

                    if (accountFilter.getStatusConfirmInfo() != null) {
                        resultRes = resultRes.stream().filter(e -> e.getConfirmStatus() != null && accountFilter.getStatusConfirmInfo() != null && e.getConfirmStatus().equalsIgnoreCase(accountFilter.getStatusConfirmInfo().toString())).collect(Collectors.toList());
                    }

                    if (accountFilter.getPoliceNumbers() != null && accountFilter.getPoliceNumbers().size() > 0) {
                        resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && accountFilter.getPoliceNumbers().contains(e.getPoliceNumber())).collect(Collectors.toList());
                    }

                    int page = accountFilter.getPage();
                    int size = accountFilter.getSize();
                    List<AccountResponse> finalResultRes;
                    if (page * size + size <= resultRes.size()) {
                        finalResultRes = resultRes.subList(page * size, page * size + size);
                    } else {
                        finalResultRes = resultRes.subList(page * size, resultRes.size());
                    }
//                    ListResponse listResponse = new ListResponse(finalResultRes, (long) resultRes.size());
                    ListResponse listResponse = new ListResponse(new ArrayList<>(finalResultRes), (long) resultRes.size());
                    return new ResponseBase(listResponse);

                }
            }
        }
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase listAccountTHDB(TextFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        if (textFilter instanceof AccountFilter) {
            AccountFilter accountFilter = (AccountFilter) textFilter;
            if (!Constants.ACCOUNT_EMP_TYPE.ADMIN.toString().equals(accountFilter.getTypeEmployee())) {
                if (enableSearchCache != null && enableSearchCache.equals(1L)) {
                    List<AccountResponse> employees = cacheAll();
                    List<AccountResponse> resultRes = new ArrayList<>();
                    if (accountFilter.getOrganization() != null) {
                        resultRes = employees.stream().filter(e -> e.getOrganization() != null && e.getOrganization().equals(accountFilter.getOrganization())).collect(Collectors.toList());
                    } else {
                        resultRes = employees;
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getKeySearch())) {
                        resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getAccount(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getPoliceNumber(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganization(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationName(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getSignOrganization(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getName(), accountFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationNew(), accountFilter.getKeySearch())).collect(Collectors.toList());
                    }

//                    if (StringUtils.isNotEmpty(accountFilter.getAccount()) && !"admin".equals(accountFilter.getAccount())) {
//                        resultRes = resultRes.stream().filter(e -> e.getCreatedBy() != null && e.getCreatedBy()
//                                .equalsIgnoreCase(accountFilter.getAccount())).collect(Collectors.toList());
//                    }

                    if (StringUtils.isNotEmpty(accountFilter.getAccount()) && !"admin".equals(accountFilter.getAccount())) {
                        resultRes = resultRes.stream().filter(e -> validAccountOfSubAdmin(e, accountFilter)).collect(Collectors.toList());

                    }

                    if (StringUtils.isNotEmpty(accountFilter.getAccountName())) {
                        resultRes = resultRes.stream().filter(e -> e.getAccount() != null && e.getAccount().equalsIgnoreCase(accountFilter.getAccountName())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getName())) {
                        resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getName(), accountFilter.getName())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getPoliceNumber())) {
                        resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && e.getPoliceNumber().equalsIgnoreCase(accountFilter.getPoliceNumber())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getPosition())) {
                        resultRes = resultRes.stream().filter(e -> e.getPosition() != null && e.getPosition().equalsIgnoreCase(accountFilter.getPosition())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getMilitary())) {
                        resultRes = resultRes.stream().filter(e -> e.getMilitary() != null && e.getMilitary().equalsIgnoreCase(accountFilter.getMilitary())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getStatus())) {
                        resultRes = resultRes.stream().filter(e -> e.getStatus() != null && e.getStatus().toString().equalsIgnoreCase(accountFilter.getStatus())).collect(Collectors.toList());
                    }

                    if (StringUtils.isNotEmpty(accountFilter.getOrganizationLevel())) {
                        resultRes = resultRes.stream().filter(e -> e.getOrganizationLevel() != null && e.getOrganizationLevel().equalsIgnoreCase(accountFilter.getOrganizationLevel())).collect(Collectors.toList());
                    }

                    if (accountFilter.getStatusConfirmInfo() != null) {
                        resultRes = resultRes.stream().filter(e -> e.getConfirmStatus() != null && accountFilter.getStatusConfirmInfo() != null && e.getConfirmStatus().equalsIgnoreCase(accountFilter.getStatusConfirmInfo().toString())).collect(Collectors.toList());
                    }

                    if (accountFilter.getPoliceNumbers() != null && accountFilter.getPoliceNumbers().size() > 0) {
                        resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && accountFilter.getPoliceNumbers().contains(e.getPoliceNumber())).collect(Collectors.toList());
                    }

                    int page = accountFilter.getPage();
                    int size = accountFilter.getSize();
                    List<AccountResponse> finalResultRes;
                    if (page * size + size <= resultRes.size()) {
                        finalResultRes = resultRes.subList(page * size, page * size + size);
                    } else {
                        finalResultRes = resultRes.subList(page * size, resultRes.size());
                    }
                    return new ResponseBase(new ListResponse(finalResultRes, (long) resultRes.size()));
                }
            }
        }
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

//    @CacheEvict(value = "userCache", allEntries = true)
//    public void clearAllAccountCache() {
//        log.info("deleted all cache AccountCache");
//    }
//
//    @CacheEvict(value = "detailUser", allEntries = true)
//    public void clearDetailAccountCache() {
//        log.info("deleted detail cache AccountCache");
//    }

    public boolean validAccountOfSubAdmin(AccountResponse response, AccountFilter accountFilter) {
        String accountOrg = AccountLogonContext.currentUser().getOrganization();
        if ((response.getOrganization().contains(accountOrg)) || (response.getOrganization().contains(accountOrg.substring(0, 6)) && response.getOrganization().contains(Constants.MA_DV_DOI_THUOC_HUYEN) && !response.getOrganization().contains(Constants.ORG_CODE.C08))) {
            return true;
        }
        return false;
    }

    @Override
    public ResponseBase listAllAccount(AccountFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        if (!Constants.ACCOUNT_EMP_TYPE.ADMIN.toString().equals(textFilter.getTypeEmployee())) {
            if (enableSearchCache != null && enableSearchCache.equals(1L)) {
                List<AccountResponse> employees = null;
                if (textFilter.getTypeEmployee() == null) {
                    employees = cacheAllUser();
                } else {
                    employees = cacheAll();
                }
                List<AccountResponse> resultRes = new ArrayList<>();
                if (textFilter.getOrganization() != null) {
                    resultRes = employees.stream().filter(e -> e.getOrganization() != null && e.getOrganization().equals(textFilter.getOrganization())).collect(Collectors.toList());
                } else {
                    resultRes = employees;
                }

                if (StringUtils.isNotEmpty(textFilter.getKeySearch())) {
                    resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getAccount(), textFilter.getKeySearch()) || CommonUtils.searchCondition(e.getPoliceNumber(), textFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganization(), textFilter.getKeySearch()) || CommonUtils.searchCondition(e.getOrganizationName(), textFilter.getKeySearch()) || CommonUtils.searchCondition(e.getSignOrganization(), textFilter.getKeySearch()) || CommonUtils.searchCondition(e.getName(), textFilter.getKeySearch())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getAccount()) && !"admin".equals(textFilter.getAccount())) {
                    resultRes = resultRes.stream().filter(e -> e.getCreatedBy() != null && e.getCreatedBy().equalsIgnoreCase(textFilter.getAccount())).collect(Collectors.toList());
                }
                List<AccountResponse> resultResTmp = new ArrayList<>();
                if (textFilter.getAccounts() != null && textFilter.getAccounts().size() > 0) {
                    for (AccountResponse accountResponse : resultRes) {
                        if (textFilter.getAccounts().contains(accountResponse.getAccount())) {
                            resultResTmp.add(accountResponse);
                        }
                    }
                }
                resultRes = resultResTmp;
                if (StringUtils.isNotEmpty(textFilter.getAccountName())) {
                    resultRes = resultRes.stream().filter(e -> e.getAccount() != null && e.getAccount().equalsIgnoreCase(textFilter.getAccountName())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getName())) {
                    resultRes = resultRes.stream().filter(e -> CommonUtils.searchCondition(e.getName(), textFilter.getName())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getPoliceNumber())) {
                    resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && e.getPoliceNumber().equalsIgnoreCase(textFilter.getPoliceNumber())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getPosition())) {
                    resultRes = resultRes.stream().filter(e -> e.getPosition() != null && e.getPosition().equalsIgnoreCase(textFilter.getPosition())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getMilitary())) {
                    resultRes = resultRes.stream().filter(e -> e.getMilitary() != null && e.getMilitary().equalsIgnoreCase(textFilter.getMilitary())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getStatus())) {
                    resultRes = resultRes.stream().filter(e -> e.getStatus() != null && e.getStatus().toString().equalsIgnoreCase(textFilter.getStatus())).collect(Collectors.toList());
                }

                if (StringUtils.isNotEmpty(textFilter.getOrganizationLevel())) {
                    resultRes = resultRes.stream().filter(e -> e.getOrganizationLevel() != null && e.getOrganizationLevel().equalsIgnoreCase(textFilter.getOrganizationLevel())).collect(Collectors.toList());
                }

                if (textFilter.getStatusConfirmInfo() != null) {
                    resultRes = resultRes.stream().filter(e -> e.getConfirmStatus() != null && textFilter.getStatusConfirmInfo() != null && e.getConfirmStatus().equalsIgnoreCase(textFilter.getStatusConfirmInfo().toString())).collect(Collectors.toList());
                }

                if (textFilter.getPoliceNumbers() != null && textFilter.getPoliceNumbers().size() > 0) {
                    resultRes = resultRes.stream().filter(e -> e.getPoliceNumber() != null && textFilter.getPoliceNumbers().contains(e.getPoliceNumber())).collect(Collectors.toList());
                }

                int page = textFilter.getPage();
                int size = textFilter.getSize();
                List<AccountResponse> finalResultRes;
                if (page * size + size <= resultRes.size()) {
                    finalResultRes = resultRes.subList(page * size, page * size + size);
                } else {
                    finalResultRes = resultRes.subList(page * size, resultRes.size());
                }
                return new ResponseBase(new ListResponse(finalResultRes, (long) resultRes.size()));
            }
        }
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase listAllAccount(AccountExploitFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase listOrg(TextFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase listAccountLead(TextFilter textFilter, String status, String acc, String typeAcc, String org) throws IllegalAccessException, ValidationException {
        trimSpaceUtil.validate(textFilter);
        String orgLead = "";
        String accountStr = "";
        String orgStr = "";
        if (StringUtils.isEmpty(org)) {
            if (StringUtils.isEmpty(acc)) {
                vn.gtel.common.dto.AccountDTO account = AccountLogonContext.currentUser();
                accountStr = account.getAccount();
                orgStr = account.getOrganization();
            } else {
                accountStr = acc;
                Account account = accountRepository.findByAccountAndStatus(acc, Constants.STATUS_CATEGORY_ACTIVE);
                if (account.getOrganization() != null) {
                    Organization organization = organizationRepo.findByCode(account.getOrganization());
                    if (organization != null) {
                        if (organization.getCode() != null) {
                            orgStr = organization.getCode();
                        }
                    } else {
                        throw new ValidationException("ValidationException.error.not.empty.org");
                    }

                }
            }
            AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(accountStr);
            Organization organization = organizationRepo.findByCode(orgStr);
            Position positionCheck = positionCatRepo.findByCode(accountEmployeeDetail.getPosition());
            if (positionCheck != null) {
                if (positionCheck.getType().equals(1)) {
                    if (organization != null) {
                        if (organization.getOrganizationParent() != null) {
                            orgLead = organization.getOrganizationParent();
                        } else {
                            throw new ValidationException("ValidationException.error.not.empty.org.parent");
                        }
                    } else {
                        throw new ValidationException("ValidationException.error.not.empty.org");
                    }
                } else {
                    if (organization != null) {
                        orgLead = organization.getCode();
                    } else {
                        throw new ValidationException("ValidationException.error.not.empty.org");
                    }
                }
            } else {
                throw new ValidationException("ValidationException.error.not.exists.position.code");
            }
        } else {
            orgLead = org;
        }
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter, status, orgLead, typeAcc);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase getMe() throws Exception {
        vn.gtel.common.dto.AccountDTO currentAccount = AccountLogonContext.currentUser();
        AccountDetailResponse accountDetailResponse = this.getMeCache(currentAccount.getAccount());
        return new ResponseBase(new DetailResponse(accountDetailResponse));
    }

    public AccountDetailResponse getMeCache(String account) throws Exception {
        String cacheGetMe = (String) redisTemplate.opsForValue().get(Constants.REDIS_KEY.GET_ME + account);
        if (StringUtils.isEmpty(cacheGetMe)) {
            Date dates = new Date();
            System.out.println("-- Start get getMe: " + dates);
            System.out.println("-- Start get call proc PROC_CHI_TIET_TK_NGUOI_DUNG: " + dates);
            ICallStoredObj callStoredObj = new AccountCallStoredDTO(account, 1);
            Object response = callStoredRepository.findById(callStoredObj);
//        AccountDetailResponse response = this.getAccountByAccount(currentAccount.getAccount());
            Date ef1 = new Date();
            System.out.println("-- End get call proc PROC_CHI_TIET_TK_NGUOI_DUNG: " + ef1 + " Times: " + (ef1.getTime() - dates.getTime()));
            AccountDetailResponse accountDetailResponse = (AccountDetailResponse) response;
            if (((AccountDetailResponse) response).getPasswordStart() != null) {
                accountDetailResponse.setPasswordStart(dePassWordAES(((AccountDetailResponse) response).getPasswordStart()));
            }
            Date ef2 = new Date();
            System.out.println("-- End dePassWordAES: " + ef2 + " Times: " + (ef2.getTime() - ef1.getTime()));
            if (((AccountDetailResponse) response).getPhone() != null) {
                accountDetailResponse.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(((AccountDetailResponse) response).getPhone()));
            }
            Date ef3 = new Date();
            System.out.println("-- End encryptAndDecryptTheDatabaseUtil: " + ef3 + " Times: " + (ef3.getTime() - ef2.getTime()));
            if (((AccountDetailResponse) response).getPoliceNumber() != null) {
                accountDetailResponse.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(((AccountDetailResponse) response).getPoliceNumber()));
            }
            Date ef4 = new Date();
            System.out.println("-- End encryptAndDecryptTheDatabaseUtil: " + ef4 + " Times: " + (ef4.getTime() - ef3.getTime()));
            ICallStoredObj callStoredGetHisObj = new AccountCallStoredDTO(accountDetailResponse.getAccount(), true);
            Object orgHis = callStoredRepository.getList(callStoredGetHisObj);
            Date ef5 = new Date();
            System.out.println("-- End call db PROC_LICH_SU_CHUYEN_DV: " + ef5 + " Times: " + (ef5.getTime() - ef4.getTime()));
            accountDetailResponse.setOrgsHistories((List<AccountOrgResponse>) orgHis);
            if (AccountLogonContext.getUsername().equals(Constants.ADMIN)) {
                accountDetailResponse.setPoliceNumber("000-000");
            }
            accountDetailResponse.setTimeOut(generalConfigRepository.getByKey(Constants.CONFIG.TIME_OUT));
            Date ef6 = new Date();
            System.out.println("-- End call generalConfigRepository.getByKey: " + ef6 + " Times: " + (ef6.getTime() - ef5.getTime()));
            System.out.println("-- End get getMe: " + ef6 + " Times: " + (ef6.getTime() - dates.getTime()));
            cacheGetMe = Constants.REDIS_KEY.GET_ME + account;
            redisTemplate.opsForValue().set(cacheGetMe, new Gson().toJson(accountDetailResponse), cacheTimeoutHours, TimeUnit.HOURS);
            return accountDetailResponse;
        } else {
            return new Gson().fromJson(cacheGetMe, new TypeToken<AccountDetailResponse>() {
            }.getType());
        }
    }


    @Override
    public ResponseBase getMeForManage(String user) throws Exception {

        List<AccountDetailOrg> accountTop = new ArrayList<>();
        List<AccountDetailOrg> accountButtom = new ArrayList<>();
        ListAccountDetailOrg listAccountTop = new ListAccountDetailOrg();
        ListAccountDetailOrg listAccountButtom = new ListAccountDetailOrg();

        ICallStoredObj callStoredObj = new AccountCallStoredDTO(user, 2); // taif khoanr
        List<AccountDetailOrg> response = (List<AccountDetailOrg>) callStoredRepository.getList(callStoredObj);

        accountTop = response.stream().filter(e -> Constants.LEVEL_ACC_MANAGE.TOP.equals(e.getType())).collect(Collectors.toList());
        accountButtom = response.stream().filter(e -> Constants.LEVEL_ACC_MANAGE.BUTTOM.equals(e.getType())).collect(Collectors.toList());


        ICallStoredObj callStoredObj1 = new AccountCallStoredDTO(user, 3); // don vi quanr lys
        List<OrganizationManage> response1 = (List<OrganizationManage>) callStoredRepository.getList(callStoredObj1);
        listAccountTop.setAccountDetailOrgs(accountTop);
        listAccountButtom.setAccountDetailOrgs(accountButtom);


        AccountOrgDetail accountOrg = new AccountOrgDetail();
        accountOrg.setListOrganizationManage(response1);
        accountOrg.setListAccountDetailOrgTop(accountTop);
        accountOrg.setListAccountDetailOrgBottom(accountButtom);


        return new ResponseBase(new DetailResponse(accountOrg));
    }

    @Override
//    @Cacheable(value = "detailUser", key = "#id")
    public ResponseBase detailAccount(String id) throws Exception {
        Account account = accountRepository.findById(id).orElse(null);
        if (account == null) {
            throw new ValidationException("ValidationException.error.not.account");
        }

        ICallStoredObj callStoredObj = new AccountCallStoredDTO(account.getAccount(), 1);
        Object response = callStoredRepository.findById(callStoredObj);
        AccountDetailResponse accountDetailResponse = (AccountDetailResponse) response;
        if (((AccountDetailResponse) response).getPasswordStart() != null) {
            accountDetailResponse.setPasswordStart(dePassWordAES(((AccountDetailResponse) response).getPasswordStart()));
        }
        if (accountDetailResponse.getPhone() != null) {
            accountDetailResponse.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(accountDetailResponse.getPhone()));
        }
        if (accountDetailResponse.getPoliceNumber() != null) {
            accountDetailResponse.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(accountDetailResponse.getPoliceNumber()));
        }
        //
        ICallStoredObj callStoredGetHisObj = new AccountCallStoredDTO(accountDetailResponse.getAccount(), true);
        Object orgHis = callStoredRepository.getList(callStoredGetHisObj);
        accountDetailResponse.setOrgsHistories((List<AccountOrgResponse>) orgHis);

        accountDetailResponse.setTimeOut(generalConfigRepository.getByKey(Constants.CONFIG.TIME_OUT));

        List<AccountDetailOrg> accountTop = new ArrayList<>();
        List<AccountDetailOrg> accountButtom = new ArrayList<>();
        ListAccountDetailOrg listAccountTop = new ListAccountDetailOrg();
        ListAccountDetailOrg listAccountButtom = new ListAccountDetailOrg();

        ICallStoredObj callStoredObj2 = new AccountCallStoredDTO(account.getAccount(), 2); // tai khoan
        List<AccountDetailOrg> response2 = (List<AccountDetailOrg>) callStoredRepository.getList(callStoredObj2);

        accountTop = response2.stream().filter(e -> Constants.LEVEL_ACC_MANAGE.TOP.equals(e.getType())).collect(Collectors.toList());
        accountButtom = response2.stream().filter(e -> Constants.LEVEL_ACC_MANAGE.BUTTOM.equals(e.getType())).collect(Collectors.toList());


        ICallStoredObj callStoredObj1 = new AccountCallStoredDTO(account.getAccount(), 3); // don vi quan ly
        List<OrganizationManage> response1 = (List<OrganizationManage>) callStoredRepository.getList(callStoredObj1);

//        ICallStoredObj callStoredObj3 = new AccountCallStoredDTO(account.getAccount(), 4); // linh vuc phu trach
//        List<FieldManageResponse> response3 = (List<FieldManageResponse>) callStoredRepository.getList(callStoredObj3);

        listAccountTop.setAccountDetailOrgs(accountTop);
        listAccountButtom.setAccountDetailOrgs(accountButtom);

//      Phuc vu nhu cau cua frontend
        List<AccountDetailOrgDTO> accountTopConverted = accountTop.stream().map(a -> {
            AccountDetailOrgDTO acc = new AccountDetailOrgDTO();
            acc.setUsername(a.getAccount());
            acc.setAccountName(a.getFullName());
            return acc;
        }).collect(Collectors.toList());

        List<OrganizationManageDTO> response1Converted = response1.stream().map(r -> {
            OrganizationManageDTO org = new OrganizationManageDTO();
            org.setName(r.getOrganizationName());
            org.setOrganization(r.getOrganizationCode());
            return org;
        }).collect(Collectors.toList());

//        List<FieldManageDTO> response3Converted = new ArrayList<>();
//        for (FieldManageResponse fieldManage : response3) {
//            FieldManageDTO fmd = new FieldManageDTO(fieldManage.getFieldCode(), fieldManage.getFieldName());
//            response3Converted.add(fmd);
//        }

        accountDetailResponse.setListOrganizationManage(response1Converted);
//        accountDetailResponse.setListFieldManage(response3Converted);
//        accountDetailResponse.setListAccountDetailOrgTop(accountTopConverted);
//        accountDetailResponse.setListAccountDetailOrgBottom(accountButtom);
        accountDetailResponse.setGroups(accountGroupAccountRepository.findGroupByAccount(account.getAccount()));
        DetailResponse detailResponse = new DetailResponse(accountDetailResponse);
        return new ResponseBase(detailResponse);
    }

    private int conditionNumberStr(String left, String right) {
        Integer leftInt = Integer.valueOf(left);
        Integer rightInt = Integer.valueOf(right);
        return leftInt - rightInt;
    }


    @Override
    public ResponseBase detailAccountService(String id) throws Exception {
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(id, Constants.ACCOUNT_TYPE.SERVICE);
        Object response = callStoredRepository.findById(callStoredObj);
        AccountServiceDetailResponse responseDTO = (AccountServiceDetailResponse) response;
        return new ResponseBase(responseDTO);
    }

    @Transactional
    @Override
    public ResponseBase importExcel(MultipartFile file) throws Exception {
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj = new AccountServiceExcelObj(0);
        List<AccountServiceExcelItemObj> lst = excelObjectMapper.map(AccountServiceExcelItemObj.class, 0, iExcelMapperObj, 5);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//        this.clearAllAccountCache();
//        this.clearDetailAccountCache();
//        Cache cacheDetailUser = cacheManager.getCache("detailUser");
//        cacheDetailUser.clear();
//        Cache cacheAllAccount = cacheManager.getCache("userCache");
//        cacheAllAccount.clear();
        return new ResponseBase(insertImport(lst));
    }

    private List<Account> insertImport(List<AccountServiceExcelItemObj> lst) throws Exception {
        List<Account> insertAccount = new ArrayList<>();
        List<AccountServiceDetail> insertAccountDetail = new ArrayList<>();
        lst.stream().forEach(iAccount -> {
            Account existAccount = accountRepository.findByAccount(iAccount.getAccount()).orElse(null);
            if (existAccount != null) {
                try {
                    throw new ValidationException("ValidationException.error.exists.account");
                } catch (ValidationException e) {
                    e.printStackTrace();
                }
            }
            Account account = modelMapper.map(iAccount, Account.class);
            account.setStatus(Constants.ACCOUNT_STATUS.ACTIVE);
            account.setPassword(passwordEncoder.encode(account.getPassword()));
            account.setType(Constants.ACCOUNT_TYPE.SERVICE);
            AccountServiceDetail accountServiceDetail = modelMapper.map(iAccount, AccountServiceDetail.class);
            accountServiceDetail.setAccount(account.getAccount());
            insertAccount.add(account);
            insertAccountDetail.add(accountServiceDetail);
        });
        accountRepository.saveAll(insertAccount);
        accountServiceDetailRepository.saveAll(insertAccountDetail);
        return insertAccount;
    }

    private ResponseEntity saveDataExcelReturnRes(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<AccountServiceExcelItemObj> lst) throws Exception {
        Map<Integer, String> errMap = new HashMap<>();
        lst.stream().forEach(iAccount -> {
            String messageError = "";
            if (StringUtils.isNotEmpty(iAccount.getAccount()) || StringUtils.isNotEmpty(iAccount.getName()) || StringUtils.isNotEmpty(iAccount.getPassword()) || StringUtils.isNotEmpty(iAccount.getOrganization()) || StringUtils.isNotEmpty(iAccount.getRelationName()) || StringUtils.isNotEmpty(iAccount.getRelationPhone())) {
                int flag = 0;
                if (StringUtils.isEmpty(iAccount.getAccount())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.code");
                    flag++;
                } else {
                    String checkMsgErr = CommonUtils.errorAccountMsg(iAccount.getAccount());
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(iAccount.getName())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.name");
                    flag++;
                } else {
                    String checkMsgErr = CommonUtils.errorAccountServiceNameMsg(iAccount.getName(), "Tên hệ thống ");
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(iAccount.getPassword())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.password");
                    flag++;
                } else {
                    String checkMsgErr = CommonUtils.errorPasswordMsg(iAccount.getPassword());
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(iAccount.getOrganization())) {
                    messageError += Messages.getString("ValidationException.error.not.null.organization.code");
                    flag++;
                } else {
                    Organization organization = organizationRepo.findByCodeAndStatus(iAccount.getOrganization(), 1);
                    if (organization == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.organization.code");
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(iAccount.getAccountTypeService())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.service.type");
                    flag++;
                } else {
                    if (Constants.ACCOUNT_SERVICE_TYPE.INTEGRATION_STR.equalsIgnoreCase(iAccount.getAccountTypeService())) {
                        iAccount.setType(Constants.ACCOUNT_SERVICE_TYPE.INTEGRATION);
                    } else if (Constants.ACCOUNT_SERVICE_TYPE.SYNCHRONIZE_STR.equalsIgnoreCase(iAccount.getAccountTypeService())) {
                        iAccount.setType(Constants.ACCOUNT_SERVICE_TYPE.SYNCHRONIZE);
                    } else {
                        messageError += Messages.getString("ValidationException.error.not.match.account.service.type");
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(iAccount.getRelationName())) {
                    messageError += Messages.getString("ValidationException.error.not.null.relation.name");
                    flag++;
                } else {
                    String checkMsgErr = CommonUtils.errorAccountServiceNameMsg(iAccount.getRelationName(), "Họ tên đầu mối liên hệ ");
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRepresentativePhone())) {
                    String checkMsgErr = CommonUtils.errorAccountServiceNameMsg(iAccount.getRepresentativePhone(), "Họ tên người đại diện ");
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(iAccount.getRelationPhone())) {
                    messageError += Messages.getString("ValidationException.error.not.null.relation.phone");
                    flag++;
                } else {
                    if (!CommonUtils.isValidMaxLength(iAccount.getRelationPhone(), Constants.VALID.MAX_LENGTH_ACCOUNT)) {
                        messageError += " SDT đầu mối liên hệ " + Messages.getString("error.common.validate.max.size.20");
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRepresentativePoliceNumber())) {
                    if (!CommonUtils.isValidMaxLength(iAccount.getRepresentativePoliceNumber(), Constants.VALID.MAX_LENGTH_ACCOUNT)) {
                        messageError += " Số hiệu CAND " + Messages.getString("error.common.validate.max.size.20");
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRepresentativePhone())) {
                    if (!CommonUtils.isValidWithPattern(iAccount.getRelationPhone(), Constants.Regex.NUMBER)) {
                        messageError += "Số điện thoại người đại diện " + Messages.getString("ValidationException.error.not.null.relation.phone");
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRelationMilitaryText())) {
                    Rank rank = rankCatRepo.findByNameAndStatus(iAccount.getRelationMilitaryText(), 1);
                    if (rank == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.military.code");
                        flag++;
                    } else {
                        iAccount.setRelationMilitary(rank.getCode());
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRepresentativeMilitaryText())) {
                    Rank rank = rankCatRepo.findByNameAndStatus(iAccount.getRelationMilitaryText(), 1);
                    if (rank == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.military.code");
                        flag++;
                    } else {
                        iAccount.setRepresentativeMilitary(rank.getCode());
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRelationPositionText())) {
                    Position position = positionCatRepo.findByNameAndStatus(iAccount.getRelationPositionText(), 1);
                    if (position == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.position.code");
                        flag++;
                    } else {
                        iAccount.setRelationPosition(position.getCode());
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getRepresentativePositionText())) {
                    Position position = positionCatRepo.findByNameAndStatus(iAccount.getRelationPositionText(), 1);
                    if (position == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.position.code");
                        flag++;
                    } else {
                        iAccount.setRepresentativePosition(position.getCode());
                    }
                }


                Account existAccount = accountRepository.findByAccount(iAccount.getAccount()).orElse(null);
                AccountServiceDetail existAccountService = accountServiceDetailRepository.findByAccountAndName(iAccount.getAccount(), iAccount.getName()).orElse(null);
                try {
                    if (existAccountService != null || existAccount != null) {
                        messageError += Messages.getString("ValidationException.error.exists.account");
                        flag++;
                    } else {
                        if (flag == 0) {
                            Account account = modelMapper.map(iAccount, Account.class);
                            account.setStatus(Constants.ACCOUNT_STATUS.ACTIVE);
                            account.setPassword(passwordEncoder.encode(account.getPassword()));
                            account.setType(Constants.ACCOUNT_TYPE.SERVICE);
                            AccountServiceDetail accountServiceDetail = modelMapper.map(iAccount, AccountServiceDetail.class);
                            accountServiceDetail.setAccount(account.getAccount());
                            accountServiceDetail.setServiceType(iAccount.getType());
                            accountRepository.save(account);
                            accountServiceDetailRepository.save(accountServiceDetail);
                        }
                    }
                } catch (Exception ex) {
                    if (ex instanceof DataIntegrityViolationException) {
                        if (ex.getCause() instanceof ConstraintViolationException) {
                            messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                            ;
                        }
                    }
                }


                errMap.put(iAccount.getRow(), messageError);
            }
        });

        return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, null), "Ket_qua_import_tai_khoan_he_thong" + "_" + sdf.format(new Date()) + ".xlsx");
    }

    @Override
    public ResponseBase setActiveDeActive(ReasonUpdateAccountDTO reasonUpdateAccountDTO) throws Exception {
        AccountReasonUpdate accountReasonUpdate = new AccountReasonUpdate();
        Account account = accountRepository.findById(reasonUpdateAccountDTO.getId()).orElse(null);
        AccountInactiveDTO accountInactiveDTO = new AccountInactiveDTO(account.getAccount(), 1);
        if (account == null) {
            throw new NotFoundException("Khong tim thay tai khoan : id = " + reasonUpdateAccountDTO.getId());
        }
        String action = null;
        if (account.getStatus().equals(Constants.ACCOUNT_STATUS.INACTIVE) || account.getStatus().equals(Constants.ACCOUNT_STATUS.ACTIVE) || account.getStatus().equals(Constants.ACCOUNT_STATUS.WAITING_CHANGE_ORG) || account.getStatus().equals(Constants.ACCOUNT_STATUS.WAITING_CREATE)) {
            Integer tobeUpdateStatus = Constants.ACCOUNT_STATUS.INACTIVE;
            accountReasonUpdate.setAction(Constants.ACCOUNT_STATUS.INACTIVE);
            action = ActionCode.INACTIVE;
            if (account.getStatus().equals(Constants.ACCOUNT_STATUS.INACTIVE) || account.getStatus().equals(Constants.ACCOUNT_STATUS.WAITING_CREATE) || account.getStatus().equals(Constants.ACCOUNT_STATUS.WAITING_CHANGE_ORG)) {
                tobeUpdateStatus = Constants.ACCOUNT_STATUS.ACTIVE;
                accountReasonUpdate.setAction(Constants.ACCOUNT_STATUS.ACTIVE);
                action = ActionCode.ACTIVE;
                accountInactiveDTO.setDanhDauXoa(0); // kich hoat ben dths
            }
            accountReasonUpdate.setAccount(account.getAccount());
            if (StringUtils.isEmpty(accountReasonUpdate.getReason()))
                accountReasonUpdate.setReason(reasonUpdateAccountDTO.getReason());
            account.setStatus(tobeUpdateStatus);
            if (Constants.ACCOUNT_STATUS.INACTIVE.equals(account.getStatus())) {
                logoutAccount(account.getAccount());
            }
            // save ly do cap nhat
            accountReasonUpdateRepository.save(accountReasonUpdate);
            // Save log
            String content = null;
            if (action.equals(ActionCode.INACTIVE)) {
                content = String.format("Đã vô hiệu hóa tài khoản tên %s", account.getAccount());
            } else if (action.equals(ActionCode.ACTIVE)) {
                content = String.format("Đã kích hoạt tài khoản tên %s", account.getAccount());
            }

            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//            this.clearAllAccountCache();
//            this.clearDetailAccountCache();
//            Cache cacheDetailUser = cacheManager.getCache("detailUser");
//            cacheDetailUser.clear();
//            Cache cacheAllAccount = cacheManager.getCache("userCache");
//            cacheAllAccount.clear();
            AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
            if (accountEmployeeDetail != null && accountEmployeeDetail.getAccountType() == 1) {
                loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.admin, action, content + ",lý do :" + reasonUpdateAccountDTO.getReason(), Instant.now()));
            } else if (accountEmployeeDetail != null && accountEmployeeDetail.getAccountType() == 2) {
                loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.emp, action, content + ",lý do :" + reasonUpdateAccountDTO.getReason(), Instant.now()));
            }
            return new ResponseBase(new DetailResponse(accountRepository.save(account)));
        } else return new ResponseBase("Do not anything!");
    }

    private void logoutAccount(String account) {
        revokeToken(account);
        new Thread(() -> sendEventService.sendEvent(account, Constants.SSE_TYPE.LOG_OUT)).start();
    }

    @Override
    public ResponseBase resetPw(String id) throws Exception {
        Account account = accountRepository.findById(id).orElse(null);
        if (account == null) {
            throw new NotFoundException("Khong tim thay tai khoan : id = " + id);
        }
        String randomPw = getRandomPw();
        account.setPassword(passwordEncoder.encode(randomPw));
        account.setPasswordStart(enPassWordAES(randomPw));
        account.setRqChangePw(Constants.ACCOUNT_RQ_CHANGE_PW.REQUIRED);
        Account newAccount = new Account(accountRepository.save(account));
        newAccount.setPassword(randomPw);

        List<Notification> notificationList = notificationRepository.findBySender(newAccount.getAccount());
        for (Notification entity : notificationList) {
            entity.setStatus(Constants.NOTIFICATION_STATUS.PROCESSED);
        }
        notificationRepository.saveAll(notificationList);

        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//        this.clearAllAccountCache();
//        this.clearDetailAccountCache();
//        Cache cacheDetailUser = cacheManager.getCache("detailUser");
//        cacheDetailUser.clear();
//        Cache cacheAllAccount = cacheManager.getCache("userCache");
//        cacheAllAccount.clear();
        // Save log
//        loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.emp, ActionCode.RESET_PW, content, Instant.now()));
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
        String content = String.format("Đã cấp lại mật khẩu cho tài khoản tên %s và tên cán bộ là %s", account.getAccount(), accountEmployeeDetail.getFullName());
        if (accountEmployeeDetail != null && accountEmployeeDetail.getAccountType() == 1) {
            loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.admin, ActionCode.RESET_PW, content, Instant.now()));
        } else if (accountEmployeeDetail != null && accountEmployeeDetail.getAccountType() == 2) {
            loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.emp, ActionCode.RESET_PW, content, Instant.now()));
        }
        revokeToken(account.getAccount());

        return new ResponseBase(new DetailResponse(newAccount));
    }

    @Override
    public ResponseBase changePw(ChangePWRequestDTO changePWRequestDTO) throws ValidationException, IllegalAccessException {
        trimSpaceUtil.validate(changePWRequestDTO);
        vn.gtel.common.dto.AccountDTO account = AccountLogonContext.currentUser();
        Account accountUpdate = accountRepository.findById(account.getId()).orElse(null);
        AccountSecurity accountSecurity = accountSecurityRepository.findByAccount(account.getAccount()).orElse(null);
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
        if (!passwordEncoder.matches(changePWRequestDTO.getOldPassword(), accountUpdate.getPassword())) {
            throw new ValidationException("ValidationException.error.not.match.old.password");
        }
        if (!account.getAccount().equals(Constants.ADMIN) && changePWRequestDTO.getNewPassword().contains(accountEmployeeDetail.getPoliceNumber().replace("-", ""))) {
            throw new ValidationException("ValidationException.error.not.police.new.password");
        }
        if (!changePWRequestDTO.getNewPassword().equals(changePWRequestDTO.getNewPasswordAgain())) {
            throw new ValidationException("ValidationException.error.not.match.new.password");
        }
        if (changePWRequestDTO.getNewPassword().equals(changePWRequestDTO.getOldPassword())) {
            throw new ValidationException("ValidationException.error.not.change.new.password");
        }
//        if (!changePWRequestDTO.getNewPassword().matches(Integer.parseInt(passwordLock) == 1 ? generalConfigService.generatePasswordFilter() : "")) {
//            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.pass.validation.new.password"), null);
//        }
        accountUpdate.setPassword(passwordEncoder.encode(changePWRequestDTO.getNewPassword()));
        accountUpdate.setPasswordStart(null);
        accountUpdate.setRqChangePw(Constants.ACCOUNT_RQ_CHANGE_PW.NOT_RQ);
        if (accountSecurity == null) {
            accountSecurity = new AccountSecurity();
            accountSecurity.setAccount(account.getAccount());
        }
        accountSecurity.resetSecurity(generalConfigService);
        accountSecurityRepository.save(accountSecurity);
        // Save log
        String content = String.format("Đã đổi mật khẩu cho tài khoản tên là %s và tên cán bộ là %s", account.getAccount(), accountEmployeeDetail.getFullName());
        if (accountEmployeeDetail != null && accountEmployeeDetail.getAccountType() == 1) {
            loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.admin, ActionCode.CHANGE_PW, content, Instant.now()));
        } else if (accountEmployeeDetail != null && accountEmployeeDetail.getAccountType() == 2) {
            loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.emp, ActionCode.CHANGE_PW, content, Instant.now()));
        }
        return new ResponseBase(new DetailResponse(accountRepository.save(accountUpdate)));
    }

    @Override
    public ResponseBase changePw(ChangePWServiceRequestDTO changePWServiceRequestDTO) throws Exception {
        trimSpaceUtil.validate(changePWServiceRequestDTO);
        Account account = accountRepository.findById(changePWServiceRequestDTO.getAccountId()).orElse(null);
        Account accountUpdate = accountRepository.findById(account.getId()).orElse(null);
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
        if (account == null) {
            throw new NotFoundException("Tai khoan khong ton tai!");
        }
        if (!passwordEncoder.matches(changePWServiceRequestDTO.getPassword(), accountUpdate.getPassword())) {
            throw new ValidationException("ValidationException.error.not.match.old.password");
        }
        System.out.println(accountEmployeeDetail.getPoliceNumber().replace("-", ""));
        if (changePWServiceRequestDTO.getNewPassword().contains(accountEmployeeDetail.getPoliceNumber().replace("-", ""))) {
            throw new ValidationException("ValidationException.error.not.police.new.password");
        }
        if (!changePWServiceRequestDTO.getNewPassword().equals(changePWServiceRequestDTO.getPasswordAgain())) {
            throw new ValidationException("ValidationException.error.not.match.new.password");
        }
        AccountSecurity accountSecurity = accountSecurityRepository.findByAccount(account.getAccount()).orElse(null);
        account.setPassword(passwordEncoder.encode(changePWServiceRequestDTO.getNewPassword()));
        account.setRqChangePw(Constants.ACCOUNT_RQ_CHANGE_PW.NOT_RQ);
        if (accountSecurity == null) {
            accountSecurity = new AccountSecurity();
            accountSecurity.setAccount(account.getAccount());
        }
        accountSecurity.resetSecurity(generalConfigService);
        return new ResponseBase(new DetailResponse(accountRepository.save(account)));
    }

    @Override
    public void changeStatusPW() {
        List<String> accountExpireds = accountSecurityRepository.getListAccountWithExpiredPW();
        List<String> accountNotifications = accountSecurityRepository.getListAccountWithNotiExpiredPW();
        for (String account : accountNotifications) {
            notificationService.sendNotificationChangePW("SYSTEM", account);
        }
        accountSecurityRepository.updateChangeStatusPw(accountExpireds);
    }

    @Override
    public ResponseBase getTreeAccountTrafficPolice(String currentNode, int pageNumber, int sizeNumber) throws IllegalAccessException {
        log.info("============== BEFORE CALL REST API ===============");
        log.info("============== CALL TO URL: {} ===============", CATE_URL.concat(Constants.URL_CONFIG.GET_ORG_CSGT));
        log.info("============== QUERY PARAM IS PAGE = 0 ===============" );
        ResponseEntity<ResponseBase> result = callRestAPIService
                .call(UriComponentsBuilder
                        .fromHttpUrl(CATE_URL.concat(Constants.URL_CONFIG.GET_ORG_CSGT))
                        .queryParam("page", 0).toUriString(),
                        HttpMethod.GET,
                        getTokenService.getBasicHeaderNoBody(),
                        null);
        List<LinkedHashMap<String, String>> results = (List<LinkedHashMap<String, String>>) ((LinkedHashMap<String, TrafficPoliceDTO>) result.getBody().getData()).get("list");
        List<TrafficPoliceDTO> organizationResponseDTOS = results.stream().map(map -> new TrafficPoliceDTO(map)).collect(Collectors.toList());
        AccountFilter textFilter = new AccountFilter(Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT, null, null, Constants.ACCOUNT_TYPE.EMPLOYEE, null, null, null, null, null, null, null, "2", null, null, (String) null);
        List<AccountResponse> accountResponses = (List<AccountResponse>) ((ListResponse) this.listAccount(textFilter).getData()).getList();
        for (TrafficPoliceDTO dto : organizationResponseDTOS) {
            for (AccountResponse account : accountResponses) {
                if (account.getOrganization().equals(dto.getCode())) {
                    List<AccountResponse> accountResponseList = dto.getAccountResponses();
                    accountResponseList.add(account);
                    dto.setAccountResponses(accountResponseList);
                }
            }
        }
        AccountOrganizationResponseDTO accountOrganizationResponseDTO = organizationResponseDTOS.stream().filter(e -> e.getCode().equals(currentNode)).findFirst().map(this::mapOneResponse).orElse(new AccountOrganizationResponseDTO());
        accountOrganizationResponseDTO.setParent(buildParents(accountOrganizationResponseDTO, organizationResponseDTOS));
        accountOrganizationResponseDTO.setChildren(buildChildren(currentNode, organizationResponseDTOS, true));
        return new ResponseBase(new DetailResponse(accountOrganizationResponseDTO));
    }

    @Override
    public void deleteAccountAfter30Days() {
        List<Account> accounts = accountRepository.findByStatusNotAndRqChangePwAndPasswordStartIsNotNull(Constants.DELETED, Constants.ACCOUNT_RQ_CHANGE_PW.REQUIRED);
        List<String> accountNames = new ArrayList<>();
        Map<String, String> nameOrgMap = new HashMap<>();
        for (Account account : accounts) {
            Instant createdDate = account.getCreatedDate();
            Instant expiredDate = createdDate.plus(2, ChronoUnit.DAYS);
            Instant now = Instant.now();

            if (expiredDate.isAfter(now)) {
                continue;
            }

            List<LoginLog> loginLogs = loginLogRepository.findByAccountAndStatusAndStartedDateAfter(account.getAccount(), Constants.STATUS_CATEGORY_ACTIVE, now.minus(2, ChronoUnit.DAYS));
            if (loginLogs == null || loginLogs.size() == 0) {
                nameOrgMap.put(account.getAccount(), account.getOrganization());
                accountNames.add(account.getAccount());
            }
        }

        if (accountNames != null && accountNames.size() > 0) {
            accountRepository.updateAccountDelete(accountNames);
            Notification notification = new Notification();
            String size = null;
            if (accountNames.size() < 10) {
                size = '0' + String.valueOf(accountNames.size());
            } else {
                size = String.valueOf(accountNames.size());
            }
            notification.setTitle("Thông báo xóa " + size + " tài khoản chưa kích hoạt trong 30 ngày");
            notification.setType(Constants.NOTIFICATION_TYPE.NOTICE);
            String content = "Các tài khoản bị xóa là : ";
            for (String str : accountNames) {
                content += "[ Tài khoản : " + str + " - mã đơn vị : " + nameOrgMap.get(str) + " ] " + "\n";
            }
            notification.setContent(content);
            Notification notificationRes = notificationRepository.save(notification);
            NotificationAccount notificationAccount = new NotificationAccount();
            notificationAccount.setAccount(Constants.ADMIN);
            notificationAccount.setStatus(1);
            notificationAccount.setNotificationId(notificationRes.getId());
            notificationAccountRepository.save(notificationAccount);
        }
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//        this.clearAllAccountCache();
//        this.clearDetailAccountCache();
//        Cache cacheDetailUser = cacheManager.getCache("detailUser");
//        cacheDetailUser.clear();
//        Cache cacheAllAccount = cacheManager.getCache("userCache");
//        cacheAllAccount.clear();
    }

    @Override
    public ResponseBase sumAccountTransfer() {
        AccountTransferOrgFilter accountTransferOrgFilter = new AccountTransferOrgFilter();
        accountTransferOrgFilter.setPage(0);
        accountTransferOrgFilter.setSize(Constants.MAX_ROW_SELECT);
        accountTransferOrgFilter.setType(Constants.CHANGE_ORG_TYPE.DIFFERENT_ORG);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountTransferOrgFilter);
        Object res = callStoredRepository.list(callStoredObj);
        ListResponse response = (ListResponse) res;
        int sum = 0;
        if (response.getList() == null) {
            return new ResponseBase(sum);
        }

        List<AccountTransferOrgResponse> results = (List<AccountTransferOrgResponse>) response.getList();
        for (AccountTransferOrgResponse dto : results) {
            if (dto.getStatus() == 1) {
                sum += 1;
            }
        }
        return new ResponseBase(sum);
    }

    private List<AccountOrganizationResponseDTO> buildChildren(String currentNode, List<TrafficPoliceDTO> organizationResponseDTOS, boolean isTree) {
        List<AccountOrganizationResponseDTO> children = organizationResponseDTOS.stream().filter(e -> currentNode.equals(e.getOrganizationDependent())).map(this::mapOneResponse).collect(Collectors.toList());
        if (isTree && CollectionUtils.isNotEmpty(children)) {
            children.forEach(e -> e.setChildren(buildChildren(e.getCode(), organizationResponseDTOS, true)));
        }
        return children;
    }

    private AccountOrganizationResponseDTO mapOneResponse(TrafficPoliceDTO organizationView) {
        return mapper.map(organizationView, AccountOrganizationResponseDTO.class);
    }

    private AccountOrganizationResponseDTO buildParents(AccountOrganizationResponseDTO current, List<TrafficPoliceDTO> organizationResponseDTOS) {
        AccountOrganizationResponseDTO parent;
        if (StringUtils.isNotEmpty(current.getOrganizationDependent())) {
            parent = organizationResponseDTOS.stream().filter(e -> e.getCode().equals(current.getOrganizationDependent())).findFirst().map(this::mapOneResponse).orElse(null);
            if (parent != null && StringUtils.isNotEmpty(parent.getOrganizationDependent())) {
                parent.setParent(buildParents(parent, organizationResponseDTOS));
            }
        } else {
            parent = null;
        }
        return parent;
    }

    @Override
    public ResponseEntity importEmp(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException {
        int defaultSheet = 0;
        int groupRoleSheet = 1;
        int firstRow = 4;
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj1 = new AccountEmployeeExcelObj(0, defaultSheet, firstRow);
        IExcelMapperObj iExcelMapperObj2 = new AccountEmployeeExcelObj(0, groupRoleSheet, firstRow);
        List<AccountEmployeeExcelItemObj> accountEmployeeList = excelObjectMapper.map(AccountEmployeeExcelItemObj.class, defaultSheet, iExcelMapperObj1, firstRow);
        List<AccountGroupRoleExcelItemObj> accountGroupRoleList = excelObjectMapper.map(AccountGroupRoleExcelItemObj.class, groupRoleSheet, iExcelMapperObj2, firstRow);
        List<AccountEmployeeExcelItemObj> accountEmployeeListTmp = new ArrayList<>();
        for (AccountEmployeeExcelItemObj obj : accountEmployeeList) {
            obj.setMilitaryText(getSubString(obj.getMilitaryText()));
            obj.setPositionText(getSubString(obj.getPositionText()));
            obj.setGender(getSubString(obj.getGender()));
            accountEmployeeListTmp.add(obj);
        }

        saveAccountEmployeeExcel(excelObjectMapper, defaultSheet, firstRow, accountEmployeeListTmp, iExcelMapperObj1);
        saveAccountGroupRoleExcel(excelObjectMapper, groupRoleSheet, firstRow, accountGroupRoleList, iExcelMapperObj2);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//        this.clearAllAccountCache();
//        this.clearDetailAccountCache();
//        Cache cacheDetailUser = cacheManager.getCache("detailUser");
//        cacheDetailUser.clear();
//        Cache cacheAllAccount = cacheManager.getCache("userCache");
//        cacheAllAccount.clear();
        return CommonUtils.downloadFile(excelObjectMapper.getWorkbook(), "Ket_qua_import_tai_khoan_nguoi_dung" + "_" + sdf.format(new Date()) + ".xlsx");
    }

    private String getSubString(String str) {
        if (StringUtils.isNotEmpty(str)) {
            return str.split("-")[0].trim();
        }
        return null;
    }

    private void saveAccountEmployeeExcel(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<AccountEmployeeExcelItemObj> lst, IExcelMapperObj iExcelMapperObj) throws IOException {
        Map<Integer, String> errMap = new HashMap<>();
        String defaultPw = getDefaultPw();
        lst.stream().forEach(iAccount -> {
            String messageError = "";
            if (StringUtils.isNotEmpty(iAccount.getName()) || StringUtils.isNotEmpty(iAccount.getOrganization()) || StringUtils.isNotEmpty(iAccount.getPoliceNumber())) {
                int flag = 0;
                if (StringUtils.isEmpty(iAccount.getName()) || iAccount.getName().length() == 0) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.name");
                    flag++;
                } else {
                    String checkMsgErr = CommonUtils.errorAccountServiceNameMsg(iAccount.getName(), "Tên người dùng ");
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(iAccount.getOrganization())) {
                    messageError += Messages.getString("ValidationException.error.not.null.organization.code");
                    flag++;
                } else {
                    Organization organization = organizationRepo.findByCodeAndStatus(iAccount.getOrganization(), 1);
                    if (organization == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.organization.code");
                        flag++;
                    }
                }

                if (!CommonUtils.isValidMaxLength(iAccount.getPhone(), Constants.VALID.MAX_LENGTH_ACCOUNT)) {
                    messageError += " SDT " + Messages.getString("error.common.validate.max.size.20");
                    flag++;
                }

                if (StringUtils.isNotEmpty(iAccount.getPoliceNumber())) {
                    if (!CommonUtils.isValidMaxLength(iAccount.getPoliceNumber(), Constants.VALID.MAX_LENGTH_ACCOUNT)) {
                        messageError += " Số hiệu CAND " + Messages.getString("error.common.validate.max.size.20");
                        flag++;
                    }
                    AccountEmployeeDetail existPoliceNumber = accountEmployeeDetailRepository.findByPoliceNumber(iAccount.getPoliceNumber());
                    if (existPoliceNumber != null) {
                        messageError += Messages.getString("ResponseError.AccountDetail.PoliceNumber.Exist");
                        flag++;
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getMilitaryText())) {
                    Rank rank = rankCatRepo.findByCodeAndStatus(iAccount.getMilitaryText(), Constants.STATUS_CATEGORY_ACTIVE);
                    if (rank == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.military.code");
                        flag++;
                    } else {
                        iAccount.setMilitary(iAccount.getMilitaryText());
                    }
                }

                if (StringUtils.isNotEmpty(iAccount.getPositionText())) {
                    Position position = positionCatRepo.findByCodeAndStatusAndClassify(iAccount.getPositionText(), Constants.STATUS_CATEGORY_ACTIVE, 1);
                    if (position == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.position.code");
                        flag++;
                    } else {
                        iAccount.setPosition(iAccount.getPositionText());
                    }
                } else {
                    messageError += Messages.getString("ValidationException.error.not.exists.position.code.null");
                    flag++;
                }

//                if (StringUtils.isNotEmpty(iAccount.getTitleText())) {
//                    Title title = titleRepo.findByCode(iAccount.getTitleText());
//                    if (title == null) {
//                        messageError += Messages.getString("ValidationException.error.not.exists.title.code");
//                        flag++;
//                    } else {
//                        iAccount.setTitle(iAccount.getTitleText());
//                    }
//                }

//                if (StringUtils.isNotEmpty(iAccount.getDirectManager())) {
//                    Account account = accountRepository.findByAccountAndStatus(iAccount.getDirectManager(), Constants.STATUS_CATEGORY_ACTIVE);
//                    if (account == null) {
//                        messageError += Messages.getString("ValidationException.error.exists.account.manage");
//                        flag++;
//                    } else {
//                        iAccount.setDirectManager(iAccount.getDirectManager());
//                    }
//                }

//                if (StringUtils.isNotEmpty(iAccount.getFieldManage())) {
//                    List<String> fields = Arrays.asList(iAccount.getFieldManage().split("\\s*,\\s*"));
//                    int fieldCheck = 0;
//                    for (String field : fields) {
//                        FieldManage fieldManage = fieldManageRepo.findByCodeAndStatus(field, Constants.STATUS_CATEGORY_ACTIVE);
//                        if (fieldManage == null) fieldCheck++;
//                    }
//                    if (fieldCheck > 0) {
//                        messageError += Messages.getString("ValidationException.error.not.existed.field.manage");
//                        flag++;
//                    } else {
//                        iAccount.setCheckedFieldManage(fields);
//                    }
//                } else {
//                    messageError += Messages.getString("ValidationException.error.not.null.field.manage.code");
//                    flag++;
//                }

                String fullName = CommonUtils.rmVNString(iAccount.getName().toLowerCase(Locale.ENGLISH));
                String[] strTen = fullName.split(" ");
                List<String> firstS = Stream.of(strTen).map(e -> getFirst(e)).collect(Collectors.toList()).subList(0, strTen.length - 1);
//                String ten = String.format("%s%s", strTen[strTen.length - 1], String.join("", firstS));
                String cand = iAccount.getPoliceNumber().replace("-", "");
                iAccount.setAccount(cand);

                Account existAccount = accountRepository.findByAccount(iAccount.getAccount()).orElse(null);
                AccountEmployeeDetail existAccountDetail = accountEmployeeDetailRepository.findByAccount(iAccount.getAccount());
                try {
                    if (existAccountDetail != null || existAccount != null) {
                        messageError += Messages.getString("ValidationException.error.exists.account");
                        flag++;
                    } else {
                        if (flag == 0) {
                            Account account = modelMapper.map(iAccount, Account.class);
                            account.setStatus(Constants.ACCOUNT_STATUS.ACTIVE);
                            account.setPassword(defaultPw);
                            account.setRqChangePw(Constants.ACCOUNT_RQ_CHANGE_PW.REQUIRED);
                            account.setType(Constants.ACCOUNT_TYPE.EMPLOYEE);
                            AccountEmployeeDetail accountEmployeeDetail = modelMapper.map(iAccount, AccountEmployeeDetail.class);
                            accountEmployeeDetail.setAccount(account.getAccount());
                            accountEmployeeDetail.setFullName(iAccount.getName());
                            accountEmployeeDetail.setMilitary(iAccount.getMilitary());
                            accountEmployeeDetail.setPosition(iAccount.getPosition());
                            accountEmployeeDetail.setPoliceNumber(iAccount.getPoliceNumber());
                            accountEmployeeDetail.setAccountType(Constants.ACCOUNT_EMP_TYPE.USER);
                            accountEmployeeDetail.setPhone(iAccount.getPhone());
                            accountEmployeeDetail.setDirectManager(iAccount.getDirectManager());
                            accountEmployeeDetail.setGender(iAccount.getGender());
                            accountRepository.save(account);
                            accountEmployeeDetailRepository.save(accountEmployeeDetail);
//                            for (String field : iAccount.getCheckedFieldManage()) {
//                                AccountForManageField accountForManageField = new AccountForManageField();
//                                accountForManageField.setAccount(account.getAccount());
//                                accountForManageField.setField(field);
//                                accountForManageField.setStatus(Constants.STATUS_CATEGORY_ACTIVE);
//                                accountForManageFieldRepository.save(accountForManageField);
//                            }
                        }
                    }
                } catch (Exception ex) {
                    if (ex instanceof DataIntegrityViolationException) {
                        if (ex.getCause() instanceof ConstraintViolationException) {
                            messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                        }
                    }
                }

                errMap.put(iAccount.getRow(), messageError);
            }
        });
        excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, iExcelMapperObj);
    }

    private void saveAccountGroupRoleExcel(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<AccountGroupRoleExcelItemObj> lst, IExcelMapperObj iExcelMapperObj) throws IOException {
        Map<Integer, String> errMap = new HashMap<>();
        lst.stream().forEach(row -> {
            String messageError = "";
            if (StringUtils.isNotEmpty(row.getAccount()) || StringUtils.isNotEmpty(row.getGroupRole())) {
                int flag = 0;
                if (StringUtils.isEmpty(row.getAccount())) {
                    messageError += Messages.getString("ValidationException.error.not.null.account.name");
                    flag++;
                } else {
                    String checkMsgErr = CommonUtils.errorAccountMsg(row.getAccount());
                    messageError += checkMsgErr;
                    if (!checkMsgErr.equalsIgnoreCase("")) {
                        flag++;
                    }
                    Account existAccount = accountRepository.findByAccount(row.getAccount()).orElse(null);
                    if (existAccount == null) {
                        messageError += Messages.getString("ValidationException.error.not.exists.account");
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(row.getGroupRole())) {
                    messageError += Messages.getString("ResponseError.GroupRole.IsNotNull");
                    flag++;
                } else {
                    GroupRole existGroupRole = groupRoleRepository.findByCode(row.getGroupRole());
                    if (existGroupRole == null) {
                        messageError += Messages.getString("ResponseError.GroupRole.IsNull");
                        flag++;
                    }
                }

                try {
                    if (flag == 0) {
                        AccountGroupRole existAccountGroupRole = accountGroupRoleRepository.findByGroupRoleAndAccount(row.getGroupRole(), row.getAccount());
                        if (existAccountGroupRole == null) {
                            AccountGroupRole accountGroupRole = new AccountGroupRole(row.getGroupRole(), row.getAccount(), 1);
                            accountGroupRoleRepository.save(accountGroupRole);
                        } else {
                            existAccountGroupRole.setStatus(1);
                            accountGroupRoleRepository.save(existAccountGroupRole);
                        }
                    }
                } catch (Exception ex) {
                    if (ex instanceof DataIntegrityViolationException) {
                        if (ex.getCause() instanceof ConstraintViolationException) {
                            messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                        }
                    }
                }
                errMap.put(row.getRow(), messageError);
            }
        });
        excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, iExcelMapperObj);
    }


    @Override
    public ResponseEntity exportAccount(AccountFilter filter, String type) throws FileNotFoundException, JRException, IllegalAccessException {
        JRDataSource dataSource = new JREmptyDataSource();
        filter.setKeySearch(CommonUtils.rmVNString(filter.getKeySearch()));
        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
        String fileName = ((AccountFilter) filter).getTypeEmployee().equals(Constants.TYPE_EMPLOYEE.ADMIN) ? "tai_khoan_quan_tri" : "tai_khoan_nguoi_dung";
        String templatePath = fileName + ".jasper";
        String mimeType = "." + type.toLowerCase(Locale.ENGLISH);
        Map<String, Object> reportParams = new HashMap<>();
        //Lưu log
        String menu = ((AccountFilter) filter).getTypeEmployee().equals(Constants.TYPE_EMPLOYEE.ADMIN) ? Constants.MENU_CODE.ACCOUNT.admin : Constants.MENU_CODE.ACCOUNT.emp;
        loggingService.successLog(new LogActionDTO(QTUD, menu, ActionCode.EXPORT, null, Instant.now()));

        ListResponse res = (ListResponse) this.listAccount(filter).getData();
//        ICallStoredObj callStoredObj = new AccountCallStoredDTO(filter);
//        Object res = callStoredRepository.list(callStoredObj);

        // sửa cho trường hợp: export tài khoản quản trị cần viết hoa
        if ((Integer.parseInt((filter).getTypeEmployee())) == Constants.ACCOUNT_EMP_TYPE.ADMIN) {
            List<AccountResponse> accountResponses = (List<AccountResponse>) ((ListResponse) res).getList();
            accountResponses.stream().forEach(e -> {
                e.setAccount(e.getAccount().toUpperCase());
                e.setOrganizationName(e.getOrganizationName() + " - " + e.getSignOrganization());
            });
            if (accountResponses != null && accountResponses.size() > 0) {
                accountResponses.stream().map(e -> {
                    if (e.getPhone() != null) {
                        e.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPhone()));
                    }
                    if (e.getPoliceNumber() != null) {
                        e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                    }
                    return e;
                }).collect(Collectors.toList());
            }
            accountResponses.add(0, new AccountResponse());
            dataSource = new JRBeanCollectionDataSource(accountResponses);
            reportParams.put("dataSource", dataSource);

            oStream = CommonService.generateReport(dataSource, templatePath, reportParams, type.toLowerCase(Locale.ENGLISH));
            return CommonUtils.downloadFileJasper(oStream, fileName + "_" + sdf.format(new Date()) + mimeType);
        } else {
            List<AccountResponse> lstResults = (List<AccountResponse>) ((ListResponse) res).getList();
            lstResults.add(0, new AccountResponse());
//            if (lstResults != null && lstResults.size() > 0) {
//                lstResults.stream().map(e -> {
//                    if (e.getPhone() != null) {
//                        e.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPhone()));
//                    }
//                    if (e.getPoliceNumber() != null) {
//                        e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
//                    }
//                    return e;
//                }).collect(Collectors.toList());
//            }
            dataSource = new JRBeanCollectionDataSource(lstResults);
            reportParams.put("dataSource", dataSource);

            oStream = CommonService.generateReport(dataSource, templatePath, reportParams, type.toLowerCase(Locale.ENGLISH));
            return CommonUtils.downloadFileJasper(oStream, fileName + "_" + sdf.format(new Date()) + mimeType);
        }
        // insert empty into 0 index
    }

    @Override
    public ResponseEntity exportAccountService(TextFilter filter, String type) throws FileNotFoundException, JRException {
        JRDataSource dataSource = new JREmptyDataSource();

        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
        String templatePath = "Tai_khoan_tich_hop.jasper";
        String fileName = "Tai_khoan_tich_hop";
        String mimeType = "." + type.toLowerCase(Locale.ENGLISH);
        Map<String, Object> reportParams = new HashMap<>();

        ICallStoredObj callStoredObj = new AccountCallStoredDTO(filter);
        Object res = callStoredRepository.list(callStoredObj);
        List<AccountServiceResponse> lstResults = (List<AccountServiceResponse>) ((ListResponse) res).getList();
        // insert empty into 0 index
        lstResults.add(0, new AccountServiceResponse());
        dataSource = new JRBeanCollectionDataSource(lstResults);
        reportParams.put("dataSource", dataSource);

        oStream = CommonService.generateReport(dataSource, templatePath, reportParams, type.toLowerCase(Locale.ENGLISH));
        return CommonUtils.downloadFileJasper(oStream, fileName + "_" + sdf.format(new Date()) + mimeType);
    }

    @Override
    public ResponseBase compareAcc(String fulLName, String policeNumber) {
        AccountCompareDTO accountCompareDTO = new AccountCompareDTO();
        Boolean check = true;
        AccountEmployeeDetail accountEmployeeDetailPoliceNumber = accountEmployeeDetailRepository.findByPoliceNumberAndFullName(policeNumber.trim(), fulLName.trim());
        if (accountEmployeeDetailPoliceNumber == null) {
            check = false;
        }
        accountCompareDTO.setCheck(check);
        accountCompareDTO.setAccountEmployeeDetail(accountEmployeeDetailPoliceNumber);

        return new ResponseBase(accountCompareDTO);
    }

    @Override
    public ResponseBase listAccountByRequirePurpose(TextFilter filter, String requirePurposeCode, Long flag) throws IllegalAccessException {
        trimSpaceUtil.validate(requirePurposeCode);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(filter, requirePurposeCode, flag);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseEntity importExcelReturnResult(MultipartFile file) throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException, Exception {
        int sheetAt = 0;
        int firstRow = 5;
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj = new AccountServiceExcelObj(0);
        List<AccountServiceExcelItemObj> lst = excelObjectMapper.map(AccountServiceExcelItemObj.class, sheetAt, iExcelMapperObj, firstRow);
        return saveDataExcelReturnRes(excelObjectMapper, sheetAt, firstRow, lst);
    }

    @Override
    public ResponseBase getAccountInGroupRole(TextFilter accountGroupRoleFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(accountGroupRoleFilter);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountGroupRoleFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase getAccountWithoutGroupRole(TextFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    private String getDefaultPw() {
        String defaultPW = (String) redisTemplate.opsForValue().get(Constants.REDIS_KEY.DEFAULT_PW);
        if (StringUtils.isNotEmpty(defaultPW)) {
            return defaultPW;
        } else {
            ICallStoredObj callStoredObj = new AccountCallStoredDTO();
            defaultPW = callStoredRepository.getStringFromMap(callStoredObj);
            redisTemplate.opsForValue().set(Constants.REDIS_KEY.DEFAULT_PW, defaultPW, 3600, TimeUnit.SECONDS);
            return defaultPW;
        }
    }

    private String getRandomPw() {
        String random = "";
        if (Integer.valueOf(passwordLock) == 1) {
            random = generalConfigService.generateRandomPassword();
        }
        if (random.length() == 0) random = String.format("%06d", new Random().nextInt(999999)).substring(0, 6);
        return random;
    }

    @Override
    public ResponseBase listAccountDirect(String code, String parentCode) {
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(code, parentCode, 1);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }


    @Override

    public ResponseBase listAccountDirectBottom(TextFilter textFilter, String position, String org) {
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter, position, org);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    public ResponseBase changeOrg(AccountChangeOrgDTO accountChangeOrgDTO) throws NotFoundException {
        Account account = accountRepository.findByAccountAndStatus(accountChangeOrgDTO.getAccount(), Constants.STATUS_CATEGORY_ACTIVE);
        if (account != null) {
            account.setOrganization(accountChangeOrgDTO.getOrganization());
            account.setStatus(Constants.STATUS_CATEGORY_ACTIVE);
            accountRepository.save(account);
        } else {
            throw new NotFoundException(String.format("Khong tim thay tai khoan %s !", accountChangeOrgDTO.getAccount()));
        }
        return new ResponseBase(account);
    }

    @Override
    public ResponseBase listAccountQLTT(TextFilter textFilter) throws IllegalAccessException {
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter, 1);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    private String getAccountByNameAndPoliceCode(String name, String policeCode) {
        String fullName = CommonUtils.rmVNString(name.toLowerCase(Locale.ENGLISH));
        String[] strTen = fullName.split(" ");
        List<String> firstS = Stream.of(strTen).map(e -> getFirst(e)).collect(Collectors.toList()).subList(0, strTen.length - 1);
        String ten = String.format("%s%s", strTen[strTen.length - 1], String.join("", firstS));
        String cand = policeCode.replace("-", "");
        return (ten + cand).toLowerCase(Locale.ENGLISH);
    }

    public ResponseBase updateAccountWhenRejectOrActive(String account, String url, AccountEmployeeDetail accountEmployeeDetail, int actionType) {
        try {
            url = url + "/" + account;
            String token = vn.gtel.common.config.security.TokenUtils.getInstance().getTokenFromRequestContextHolder();
            callRestAPIServiceImpl.call(url, HttpMethod.POST, null, null, token, accountEmployeeDetail, actionType);
            accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.SUCESS);
            return new ResponseBase(accountEmployeeDetailRepository.save((accountEmployeeDetail)));
        } catch (Exception e) {
            if (Constants.ACTION_TYPE_CODE_FOR_DTHS.ACCEPT_TYPE == actionType) {
                log.error("call into DTHS(Accept-Acount) Error");
            } else {
                log.error("call into DTHS(Reject-Acount) Error");
            }
            return new ResponseBase(accountEmployeeDetailRepository.save((accountEmployeeDetail)));
        }
    }

    public void updateAccountWhenRejectOrActiveForSynchronized(String account, String url, AccountEmployeeDetail accountEmployeeDetail, int actionType) {
        try {
            url = url + "/" + account;
            String token = vn.gtel.common.config.security.TokenUtils.getInstance().getTokenFromRequestContextHolder();
            callRestAPIServiceImpl.call(url, HttpMethod.POST, null, null, token, accountEmployeeDetail, actionType);
            accountEmployeeDetail.setMoveStatus(Constants.ACTION_TYPE_CODE_FOR_DTHS.SUCESS);
            accountEmployeeDetailRepository.save((accountEmployeeDetail));
        } catch (Exception e) {
            if (Constants.ACTION_TYPE_CODE_FOR_DTHS.ACCEPT_TYPE == actionType) {
                log.error("--------------call into DTHS(Accept-Acount) Error--------------c");
            } else {
                log.error("--------------call into DTHS(Reject-Acount) Error--------------c");
            }
            // accountEmployeeDetailRepository.save((accountEmployeeDetail));
        }
    }

//    @Override
//    public ResponseBase generateAdmin(AdminGeneratorReq request) throws Exception {
//        trimSpaceUtil.validate(request);
//        if (request.getPassword() == null)
//            request.setPassword(getRandomPw());
//        String encodedPassword = passwordEncoder.encode(request.getPassword());
//        vn.gtel.common.dto.AccountDTO account = AccountLogonContext.currentUser();
//        ICallStoredObj callStoredObj = new AccountCallStoredDTO(request.getOrganization(), encodedPassword, account.getAccount());
//        Object response = callStoredRepository.save(callStoredObj);
//        return new ResponseBase(new AdminGeneratorRes(response, request.getPassword()));
//    }

    @Override
    public ResponseBase listLead(TextFilter textFilter) throws IllegalAccessException {
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter, 2);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseEntity createTemplate() throws IOException, IllegalAccessException, NoSuchFieldException, InstantiationException {
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(CommonService.pathTemp("IMPORT_ACCOUNT_EMP_TEMPLATE.xlsx"));

        List<Position> positions = positionCatRepo.findByStatusAndClassifyOrderByCodeAsc(1, 1);
        List<ExcelItemDto> positionDtos = positions.stream().map(e -> new ExcelItemDto(e.getCode(), e.getName(), e.getCode() + " - " + e.getName())).collect(Collectors.toList());
        List<IExcelItem> positionsData = positionDtos.stream().map(e -> new ActionExcelItemObj(e.getCode(), e.getName(), e.getPooledCode())).collect(Collectors.toList());

        List<Rank> ranks = rankCatRepo.findByStatusOrderByCodeAsc(1);
        List<ExcelItemDto> ranksDtos = ranks.stream().map(e -> new ExcelItemDto(e.getCode(), e.getName(), e.getCode() + " - " + e.getName())).collect(Collectors.toList());
        List<IExcelItem> ranksData = ranksDtos.stream().map(e -> new ActionExcelItemObj(e.getCode(), e.getName(), e.getPooledCode())).collect(Collectors.toList());

        List<Gender> genders = genderRepo.findByStatusOrderByCodeAsc(1);
        List<ExcelItemDto> genderDtos = genders.stream().map(e -> new ExcelItemDto(e.getCode(), e.getName(), e.getCode() + " - " + e.getName())).collect(Collectors.toList());
        List<IExcelItem> gendersData = genderDtos.stream().map(e -> new ActionExcelItemObj(e.getCode(), e.getName(), e.getPooledCode())).collect(Collectors.toList());

        List<CatSheetDTO> catSheetDTOS = List.of(new CatSheetDTO(2, positionsData), new CatSheetDTO(3, ranksData), new CatSheetDTO(4, gendersData));
        int startRowAt = 4;
        IExcelMapperObj actionExcelObj = new ActionExcelObj(0);
        return CommonUtils.downloadFile(excelObjectMapper.getTemplateWithData(catSheetDTOS, ActionExcelItemObj.class, actionExcelObj, startRowAt), "temp_import_tai_khoan_nguoi_dung.xlsx");
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ResponseBase transferOrganization(OrganizationTransferReq request) throws Exception {
        trimSpaceUtil.validate(request);
        AccountOrganization accountOrganization = new AccountOrganization(request);
        accountOrganization.setTransferType(request.getTransferReqType());
        vn.gtel.common.dto.AccountDTO accountLogin = AccountLogonContext.currentUser();
        Account account = accountRepository.findByAccountAndStatus(request.getAccount(), Constants.ACCOUNT_STATUS.ACTIVE);
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(request.getAccount());
        Organization oldOrganization = organizationRepo.findByCodeAndStatus(request.getOldOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        Organization newOrganization = organizationRepo.findByCodeAndStatus(request.getNewOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountLogin.getAccount(), Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT);
//        List<Organization> managedOrganizations = (List<Organization>) callStoredRepository.getList(callStoredObj);

        if (account == null)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.exists.account"), null);

        if (!accountLogin.getType().toString().equals(Constants.TYPE_EMPLOYEE.ADMIN))
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.admin.account.required"), null);

//        if (managedOrganizations.stream().filter(org -> org.getCode().equals(account.getOrganization())).count() == 0)
//            // Exception: Admin V01 manages BCA accounts
//            if (!account.getOrganization().equals(Constants.ORGANIZATION_CODE.BCA) || !accountLogin.getOrganization().equals(Constants.ORGANIZATION_CODE.V01))
//                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.account.org.out.of.range.permission"), null);

        if (newOrganization == null)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.exist.organization.code"), null);

        if (newOrganization.getCode().equals(account.getOrganization()))
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.transfer.error.duplicated.new.old.org"), null);

        AccountOrganization existTransfer = accountOrganizationRepository.findByAccountAndStatus(request.getAccount(), Constants.TRANSFER_ORG_STATUS.IN_PROGRESS);

        if (existTransfer != null)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.transfer.error.existed.account"), null);


        // Check chuyen doi sang doi thuoc PC cac tinh (khong can cap lai so dang ky ho so)
        int checkPC = 0;
//        if (newOrganization.getCode().length() == 12 && oldOrganization.getCode().length() == 12
//                && newOrganization.getCode().startsWith(Constants.ORGANIZATION_CODE.CAT) && oldOrganization.getCode().startsWith(Constants.ORGANIZATION_CODE.CAT)) {
//            if (newOrganization.getSubSystem() != null && oldOrganization.getSubSystem() != null) {
//                if (newOrganization.getSubSystem() == 1 && oldOrganization.getSubSystem() == 1 && newOrganization.getOrganizationParent().equals(oldOrganization.getOrganizationParent())) {  // 1 canh sat, 2 an ninh
//                    Organization parentOfNewOrg = organizationRepo.findByCode(newOrganization.getOrganizationParent());// doi thuoc huyen
//                    if (parentOfNewOrg.getOrganizationDependent() != null) {
//                        checkPC = 1;
//                    }
//                }
//            }
//        }
        // API CHECK TRANSFER ACCOUNT'S DATA FROM OTHERS APPLICATION
//        AccountChangeOrgDTO accountChangeOrgDTO = new AccountChangeOrgDTO(request.getAccount(), request.getOldOrganization());
//        String token = vn.gtel.common.config.security.TokenUtils.getInstance().getTokenFromRequestContextHolder();

//        if (checkPC == 1) { // khong can check nvcb
//            String errorMessage = checkForeignJobsBeforeOrgTransfer(request, token, null);
//            if (errorMessage != null)
//                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, errorMessage, request.getAccount());
//
//            // push data len kafka cho nvcb va hscs
//            OrganizationTransferByGroupReq transferKafka = new OrganizationTransferByGroupReq();
//            transferKafka.setDecisionDate(request.getDecisionDate());
//            transferKafka.setTransferType(3);
//            transferKafka.setDecisionNo(request.getDecisionNo());
//            transferKafka.setDecisionSigner(request.getDecisionSigner());
//            List<AccountTransferReq> list = new ArrayList<>();
//            AccountTransferReq accountTransferReq = new AccountTransferReq();
//            accountTransferReq.setAccount(request.getAccount());
//            accountTransferReq.setNewOrganization(request.getNewOrganization());
//            accountTransferReq.setOldOrganization(request.getOldOrganization());
//            list.add(accountTransferReq);
//            transferKafka.setAccountTransferList(list);
//            transferProducer.sendMsg(Constants.TOPIC_NAME.TRANSFER_LIST_ACC_TO_NVCB, transferKafka);
//            transferProducer.sendMsg(Constants.TOPIC_NAME.TRANSFER_LIST_ACC_TO_HSCS, transferKafka);
//            accountOrganization.setTransferType(3);
//        } else {
//            String errorMessage = checkForeignJobsBeforeOrgTransfer(request, token, accountChangeOrgDTO);
//            if (errorMessage != null)
//                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, errorMessage, request.getAccount());
//
//        }

        // remove role
//        accountGroupRoleRepository.deleteByAccountAndCreatedByNot(account.getAccount(),"admin");
        request.setOldOrganization(account.getOrganization());
        //chuyển trạng thái account sang chờ chuyển đơn vị
//        account.setStatus(Constants.ACCOUNT_STATUS.WAITING_CHANGE_ORG);
//        if (managedOrganizations.stream().filter(org -> org.getCode().equals(newOrganization.getCode())).count() > 0) {
//            accountOrganization.setStatus(Constants.TRANSFER_ORG_STATUS.APPROVE);
//            account.setOrganization(newOrganization.getCode());
//            if (account.getConfirmInformation() == Constants.CONFIRM_INFO.REFUSE) {
//                account.setConfirmInformation(Constants.CONFIRM_INFO.WAITING);
//            }
//
//            // khi chuyen cung admin thi day sang dths luôn con khac admin thì phải an nút tiep nhan mới đua sang
//            // cap nhat don vi sang dths
//            // kiem tra tai khoan co duoc phan vao dths hay khong (chuc danh, nhom quyen)
//            if (IsQualifiedToDTHS(account.getAccount(), accountEmployeeDetail)) {
//                try {
//                    AccountDTHSDTO accountDTHSDTO = new AccountDTHSDTO();
//                    accountDTHSDTO.setTaikhoan(account.getAccount());
//                    accountDTHSDTO.setHoten(accountEmployeeDetail.getFullName());
//                    accountDTHSDTO.setSodienthoai(accountEmployeeDetail.getPhone());
//                    accountDTHSDTO.setSohieucand(accountEmployeeDetail.getPoliceNumber());
//                    if (accountEmployeeDetail.getMilitary() != null) {
//                        accountDTHSDTO.setMacapbac(accountEmployeeDetail.getMilitary());
//                    }
//                    accountDTHSDTO.setMachucvu(accountEmployeeDetail.getPosition());
//                    if (accountEmployeeDetail.getDignity() != null) {
//                        accountDTHSDTO.setMachucdanh(accountEmployeeDetail.getDignity());
//                    }
//                    accountDTHSDTO.setMadonvicongtac(request.getNewOrganization());
//                    callRestAPIServiceImpl.call(urlUpdate, HttpMethod.POST, null, accountDTHSDTO, token);
//                } catch (Exception e) {
//                    throw new ValidationException("ValidationException.transfer.error.call.change.org.dths");
//                }
//            }
//
//        } else {
//            accountOrganization.setStatus(Constants.TRANSFER_ORG_STATUS.IN_PROGRESS);
//            account.setStatus(Constants.ACCOUNT_STATUS.WAITING_CHANGE_ORG);
//            if (account.getConfirmInformation() == Constants.CONFIRM_INFO.REFUSE) {
//                account.setConfirmInformation(Constants.CONFIRM_INFO.WAITING);
//            }
//
//        }
        accountRepository.save(account);
        accountOrganization = accountOrganizationRepository.save(accountOrganization);
        if (accountOrganization.getTransferType().equals(Constants.CHANGE_ORG_TYPE.SAME_ORG)) {
            this.updateTransferProcess(accountOrganization.getId(), Constants.TRANSFER_ORG_STATUS.APPROVE, null);
        }

        Organization organizationOld = organizationRepo.findByCode(accountOrganization.getOldOrganization());
        Organization organizationNew = organizationRepo.findByCode(accountOrganization.getNewOrganization());

        List<String> accountHistoryList = List.of(account.getAccount());
        updateAccountHistory(accountHistoryList);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//        this.clearAllAccountCache();
//        this.clearDetailAccountCache();
//        Cache cacheDetailUser = cacheManager.getCache("detailUser");
//        cacheDetailUser.clear();
//        Cache cacheAllAccount = cacheManager.getCache("userCache");
//        cacheAllAccount.clear();
        clearCache(Constants.REDIS_KEY.GET_ME + account.getAccount());
        String content = null;
        if (organizationOld != null && organizationNew != null) {
            content = String.format("Đã chuyển tài khoản tên là %s từ đơn vị là %s - %s - %s sang đơn vị là %s - %s - %s", account.getAccount(), accountOrganization.getOldOrganization(), organizationOld.getFullName(), organizationOld.getOrgCodeNew() == null ? "" : organizationOld.getOrgCodeNew(), accountOrganization.getNewOrganization(), organizationNew.getOrgCodeNew() == null ? "" : organizationNew.getOrgCodeNew(), organizationNew.getFullName());
        } else {
            content = String.format("Đã chuyển Tài khoản tên là %s từ đơn vị có mã là %s sang đơn vị có mã là %s", account.getAccount(), accountOrganization.getOldOrganization(), accountOrganization.getNewOrganization());
        }
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.emp, ActionCode.CHANGE_ORG, content, Instant.now()));
        return new ResponseBase(accountOrganization);
    }

    @Override
    public ResponseBase updateTransferProcess(String transferId, Integer action, String decisionSigner) throws NotFoundException, ValidationException {
        String token = vn.gtel.common.config.security.TokenUtils.getInstance().getTokenFromRequestContextHolder();
        AccountOrganization accountOrganization = accountOrganizationRepository.findByIdAndStatus(transferId, Constants.TRANSFER_ORG_STATUS.IN_PROGRESS);
        vn.gtel.common.dto.AccountDTO accountLogin = AccountLogonContext.currentUser();
//        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountLogin.getAccount(), Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT);
//        List<Organization> managedOrganizations = (List<Organization>) callStoredRepository.getList(callStoredObj);
        if (StringUtils.isNotEmpty(decisionSigner)) {
            accountOrganization.setDecisionSigner(decisionSigner);
        }

        if (accountOrganization == null)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.transfer.error.not.exist.id"), null);

//        if (managedOrganizations.stream().filter(org -> org.getCode().equals(accountOrganization.getNewOrganization())).count() == 0)
//            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.account.org.out.of.range.permission"), null);

        if (action != null && action.longValue() != Constants.TRANSFER_ORG_STATUS.APPROVE && action.longValue() != Constants.TRANSFER_ORG_STATUS.REJECT)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("response.message.error.100025"), null);

        Account account = accountRepository.findByAccount(accountOrganization.getAccount()).get();
        AccountEmployeeDetail employeeDetail = null;
        if (account != null && account.getAccount() != null) {
            employeeDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
        }

        if (action != null && action.longValue() == Constants.TRANSFER_ORG_STATUS.APPROVE) {
            if (account == null)
                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.transfer.error.not.exist.account"), null);
            // remove role
            if (accountOrganization.getTransferType() == Constants.CHANGE_ORG_TYPE.DIFFERENT_ORG) {
                accountGroupRoleRepository.deleteByAccountAndCreatedByNotAndCreatedByNot(account.getAccount(), Constants.ADMIN, Constants.SUB_ADMIN_PC08);
            }

            //remove người dùng khỏi nhóm người dùng
            if (accountOrganization.getTransferType() == Constants.CHANGE_ORG_TYPE.DIFFERENT_ORG) {
                accountGroupAccountRepository.deleteByAccountAndCreatedByNotAndCreatedByNot(account.getAccount(), Constants.ADMIN, Constants.SUB_ADMIN_PC08);
            }
            account.setOrganization(accountOrganization.getNewOrganization());

            AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
            if (accountEmployeeDetail == null)
                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.exist.account.detail"), null);
        }
        account.setStatus(Constants.ACCOUNT_STATUS.ACTIVE);
        account.setCreatedBy(accountLogin.getAccount());
        accountRepository.save(account);
        if (accountOrganization.getPosition() != null) {
            employeeDetail.setPosition(accountOrganization.getPosition());
        }
        if (accountOrganization.getMilitary() != null) {
            employeeDetail.setMilitary(accountOrganization.getMilitary());
        }
        accountEmployeeDetailRepository.save(employeeDetail);
        if (action != null) {
            accountOrganization.setStatus(action);
        }

        accountOrganizationRepository.save(accountOrganization);

        Organization organizationOld = organizationRepo.findByCode(accountOrganization.getOldOrganization());
        Organization organizationNew = organizationRepo.findByCode(accountOrganization.getNewOrganization());

        List<String> accountHistoryList = List.of(account.getAccount());
        updateAccountHistory(accountHistoryList);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//        this.clearAllAccountCache();
//        this.clearDetailAccountCache();
//        Cache cacheDetailUser = cacheManager.getCache("detailUser");
//        cacheDetailUser.clear();
//        Cache cacheAllAccount = cacheManager.getCache("userCache");
//        cacheAllAccount.clear();
        clearCache(Constants.REDIS_KEY.GET_ME + account.getAccount());
        String content = null;
        if (action != null && action == 3) {
            if (organizationOld != null && organizationNew != null) {
                content = String.format("Đã từ chối tài khoản có tên là %s từ đơn vị %s - %s - %s sang đơn vị là %s - %s - %s", account.getAccount(), accountOrganization.getOldOrganization(), organizationOld.getFullName(), organizationOld.getOrgCodeNew() == null ? "" : organizationOld.getOrgCodeNew(), accountOrganization.getNewOrganization(), organizationNew.getOrgCodeNew() == null ? "" : organizationNew.getOrgCodeNew(), organizationNew.getFullName());
            } else {
                content = String.format("Đã từ chối tài khoản có tên là %s từ đơn vị mã %s sang đơn vị %s", account.getAccount(), accountOrganization.getOldOrganization(), accountOrganization.getNewOrganization());
            }
        } else if (action != null && action == 2) {
            if (organizationOld != null && organizationNew != null) {
                content = String.format("Đã tiếp nhận tài khoản có tên là %s từ đơn vị %s - %s - %s sang đơn vị là %s - %s - %s", account.getAccount(), accountOrganization.getOldOrganization(), organizationOld.getFullName(), organizationOld.getOrgCodeNew() == null ? "" : organizationOld.getOrgCodeNew(), accountOrganization.getNewOrganization(), organizationNew.getOrgCodeNew() == null ? "" : organizationNew.getOrgCodeNew(), organizationNew.getFullName());
            } else {
                content = String.format("Đã tiếp nhận tài khoản có tên là %s từ đơn vị mã %s sang đơn vị %s", account.getAccount(), accountOrganization.getOldOrganization(), accountOrganization.getNewOrganization());
            }
        }
        if (action != null && action.longValue() == Constants.TRANSFER_ORG_STATUS.APPROVE) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.transferProcess, ActionCode.RECEIVE, content, Instant.now()));
        } else if (action != null && action.longValue() == Constants.TRANSFER_ORG_STATUS.REJECT) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.transferProcess, ActionCode.REFUSE, content, Instant.now()));
        }
        return new ResponseBase(accountOrganization);
    }

    @Override
    public ResponseBase listTransferOrg(AccountTransferOrgFilter accountTransferOrgFilter) {
        accountTransferOrgFilter.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.encrypt(accountTransferOrgFilter.getPoliceNumber()));
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountTransferOrgFilter);
        Object res = callStoredRepository.list(callStoredObj);
        ListResponse response = (ListResponse) res;
        if (response.getList() != null) {
            List<AccountTransferOrgResponse> results = (List<AccountTransferOrgResponse>) response.getList();
            if (results != null && results.size() > 0) {
                results.parallelStream().map(e -> {
                    if (e.getPoliceNumber() != null) {
                        e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                    }
                    if (e.getChangeDate().equals(e.getAcctionDate())) {
                        e.setAcctionDate(null);
                    }
                    return e;
                }).collect(Collectors.toList());
            }
            return new ResponseBase(new ListResponse(results, response.getTotal()));
        }
        return new ResponseBase(res);
    }

    @Override
    public ResponseEntity exportAcc(String acc) throws ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, JRException {

        ExportAccountDTO exportAccountDTO = new ExportAccountDTO();
        Account account = accountRepository.findByAccountAndStatus(acc, Constants.STATUS_CATEGORY_ACTIVE);
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(acc);

        if (account == null || accountEmployeeDetail == null) {
            throw new ValidationException("ValidationException.error.not.exists.account");
        }

        Organization organization = organizationRepo.findByCodeAndStatus(AccountLogonContext.currentUser().getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        if (organization == null) {
            throw new ValidationException("ValidationException.error.not.exists.organization.code");
        }
        Organization organizationAcc = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        if (organizationAcc == null) {
            throw new ValidationException("ValidationException.error.not.exists.organization.code");
        }
        exportAccountDTO.setFullName(accountEmployeeDetail.getFullName());
        exportAccountDTO.setPoliceNumber(accountEmployeeDetail.getPoliceNumber());
        exportAccountDTO.setOrgName(organization.getName());
        exportAccountDTO.setAccount(account.getAccount());
        if (account.getPasswordStart() != null) {
            exportAccountDTO.setPasswordStart(dePassWordAES(account.getPasswordStart()));
        }
        ICallStoredObj callStoredObj = new GroupRoleCallStoredDTO(new TextFilter(), acc, null, null, Constants.ACCOUNT_EMP_TYPE.USER, null);
        Object res = callStoredRepository.getList(callStoredObj);
        List<GroupRoleResponse> groupRoleAccountDTOS = (List<GroupRoleResponse>) res;
        List<ExportRoleAccountDTO> exportRole = new ArrayList<>();
        if (groupRoleAccountDTOS.size() != 0) {
            for (GroupRoleResponse groupRoleResponse : groupRoleAccountDTOS) {
                ExportRoleAccountDTO exportRoleAccountDTO = modelMapper.map(groupRoleResponse, ExportRoleAccountDTO.class);
                exportRole.add(exportRoleAccountDTO);

            }
        }
        exportAccountDTO.setExportRoleAccountDTOS(exportRole);


        JRDataSource dataSource = new JREmptyDataSource();

        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
        String fileName = "";
        String fileNameResponse = "";
        if (accountEmployeeDetail.getAccountType() == 1) {
            fileName = "Thong_tin_tai_khoan_admin";
            fileNameResponse = "Thong_tin_tai_khoan_admin" + "_" + organizationAcc.getSign().replaceAll("\\s", "_");
        } else {
            fileName = "Thong_tin_tai_khoan_nguoi_dung";
            fileNameResponse = "Thong_tin_tai_khoan_nguoi_dung" + "_" + account.getAccount();
        }

        String templatePath = fileName + ".jasper";
        String mimeType = "." + Constants.EXPORT_TYPE.docx;
        Map<String, Object> reportParams = new HashMap<>();

        Date date = new Date();
        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        exportRole.add(0, new ExportRoleAccountDTO());
        dataSource = new JRBeanCollectionDataSource(exportRole);

        //reportParams.put("account", exportAccountDTO.getAccount());
        reportParams.put("passwordStart", exportAccountDTO.getPasswordStart());
        reportParams.put("policeNumber", exportAccountDTO.getPoliceNumber());
        reportParams.put("fullName", exportAccountDTO.getFullName());
        if (accountEmployeeDetail.getPosition() != null) {
            Position position = positionCatRepo.findByCode(accountEmployeeDetail.getPosition());
            if (position != null) {
                reportParams.put("position", position.getName());
            }
        } else {
            reportParams.put("position", "");
        }
        if (accountEmployeeDetail.getDignity() != null) {
            Title title = titleRepo.findByCode(accountEmployeeDetail.getDignity());
            reportParams.put("dignity", title.getName());
        } else {
            reportParams.put("dignity", "");
        }
        if (accountEmployeeDetail.getMilitary() != null) {
            Rank rank = rankCatRepo.findByCodeAndStatus(accountEmployeeDetail.getMilitary(), Constants.STATUS_CATEGORY_ACTIVE);
            reportParams.put("military", rank.getName());
        } else {
            reportParams.put("military", "");
        }
        if (accountEmployeeDetail.getDirectManager() != null) {
            AccountEmployeeDetail accountEmployeeDetailManager = accountEmployeeDetailRepository.findByAccount(accountEmployeeDetail.getDirectManager());
            if (accountEmployeeDetailManager != null) {
                reportParams.put("accountManager", accountEmployeeDetailManager.getFullName());
            }

        } else {
            reportParams.put("accountManager", "");
        }

        reportParams.put("phone", accountEmployeeDetail.getPhone());
        reportParams.put("orgFull", organizationAcc.getName());
        if (accountEmployeeDetail.getAccountType() == 1) {
            reportParams.put("account", exportAccountDTO.getAccount().toUpperCase());
            reportParams.put("dataSource", null);
            Organization orgParent = organizationRepo.findByCodeAndStatus(organizationAcc.getOrganizationParent(), Constants.STATUS_CATEGORY_ACTIVE);
            if (organizationAcc.getCode().length() == 6) {
                reportParams.put("org", organizationAcc.getName());
            } else {
                reportParams.put("org", organizationAcc.getName() + ", " + orgParent.getName());
            }

            reportParams.put("day", localDate.getDayOfMonth());
            reportParams.put("month", localDate.getMonthValue());
        } else {
            reportParams.put("dataSource", dataSource);
            reportParams.put("account", exportAccountDTO.getAccount());
            reportParams.put("org", organization.getName());
        }


        oStream = CommonService.generateReport(dataSource, templatePath, reportParams, Constants.EXPORT_TYPE.docx.toString());
        return CommonUtils.downloadFileJasper(oStream, fileNameResponse + mimeType);

        //return new ResponseBase(exportAccountDTO);
    }

    @Override
    public ResponseBase updatePassAdmin(String text) throws NotFoundException, ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, JRException {
        List<Account> accounts = accountRepository.findAllByAccountStartingWith(text);
        for (Account account : accounts) {
            account.setRqChangePw(1);
            String pass = getRandomPw();
            account.setPassword(passwordEncoder.encode(pass));
            account.setPasswordStart(enPassWordAES(pass));
            accountRepository.save(account);
        }
        return new ResponseBase(null);
    }

    private void exportAccount(String acc, Organization organizationProvince) throws ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, JRException {

        ExportAccountDTO exportAccountDTO = new ExportAccountDTO();
        Account account = accountRepository.findByAccountAndStatus(acc, Constants.STATUS_CATEGORY_ACTIVE);
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(acc);

        if (account == null || accountEmployeeDetail == null) {
            throw new ValidationException("ValidationException.error.not.exists.account");
        }

        Organization organization = organizationRepo.findByCodeAndStatus(AccountLogonContext.currentUser().getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        if (organization == null) {
            throw new ValidationException("ValidationException.error.not.exists.organization.code");
        }
        Organization organizationAcc = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        if (organizationAcc == null) {
            throw new ValidationException("ValidationException.error.not.exists.organization.code");
        }
        exportAccountDTO.setFullName(accountEmployeeDetail.getFullName());
        exportAccountDTO.setPoliceNumber(accountEmployeeDetail.getPoliceNumber());
        exportAccountDTO.setOrgName(organization.getName());
        exportAccountDTO.setAccount(account.getAccount());
        if (account.getPasswordStart() != null) {
            exportAccountDTO.setPasswordStart(dePassWordAES(account.getPasswordStart()));
        }
        ICallStoredObj callStoredObj = new GroupRoleCallStoredDTO(new TextFilter(), acc, null, null, Constants.ACCOUNT_EMP_TYPE.USER, null);
        Object res = callStoredRepository.getList(callStoredObj);
        List<GroupRoleResponse> groupRoleAccountDTOS = (List<GroupRoleResponse>) res;
        List<ExportRoleAccountDTO> exportRole = new ArrayList<>();
        if (groupRoleAccountDTOS.size() != 0) {
            for (GroupRoleResponse groupRoleResponse : groupRoleAccountDTOS) {
                ExportRoleAccountDTO exportRoleAccountDTO = modelMapper.map(groupRoleResponse, ExportRoleAccountDTO.class);
                exportRole.add(exportRoleAccountDTO);

            }
        }
        exportAccountDTO.setExportRoleAccountDTOS(exportRole);


        JRDataSource dataSource = new JREmptyDataSource();

        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
        String fileName = "";
        String fileNameResponse = "";
        if (accountEmployeeDetail.getAccountType() == 1) {
            fileName = "Thong_tin_tai_khoan_admin";
            fileNameResponse = "Thong_tin_tai_khoan_admin";
        } else {
            fileName = "Thong_tin_tai_khoan_nguoi_dung";
            fileNameResponse = "Thong_tin_tai_khoan_nguoi_dung";
        }

        String templatePath = fileName + ".jasper";
        String mimeType = "." + Constants.EXPORT_TYPE.docx;
        Map<String, Object> reportParams = new HashMap<>();

        Date date = new Date();
        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        exportRole.add(0, new ExportRoleAccountDTO());
        dataSource = new JRBeanCollectionDataSource(exportRole);

        //reportParams.put("account", exportAccountDTO.getAccount());
        reportParams.put("passwordStart", exportAccountDTO.getPasswordStart());
        reportParams.put("policeNumber", exportAccountDTO.getPoliceNumber());
        reportParams.put("fullName", exportAccountDTO.getFullName());
        if (accountEmployeeDetail.getAccountType() == 1) {
            reportParams.put("account", exportAccountDTO.getAccount().toUpperCase());
            reportParams.put("dataSource", null);
            Organization orgParent = organizationRepo.findByCodeAndStatus(organizationAcc.getOrganizationParent(), Constants.STATUS_CATEGORY_ACTIVE);
            if (organizationAcc.getCode().length() == 6) {
                reportParams.put("org", organizationAcc.getName());
            } else {
                reportParams.put("org", organizationAcc.getName() + ", " + orgParent.getName());
            }
            reportParams.put("day", localDate.getDayOfMonth());
            reportParams.put("month", localDate.getMonthValue());
        } else {
            reportParams.put("account", exportAccountDTO.getAccount());
            reportParams.put("dataSource", dataSource);
            reportParams.put("org", organization.getName());
        }

        oStream = CommonService.generateReport(dataSource, templatePath, reportParams, Constants.EXPORT_TYPE.docx.toString());

        Path uploadPath = Paths.get(organizationProvince.getSign());
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }


        Files.write(Paths.get(organizationProvince.getSign(), organizationProvince.getSign() + "_" + fileNameResponse + "_" + organizationAcc.getSignNo().replaceAll("\\s", "") + mimeType), oStream.toByteArray());

        Files.write(Paths.get(organizationProvince.getSign(), organizationProvince.getSign() + "_" + fileNameResponse + "_" + acc + mimeType), oStream.toByteArray());

    }

    @Override
    public ResponseBase exportByProvinceCode() throws Exception {
        List<Organization> orgs = organizationRepo.findByOrganizationParentAndStatus("500", Constants.STATUS_CATEGORY_ACTIVE);


        List<String> orgThamGia = new ArrayList<>();
        orgThamGia.add("100018");
        orgThamGia.add("100030");
        orgThamGia.add("100031");
        orgThamGia.add("100032");
        orgThamGia.add("100033");
        orgThamGia.add("100034");
        orgThamGia.add("100035");
        orgThamGia.add("100036");
        orgThamGia.add("100037");
        orgThamGia.add("100039");
        orgThamGia.add("100040");
        orgThamGia.add("100041");
        orgThamGia.add("100046");
        orgThamGia.add("100050");
        orgThamGia.add("100055");


        for (Organization organization : orgs) {
            List<Account> accountInProvince = accountRepository.findAllByOrganizationStartingWithAndAccountStartingWith(organization.getCode(), "g0");
            Organization organization1 = organizationRepo.findByCode(organization.getCode());
            for (Account e : accountInProvince) {

                Organization orgC = organizationRepo.findByCode(e.getOrganization());
                if (orgC.getOrganizationDependent() == null || orgThamGia.contains(orgC.getOrganizationDependent())) {
                    exportAccount(e.getAccount(), organization1);
                    //Thread.sleep(50);
                }


                exportAccount(e.getAccount(), organization1);
                Thread.sleep(50);

            }
        }

        return new ResponseBase(orgs.size());
    }

    @Override
    public ResponseBase cloneGroup(CloneGroupRoleDTO cloneGroupRoleDTO) throws Exception {
        List<AccountGroupRole> accountGroupRoles = accountGroupRoleRepository.findByAccountAndStatus(cloneGroupRoleDTO.getAccount(), Constants.STATUS_CATEGORY_ACTIVE);
        List<Account> listAccSave = new ArrayList<>();

        if (cloneGroupRoleDTO.getType() == 1) {//admin cuc
            List<Account> accounts = accountRepository.findAllByAccountStartingWithAndOrganizationStartingWith("g01", "100");
            for (Account acc : accounts) {
                for (AccountGroupRole accountGroupRole : accountGroupRoles) {
                    AccountGroupRole accountGroupRoleNew = new AccountGroupRole();
                    accountGroupRoleNew.setAccount(acc.getAccount());
                    accountGroupRoleNew.setGroupRole(accountGroupRole.getGroupRole());
                    AccountGroupRole accountGroupRoleCheck = accountGroupRoleRepository.findByGroupRoleAndAccount(accountGroupRoleNew.getGroupRole(), accountGroupRoleNew.getAccount());
                    if (accountGroupRoleCheck == null) {
                        accountGroupRoleRepository.save(accountGroupRoleNew);
                    }
                }
            }
        }
        if (cloneGroupRoleDTO.getType() == 2) {//admin tinh
            List<Account> accounts = accountRepository.findAllByAccountStartingWithAndOrganizationStartingWith("g01", "500");
            for (Account acc : accounts) {
                for (AccountGroupRole accountGroupRole : accountGroupRoles) {
                    AccountGroupRole accountGroupRoleNew = new AccountGroupRole();
                    accountGroupRoleNew.setAccount(acc.getAccount());
                    accountGroupRoleNew.setGroupRole(accountGroupRole.getGroupRole());
                    AccountGroupRole accountGroupRoleCheck = accountGroupRoleRepository.findByGroupRoleAndAccount(accountGroupRoleNew.getGroupRole(), accountGroupRoleNew.getAccount());
                    if (accountGroupRoleCheck == null) {
                        accountGroupRoleRepository.save(accountGroupRoleNew);
                    }
                }
            }
        }

        if (cloneGroupRoleDTO.getType() == 3) {//admin quan/huyen
            if (cloneGroupRoleDTO.getProvice().size() != 0) {
                for (String province : cloneGroupRoleDTO.getProvice()) {
                    List<Account> accounts = accountRepository.findAllByAccountStartingWithAndOrganizationStartingWith("g01", province);
                    for (Account accQh : accounts) {
                        Organization organization = organizationRepo.findByCodeAndStatus(accQh.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                        if (organization != null) {
                            if (organization.getOrganizationDependent() == null) {
                                listAccSave.add(accQh);
                            }
                        }
                    }
                    if (listAccSave.size() != 0) {
                        for (Account acc : listAccSave) {
                            for (AccountGroupRole accountGroupRole : accountGroupRoles) {
                                AccountGroupRole accountGroupRoleNew = new AccountGroupRole();
                                accountGroupRoleNew.setAccount(acc.getAccount());
                                accountGroupRoleNew.setGroupRole(accountGroupRole.getGroupRole());
                                AccountGroupRole accountGroupRoleCheck = accountGroupRoleRepository.findByGroupRoleAndAccount(accountGroupRoleNew.getGroupRole(), accountGroupRoleNew.getAccount());
                                if (accountGroupRoleCheck == null) {
                                    accountGroupRoleRepository.save(accountGroupRoleNew);
                                }
                            }
                        }
                    }

                }

            }

        }

        if (cloneGroupRoleDTO.getType() == 4) {//admin phong nghiep vu
            if (cloneGroupRoleDTO.getProvice().size() != 0) {
                for (String province : cloneGroupRoleDTO.getProvice()) {
                    List<Account> accounts = accountRepository.findAllByAccountStartingWithAndOrganizationStartingWith("g01", province);
                    for (Account accPNV : accounts) {
                        Organization organization = organizationRepo.findByCodeAndStatus(accPNV.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                        if (organization != null) {
                            if (organization.getOrganizationDependent() != null) {
                                listAccSave.add(accPNV);
                            }
                        }
                    }
                    if (listAccSave.size() != 0) {
                        for (Account acc : listAccSave) {
                            for (AccountGroupRole accountGroupRole : accountGroupRoles) {
                                AccountGroupRole accountGroupRoleNew = new AccountGroupRole();
                                accountGroupRoleNew.setAccount(acc.getAccount());
                                accountGroupRoleNew.setGroupRole(accountGroupRole.getGroupRole());
                                AccountGroupRole accountGroupRoleCheck = accountGroupRoleRepository.findByGroupRoleAndAccount(accountGroupRoleNew.getGroupRole(), accountGroupRoleNew.getAccount());
                                if (accountGroupRoleCheck == null) {
                                    accountGroupRoleRepository.save(accountGroupRoleNew);
                                }
                            }
                        }
                    }

                }

            }

        }


        //accountGroupRoleRepository.saveAll(listSave);
        return new ResponseBase();
    }

    @Override
    public ResponseBase confirmInfo(AccConfirmInfoDTO accConfirmInfoDTO) throws ValidationException, NotFoundException {
        Account acc = accountRepository.findByAccountAndStatus(accConfirmInfoDTO.getAccount(), Constants.STATUS_CATEGORY_ACTIVE);
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(acc.getAccount());
        if (acc != null) {
            acc.setConfirmInformation(accConfirmInfoDTO.getAction());
            if (accConfirmInfoDTO.getAction().equals(Constants.CONFIRM_INFO.REFUSE)) {
                AccountReasonUpdate accReasonUpdate = accountReasonUpdateRepository.findByAccountAndStatusAndAction(accConfirmInfoDTO.getAccount(), Constants.STATUS_CATEGORY_ACTIVE, Constants.CONFIRM_INFO.REFUSE);
                if (accReasonUpdate != null) {
                    accReasonUpdate.setReason(accConfirmInfoDTO.getNote());
                    accountReasonUpdateRepository.save(accReasonUpdate);
                } else {
                    AccountReasonUpdate accountReasonUpdate = new AccountReasonUpdate();
                    accountReasonUpdate.setAction(Constants.CONFIRM_INFO.REFUSE);
                    accountReasonUpdate.setReason(accConfirmInfoDTO.getNote());
                    accountReasonUpdate.setAccount(accConfirmInfoDTO.getAccount());
                    accountReasonUpdateRepository.save(accountReasonUpdate);
                }
            } else if (accConfirmInfoDTO.getAction() == Constants.CONFIRM_INFO.ACCEPT) {
                int checkCall = 0; // check có gán nhóm quyền dths ?
                int checkInDignity = 0;
//                if (accountEmployeeDetail.getDignity() != null) {
//                    String currentDignity = generalConfigRepository.getByKey("DTHS_DIGNITY");
//                    String[] dignityCodes = currentDignity.split(",");
//                    for (String dignityCode : dignityCodes) {
//                        if (accountEmployeeDetail.getDignity().equals(dignityCode)) {
//                            checkInDignity++;
//                            break;
//                        }
//                    }
//                }

//                if (checkInDignity == 0) {
//                    List<AccountGroupRole> accountGroupRoleList = accountGroupRoleRepository.findByAccountAndStatus(accConfirmInfoDTO.getAccount(), Constants.STATUS_CATEGORY_ACTIVE);
//                    if (accountGroupRoleList.size() != 0) {
//                        for (AccountGroupRole accGroupRole : accountGroupRoleList) {
//                            List<GroupRoleApplication> groupRoleApplication = groupRoleApplicationRepository.findByGroupRoleAndApplicationAndStatus(accGroupRole.getGroupRole(), "009", Constants.STATUS_CATEGORY_ACTIVE);
//                            if (groupRoleApplication.size() != 0) {
//                                checkCall++;
//                                break;
//                            }
//                        }
//                    }
//                }
            }
        } else {
            throw new ValidationException("ValidationException.error.not.exists.account");
        }
        accountRepository.save(acc);
        List<String> accountHistoryList = List.of(acc.getAccount());
        updateAccountHistory(accountHistoryList);
        return new ResponseBase(acc);
    }

    @Override
    public ResponseBase checkNumberPhoneOrPoliceNumber(AccNumberPhoneOrPoliceNumberDTO accNumberPhoneOrPoliceNumberDTO) throws ValidationException {
        AccountEmployeeDetail accountEmployeeDetail = new AccountEmployeeDetail();
        Account account = new Account();
        AccPhonePoliceResponseDTO accPhonePoliceResponseDTO = new AccPhonePoliceResponseDTO();
        if (accNumberPhoneOrPoliceNumberDTO.getPhoneNumber() == null) {
            return new ResponseBase();
        }
        if (StringUtils.isNotEmpty(accNumberPhoneOrPoliceNumberDTO.getPoliceNumber())) {
            AccountEmployeeDetail accountEmployeeDetailCheck = accountEmployeeDetailRepository.findByPoliceNumber(accNumberPhoneOrPoliceNumberDTO.getPoliceNumber());
            if (accountEmployeeDetailCheck != null) {
                Account accountCheck = accountRepository.findByAccountAndStatus(accountEmployeeDetailCheck.getAccount(), Constants.STATUS_CATEGORY_ACTIVE);
                if (accountCheck != null) {
                    accountEmployeeDetail = accountEmployeeDetailCheck;
                }
            }
        }
        if (StringUtils.isNotEmpty(accNumberPhoneOrPoliceNumberDTO.getPhoneNumber())) {
            accountEmployeeDetail = accountEmployeeDetailRepository.findByPhone(accNumberPhoneOrPoliceNumberDTO.getPhoneNumber());
        }
        if (accountEmployeeDetail != null) {
            account = accountRepository.findByAccountAndStatus(accountEmployeeDetail.getAccount(), Constants.STATUS_CATEGORY_ACTIVE);
            if (account != null) {
                Organization organization = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
                if (organization != null) {
                    accPhonePoliceResponseDTO.setOrg(organization.getFullName());
                }
                accPhonePoliceResponseDTO.setFullName(accountEmployeeDetail.getFullName());
                accPhonePoliceResponseDTO.setPhoneNumber(accountEmployeeDetail.getPhone());
                accPhonePoliceResponseDTO.setPoliceNumber(accountEmployeeDetail.getPoliceNumber());
                return new ResponseBase(accPhonePoliceResponseDTO);
            }
        }

        return new ResponseBase();
    }

    @Transactional
    @Override
    public boolean removeAccount(String account) throws ValidationException {
        AccountEmployeeDetail accountEmployeeDetail = accountEmployeeDetailRepository.findByAccount(account);
//        Account accCheck = accountRepository.findByAccountAndConfirmInformation(account, Constants.CONFIRM_INFO.ACCEPT);
        List<LoginLog> loginLogList = loginLogRepository.findByAccountAndStatus(account, Constants.STATUS_CATEGORY_ACTIVE);// cha dang nhap lan nao
        if (CollectionUtils.isEmpty(loginLogList)) {
            // xoa nhóm quyền
            accountGroupRoleRepository.deleteByAccount(account);

            accountGroupAccountRepository.deleteAllByAccount(account);

            // xóa lĩnh vực phụ trách
            accountForManageFieldRepository.deleteAllByAccount(account);
            // xoa phụ trách đơn vị
            accountForManageOrganizationRepository.deleteAllByAccount(account);

            // xóa tk bao mat
            accountSecurityRepository.deleteByAccount(account);
            // xao nhat ky dang nhap
            loginLogRepository.deleteAllByAccount(account);
            // xao ly do cap nhat
            accountReasonUpdateRepository.deleteAllByAccount(account);
            // xao tk thông bao
            notificationAccountRepository.deleteAllByAccount(account);

            // xóa tk người dùng
            accountEmployeeDetailRepository.deleteAllByAccount(account);
            // xóa tk tai khoan
            accountRepository.deleteAllByAccount(account);


            // Action Log
            String content = String.format("Đã xóa tài khoản %s ,tên cán bộ là %s", account, accountEmployeeDetail.getFullName());
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
            clearCache(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
//            this.clearAllAccountCache();
//            this.clearDetailAccountCache();
//            Cache cacheDetailUser = cacheManager.getCache("detailUser");
//            cacheDetailUser.clear();
//            Cache cacheAllAccount = cacheManager.getCache("userCache");
//            cacheAllAccount.clear();
            loggingService.successLog(new LogActionDTO(QTUD, Constants.MENU_CODE.ACCOUNT.emp, ActionCode.DEL, content, Instant.now()));
            return true;
        }
        throw new ValidationException("ValidationException.error.not.delete.account");
    }

    @Override
    public ResponseBase listLeadOrEmByOrg(AccountLeadOrEmFilter accountLeadOrEmFilter) throws ValidationException, IllegalAccessException {
        trimSpaceUtil.validate(accountLeadOrEmFilter);

        ICallStoredObj callStoredObj = new AccountCallStoredDTO(accountLeadOrEmFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase getAccountInListOrg(List<String> parents) {
        List<AccountView> accountViews = accountViewRepository.findByListOrg(parents);
        return new ResponseBase(new ListResponse(accountViews, (long) accountViews.size()));
    }

    @Override
    public ResponseEntity exportAccountV2(String acc, String passWord) throws NotFoundException, ValidationException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, JRException {
        String fileInput = "Thong_tin_tai_khoan.docx";
        String fileOutPut = "Thong_tin_tai_khoan";
        new HashMap<>();
        try {
            Map<String, Object> dataMap = new HashMap<>(0);
            dataMap.put("account", acc);
            dataMap.put("password", passWord);
            InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/docx/account/" + fileInput);
            Document doc = new Document(is);
//            doc.getMailMerge().setFieldMergingCallback(new CheckBoxMergeField());
            return asposeReportService.generateDataReport(doc, "pdf", dataMap, false, null, fileOutPut, fileInput);
        } catch (Exception e) {
            log.error("Extract dk1 fail : " + e.getCause());
        }
        return null;
    }

    @Override
    public ResponseBase groupTransferList(GroupTransferOrgFilter filter) throws IllegalAccessException {
        trimSpaceUtil.validate(filter);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(filter);
        List<GroupTransferOrgResponse> response = (List<GroupTransferOrgResponse>) callStoredRepository.getList(callStoredObj);
        if (filter.getExcludeAccount() != null)
            response = response.stream().filter(a -> !filter.getExcludeAccount().contains(a.getAccount())).collect(Collectors.toList());

        int page = filter.getPage() == null ? Constants.DEFAULT_PAGE : filter.getPage();
        int size = filter.getSize() == null ? Constants.DEFAULT_SIZE : filter.getSize();
        List<GroupTransferOrgResponse> finalResultRes = new ArrayList<>();
        if (page * size + size <= response.size()) {
            finalResultRes = response.subList(page * size, page * size + size);
        } else {
            finalResultRes = response.subList(page * size, response.size());
        }

        return new ResponseBase(new ListResponse(finalResultRes, (long) response.size()));
    }

    @Override
    public ResponseBase groupTransfer(OrganizationTransferByGroupReq request) throws IllegalAccessException, NotFoundException {
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(AccountLogonContext.currentUser().getAccount(), Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT);
        List<Organization> managedOrganizations = (List<Organization>) callStoredRepository.getList(callStoredObj);
        if (!AccountLogonContext.currentUser().getType().toString().equals(Constants.TYPE_EMPLOYEE.ADMIN))
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.admin.account.required"), null);

        if (request.getAccountTransferList().size() != 0) {
            List<AccountOrganization> accountOrganizationList = new ArrayList<>();
            List<Account> accountList = new ArrayList<>();
            List<String> accountGroupRoleList = new ArrayList<>();
            List<AccountReasonUpdate> accountReasonUpdateList = new ArrayList<>();
            Long measureTransferType = 0L;

            for (AccountTransferReq a : request.getAccountTransferList()) {
                Account account = accountRepository.findByAccountAndStatus(a.getAccount(), Constants.ACCOUNT_STATUS.ACTIVE);
                String errorMessage = checkPrerequisiteForOrgTransfer(a, managedOrganizations, account);
                if (errorMessage != null)
                    return new ResponseBase(Constants.ERROR_CODE.VALIDATION, errorMessage, a.getAccount());

                AccountOrganization accountOrganization = new AccountOrganization(a, request.getTransferType());
                if (request.getTransferType().equals(Constants.TRANSFER_ORG_TYPE.INCORRECT.GENERAL)) {
                    if (StringUtils.isEmpty(request.getDecisionNo()) || Objects.isNull(request.getDecisionDate()) || StringUtils.isEmpty(request.getDecisionSigner()))
                        return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.null.decision.info"), a.getAccount());
                    else {
                        accountOrganization.setDecisionNo(request.getDecisionNo());
                        accountOrganization.setDecisionDate(request.getDecisionDate());
                        accountOrganization.setDecisionSigner(request.getDecisionSigner());
                    }
                } else {
                    request.initDecision();
                    /*Create update reason*/
                    AccountReasonUpdate updateReason = new AccountReasonUpdate();
                    Reason reason = reasonRepo.findByCode("226").orElse(null);
                    updateReason.setReason(reason != null ? reason.getName() : "226");
                    updateReason.setAccount(a.getAccount());
                    updateReason.setAction(3);
                    accountReasonUpdateList.add(updateReason);

                    /*Retype transfer type*/
                    Organization oldOrg = organizationRepo.findByCode(a.getOldOrganization());
                    Organization newOrg = organizationRepo.findByCode(a.getNewOrganization());
                    if (oldOrg != null && StringUtils.isNotEmpty(oldOrg.getOrganizationLevel()) && newOrg != null && StringUtils.isNotEmpty(newOrg.getOrganizationLevel())) {
                        if (oldOrg.getOrganizationLevel().equals(Constants.ORGANIZATION_LEVEL.QH) && newOrg.getOrganizationLevel().equals(Constants.ORGANIZATION_LEVEL.Đ_QH))
                            measureTransferType++;
                        if (oldOrg.getOrganizationLevel().equals(Constants.ORGANIZATION_LEVEL.PNV) && newOrg.getOrganizationLevel().equals(Constants.ORGANIZATION_LEVEL.Đ_PNV))
                            measureTransferType--;
                    }
                }

                accountOrganization.setStatus(Constants.TRANSFER_ORG_STATUS.APPROVE);
                accountOrganizationList.add(accountOrganization);

                account.setOrganization(a.getNewOrganization());
                accountList.add(account);

                accountGroupRoleList.add(a.getAccount());
            }

            /*Retype transfer type part 2*/
            if (measureTransferType == request.getAccountTransferList().size())
                request.setTransferType(Constants.TRANSFER_ORG_TYPE.INCORRECT.DISTRICT_TO_TEAM);
            else if (measureTransferType == -1 * request.getAccountTransferList().size())
                request.setTransferType(Constants.TRANSFER_ORG_TYPE.INCORRECT.ROOM_TO_TEAM);

            accountOrganizationRepository.saveAll(accountOrganizationList);
            accountRepository.saveAll(accountList);
            accountGroupRoleRepository.deleteByAccountList(accountGroupRoleList);
            accountReasonUpdateRepository.saveAll(accountReasonUpdateList);
            List<String> accountHistoryList = accountList.stream().map(a -> a.getAccount()).collect(Collectors.toList());
            updateAccountHistory(accountHistoryList);

            // API LIEN QUAN PHAN MEM KHAC
        }
        return new ResponseBase();
    }

    private String checkPrerequisiteForOrgTransfer(AccountTransferReq req, List<Organization> managedOrganizations, Account account) {
        vn.gtel.common.dto.AccountDTO accountLogin = AccountLogonContext.currentUser();
        Organization newOrganization = organizationRepo.findByCodeAndStatus(req.getNewOrganization(), Constants.STATUS_CATEGORY_ACTIVE);

        if (account == null) return Messages.getString("ValidationException.error.not.exists.account");

        if (managedOrganizations.stream().filter(org -> org.getCode().equals(account.getOrganization())).count() == 0)
            // Exception: Admin V01 manages BCA accounts
            if (!account.getOrganization().equals(Constants.ORGANIZATION_CODE.BCA) || !accountLogin.getOrganization().equals(Constants.ORGANIZATION_CODE.V01))
                return Messages.getString("ValidationException.error.account.org.out.of.range.permission");

        if (newOrganization == null) return Messages.getString("ValidationException.error.not.exist.organization.code");

        if (newOrganization.getCode().equals(account.getOrganization()))
            return Messages.getString("ValidationException.transfer.error.duplicated.new.old.org");

        if (checkPositionEmployee(null, req))
            return Messages.getString("ValidationException.transfer.error.not.position.not.allowed");

        AccountOrganization existTransfer = accountOrganizationRepository.findByAccountAndStatus(req.getAccount(), Constants.TRANSFER_ORG_STATUS.IN_PROGRESS);

        if (existTransfer != null) return Messages.getString("ValidationException.transfer.error.existed.account");

        return null;
    }

    @Override
    public ResponseBase accountWithPositionTypeInOrg(AccountWithPositionTypeInOrgFilter filter) throws IllegalAccessException {
        trimSpaceUtil.validate(filter);
        ICallStoredObj callStoredObj = new AccountCallStoredDTO(filter);
        Object res = callStoredRepository.list(callStoredObj);
        List<AccountResponse> lstResults = (List<AccountResponse>) ((ListResponse) res).getList();
        if (lstResults != null && lstResults.size() > 0) {
            lstResults.stream().map(e -> {
                if (e.getPhone() != null) {
                    e.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPhone()));
                }
                if (e.getPoliceNumber() != null) {
                    e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                }
                return e;
            }).collect(Collectors.toList());
        }
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase accountCheck(String acc, String app) throws IllegalAccessException {
        Account account = accountRepository.findByAccountAndStatus(acc, Constants.ACCOUNT_STATUS.ACTIVE);
        Integer result = 1;
        String message = "Có lỗi xảy ra";
        if (account == null) {
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.exists.account"), null);
        }
        AccountEmployeeDetail accountDetail = accountEmployeeDetailRepository.findByAccount(account.getAccount());
        Position postion = positionCatRepo.findByCode(accountDetail.getPosition());

        return new ResponseBase(new StringAndIntegerResponse(message, result));
    }

    @Override
    public ResponseBase updateDisplayPosition(DisplayPositionDTO request) throws Exception {
        trimSpaceUtil.validate(request);
        if (StringUtils.isNotEmpty(request.getAccount())) {
            AccountEmployeeDetail accountDetail = accountEmployeeDetailRepository.findByAccount(request.getAccount());
            accountDetail.setDisplayPosition(request.getDisplayPosition());
            return new ResponseBase(accountDetail);
        }
        return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.not.exists.account"), null);
    }

    @Override
    public ResponseBase accountHistory(String id, Integer page, Integer size) throws Exception {
        Account account = accountRepository.findById(id).orElse(null);
        if (account == null) throw new ValidationException("ValidationException.error.not.account");

        ICallStoredObj callStoredObj = new AccountCallStoredDTO(page, size, account.getAccount());
        List<AccountHistoryResponse> res = (List<AccountHistoryResponse>) callStoredRepository.getList(callStoredObj);

        for (int i = 0; i < res.size() - 1; i++) {
            List<String> changeField = new ArrayList<>();
            if (StringUtils.compare(res.get(i).getOrganization(), res.get(i + 1).getOrganization()) != 0)
                changeField.add("displayOrganization");
            if (StringUtils.compare(res.get(i).getPosition(), res.get(i + 1).getPosition()) != 0)
                changeField.add("displayPosition");
            if (StringUtils.compare(res.get(i).getMilitary(), res.get(i + 1).getMilitary()) != 0)
                changeField.add("displayMilitary");
            if (StringUtils.compare(res.get(i).getDignity(), res.get(i + 1).getDignity()) != 0)
                changeField.add("displayDignity");

            res.get(i).setChangeField(changeField);
        }
        return new ResponseBase(res);
    }

    private void updateAccountHistory(List<String> accounts) throws NotFoundException {
        List<AccountHistory> accountHistoryList = new ArrayList<>();
        for (String account : accounts) {
            AccountBasicInfoDTO info = accountHistoryRepository.findBasicInfo(account);
            if (info == null) return;
//                throw new NotFoundException("Tai khoan khong ton tai hoac chua duoc xac nhan: " + account);

            Integer count = 0;
            AccountHistory accountHistory = accountHistoryRepository.findCurrentHistory(account).orElse(null);

            if (accountHistory == null) count--;
            else {
                if (StringUtils.compare(info.getOrganization(), accountHistory.getOrganization()) != 0) count++;

                if (StringUtils.compare(info.getPosition(), accountHistory.getPosition()) != 0) count++;

                if (StringUtils.compare(info.getMilitary(), accountHistory.getMilitary()) != 0) count++;

                if (StringUtils.compare(info.getDignity(), accountHistory.getDignity()) != 0) count++;
            }

            if (count != 0) accountHistoryList.add(new AccountHistory(info));

            if (count > 0) {
                accountHistory.setEndDate(Instant.now());
                accountHistoryList.add(accountHistory);
            }
        }
        accountHistoryRepository.saveAll(accountHistoryList);
    }

    private boolean IsQualifiedToDTHS(String account, AccountEmployeeDetail detail) {
        AccountEmployeeDetail accountDetail;
        if (detail != null) accountDetail = detail;
        else accountDetail = accountEmployeeDetailRepository.findByAccount(account);
        if (accountDetail == null) return false;

        /*Kiem tra chuc danh*/
//        if (StringUtils.isNotEmpty(accountDetail.getDignity())) {
//            String currentDignity = generalConfigRepository.getByKey("DTHS_DIGNITY");
//            List<String> dignityCodes = Arrays.asList(currentDignity.split(","));
//            if (dignityCodes.contains(accountDetail.getDignity()))
//                return true;
//        }

        /*Kiem tra nhom quyen*/
        List<AccountGroupRole> accountGroupRoles = accountGroupRoleRepository.findByAccountAndStatus(account, Constants.STATUS_CATEGORY_ACTIVE);
        for (AccountGroupRole accountGroupRole : accountGroupRoles) {
            List<GroupRoleApplication> groupRoleApplication = groupRoleApplicationRepository.findByGroupRoleAndApplicationAndStatus(accountGroupRole.getGroupRole(), "009", Constants.STATUS_CATEGORY_ACTIVE);
            if (groupRoleApplication.size() > 0) return true;
        }

        return false;
    }

    @Override
    public ResponseBase kafkaLog(KafkaLogFilter filter) {
        ICallStoredObj callStoredObj = new KafkaLogCallStoredDTO(filter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase forgetPw(ForgetPWRequestDTO forgetPWRequestDTO) throws IllegalAccessException, NotFoundException, ValidationException {
        trimSpaceUtil.validate(forgetPWRequestDTO);
        AccountEmployeeDetail employeeDetail = accountEmployeeDetailRepository.findByAccount(forgetPWRequestDTO.getAccount());
        if (employeeDetail == null) {
            throw new ValidationException("ValidationException.error.not.exists.account");
        } else {
            if (!forgetPWRequestDTO.getName().equals(employeeDetail.getFullName())) {
                throw new ValidationException("ValidationException.error.not.exists.account.name");
            }
            Account account = accountRepository.findByAccount(forgetPWRequestDTO.getAccount()).orElseThrow(() -> new NotFoundException("Tai khoan khong ton tai!"));
            if (!account.getStatus().equals(Constants.ACCOUNT_STATUS.ACTIVE)) {
                throw new ValidationException("ValidationException.error.not.exists.account.lock");
            }
            if (UrlValidator.getInstance().isValid(CATEGORY_URL)) {
                ResponseEntity<ResponseBase> res = callRestAPIServiceImpl.call(UriComponentsBuilder.fromHttpUrl(CATEGORY_URL.concat(Constants.URL_CONFIG.GET_TEMP_NOTI)).toUriString(), HttpMethod.GET, getTokenService.getBasicHeaderNoBody(), null);
                LinkedHashMap data = (LinkedHashMap) res.getBody().getData();
                Notification notification = new Notification((String) data.get(Notification.Fields.title), CommonUtils.replaceTemp((String) data.get(Notification.Fields.content), Account.Fields.account, forgetPWRequestDTO.getAccount()), forgetPWRequestDTO.getAccount(), Constants.NOTIFICATION_TYPE.NOTICE, QTUD, Constants.MENU_CODE.ACCOUNT.emp, new Gson().toJson(forgetPWRequestDTO));
                notificationRepository.save(notification);
                String accountEmployeeDetailSubAdminName = accountRepository.findByOrgAdmin(account.getOrganization());
                Account accountSub = null;
                List<NotificationAccount> notificationAccounts = new ArrayList<>();
                if (accountEmployeeDetailSubAdminName != null) {
                    accountSub = accountRepository.findByAccount(accountEmployeeDetailSubAdminName).orElse(null);
                }
                if (accountSub != null) {
                    NotificationAccount notificationAccountSubadmin = new NotificationAccount(notification.getId(), accountSub.getAccount());
                    notificationAccounts.add(notificationAccountSubadmin);
                }
                String notifyToAdmin = StringUtils.defaultString(accountRepository.getCreatedAccount(forgetPWRequestDTO.getAccount()), "admin");
                NotificationAccount notificationAccount = new NotificationAccount(notification.getId(), notifyToAdmin);
                notificationAccounts.add(notificationAccount);
                notificationAccountRepository.saveAll(notificationAccounts);
                new Thread(() -> sendEventService.sendEvent(notifyToAdmin, Constants.SSE_TYPE.NOTIFICATION)).start();
                return new ResponseBase(String.format("Da gui yeu cau! Vui long lien he %s de duoc cap lai mat khau!", notifyToAdmin));
            } else throw new NullPointerException(String.format("Not config or wrong url %s!", CATEGORY_URL));
        }
    }

    @Override
    public void revokeToken(String account) {
        jdbcTemplate.update("delete oauth_refresh_token where token_id in (select REFRESH_TOKEN from oauth_access_token where USER_NAME = ?)", account);
        jdbcTemplate.update("delete oauth_access_token where USER_NAME = ?", account);
    }

    public List<AccountResponse> cacheAll() {
        String cacheData = (String) redisTemplate.opsForValue().get(Constants.CACHE.APP.ALL_USER_EMPLOYEE);
        if (StringUtils.isEmpty(cacheData)) {
            AccountFilter textFilter = new AccountFilter(Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT, null, null, Constants.ACCOUNT_TYPE.EMPLOYEE, null, null, null, null, null, null, null, "2", null, null, (String) null);
            ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
            List<AccountResponse> res = (List<AccountResponse>) callStoredRepository.getList(callStoredObj);
            if (res != null && res.size() > 0) {
                res.stream().map(e -> {
                    if (e.getPhone() != null) {
                        e.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPhone()));
                    }
                    if (e.getPoliceNumber() != null) {
                        e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                    }
                    return e;
                }).collect(Collectors.toList());
            }
            redisTemplate.opsForValue().set(Constants.CACHE.APP.ALL_USER_EMPLOYEE, new Gson().toJson(res), cacheTimeoutHours, TimeUnit.HOURS);
            return res;
        } else {
            List<AccountResponse> res = new Gson().fromJson(cacheData, new TypeToken<List<AccountResponse>>() {
            }.getType());
            return res;
        }
    }

    public List<AccountResponse> cacheAllUser() {
        String cacheData = (String) redisTemplate.opsForValue().get(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1);
        if (StringUtils.isEmpty(cacheData)) {
            AccountFilter textFilter = new AccountFilter(Constants.DEFAULT_PAGE, Constants.MAX_ROW_SELECT, null, null, null, null, null, null, null, null, null, null, null, null, null, (String) null);
            ICallStoredObj callStoredObj = new AccountCallStoredDTO(textFilter);
            List<AccountResponse> res = (List<AccountResponse>) callStoredRepository.getList(callStoredObj);
            if (res != null && res.size() > 0) {
                res.stream().map(e -> {
                    if (e.getPhone() != null) {
                        e.setPhone(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPhone()));
                    }
                    if (e.getPoliceNumber() != null) {
                        e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                    }
                    return e;
                }).collect(Collectors.toList());
            }
            redisTemplate.opsForValue().set(Constants.CACHE.APP.ALL_USER_EMPLOYEE_V1, new Gson().toJson(res), cacheTimeoutHours, TimeUnit.HOURS);
            return res;
        } else {
            List<AccountResponse> res = new Gson().fromJson(cacheData, new TypeToken<List<AccountResponse>>() {
            }.getType());
            return res;
        }
    }

    private void clearCache(String cacheName) {
        redisTemplate.opsForValue().set(cacheName, null);
    }
}
