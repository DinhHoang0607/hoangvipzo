package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_TK_ANH_KY")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AccountSignImg extends AuditModelBase {

    @Id
    @GeneratedValue(generator = "UUID")//UUID version 1
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator", parameters = {
            @org.hibernate.annotations.Parameter(
                    name = "uuid_gen_strategy_class",
                    value = "org.hibernate.id.uuid.CustomVersionOneStrategy"
            )
    })
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Lob
    @Column(name = "ANH_CHU_KY")
    private byte[] signImg;

    @Basic
    @Column(name = "TEN_ANH_CHU_KY")
    private String signImgName;

//    @Basic
//    @Column(name = "PHAN_LOAI")
//    private Integer type;

//    @Basic
//    @Column(name = "THUMB_PRINT")
//    private String thumbprint;

}
