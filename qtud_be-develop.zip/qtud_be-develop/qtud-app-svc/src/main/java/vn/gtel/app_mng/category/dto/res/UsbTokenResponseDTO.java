package vn.gtel.app_mng.category.dto.res;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.response.AuditCategoryResponseDTO;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsbTokenResponseDTO {

    @Column(name = "ID")
    private String id;

    @Column(name = "MA")
    private String code;

    @Column(name = "TAI_KHOAN")
    private String accountCode;

    @Column(name = "HO_TEN")
    private String fullName;

    @Column(name = "SO_CMND_CCCD_HO_CHIEU")
    private String cmndCccd;

    @Column(name = "DIEN_THOAI")
    private String phoneNumber;

    @Basic
    @Column(name = "DIA_CHI_THU")
    private String address;

    @Column(name = "DON_VI")
    private String organizationName;

    @Column(name = "MA_DON_VI")
    private String organizationCode;

    @Column(name = "TEN_TINH_TP")
    private String provinceName;
    @Column(name = "MA_TINH_TP")
    private String provinceCode;

    @Column(name = "LOAI_CHUNG_THU_SO")
    private String digitalCertificateType;

    @Column(name = "TEN_LOAI")
    private String digitalCertificateName;

    @Column(name = "CHUC_VU")
    private String position;

    @Column(name = "TEN_CHUC_VU")
    private String positionName;

    @Column(name = "NGAY_SINH")
    private Instant dateOfBirth;


    @Column(name = "NGAY_CAP")
    private Instant dateOfIssue;

    @Column(name = "NOI_CAP")
    private String placeOfIssue;

    @Column(name = "PHUONG_XA")
    private String village;

    @Column(name = "MA_PHUONG_XA")
    private String villageCode;

    @Column(name = "QUAN_HUYEN")
    private String district;

    @Column(name = "MA_QUAN_HUYEN")
    private String districtCode;

    @Column(name = "TINH_TP")
    private String province;

    @Column(name = "MA_TINH_TP")
    private String provinceCodeAgency;

    @Column(name = "NHAP_MA")
    private String codeEnter;

    @Column(name = "CO_QUAN")
    private String agency;

    @Column(name = "MA_CO_QUAN")
    private String agencyCode;

    @Column(name = "DIA_CHI_THU_DIEN_TU")
    private String mailAddress;

    @Column(name = "DIA_CHI_CO_QUAN")
    private String organizationAddress;


}
