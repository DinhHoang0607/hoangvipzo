package vn.gtel.app_mng.maintenance.service.impl;

import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import vn.gtel.common.config.security.GetTokenService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CallRestAPIService;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.maintenance.dto.MaintenanceConfigurationDTO;
import vn.gtel.app_mng.maintenance.dto.ServerStatusDTO;
import vn.gtel.app_mng.maintenance.dto.filter.MaintenanceConfigurationFilterDTO;
import vn.gtel.app_mng.maintenance.dto.stored.MaintenanceConfigurationCallStoredDTO;
import vn.gtel.app_mng.maintenance.model.MaintenanceConfiguration;
import vn.gtel.app_mng.maintenance.repository.MaintenanceConfigurationRepository;
import vn.gtel.app_mng.maintenance.service.MaintenanceConfigurationService;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class MaintenanceConfigurationServiceImpl implements MaintenanceConfigurationService {
    @Autowired
    private MaintenanceConfigurationRepository maintenanceConfigurationRepo;

    @Autowired
    private TrimSpaceUtil trimSpaceUtil;

    @Autowired
    private CallStoredRepository callStoredRepository;

    @Autowired
    private CallRestAPIService callRestAPIService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Value("${gateway-config.notification:http}")
    private String baseUrl;

    @Autowired
    private GetTokenService getTokenService;

    public static final String cacheNextConfigs = "NEXT_CONFIGS";

    @Override
    public ResponseBase serverStatus() {
        List<MaintenanceConfiguration> ls = cacheNextConfigs();
        MaintenanceConfiguration mc = ls.size() > 0 ? ls.get(0) : null;
        if (mc != null) {
            Instant currentDate = Instant.now();
            if (mc.getStatus().equals(Constants.MAINTENANCE_STATUS.IN_PROGRESS)) {
                String message = "response.message.success.maintenance.inProgress";
                Long countDown = ChronoUnit.MILLIS.between(currentDate, mc.getFinishedDate());
                return new ResponseBase(new ServerStatusDTO(Constants.SERVER_STATUS.UNDER_MAINTENANCE_CODE,
                        Constants.SERVER_STATUS.UNDER_MAINTENANCE,
                        message,
                        mc.getStartedDate(),
                        mc.getFinishedDate(),
                        currentDate,
                        countDown));
            } else {
                String message = "response.message.success.maintenance.prepared";
                Long countDown = ChronoUnit.MILLIS.between(currentDate, mc.getStartedDate());
                return new ResponseBase(new ServerStatusDTO(
                        Constants.SERVER_STATUS.NORMAL_CODE,
                        Constants.SERVER_STATUS.NORMAL,
                        message,
                        mc.getStartedDate(),
                        mc.getFinishedDate(),
                        currentDate,
                        countDown));
            }
        }
        return new ResponseBase(new ServerStatusDTO());
    }

    @Override
    public ResponseBase finishMaintenanceSchedule() {
        getTokenService.checkAdmin();
        Optional<MaintenanceConfiguration> mc = maintenanceConfigurationRepo.findCurrentMaintenanceSchedule();
        if (!mc.isPresent())
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, " response.message.error.maintenance.schedule.current");
        stopScheduler();
        clearCache();
        return new ResponseBase(maintenanceConfigurationRepo.save(mc.get().instantFinish()));
    }

    @Override
    public ResponseBase extendMaintenanceSchedule(Instant finishedDate) {
        getTokenService.checkAdmin();
        if (Instant.now().compareTo(finishedDate) >= 0)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.time.invalid");
        Optional<MaintenanceConfiguration> mc = maintenanceConfigurationRepo.findCurrentMaintenanceSchedule();
        if (!mc.isPresent())
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, " response.message.error.maintenance.schedule.current");
        clearCache();
        return new ResponseBase(maintenanceConfigurationRepo.save(mc.get().extendFinished(finishedDate)));
    }

    @Override
    public ResponseBase createMaintenanceSchedule(MaintenanceConfigurationDTO config) throws IllegalAccessException {
        getTokenService.checkAdmin();
        trimSpaceUtil.validate(config);
        Instant currentDate = Instant.now();
        int cdVsSd = currentDate.compareTo(config.getStartedDate()); // Compare currentDate with input startedDate
        int sdVsFd = config.getStartedDate().compareTo(config.getFinishedDate()); // Compare input startedDate with input finishedDate
        if (cdVsSd > 0 || sdVsFd >= 0)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.time.invalid");
        if (CountAvailableMaintenanceSchedule() > 0)
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.schedule.unique");
        if (ConflictConfig(config))
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.time.conflict");
        startScheduler();
        clearCache();
        return new ResponseBase(maintenanceConfigurationRepo.save(new MaintenanceConfiguration(config)));
    }

    @Override
    public void startScheduler() {
//        callRestAPIService.call(baseUrl + "/api/v1/scheduler/maintenance/start", HttpMethod.GET, getTokenService.getBasicHeaderNoBody(redisTemplate), null);
    }

    @Override
    public void stopScheduler() {
//        callRestAPIService.call(baseUrl + "/api/v1/scheduler/maintenance/stop", HttpMethod.GET, getTokenService.getBasicHeaderNoBody(redisTemplate), null);
    }

    @Override
    public ResponseBase updateMaintenanceSchedule(MaintenanceConfigurationDTO config) {
        getTokenService.checkAdmin();
        Instant currentDate = Instant.now();
        Optional<MaintenanceConfiguration> mc = maintenanceConfigurationRepo.findById(config.getId());
        if (!mc.isPresent())
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.not.exist");
        if (mc.get().getStatus().equals(Constants.MAINTENANCE_STATUS.PREPARED)) {
            int cdVsSd = currentDate.compareTo(config.getStartedDate());
            int sdVsFd = config.getStartedDate().compareTo(config.getFinishedDate());
            if (cdVsSd > 0 || sdVsFd >= 0)
                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.time.invalid");
        } else if (mc.get().getStatus().equals(Constants.MAINTENANCE_STATUS.IN_PROGRESS)) {
            int cdVsFd = currentDate.compareTo(config.getFinishedDate());
            if (cdVsFd >= 0)
                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.time.invalid");
            int sdVsSd = mc.get().getStartedDate().compareTo(config.getStartedDate());
            if (sdVsSd != 0)
                return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.schedule.update.start.unavailable");
        } else {
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.schedule.update.unavailable");
        }
        if (ConflictConfig(config))
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.time.conflict");
        clearCache();
        return new ResponseBase(maintenanceConfigurationRepo.save(mc.get().updateConfig(config)));
    }

    private Boolean ConflictConfig(MaintenanceConfigurationDTO config) {
        List<MaintenanceConfiguration> configList = cacheNextConfigs();
        if (configList.size() > 0) {
            if (config.getId() != null)
                configList = configList.stream().filter(c -> !c.getId().equals(config.getId())).collect(Collectors.toList());
            Optional<MaintenanceConfiguration> conflictConfig = configList.stream().parallel().filter(c -> {
                int sdVsSd = 1;
                int sdVsFd = 1;
                int fdVsSd = -1;
                int fdVsFd = -1;
                if (config.getStartedDate() != null) {
                    sdVsSd = c.getStartedDate().compareTo(config.getStartedDate()); // Compare existed startedDate with input startedDate
                    fdVsSd = c.getFinishedDate().compareTo(config.getStartedDate()); // Compare existed finishedDate with input startedDate
                }
                if (config.getFinishedDate() != null) {
                    sdVsFd = c.getStartedDate().compareTo(config.getFinishedDate()); // Compare existed startedDate with input finishedDate
                    fdVsFd = c.getFinishedDate().compareTo(config.getFinishedDate()); // Compare existed finishedDate with input finishedDate
                }
                return !((fdVsSd <= 0 && fdVsFd < 0) || (sdVsSd > 0 && sdVsFd >= 0));
            }).findAny();
            return conflictConfig.isPresent();
        }
        return false;
    }

    private Integer CountAvailableMaintenanceSchedule() {
        clearCache();
        List<MaintenanceConfiguration> configList = cacheNextConfigs();
        return configList.size();
    }

    @Override
    public ResponseBase getMaintenanceScheduleList(MaintenanceConfigurationFilterDTO filter) {
        getTokenService.checkAdmin();
        ICallStoredObj callStoredObj = new MaintenanceConfigurationCallStoredDTO(filter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase getMaintenanceSchedule(String id) {
        getTokenService.checkAdmin();
        Optional<MaintenanceConfiguration> mc = maintenanceConfigurationRepo.findById(id);
        if (!mc.isPresent())
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.not.exist");
        return new ResponseBase(mc);
    }

    @Override
    public ResponseBase cancelMaintenanceSchedule(String id) {
        getTokenService.checkAdmin();
        Optional<MaintenanceConfiguration> mc = maintenanceConfigurationRepo.findById(id);
        if (!mc.isPresent())
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.not.exist");
        if (!mc.get().getStatus().equals(Constants.MAINTENANCE_STATUS.PREPARED))
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, "response.message.error.maintenance.schedule.update.state.unavailable");
        clearCache();
        maintenanceConfigurationRepo.deleteById(id);
        return new ResponseBase();
    }

    public List<MaintenanceConfiguration> cacheNextConfigs() {
        String cacheConfig = (String) redisTemplate.opsForValue().get(cacheNextConfigs);
        if (StringUtils.isEmpty(cacheConfig)) {
            List<MaintenanceConfiguration> res = maintenanceConfigurationRepo.findNextMaintenanceSchedules();
            redisTemplate.opsForValue().set(cacheNextConfigs, new Gson().toJson(res), 1, TimeUnit.HOURS);
            return res;
        } else {
            List<MaintenanceConfiguration> res = new Gson().fromJson(cacheConfig, new TypeToken<List<MaintenanceConfiguration>>() {
            }.getType());
            return res;
        }
    }

    public ResponseBase clearCache() {
        redisTemplate.opsForValue().set(cacheNextConfigs, null);
        return new ResponseBase(null);
    }
}
