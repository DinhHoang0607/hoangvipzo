package vn.gtel.app_mng.category.dto.req;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
public class ChangeSecretReqDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String oldSecret;
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String newSecret;
    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String newSecretAgain;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String id;
}
