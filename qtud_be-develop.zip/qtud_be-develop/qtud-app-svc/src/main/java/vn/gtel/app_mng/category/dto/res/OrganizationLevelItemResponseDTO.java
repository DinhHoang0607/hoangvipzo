package vn.gtel.app_mng.category.dto.res;

import lombok.Data;

import javax.persistence.Column;

@Data
public class OrganizationLevelItemResponseDTO {
    @Column(name = "ID")
    private String organizationLevelId;

    @Column(name = "TEN_DANH_MUC")
    private String organizationLevelName;
}
