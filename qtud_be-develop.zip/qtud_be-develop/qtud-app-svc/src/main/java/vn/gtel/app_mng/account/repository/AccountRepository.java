package vn.gtel.app_mng.account.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;

import javax.transaction.Transactional;

@Repository
public interface AccountRepository extends JpaRepository<Account, String> {
    Account findByAccountAndStatus(String account, Integer status);

    Account findByAccountAndConfirmInformation(String account, Integer status);

    Optional<Account> findByAccount(String account);

    @Query(value = "select * from TBL_TK_TAI_KHOAN tk  join TBL_DM_DON_VI dv \n" +
            "  on UPPER(tk.TAI_KHOAN) = replace(dv.MA_DON_VI_H05,'.','')\n" +
            "  where tk.DON_VI = ?  and tk.TRANG_THAI = 1", nativeQuery = true)
    Account getAdminAccountByOrganization(String organization);

    @Query(value = "SELECT DON_VI FROM TBL_TK_TAI_KHOAN  where TAI_KHOAN = ?", nativeQuery = true)
    String findOrganizationByAccount(String account);

    @Query(value = "select tk.* from TBL_TK_TAI_KHOAN tk  join TBL_DM_DON_VI dv \n" +
            "    on UPPER(tk.TAI_KHOAN) = replace(dv.MA_DON_VI_H05,'.','') where tk.TAI_KHOAN in (\n" +
            "    SELECT tk.TAI_KHOAN from TBL_DM_DON_VI dv join TBL_TK_TAI_KHOAN tk \n" +
            "\ton dv.DON_VI_CHA = tk.DON_VI\n" +
            "\twhere dv.MA = ?  and tk.TRANG_THAI = 1)", nativeQuery = true)
    Account findAdminAccountByOrganization(String organization);

    @Query(value = "SELECT tk.tai_khoan FROM tbl_tk_tai_khoan tk \n" +
            "LEFT JOIN tbl_tk_nguoi_dung nd ON nd.tai_khoan = tk.tai_khoan \n" +
            "LEFT JOIN tbl_dm_don_vi dv ON dv.ma = tk.don_vi \n" +
            "WHERE tk.trang_thai = 1 AND nd.phan_loai = 1 AND dv.trang_thai = 1 \n" +
            "AND dv.ma LIKE :organization || '%'", nativeQuery = true)
    List<String> findAllAdminByOriginOrganization(String organization);

    @Query(value = "select * from TBL_TK_TAI_KHOAN WHERE DON_VI LIKE '100055' and TRANG_THAI =1 and PHAN_LOAI  = 1 and TAI_KHOAN = 'admin'", nativeQuery = true)
    Account findAdminV06();

    List<Account> findAllByAccountStartingWith(String text);

    List<Account> findAllByStatusAndAccountStartingWith(Long status, String text);

    List<Account> findAllByAccountStartingWithAndOrganizationStartingWith(String acc, String org);

    List<Account> findAllByOrganizationStartingWithAndAccountStartingWith(String orgStart, String accStart);

    void deleteAllByAccount(String acc);


    @Query(value = "select a.createdBy from Account a where a.account = :account")
    String getCreatedAccount(String account);

    @Query(value = "select nd.tai_khoan from tbl_tk_nguoi_dung nd " +
            "where nd.phan_loai = 1 " +
            "and nd.tai_khoan in (select tk.tai_khoan from tbl_tk_tai_khoan tk where tk.trang_thai = 1 and tk.tai_khoan like 'admin%' and INSTR(:org,tk.don_vi)>0 and LENGTH(tk.don_vi)=9) " +
            "and nd.tai_khoan <> 'admin'", nativeQuery = true)
    String findByOrgAdmin(String org);

    boolean existsByAccount(String sender);

    List<Account> findByStatusNotAndRqChangePw(Integer deleted, Integer required);

    @Transactional
    @Modifying
    @Query(value = "update tbl_tk_tai_khoan u set u.trang_thai = -1,u.ngay_sua = current_timestamp where u.tai_khoan in :account", nativeQuery = true)
    void updateAccountDelete(List<String> account);

    List<Account> findByStatusNotAndRqChangePwAndPasswordStartIsNotNull(Integer deleted, Integer required);
}
