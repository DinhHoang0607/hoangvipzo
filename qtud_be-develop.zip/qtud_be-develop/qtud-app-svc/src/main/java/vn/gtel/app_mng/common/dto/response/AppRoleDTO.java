package vn.gtel.app_mng.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppRoleDTO {
    @Column(name = "TEN")
    private String name;

    @Column(name = "MA")
    private String code;

    @Column(name = "MA_CHA")
    private String parentCode;

    @Column(name = "DUONG_DAN")
    private String url;

    @Column(name = "ANH")
    private String logo;

//    @Column(name = "MA_BI_MAT")
//    private String clientSecret;
//
//    @Column(name = "LOAI_UY_QUYEN")
//    private String grantType;

//    @Column(name = "THOI_HAN_MA_TRUY_CAP")
//    private Integer accessTokenValidity;
//
//    @Column(name = "THOI_HAN_MA_LAM_MOI")
//    private Integer refreshTokenValidity;

//    private String file;
//    private String fileName;
//
//    @Column(name = "MO_TA")
//    private String description;

    @Column(name = "THU_TU")
    private Integer numberOrder;

//    @Column(name = "ID")
//    private String id;
}
