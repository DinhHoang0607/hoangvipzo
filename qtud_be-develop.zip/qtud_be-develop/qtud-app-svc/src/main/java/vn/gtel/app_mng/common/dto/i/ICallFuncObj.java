/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ICallStoredObj.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/4/21, 11:35 AM
 */

package vn.gtel.app_mng.common.dto.i;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class ICallFuncObj {
    String functionName;
    Class <?> responseType;
    Map<String, Object> params;

    String responseName = "RESPONSE";
}
