/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.category.dto.res;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import vn.gtel.app_mng.category.dto.req.MenuActionDTO;
import vn.gtel.app_mng.category.model.Action;
import vn.gtel.app_mng.category.model.Menu;
import vn.gtel.app_mng.category.model.MenuAction;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

@Data
public class MenuActionRes {

    @Column(name = "TEN")
    private String name;

    @Column(name = "CHUC_NANG_CHA")
    private String parentMenuCode;

    @Column(name = "UNG_DUNG")
    private String applicationCode;

    @Column(name = "MA")
    private String code;

    @Column(name = "URL")
    private String url;

    @Column(name = "END_POINT")
    private String endPoint;

    @Column(name = "THU_TU")
    private Integer order;

    @Column(name = "NOI_DUNG")
    private byte[] file;

    @Column(name = "TEN_TEP_TIN")
    private String fileName;

    private List<ActionNameIdRes> lstAction = new ArrayList<>();

/*	@Column(name = "HANH_DONG")
	private String actionCode;*/

    @Column(name = "MO_TA")
    private String description;


    @Column(name = "ID")
    private String id;

    @Column(name = "NGAY_TAO")
    private Instant createdDate;

    @Column(name = "NGUOI_TAO")
    private String createdBy;

    @Column(name = "NGAY_SUA")
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    private String lastModifiedBy;

    @Column(name = "TRANG_THAI")
    private Integer status;

    @Column(name = "MA_QUYEN_CHUC_NANG")
    private String functionRoleCode;

    @Column(name = "TEN_HANH_DONG")
    private String actionName;

    @Column(name = "HANH_DONG")
    private String action;

    @Column(name = "PHUONG_THUC")
    private String method;

    @Column(name = "DUONG_DAN")
    private String menuActionUrl;

    @Column(name = "BIEU_TUONG")
    private String icon;

    @Column(name = "THANH_PHAN")
    private String component;

    @Column(name = "LOAI_CHUC_NANG")
    private Integer typeMenu;

    @Column(name = "MA_KHAC")
    private String codeOther;

    public MenuActionRes() {
    }
    public MenuActionRes(Menu menu, MenuAction menuAction, Action action) {
        if(menu != null){
            this.id = menu.getId();
            this.createdBy = menu.getCreatedBy();
            this.createdDate = menu.getCreatedDate();
            this.lastModifiedBy = menu.getLastModifiedBy();
            this.lastModifiedDate = menu.getLastModifiedDate();
            this.name = menu.getName();
            this.parentMenuCode = menu.getParentMenuCode();
            this.applicationCode = menu.getAppCode();
            this.code = menu.getCode();
            this.url = menu.getUrl();
            this.endPoint = menu.getEndPoint();
            this.order = menu.getOrder();
            this.description = menu.getDescription();
            this.status = menu.getStatus();
            this.icon = menu.getIcon();
            this.component = menu.getComponent();
            this.typeMenu = menu.getTypeMenu();
            this.codeOther = menu.getCodeOther();
        }
        if(menuAction != null){
            this.functionRoleCode = menuAction.getCode();
            this.action = menuAction.getAction();
            this.method = menuAction.getMethod();
            this.menuActionUrl = menuAction.getEndPoint();
        }
        if(action != null){
            this.actionName = action.getName();

        }
    }
}
