package vn.gtel.app_mng.account.reponse;

import java.util.List;

import javax.persistence.Column;

import lombok.Data;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;
import vn.gtel.app_mng.role.reponse.GroupRoleResponse;

@Data
public class GroupAccountReponse extends AuditItemResponse {
	@Column(name = "MA_NHOM_TAI_KHOAN")
	private String groupCode;

	@Column(name = "TEN")
	private String name;

	@Column(name = "THU_TU")
	private Long oderBy;
	
	@Column(name = "PHAN_LOAI")
	private Integer type;
	
	@Column(name = "ID_UNG_DUNG")
	private String applicationId;
	
	@Column(name = "TEN_UNG_DUNG")
	private String applicationName;
	
	private List<GroupRoleResponse> groupRoleResponse;
}
