package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
public class MenuExcelItemObj extends IExcelItem {
    private String code;
    private String codeOther;
    private String name;
    private String parentMenuCode;
    private String appCode;
    private String url;
    private String endPoint;
    private Integer type;
    private String component;
    private String description;
    private Integer order;

}
