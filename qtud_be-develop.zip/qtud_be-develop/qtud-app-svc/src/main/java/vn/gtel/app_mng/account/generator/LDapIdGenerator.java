///*
// * Copyright (c) 2022.
// * Project  :  app-mng
// * File  :  LDapIdGenerator.java
// * Created By :  tuannp
// * Created at :  $file.created
// * LastModified  :  1/17/22, 4:27 PM
// */
//
//package vn.gtel.app_mng.account.generator;
//
//import org.hibernate.HibernateException;
//import org.hibernate.engine.spi.SharedSessionContractImplementor;
//import org.hibernate.id.IdentifierGenerator;
//import vn.gtel.app_mng.common.config.constant.Constants;
//import vn.gtel.app_mng.common.repository.CallStoredRepository;
//
//import java.io.Serializable;
//
//public class LDapIdGenerator implements IdentifierGenerator {
//
//    private String sequence = "SQ_TBL_LDAP";
//    private String SQL = String.format("%s,%s%s", Constants.COMMON_CALL_PREFIX, sequence, ".nextval) from dual");
//
//    @Override
//    public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
//        return CallStoredRepository.getSequence(session, SQL);
//    }
//}