/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 7, 2021
 */
package vn.gtel.app_mng.category.dto.req;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.RequestParam;
import org.yaml.snakeyaml.scanner.Constant;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditBaseDTO;
import vn.gtel.app_mng.common.dto.AuditCodeDTO;
import vn.gtel.app_mng.common.dto.AuditDTO;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.validation.Valid;
import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuReq extends AuditBaseDTO {


    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @Pattern(regexp = Constants.Regex.CATEGORY_CODE, message = "error.common.validate.only.number")
    @NotEmpty(message = "error.common.validate.not.empty")
    private String appCode;

    @Size(max = 24, message = "error.common.validate.max.size.24")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @Pattern(regexp = Constants.Regex.CODE, message = "error.common.validate.character.number")
    private String parentMenuCode;

    private String url;

    private String file;

    private String fileName;

    private String endPoint;

    @NotNull(message = "error.common.validate.not.null")
    @Max(value = 100000, message = "error.common.validate.max.value.100000")
    private Long order;


    @Size(max = 24, message = "error.common.validate.max.size.24")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
    @Pattern(regexp = Constants.Regex.CODE, message = "error.common.validate.character.number")
    private String code;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String name;

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String description;

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String component;

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String icon;

    private Integer typeMenu;

    private String codeOther;

    private List<MenuActionDTO> listAction = new ArrayList<>();

}


