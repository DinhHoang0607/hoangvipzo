package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccNumberPhoneOrPoliceNumberDTO {

    @Size(max = Constants.VALID.MIN_PHONE_NUMBER, message = "error.common.validate.max.size.10")
    @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
    private String phoneNumber;


    @Size(max = Constants.VALID.MIN_POLICE_NUMBER, message = "error.common.validate.max.size.7")
    @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
    private String policeNumber;





}
