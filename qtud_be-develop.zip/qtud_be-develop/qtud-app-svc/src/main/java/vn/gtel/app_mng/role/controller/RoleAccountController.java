package vn.gtel.app_mng.role.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.role.service.RoleService;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Validated
@Tag(name = "Quyền")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/permission")
public class RoleAccountController {
	private static final Logger LOGGER = LogManager.getLogger(RoleAccountController.class);

	@Autowired
	private RoleService roleService;

	@Operation(summary = "Danh sách mã quyền")
	@GetMapping(value = "")
	public ResponseBase getPermission(){
		return roleService.getPermission();
	}

//	@Operation(summary = "Lấy quyền ứng dụng")
//	@GetMapping("/fe/appCode")
//	public ResponseBase getPermissionByAppCode(
//			@RequestParam(name = "appCode", required = false) String appCode
//	) throws Exception {
//		return roleService.getPermission(appCode, false);
//	}

	@Operation(summary = "Lấy quyền truy cập ứng dụng")
	@GetMapping("/apps")
	public ResponseBase getPermissionByAppCode() {
		return roleService.getAppPermission();
	}

	@GetMapping("/fe")
	public ResponseBase getMenuActionPermissionByAppCode(@RequestParam(name = "appCode") String appCode) throws Exception {
		return roleService.getMenuActionPermission(appCode);
	}

	@Operation(summary = "Lấy ds mã quyền theo ứng dụng")
	@GetMapping("/be")
	public ResponseBase getPermissionBEByAppCode(@RequestParam(name = "appCode") String appCode) throws Exception {
		return roleService.getPermission(appCode, true);
	}

	@Operation(summary = "Lấy danh sách ứng dụng theo tài khoản")
	@GetMapping("/apps-by-acc")
	public ResponseBase getAppsByAcc(
			@Valid
			@Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters")
			@Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.20")
			@RequestParam(name = "account") String account
	) throws Exception {
		return roleService.getAppsByAcc(account);
	}

	@Operation(summary = "Lấy quyền ứng dụng phục vụ log thao tác")
	@GetMapping("/log/appCode")
	public ResponseBase getPermissionByAppCodeForLog(
			@RequestParam(name = "appCode", required = false) String appCode
	) throws Exception {
		return roleService.getPermissionForLog(appCode);
	}


}
