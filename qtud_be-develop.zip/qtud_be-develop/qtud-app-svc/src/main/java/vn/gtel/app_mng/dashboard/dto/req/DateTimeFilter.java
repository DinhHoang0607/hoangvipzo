/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  DateTimeFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/28/22, 5:37 PM
 *
 */

package vn.gtel.app_mng.dashboard.dto.req;

public class DateTimeFilter {
}
