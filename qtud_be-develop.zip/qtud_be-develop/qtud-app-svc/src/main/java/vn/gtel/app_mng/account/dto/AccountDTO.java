package vn.gtel.app_mng.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountDTO {

    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.validate.max.size.36")
    private String id;

    //    @NotEmpty(message = "error.common.validate.not.empty")
//    @Size(min = Constants.VALID.MIN_LENGTH_ACCOUNT_3, message = "error.common.validate.min.size.3")
    @Size(max = Constants.VALID.MAX_LENGTH_ACCOUNT, message = "error.common.validate.max.size.100")
//    @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.character.number")
    private String account;

    //    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    private String password;

    //    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(min = 5, message = "error.common.validate.min.size.5")
    @Size(max = 50, message = "error.common.validate.max.size.50")
    private String reTypePassword;

    private @NotNull(message = "error.common.validate.not.null") Integer type;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    private String organization;

    private Integer status;

    private String pictureDigitalSign;

    private Integer checkAnCs;
}
