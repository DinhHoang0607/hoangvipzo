package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.time.Instant;

@Data
public class AccountTransferOrgResponse {
    @Basic
    @Column(name = "ID_CHUYEN_DV")
    private String idTransferOrg;

    @Basic
    @Column(name = "ngay_tao")
    private Instant changeDate;

    @Basic
    @Column(name = "ngay_sua")
    private Instant acctionDate;

    @Basic
    @Column(name = "SO_QUYET_DINH")
    private String decisionNumber;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "HO_TEN")
    private String fullName;

    @Basic
    @Column(name = "DON_VI")
    private String presentOrgCode;

    @Basic
    @Column(name = "TEN")
    private String presentOrgName;

    @Basic
    @Column(name = "MA_DON_VI_MOI")
    private String newOrgCode;
    @Basic
    @Column(name = "TEN_DON_VI_MOI")
    private String newOrgName;
    @Basic
    @Column(name = "MA_DV_CU")
    private String oldOrgCode;
    @Basic
    @Column(name = "TEN_DV_CU")
    private String oldOrgName;
    @Basic
    @Column(name = "NGAY_QUYET_DINH")
    private Instant decisionDate;
    @Basic
    @Column(name = "NGUOI_KY")
    private String decisionSigner;

    @Basic
    @Column(name = "TEN_DON_VI_CHA")
    private String organizationParentName;

    @Basic
    @Column(name = "SO_HIEU_CAND")
    private String policeNumber;

    @Column(name = "TRANG_THAI")
    private Long status;

    @Column(name = "TRANG_THAI_HIEN_THI")
    private String statusName;
}
