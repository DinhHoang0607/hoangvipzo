/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  Service.java
 * Created By :  tuannp
 * Created at :  12/20/21, 4:12 PM
 * LastModified  :  12/20/21, 4:12 PM
 */

package vn.gtel.app_mng.category.model;

import lombok.Data;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "TBL_DM_DON_VI")
@FieldNameConstants
public class Organization extends AuditModelBase implements Cloneable {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    //    @Basic
//    @Column(name = "MA_CHUAN_QG")
//    private String countryCode;
    @Basic
    @Column(name = "DON_VI_TRUC_THUOC")
    private String organizationDependent;
    @Basic
    @Column(name = "DON_VI_CU")
    private String organizationOld;

    @Basic
    @Column(name = "MA_DON_VI_MOI")
    private String orgCodeNew;

    @Basic
    @Column(name = "DON_VI_CHA")
    private String organizationParent;
    //    @Basic
//    @Column(name = "TEN")
//    private String name;
//    @Basic
//    @Column(name = "CUM")
//    private String cluster;
//    @Basic
//    @Column(name = "NHOM_DON_VI")
//    private String organizationGroup;
    @Basic
    @Column(name = "LOAI_DON_VI")
    private String organizationType;
    @Basic
    @Column(name = "CAP_DON_VI")
    private String organizationLevel;
    //    @Basic
//    @Column(name = "HE_LUC_LUONG")
//    private String cardinality;
    @Basic
    @Column(name = "DIA_CHI")
    private String address;
    @Basic
    @Column(name = "PHUONG_XA")
    private String village;
    @Basic
    @Column(name = "QUAN_HUYEN")
    private String district;
    @Basic
    @Column(name = "TINH_TP")
    private String province;
    @Basic
    @Column(name = "VUNG")
    private String area;
    @Basic
    @Column(name = "MIEN")
    private String region;
//    @Basic
//    @Column(name = "THONG_KE")
//    private Long statistic;

//    @Basic
//    @Column(name = "NGAY_THANH_LAP")
//    private Date establish;

    @Basic
    @Column(name = "KY_HIEU")
    private String sign;
    @Basic
    @Column(name = "KY_HIEU_KHONG_DAU")
    private String signNo;

    @Basic
    @Column(name = "TEN_HIEN_THI")
    private String displayName;

    @Basic
    @Column(name = "TEN_DAY_DU")
    private String fullName;

    @Basic
    @Column(name = "HE_LUC_LUONG")
    private Long subSystem;

    @Basic
    @Column(name = "PHAN_LOAI_NHOM_DON_VI")
    private Integer orgType;


    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
