package vn.gtel.app_mng.common.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.UploadFileService;

import java.io.InputStream;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/upload-file")
public class UploadFileController {
    @Autowired
    private UploadFileService uploadFileService;
    @Value("${minio.bucket}")
    private String minioBucket;
    @PostMapping("/upload")
    public ResponseBase uploadFile(@RequestParam("file") MultipartFile file){
        return uploadFileService.uploadFile(file, minioBucket);
    }

    @GetMapping("/download/{fileName}")
    public ResponseEntity<InputStreamResource> downloadFile(@PathVariable String fileName){
        try {
            InputStream inputStream = uploadFileService.download(fileName, minioBucket);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(inputStream));
        }catch (Exception e){
            e.getStackTrace();
            return ResponseEntity.status(500).build();
        }
    }
}
