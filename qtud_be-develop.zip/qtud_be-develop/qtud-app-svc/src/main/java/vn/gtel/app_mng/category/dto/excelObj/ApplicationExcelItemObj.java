package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

@Data
public class ApplicationExcelItemObj extends IExcelItem {
    //    private String id;
    private String code;
    private String name;
    //    private String website;
    private String url;
    //    private String clientId;
    private String clientSecret;
    //    private Long iconId;
    private String grantType;
    //    private String scope;
    private Integer accessTokenValidity;
    private Integer refreshTokenValidity;
    private String parentCode;
    private String description;
    private String sortName;
    private Integer type;
    private Integer isWebsite;
    private Long order;
}
