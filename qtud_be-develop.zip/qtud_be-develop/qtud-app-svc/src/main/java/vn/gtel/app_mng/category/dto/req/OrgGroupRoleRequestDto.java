package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class OrgGroupRoleRequestDto {
    private String orgCode;
    private List<CodeItemWithActionDTO> groupRoles;
}
