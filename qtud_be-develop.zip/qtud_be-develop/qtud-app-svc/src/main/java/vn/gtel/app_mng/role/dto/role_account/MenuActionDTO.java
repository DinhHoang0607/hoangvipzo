package vn.gtel.app_mng.role.dto.role_account;

import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonTypeName("menuAction")
@AllArgsConstructor
@NoArgsConstructor
public class MenuActionDTO extends RoleDTO {
	private String menu;
	private String action;
	private Long box;
	private Long check;
}
