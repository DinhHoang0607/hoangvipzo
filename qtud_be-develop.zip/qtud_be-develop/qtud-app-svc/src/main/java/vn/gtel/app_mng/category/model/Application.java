package vn.gtel.app_mng.category.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "TBL_DM_UNG_DUNG")
@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class Application extends AuditCategoryModel {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "DUONG_DAN")
    private String url;

    @Basic
    @Column(name = "MA_BI_MAT")
    private String clientSecret;

    @Basic
    @Column(name = "LOAI_UY_QUYEN")
    private String grantType;

    @Basic
    @Column(name = "THOI_HAN_MA_TRUY_CAP")
    private Integer accessTokenValidity;

    @Basic
    @Column(name = "THOI_HAN_MA_LAM_MOI")
    private Integer refreshTokenValidity;

    @Basic
    @Column(name = "MA_CHA")
    private String parentCode;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Integer type;

    @Basic
    @Column(name = "ANH")
    private String logo;

    @Basic
    @Column(name = "TEN_VIET_TAT")
    private String sortName;

    @Basic
    @Column(name = "KHONG_SUA")
    private Integer notEdit;

    @Basic
    @Column(name = "LA_TRANG_WEB")
    private Integer isWebsite;

}
