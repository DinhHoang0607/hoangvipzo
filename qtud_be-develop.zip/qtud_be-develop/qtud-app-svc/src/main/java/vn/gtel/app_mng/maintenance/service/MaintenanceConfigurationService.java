package vn.gtel.app_mng.maintenance.service;

import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.maintenance.dto.MaintenanceConfigurationDTO;
import vn.gtel.app_mng.maintenance.dto.filter.MaintenanceConfigurationFilterDTO;

import java.time.Instant;

public interface MaintenanceConfigurationService {
    ResponseBase serverStatus();
    ResponseBase finishMaintenanceSchedule();
    ResponseBase extendMaintenanceSchedule(Instant finishedDate);
    ResponseBase createMaintenanceSchedule(MaintenanceConfigurationDTO config) throws IllegalAccessException;
    void startScheduler();
    void stopScheduler();
    ResponseBase updateMaintenanceSchedule(MaintenanceConfigurationDTO config);
    ResponseBase getMaintenanceScheduleList(MaintenanceConfigurationFilterDTO filter);
    ResponseBase getMaintenanceSchedule(String id);
    ResponseBase cancelMaintenanceSchedule(String id);
    ResponseBase clearCache();
}
