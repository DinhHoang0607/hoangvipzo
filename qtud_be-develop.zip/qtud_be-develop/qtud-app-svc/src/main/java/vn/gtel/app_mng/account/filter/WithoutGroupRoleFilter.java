/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/23/22, 4:23 PM
 *
 */

package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class WithoutGroupRoleFilter extends AccountGroupRoleFilter {

    private Integer type;

    public WithoutGroupRoleFilter(Integer page, Integer size, String keySearch, String groupRole, Integer type, String position, String org) {
        super(page, size, keySearch, groupRole, position, org);
        this.type = type;
    }
}
