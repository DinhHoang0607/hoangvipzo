package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.Gender;

import java.util.List;

@Repository
public interface GenderRepo extends JpaRepository<Gender, String> {

    List<Gender> findByStatusOrderByCodeAsc(Integer status);
}
