package vn.gtel.app_mng.report.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldNameConstants
public class AccountOrganizationResponseDTO {
    private String organizationCode;
    private String organizationName;
    private Integer quantityShipped;
    private Integer numberOfTransfers;
    private Integer waitingForReception;
    private Integer reject;
}
