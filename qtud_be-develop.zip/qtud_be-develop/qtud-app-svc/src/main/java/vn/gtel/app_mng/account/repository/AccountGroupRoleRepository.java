package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.model.AccountGroupRole;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface AccountGroupRoleRepository extends JpaRepository<AccountGroupRole, String> {

    List<AccountGroupRole> findByGroupRole(String groupRole);

    List<AccountGroupRole> findByGroupRoleAndStatus(String groupRole, Integer status);

    List<AccountGroupRole> findByAccountAndStatus(String account, Integer status);

    // AccountGroupRole findByAccountAndStatus(String account, Long status);

    AccountGroupRole findByGroupRoleAndAccount(String groupRole, String account);

    AccountGroupRole findByAccount(String account);

    @Transactional
    @Modifying
    @Query(value = "update AccountGroupRole set status = :status where account = :account", nativeQuery = false)
    void updateStatusByAccount(Integer status, String account);

    @Transactional
    @Modifying
    @Query(value = "update AccountGroupRole set status = :status where account = :account and groupRole = :groupRole", nativeQuery = false)
    void updateStatusByAccountAndGroupRole(String account, String groupRole, Integer status);

    @Transactional
    @Modifying
    @Query(value = "update AccountGroupRole set status = :status where createdBy = :account and groupRole = :groupRole", nativeQuery = false)
    void updateStatusByCreatedByAndGroupRole(String account, String groupRole, Long status);

    @Query(value = "select * from tbl_tk_nhom_quyen where nhom_quyen = :groupRole", nativeQuery = true)
    List<AccountGroupRole> accByGroupRole(String groupRole);

    @Transactional
    @Modifying
    @Query(value = "update AccountGroupRole set status = 3 where groupRole = :code", nativeQuery = false)
    void updateStatusConverted(String code);

    @Transactional
    void deleteByAccount(String account);

    @Transactional
    @Modifying
    @Query(value = "delete from AccountGroupRole where account in (:account)", nativeQuery = false)
    void deleteByAccountList(List<String> account);

    @Transactional
    @Modifying
    @Query(value = "update TBL_TK_NHOM_QUYEN ag set ag.trang_thai =1 where ag.nhom_quyen = :groupRole", nativeQuery = true)
    void setDeleteByGroupRole(String groupRole);

    @Transactional
    void deleteByCreatedByAndGroupRole(String createdBy, String groupRole);

    List<AccountGroupRole> findByCreatedByAndGroupRoleAndStatus(String createdBy, String groupRole, Integer status);


    boolean existsByGroupRole(String code);

    @Transactional
    void deleteByAccountAndCreatedByNotAndCreatedByNot(String account, String admin, String subAdminPC08);
}
