/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.category.dto.res;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import vn.gtel.app_mng.category.model.Action;
import vn.gtel.app_mng.category.model.MenuAction;

@Data
public class ActionNameIdRes {


    @Column(name = "CHUC_NANG_HANH_DONG_ID")
    private String id;

    @Column(name = "MA")
    private String code;

    @Column(name = "MA_HANH_DONG_KHAC")
    private String codeActionOther;

/*	@Column(name = "CHUC_NANG")
	private String menu;*/

    @Column(name = "HANH_DONG")
    private String action;

    @Column(name = "DUONG_DAN")
    private String endPoint;

    @Column(name = "PHUONG_THUC")
    private String method;

    @Column(name = "TEN_HANH_DONG")
    private String actionName;

    private String status;

    /*	private Boolean isActive;*/

    /**
     * @param actionCode
     */
    public ActionNameIdRes(String actionCode) {
        super();
        this.action = actionCode;
    }

    public ActionNameIdRes() {
        super();
    }

    public ActionNameIdRes(MenuAction menuAction, Action action) {
        if(menuAction != null){
            this.id = menuAction.getId();
            this.code = menuAction.getCode();
            this.codeActionOther = menuAction.getCodeActionOther();
            this.action = menuAction.getAction();
            this.endPoint = menuAction.getEndPoint();
            this.method = menuAction.getMethod();
        }
        if(action != null){
            this.actionName = action.getName();
        }
    }
}
