/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceExcelObj.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 10:52 AM
 *
 */

package vn.gtel.app_mng.account.dto.excelObj;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.util.HashMap;
import java.util.Map;

@Data
@AllArgsConstructor
public class AccountEmployeeExcelObj extends IExcelMapperObj {
    private Integer sheetIndex;
    private Integer firstRow;
    private Map<String, Integer> fieldToIndexMap = new HashMap<>();

    private void setIndex(Integer sheetIndex, Integer firstRow) {
        this.sheetIndex = (sheetIndex != null) ? sheetIndex : 0;
        this.firstRow = (sheetIndex != null) ? firstRow : 0;
    };

    public AccountEmployeeExcelObj(Integer stt, Integer sheetIndex, Integer firstRow) {
        setIndex(sheetIndex, firstRow);
        switch (sheetIndex) {
            // Default account import
            case 0: {
                fieldToIndexMap.put("name", stt + 1);
                fieldToIndexMap.put("organization",stt + 2);
                fieldToIndexMap.put("policeNumber", stt + 3);
                fieldToIndexMap.put("phone", stt + 4);
                fieldToIndexMap.put("positionText",stt + 5);
                fieldToIndexMap.put("militaryText",stt + 6);
                fieldToIndexMap.put("gender",stt + 7);
                fieldToIndexMap.put("citizenID",stt + 8);
                fieldToIndexMap.put("resultColumn",stt + 9);
//                fieldToIndexMap.put("directManager",stt + 11);
//                fieldToIndexMap.put("fieldManage",stt + 14);
//                fieldToIndexMap.put("resultColumn",stt + 15);
//                fieldToIndexMap.put("titleText",stt + 9);
//                fieldToIndexMap.put("directManager",stt + 11);
//                fieldToIndexMap.put("fieldManage",stt + 14);
//                fieldToIndexMap.put("resultColumn",stt + 15);
                break;
            }
            // Group role account import
            case 1: {
                fieldToIndexMap.put("account", stt + 1);
                fieldToIndexMap.put("groupRole", stt + 2);
                fieldToIndexMap.put("resultColumn",stt + 3);
                break;
            }
        }
        setFieldToIndexMap(fieldToIndexMap);
    }
}
