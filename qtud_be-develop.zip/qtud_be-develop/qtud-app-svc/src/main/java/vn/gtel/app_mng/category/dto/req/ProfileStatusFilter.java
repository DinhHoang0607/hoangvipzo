package vn.gtel.app_mng.category.dto.req;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Getter
@Setter
@NoArgsConstructor
public class ProfileStatusFilter extends TextFilter {
    private String typeCode;
    private Integer status;
    private String codeXLVP;
    private String codeTNGT;

    public ProfileStatusFilter(Integer page, Integer size, String keySearch, String typeCode, Integer status, String codeXLVP, String codeTNGT) {
        super(page, size, keySearch);
        this.typeCode = typeCode;
        this.status = status;
        this.codeXLVP = codeXLVP;
        this.codeTNGT = codeTNGT;
    }
}
