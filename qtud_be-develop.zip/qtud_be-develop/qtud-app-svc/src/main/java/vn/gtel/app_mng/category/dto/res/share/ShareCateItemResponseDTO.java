/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  ShareCateItemResponseDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/25/22, 3:27 PM
 *
 */

package vn.gtel.app_mng.category.dto.res.share;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShareCateItemResponseDTO {

//    @Column(name = "ID")
//    private String id;

    @Column(name = "MA")
    private String code;

    @Column(name = "TEN")
    private String name;

    @Column(name = "MA_CHA")
    private String parentCode;

    @Column(name = "TEN_CHA")
    private String parentName;

    @Column(name = "MO_TA")
    private String description;

}
