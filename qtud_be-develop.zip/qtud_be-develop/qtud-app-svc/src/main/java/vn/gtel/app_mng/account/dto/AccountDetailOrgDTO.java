package vn.gtel.app_mng.account.dto;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
public class AccountDetailOrgDTO {
    @Column(name = "ID")
    private String id;

    @Column(name = "TAI_KHOAN")
    private String username;

    @Basic
    @Column(name = "HO_TEN")
    private String accountName;

    @Basic
    @Column(name = "DON_VI")
    private String organizationCode;

    @Basic
    @Column(name = "TEN_DON_VI")
    private String organizationName;

    @Basic
    @Column(name = "PHAN_LOAI")
    private String type;
}
