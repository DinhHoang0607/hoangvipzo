package vn.gtel.app_mng.common.dto.stored;

import vn.gtel.app_mng.category.dto.res.AuditCategoryResponseDTO;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.NewCodeResponseDTO;

import java.util.HashMap;
import java.util.Map;

public class CommonCateCallStoredDTO extends ICallStoredObj {
    private static final String PACKAGE_NAME = "PKG_DANH_MUC_CHIA_SE";
    private static final String PROC_GENERATE_NEW_CODE = "PROC_SINH_MA_MOI";

    private static final String IN_CODE_PARENT = "PI_CODE_PARENT";
    private static final String IN_TABLE_NAME = "PI_TABLE_NAME";

    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(AuditCategoryResponseDTO.class);
    }

    public CommonCateCallStoredDTO(String parentCode, String tableName) {
        setBase();
        setResponseType(NewCodeResponseDTO.class);
        setStoredName(PROC_GENERATE_NEW_CODE);
        params.put(IN_CODE_PARENT, parentCode);
        params.put(IN_TABLE_NAME, tableName);
        setParams(params);
    }
}
