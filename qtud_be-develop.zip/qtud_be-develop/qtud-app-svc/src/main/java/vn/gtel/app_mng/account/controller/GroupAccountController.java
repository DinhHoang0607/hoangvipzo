package vn.gtel.app_mng.account.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.account.dto.AccountGroupDTO;
import vn.gtel.app_mng.account.service.GroupAccountService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.StatusTextFilter;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.validation.Valid;
import java.util.Optional;

import static vn.gtel.app_mng.common.config.constant.Constants.DEFAULT_PAGE;
import static vn.gtel.app_mng.common.config.constant.Constants.DEFAULT_SIZE;

@Tag(name = "Nhóm tài khoản")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
@RequestMapping("/api/v1/account-group")
public class GroupAccountController {

    private final GroupAccountService groupAccountService;

    @Operation(summary = "Tìm kiếm nhóm tài khoản")
    @GetMapping(value = "")
    public ResponseBase search(@RequestParam(name = "keySearch", required = false) String keySearch,
                               @RequestParam(name = "status", required = false) Integer status,
                               @RequestParam(name = "isLogin", required = false) boolean isLogin,
                               @RequestParam(name = "page") Optional<Integer> page, @RequestParam(name = "size") Optional<Integer> size) throws Exception {
        int pageNumber = page.orElse(DEFAULT_PAGE);
        int sizeNumber = size.orElse(DEFAULT_SIZE);
        StatusTextFilter statusTextFilter = new StatusTextFilter(pageNumber, sizeNumber, keySearch, status, isLogin);
        return groupAccountService.list(statusTextFilter);
    }

    @Operation(summary = "Danh sách nhóm tài khoản")
    @GetMapping(value = "/list")
    public ResponseBase list(@RequestParam(name = "keySearch", required = false) String keySearch,
                             @RequestParam(name = "isLogin", required = false) boolean isLogin,
                             @RequestParam(name = "page") Optional<Integer> page, @RequestParam(name = "size") Optional<Integer> size) throws Exception {
        int pageNumber = page.orElse(DEFAULT_PAGE);
        int sizeNumber = size.orElse(DEFAULT_SIZE);
        StatusTextFilter statusTextFilter = new StatusTextFilter(pageNumber, sizeNumber, keySearch, Constants.COMMON_STATUS.ACTIVE, isLogin);
        return groupAccountService.list(statusTextFilter);
    }

    @Operation(summary = "Thêm mới/ cập nhật nhóm tài khoản")
    @PostMapping(value = "")
    public ResponseBase insertOrUpdate(@RequestBody @Valid AccountGroupDTO groupAccountRequestDTO)
            throws Exception {
        return groupAccountService.save(groupAccountRequestDTO);
    }

    @Operation(summary = "Xem chi tiết nhóm tài khoản")
    @GetMapping(value = "/{id}")
    public ResponseBase detail(@PathVariable String id) throws Exception {
        return groupAccountService.detail(id);
    }

    @Operation(summary = "Kích hoạt/ bỏ kích hoạt")
    @PutMapping(value = "/active")
    public ResponseBase active(@RequestParam String id) throws Exception {
        return groupAccountService.active(id);
    }

    @Operation(summary = "Xóa nhóm tài khoản")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@PathVariable String id) throws Exception {
        return groupAccountService.delete(id);
    }

    @Operation(summary = "DS TK, NQ")
    @GetMapping(value = "/{type}/{status}")
    public ResponseBase selectList(@PathVariable String type, @PathVariable String status,
                                   @RequestParam(name = "keySearch", required = false) String keySearch, @RequestParam(name = "id", required = false) String id,
                                   @RequestParam(name = "page") Optional<Integer> page, @RequestParam(name = "size") Optional<Integer> size) {
        int pageNumber = page.orElse(DEFAULT_PAGE);
        int sizeNumber = size.orElse(DEFAULT_SIZE);
        return groupAccountService.selectList(id, type, status, new TextFilter(pageNumber, sizeNumber, keySearch));
    }

    @Operation(summary = "Kết xuất nhóm tài khoản")
    @GetMapping(value = "/export/{type}")
    public ResponseEntity export(@PathVariable String type,
                                 @RequestParam(name = "status", required = false) Integer status,
                                 @RequestParam(name = "keySearch", required = false) String keySearch) throws Exception {
        return groupAccountService.export(status, keySearch, type);
    }

    @Operation(summary = "Mã tiếp theo")
    @GetMapping(value = "/new-code")
    public ResponseBase newCode() {
        return groupAccountService.newCode();
    }
}
