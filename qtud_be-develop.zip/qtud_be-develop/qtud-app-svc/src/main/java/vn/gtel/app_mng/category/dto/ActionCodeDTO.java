/**
 * @author tronglm
 * app-mng
 * Dec 6, 2021
 */
package vn.gtel.app_mng.category.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditBaseDTO;
import vn.gtel.app_mng.common.dto.AuditCodeDTO;
import vn.gtel.app_mng.common.dto.AuditDTO;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ActionCodeDTO extends AuditBaseDTO {

    @NotNull(message = "error.common.validate.not.null")
    @Max(value = 100000, message = "error.common.validate.max.value.100000")
    private Long order;

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String description;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String name;

    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
    @Pattern(regexp = Constants.Regex.CODE, message = "error.common.validate.character.number")
    private String code;
}
