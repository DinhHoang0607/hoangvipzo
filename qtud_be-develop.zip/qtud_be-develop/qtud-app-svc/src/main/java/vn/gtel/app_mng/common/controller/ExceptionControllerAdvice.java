/*
 *  ExceptionControllerAdvice.java
 *  Copyright (c) 2021.
 *  Modification Logs:
 *  DATE                AUTHOR             DESCRIPTION
 *  8/10/21, 8:46 AM    TuanNP             File is created
 *
 */

package vn.gtel.app_mng.common.controller;

import javassist.NotFoundException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.IllegalAddException;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.dto.response.ValidateResponse;
import vn.gtel.common.dto.ErrorLogDTO;
import vn.gtel.common.service.LoggingService;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.common.util.ExceptionUtils;

import javax.crypto.BadPaddingException;
import javax.naming.LimitExceededException;
import javax.naming.SizeLimitExceededException;
import javax.transaction.NotSupportedException;
import javax.xml.bind.ValidationException;
import java.io.FileNotFoundException;
import java.security.InvalidParameterException;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.Instant;
import java.util.MissingResourceException;

import static vn.gtel.app_mng.common.config.constant.Constants.APPLICATION_CODE.QTUD;

@Slf4j
@RestControllerAdvice
@AllArgsConstructor
public class ExceptionControllerAdvice extends ResponseEntityExceptionHandler {

    private static final String PREFIX_ERR_CODE = "100";

    private static final String PREFIX_ERR_CONSTRAINT_MESSAGE = "ConstraintViolationException.";

    private final LoggingService loggingService;

    @ExceptionHandler(NullPointerException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase nullPointerException(NullPointerException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "013", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase runTimeException(RuntimeException ex) {
        saveLogger(ex);
        if (ex.getMessage().contains("Unable to acquire JDBC Connection")) {
            return new ResponseBase(PREFIX_ERR_CODE + "029", "ResponseError.JDBC.Connect.Time.Out");// Messages.getString("ResponseError.JDBC.Connect.Time.Out"));
        }
        if (ex instanceof DataIntegrityViolationException) {
            if (ex.getCause() instanceof ConstraintViolationException) {
                return new ResponseBase(PREFIX_ERR_CODE + "006", Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
            }
        }
        return new ResponseBase(PREFIX_ERR_CODE + "001", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(SecurityException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase securityException(SecurityException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "002", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(NumberFormatException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase numberFormatException(NumberFormatException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "003", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseBase notFoundException(NotFoundException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "004", ex.getMessage());
    }

//  @ExceptionHandler(MethodArgumentNotValidException.class)
//  @ResponseStatus(HttpStatus.BAD_REQUEST)
//  public ResponseBase validationForm(MethodArgumentNotValidException e){
//    return new ValidateResponse(PREFIX_ERR_CODE+"007", e.getBindingResult().getFieldErrors());
//  }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        saveLogger(e);
        return new ResponseEntity<Object>(new ValidateResponse(PREFIX_ERR_CODE + "007", e.getBindingResult().getFieldErrors()), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(javax.validation.ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseBase constraintViolationException(javax.validation.ConstraintViolationException ex) {
        saveLogger(ex);
        String err = "";
        String message = "";
        if (ex.getMessage().indexOf(":") > 0) {
            message = ex.getMessage().substring(ex.getMessage().indexOf(":") + 2);
        }
        if (ex.getMessage().indexOf(":") > 0) {
            err = ex.getMessage().substring(0, ex.getMessage().indexOf(":"));
            err = err.substring(err.lastIndexOf(".") + 1);
        }
        return new ResponseBase(PREFIX_ERR_CODE + "007", String.format("[%s] %s", Messages.getString(err), Messages.getString(message)));
    }

    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseBase validationException(ValidationException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "006", Messages.getString(ex.getMessage()));
    }

    @ExceptionHandler(InvalidParameterException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase invalidParameterException(InvalidParameterException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "007", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(IndexOutOfBoundsException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase indexOutOfBoundsException(IndexOutOfBoundsException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "009", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(FileNotFoundException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase fileNotFoundException(FileNotFoundException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "010", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseBase illegalArgumentException(IllegalArgumentException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "011", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(ParseException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase parseException(ParseException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "012", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(DuplicateKeyException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseBase duplicateExceptionListItem(DuplicateKeyException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "014", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(BadPaddingException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseBase badPaddingException(BadPaddingException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "015", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(NotSupportedException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase notSupportedException(NotSupportedException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "016", ex.getClass().getSimpleName());
    }

//  @ExceptionHandler(NotImplementedException.class)
//  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//  public ResponseBase notImplementedException(NotImplementedException ex) {
//    return new ResponseBase(PREFIX_ERR_CODE+"017", ex.getClass().getSimpleName());
//  }

    @ExceptionHandler(NoSuchFieldException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase noSuchFieldException(NoSuchFieldException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "019", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(LimitExceededException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase limitExceededException(LimitExceededException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "022", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(ResponseStatusException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseBase responseStatusException(ResponseStatusException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "023", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(IllegalAddException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase illegalAddException(IllegalAddException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "024", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(IllegalStateException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase illegalStateException(IllegalStateException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "025", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(IllegalAccessException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase illegalAccessException(IllegalAccessException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "027", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(SizeLimitExceededException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase sizeLimitException(SizeLimitExceededException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "028", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(SQLException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase sqlException(SQLException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "029", ex.getClass().getSimpleName());
    }

    @ExceptionHandler(MissingResourceException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase socketTimeoutException(MissingResourceException ex) {
        saveLogger(ex);
        return new ResponseBase(PREFIX_ERR_CODE + "030", ex.getClass().getSimpleName());
    }

    //bat tat ca cac loi
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseBase handleAllException(Exception ex) {
        saveLogger(ex);
        return new ResponseBase("1000", Messages.getString(ex.getMessage()));
    }

    private void saveLogger(Exception e) {
        log.error(e.getMessage());
        loggingService.errorLog(new ErrorLogDTO(QTUD, AccountLogonContext.getUsernameOrSystem(), ExceptionUtils.getStackTrace(e), Instant.now(), e.getClass().getSimpleName()));
    }

//  @ExceptionHandler(Exception.class)
//  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//  public ResponseBase handleCustomException(CustomException ex, WebRequest request) {
//    log.error(ex.getClass().getSimpleName());
//    if(ex.isFlag()){
//      return new ResponseBase("1000", ex.getClass().getSimpleName());
//    }
//    Luu log API vao db log
//   logImportDatabase.info(ex.getServiceLogDTO());
//    return new ResponseBase("1000", ex.getClass().getSimpleName());
//  }

}
