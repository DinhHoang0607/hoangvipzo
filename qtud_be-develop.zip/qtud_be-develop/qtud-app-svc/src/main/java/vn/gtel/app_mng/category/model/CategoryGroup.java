/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  CategoryGroup.java
 * Created By :  tuannp
 * Created at :  12/20/21, 4:12 PM
 * LastModified  :  12/20/21, 4:12 PM
 */

package vn.gtel.app_mng.category.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;
import java.util.Objects;

@Data
@Entity
@Table(name = "TBL_DM_NHOM_DANH_MUC")
public class CategoryGroup extends AuditModel {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "THU_TU")
    private Long order;

    @Column(name = "MA_DM_LIEN_QUAN")
    private String relatedCode;

    @Column(name = "CO_DA_CAP")
    private Long isMultilevel;

    @Column(name = "CO_DUNG_MA_CU")
    private Long isOldCode;

    @Column(name = "CO_PHAN_HE")
    private Long isSubsystem;

}
