package vn.gtel.app_mng.account.reponse;

import lombok.Data;

import javax.persistence.Column;

@Data
public class AccountServiceResponse {
    @Column(name = "ID")
    private String id;

    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "TEN")
    private String name;

    @Column(name = "TEN_DON_VI")
    private String organizationName;

    @Column(name = "TRANG_THAI")
    private Long status;

    @Column(name = "TRANG_THAI_HIEN_THI")
    private String statusName;

    @Column(name = "TEN_PHAN_LOAI")
    private String typeName;

}
