package vn.gtel.app_mng.account.dto;

import lombok.Data;
import vn.gtel.app_mng.common.dto.AuditCodeDTO;

@Data
public class GroupAccountGroupRoleCodeDTO extends AuditCodeDTO {
	private String groupRoleId;
	private String groupAccountId;
}
