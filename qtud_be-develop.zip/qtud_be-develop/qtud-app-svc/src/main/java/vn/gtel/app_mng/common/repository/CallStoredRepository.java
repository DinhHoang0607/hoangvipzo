/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  CallStoredRepository.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/4/21, 11:21 AM
 */

package vn.gtel.app_mng.common.repository;

import javassist.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallFuncObj;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.util.ColumnRowMapper;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Slf4j
@Repository
public class CallStoredRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private SimpleJdbcCall simpleJdbcCall;

    public Object list(ICallStoredObj iCallStoredObj) {
        Map out = getOut(iCallStoredObj, "list");
        if (out == null || CollectionUtils.isEmpty((List<Object>) out.get(iCallStoredObj.getResponseName()))) {
            return new ListResponse();
        } else {
            ListResponse listResponse = new ListResponse(out.get(iCallStoredObj.getResponseName()), ((BigDecimal) out.get(iCallStoredObj.getResponseTotal())).longValue());
            return listResponse;
        }
    }

    public Object getList(ICallStoredObj iCallStoredObj) {
        Map out = getOut(iCallStoredObj, "getList");
        if (CollectionUtils.isNotEmpty((List<Object>) out.get(iCallStoredObj.getResponseName()))) {
            return (List<Object>) out.get(iCallStoredObj.getResponseName());
        }
        return new ArrayList<>();
    }

    public Object findById(ICallStoredObj iCallStoredObj) throws Exception {
        Map out = getOut(iCallStoredObj, "findById");
        if (CollectionUtils.isNotEmpty((List<Object>) out.get(iCallStoredObj.getResponseName()))) {
            List<Object> responses = (List<Object>) out.get(iCallStoredObj.getResponseName());
            return responses.get(0);
        } else {
            throw new NotFoundException(String.format(" obj : %s", iCallStoredObj.getParams().toString()));
        }
    }

    public Object getNumber(ICallStoredObj iCallStoredObj) {
        Map out = getOut(iCallStoredObj, "getNumber");
        return ((BigDecimal) out.get(iCallStoredObj.getResponseTotal())).longValue();
    }

    public String getStringFromMap(ICallStoredObj iCallStoredObj) {
        Map out = getMapString(iCallStoredObj, "getString");
        return ((List<String>) out.get(iCallStoredObj.getResponseName())).get(0);
    }

    public String getString(ICallStoredObj iCallStoredObj) {
        return getString(iCallStoredObj, "getString");
    }

    public String getString(ICallFuncObj iCallFuncObj) {
        return getString(iCallFuncObj, "getString");
    }

    public Object save(ICallStoredObj iCallStoredObj) throws Exception {
        Map out = getOutSave(iCallStoredObj, "save");
        return ((BigDecimal) out.get(iCallStoredObj.getResponseTotal())).longValue();
    }

    private Map getMapString(ICallStoredObj iCallStoredObj, String functionName) {
        log.info(String.format(" %s %s", functionName, iCallStoredObj.toString()));
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withCatalogName(iCallStoredObj.getPackageName())
                .withProcedureName(iCallStoredObj.getStoredName())
                .returningResultSet(iCallStoredObj.getResponseName(), new SingleColumnRowMapper<>(String.class));
        return simpleJdbcCall.execute();
    }

    private String getString(ICallStoredObj iCallStoredObj, String functionName) {
        log.info(String.format(" %s %s", functionName, iCallStoredObj.toString()));
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withCatalogName(iCallStoredObj.getPackageName())
                .withProcedureName(iCallStoredObj.getStoredName()).withReturnValue();
//                .returningResultSet(iCallStoredObj.getResponseName(), new SingleColumnRowMapper<>(String.class));
        return simpleJdbcCall.executeObject(String.class, iCallStoredObj.getParams());
    }

    private String getString(ICallFuncObj iCallFuncObj, String functionName) {
        log.info(String.format(" %s %s", functionName, iCallFuncObj.toString()));
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withFunctionName(iCallFuncObj.getFunctionName());
        return simpleJdbcCall.executeFunction(String.class, iCallFuncObj.getParams());
    }

    private Map getOut(ICallStoredObj iCallStoredObj, String functionName) {
        log.info(String.format(" %s %s", functionName, iCallStoredObj.toString()));
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withCatalogName(iCallStoredObj.getPackageName())
                .withProcedureName(iCallStoredObj.getStoredName())
                .returningResultSet(iCallStoredObj.getResponseName(), ColumnRowMapper.newInstance(iCallStoredObj.getResponseType()));
        return getMap(iCallStoredObj);
    }

    public Object getObject(ICallStoredObj iCallStoredObj) {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withCatalogName(iCallStoredObj.getPackageName())
                .withProcedureName(iCallStoredObj.getStoredName());
        return simpleJdbcCall.execute(iCallStoredObj.getParams());
    }

    private Map getOutSave(ICallStoredObj iCallStoredObj, String functionName) {
        log.info(String.format(" %s %s", functionName, iCallStoredObj.toString()));
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withCatalogName(iCallStoredObj.getPackageName())
                .withProcedureName(iCallStoredObj.getStoredName());
        return getMap(iCallStoredObj);
    }

    private Map getMap(ICallStoredObj iCallStoredObj) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        if (iCallStoredObj.getParams() != null) {
            for (Map.Entry<String, Object> param : iCallStoredObj.getParams().entrySet()) {
                parameters.addValue(param.getKey(), param.getValue());
            }
        }
        return simpleJdbcCall.execute(parameters);
    }

//    public static Long getSequence(SharedSessionContractImplementor session, String sql) {
//        if(!isValidSql(sql)){
//            throw new IllegalArgumentException("Invalid SQL statement");
//        }
//
//        Connection connection = session.connection();
//        try {
//            PreparedStatement preparedStatement = connection.prepareStatement(sql);
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()) {
//                long id = resultSet.getLong(1);
//                return id;
//            }
//        } catch (SQLException sqlException) {
//            sqlException.printStackTrace();
//        }
//        return null;
//    }

    private static boolean isValidSql(String sql) {
        List<String> allowedStatement = Arrays.asList(
                String.format("%s,%s%s", Constants.COMMON_CALL_PREFIX, "SQ_TBL_CHI_TIET_TAI_KHOAN", ".nextval) from dual"),
                String.format("%s,%s%s", Constants.COMMON_CALL_PREFIX, "SQ_TBL_TK_NTK", ".nextval) from dual")
        );
        return allowedStatement.contains(sql);
    }
}
