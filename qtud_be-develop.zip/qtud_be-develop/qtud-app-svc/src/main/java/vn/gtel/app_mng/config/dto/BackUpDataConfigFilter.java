/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  BackUpDataConfigFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/7/22, 4:06 PM
 *
 */

package vn.gtel.app_mng.config.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@AllArgsConstructor
public class BackUpDataConfigFilter extends TextFilter {

    private String type;

    public BackUpDataConfigFilter(Integer page, Integer size, String keySearch, String type) {
        super(page, size, keySearch);
        this.type = type;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
