package vn.gtel.app_mng.account.dto.storeObj;

import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.app_mng.account.filter.GeneralConfigFilterDTO;
import vn.gtel.app_mng.account.model.GeneralConfig;
import vn.gtel.app_mng.account.reponse.GeneralConfigResponse;
import vn.gtel.app_mng.account.reponse.GeneralConfigResponseDTO;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GeneralConfigCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_CAU_HINH_CHUNG";
    private static final String PROC_SEARCH_NAME = "TIM_KIEM_CAU_HINH_CHUNG";
    private static final String PROC_SEARCH_NAME_BY_LEVEL = "TIM_KIEM_CAU_HINH_THEO_CAP_TEN";

    private static final String IN_PRIMARY_KEY = "pi_primary_key";
    private static final String IN_ACCOUNT = "pi_tai_khoan";
    private static final String IN_KEY_SEARCH = "pi_keysearch";
    private static final String IN_PI_PAGE = "pi_page";
    private static final String IN_PI_SIZE = "pi_size";

    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(GeneralConfigResponse.class);
    }

    public GeneralConfigCallStoredDTO(TextFilter textFilter){
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
        params.put(IN_PI_PAGE,textFilter.getPage());
        params.put(IN_PI_SIZE,textFilter.getSize());
        setParams(params);
    }

    public GeneralConfigCallStoredDTO(String cacheName) {
        setBase();
        setStoredName(PROC_SEARCH_NAME_BY_LEVEL);
        setResponseType(GeneralConfigResponseDTO.class);
        switch (cacheName) {
            case Constants.CACHE.APP.PASSWORD_CONFIG:
                params.put(IN_PRIMARY_KEY, String.join(".", Constants.GENERAL_CONFIG.PASSWORD));
                break;
            case Constants.CACHE.APP.LOGIN_CONFIG:
                params.put(IN_PRIMARY_KEY, String.join(".", Constants.GENERAL_CONFIG.LOGIN));
                break;
        }
        params.put(IN_ACCOUNT, Constants.USERNAME.ADMIN);
        params.put(IN_PI_PAGE, Constants.DEFAULT_PAGE);
        params.put(IN_PI_SIZE, Constants.MAX_ROW_SELECT);
        setParams(params);
    }

    public GeneralConfigCallStoredDTO(GeneralConfigFilterDTO request) {
        setBase();
        setStoredName(PROC_SEARCH_NAME_BY_LEVEL);
        setResponseType(GeneralConfigResponseDTO.class);
        params.put(IN_PRIMARY_KEY, String.join(".", request.getKeys()));
        params.put(IN_ACCOUNT, AccountLogonContext.getUsername());
        params.put(IN_PI_PAGE, request.getPage());
        params.put(IN_PI_SIZE, request.getSize());
        setParams(params);
    }
}
