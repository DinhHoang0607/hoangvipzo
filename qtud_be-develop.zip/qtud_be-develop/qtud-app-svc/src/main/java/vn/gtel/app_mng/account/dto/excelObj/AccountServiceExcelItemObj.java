/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountServiceExcelItemObj.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 11:29 AM
 *
 */

package vn.gtel.app_mng.account.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

@Data
public class AccountServiceExcelItemObj  extends IExcelItem {
    private String account;
    private String name;
    private String password;
    private String confirmPassword;
    private String description;
    private String organization;
    private String organizationName;

    private String representativeName;
    private String representativePhone;
    //	@Column(name = "CAP_BAC")
    private String representativeMilitary;
    //	@Column(name = "CHUC_VU")
    private String representativePosition;

    //	@Column(name = "CAP_BAC")
    private String representativeMilitaryText;
    //	@Column(name = "CHUC_VU")
    private String representativePositionText;
//    private String representativeDescription;
    //	@Column(name = "SO_HIEU_CAND")
    private String representativePoliceNumber;

    private String relationName;
    private String relationPhone;
    //	@Column(name = "CAP_BAC")
    private String relationMilitary;
    //	@Column(name = "CHUC_VU")
    private String relationPosition;

    //	@Column(name = "CAP_BAC")
    private String relationMilitaryText;
    //	@Column(name = "CHUC_VU")
    private String relationPositionText;
//    private String relationDescription;
    //	@Column(name = "SO_HIEU_CAND")
    private String relationPoliceNumber;

    private String accountTypeService;
    private Long type;
}
