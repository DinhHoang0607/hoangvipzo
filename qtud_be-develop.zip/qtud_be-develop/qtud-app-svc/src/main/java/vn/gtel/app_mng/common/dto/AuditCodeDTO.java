package vn.gtel.app_mng.common.dto;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Data
public class AuditCodeDTO extends AuditDTO implements Serializable {

    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
    @Pattern(regexp = Constants.Regex.CODE,message = "error.common.validate.character.number")
    private String code;


}
