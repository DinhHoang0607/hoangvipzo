package vn.gtel.app_mng.category.service;

import vn.gtel.app_mng.category.dto.req.DashboardPermissionsReqDTO;
import vn.gtel.app_mng.common.dto.response.ResponseBase;


public interface DashboardPermissionsService {
    ResponseBase getListByUserName(String userName);

    ResponseBase save(DashboardPermissionsReqDTO request);
}
