package vn.gtel.app_mng.account.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationTransferByGroupReq {
    private String decisionNo;

    private Instant decisionDate;

    private String decisionSigner;

    @NotNull(message = "error.common.validate.not.null")
    private Integer transferType;

    private List<AccountTransferReq> accountTransferList;

    public void initDecision() {
        this.decisionNo = new String();
        this.decisionDate = Instant.now();
        this.decisionSigner = new String();
    }
}
