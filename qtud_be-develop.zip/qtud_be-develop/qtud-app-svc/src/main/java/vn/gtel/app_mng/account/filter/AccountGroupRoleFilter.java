/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  AccountGroupRoleFilter.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/23/22, 4:23 PM
 *
 */

package vn.gtel.app_mng.account.filter;

import lombok.Data;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
public class AccountGroupRoleFilter extends TextFilter {

    private String groupRole;
    private String position;
    private String org;


    public AccountGroupRoleFilter(Integer page, Integer size, String keySearch, String groupRole,String position, String org ) {
        super(page, size, keySearch);
        this.groupRole = groupRole;
        this.position = position;
        this.org = org;
    }
}
