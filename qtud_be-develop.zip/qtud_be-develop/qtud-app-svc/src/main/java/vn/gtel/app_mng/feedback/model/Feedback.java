package vn.gtel.app_mng.feedback.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.Instant;
import java.util.Objects;

@Data
@Entity
@Table(name = "TBL_PHAN_ANH", catalog = "")
@EntityListeners(AuditingEntityListener.class)
@NoArgsConstructor
@AllArgsConstructor
public class Feedback {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Long classify;

    @Basic
    @Column(name = "NOI_DUNG")
    private String content;

    @Basic
    @Column(name = "PHAN_MEM")
    private String applicationCode;

    @Basic
    @Column(name = "NGUOI_GUI")
    private String sender;

    @Basic
    @Column(name = "DON_VI_XU_LY")
    private String organization;

    @Basic
    @Column(name = "DON_VI_PHAN_ANH")
    private String orgFeedbackCode;

    @Basic
    @Column(name = "NGUOI_XY_LY")
    private String processor;

    @Basic
    @Column(name = "TRANG_THAI")
    private Integer status;

    @Column(name = "NGAY_TAO")
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

    @Basic
    @Column(name = "SO_DIEN_THOAI")
    private String phoneNumber;

    @Basic
    @Column(name = "TIEU_DE")
    private String title;

    @Basic
    @Column(name = "MUC_DO")
    private Integer level;

    @Basic
    @Column(name = "MA")
    private String code;

}
