/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationRequestDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 11:28 AM
 */

package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.AuditDTO;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
public class ApplicationRequestCodeDTO extends AuditDTO {

    @Size(max = 250, message = "error.common.validate.max.size.250")
    private String url;
    private String file;
    private String fileName;
    @Size(max = 250, message = "error.common.validate.max.size.250")
//    @NotEmpty(message = "error.common.validate.not.empty")
    private String clientSecret;
    @Size(max = 250, message = "error.common.validate.max.size.250")
    private String grantType;
    @NotNull(message = "error.common.validate.not.null")
    private Integer accessTokenValidity;
    @NotNull(message = "error.common.validate.not.null")
    private Integer refreshTokenValidity;
    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @Pattern(regexp = Constants.Regex.CATEGORY_CODE, message = "error.common.validate.only.number")
    private String parentCode;
    @Size(max = 50, message = "error.common.validate.max.size.50")
    @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.character.number= Chỉ nhập chữ và số")
    private String logo;
    @Size(max = 50, message = "error.common.validate.max.size.50")
    private String sortName;
    @NotNull(message = "error.common.validate.not.null")
    private Integer type;
    private Integer notEdit;
    private Integer isWebsite=1;
    private String statusName;
}
