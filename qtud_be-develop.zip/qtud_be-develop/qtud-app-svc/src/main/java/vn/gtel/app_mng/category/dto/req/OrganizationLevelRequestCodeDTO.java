package vn.gtel.app_mng.category.dto.req;

import lombok.Data;

@Data
public class OrganizationLevelRequestCodeDTO extends AuditCategoryCodeDTO {

}
