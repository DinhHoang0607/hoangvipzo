package vn.gtel.app_mng.role.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_Q_NHOM_QUYEN_CHUC_NANG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleMenu extends AuditModelBase {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "NHOM_QUYEN")
    private String groupRole;

    @Basic
    @Column(name = "CHUC_NANG")
    private String menu;

    @Basic
    @Column(name = "HANH_DONG")
    private String action;

}
