package vn.gtel.app_mng.role.reponse;

import lombok.Data;

import javax.persistence.Column;

@Data
public class GroupRoleMenuNotAccountItemResponseDTO {

    @Column(name = "ID")
    private String accountID;

    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "TEN")
    private String name;


}
