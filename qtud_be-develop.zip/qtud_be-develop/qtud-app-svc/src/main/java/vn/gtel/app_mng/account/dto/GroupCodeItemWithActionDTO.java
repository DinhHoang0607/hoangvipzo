package vn.gtel.app_mng.account.dto;

import lombok.Data;
import vn.gtel.app_mng.account.model.AccountGroupAccount;
import vn.gtel.app_mng.role.model.GroupRoleAccountGroup;

@Data
public class GroupCodeItemWithActionDTO extends CodeItemWithActionDTO {
    private String groupCode;

    public GroupCodeItemWithActionDTO() {
        super(null, null, null, 0);
    }

    public GroupCodeItemWithActionDTO(CodeItemWithActionDTO e, String groupCode) {
        super(e.getId(), e.getCode(), e.getName(), e.getAction());
        this.groupCode = groupCode;
    }

    public AccountGroupAccount toDelAccountGroupAccount(CodeItemWithActionDTO e, String groupCode) {
        return new AccountGroupAccount(new GroupCodeItemWithActionDTO(e, groupCode));
    }

    public GroupRoleAccountGroup toDelGroupRoleAccountGroup(CodeItemWithActionDTO e, String groupCode) {
        return new GroupRoleAccountGroup(new GroupCodeItemWithActionDTO(e, groupCode));
    }
}
