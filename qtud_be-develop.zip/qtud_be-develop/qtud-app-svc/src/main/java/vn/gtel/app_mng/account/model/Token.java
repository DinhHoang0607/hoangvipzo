//package vn.gtel.app_mng.account.model;
//
//import javax.persistence.*;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.hibernate.annotations.GenericGenerator;
//import vn.gtel.app_mng.common.model.AuditModel;
//
//import java.sql.Timestamp;
//
//@Entity
//@Table(name = "TBL_TOKEN")
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class Token extends AuditModel {
//	/**
//	 *
//	 */
//	private static final long serialVersionUID = 1L;
//
//	@Id
//	@GeneratedValue(generator = "uuid2")
//	@GenericGenerator(name = "uuid2", strategy = "uuid2")
//	@Column(name = "ID")
//	private String id;
//
//	@Basic
//	@Column(name = "MA")
//	private String code;
//
//	@Basic
//	@Column(name = "ID_TAI_KHOAN")
//	private String accountId;
//
//	@Basic
//	@Column(name = "TOKEN")
//	private String token;
//
//	@Basic
//	@Column(name = "PHAN_LOAI")
//	private Long type;
//
//	@Basic
//	@Column(name = "HET_HAN")
//	private Timestamp expiredDate;
//
//}
