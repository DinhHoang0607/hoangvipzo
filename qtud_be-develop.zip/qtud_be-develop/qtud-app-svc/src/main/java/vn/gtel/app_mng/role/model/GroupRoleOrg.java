package vn.gtel.app_mng.role.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;
import vn.gtel.app_mng.account.dto.GroupCodeItemWithActionDTO;
import vn.gtel.app_mng.account.model.AccountGroupAccount;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "TBL_DV_NHOM_QUYEN")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleOrg extends AuditModelBase {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

	@Basic
	@Column(name = "NHOM_QUYEN")
	private String groupRole;

	@Basic
	@Column(name = "DON_VI")
	private String org;

	public GroupRoleOrg(List<GroupRoleOrg> groupRoleOrgs, CodeItemWithActionDTO item, String orgCode) {
		GroupRoleOrg groupRoleOrg = groupRoleOrgs.stream().filter(e -> e.getGroupRole().equals(item.getCode())).findFirst().orElse(null);
		if (groupRoleOrg == null) {
			groupRoleOrg = new GroupRoleOrg(item.getCode(), orgCode, Constants.COMMON_STATUS.ACTIVE);
		}
		this.id = groupRoleOrg.getId();
		this.groupRole = groupRoleOrg.getGroupRole();
		this.org = groupRoleOrg.getOrg();
		this.setStatus(item.getAction());
	}

	public GroupRoleOrg(String groupRole, String orgCode, Integer status) {
		this.groupRole = groupRole;
		this.org = orgCode;
		setStatus(status);
	}
}
