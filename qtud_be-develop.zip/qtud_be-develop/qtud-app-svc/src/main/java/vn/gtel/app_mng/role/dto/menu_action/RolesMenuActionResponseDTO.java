/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  MenuActionResponseDTO.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 2:39 PM
 *  * LastModified  :  12/15/21, 2:25 PM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import vn.gtel.app_mng.category.dto.res.MenuActionRes;

import java.util.List;

@Data
public class RolesMenuActionResponseDTO {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<MenuByAccount> menuByRole;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<MenuByAccount> menuRoles;

    private List<RoleActionDTO> actions;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<RoleMenuDTO> menus;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<RoleMenuItemDTO> roles;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<String> permissions;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long total;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<String> listMenuUrl;

}
