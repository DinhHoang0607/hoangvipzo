package vn.gtel.app_mng.common.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Data
@FieldNameConstants
@NoArgsConstructor
public class AuditDTO extends AuditBaseDTO implements Serializable {

    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    private String description;

    @NotEmpty(message = "error.common.validate.not.empty")
    @Size(max = Constants.VALID.MAX_LENGTH_NAME_250, message = "error.common.validate.max.size.250")
    @Pattern(regexp = Constants.Regex.NAME, message = "error.common.validate.not.special-characters")
    private String name;
    private String code;

    private Integer order;

    public AuditDTO(String id, String code, String name) {
        this.setId(id);
        this.setCode(code);
        this.setName(name);
    }
}
