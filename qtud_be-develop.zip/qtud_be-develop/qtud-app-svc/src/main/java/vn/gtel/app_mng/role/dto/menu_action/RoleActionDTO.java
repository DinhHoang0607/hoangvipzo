/*
 *
 *  * Copyright (c) 2021.
 *  * Project  :  app-mng
 *  * File  :  RoleActionDTO.java
 *  * Created By :  tuannp
 *  * Created at :  12/15/21, 2:39 PM
 *  * LastModified  :  12/15/21, 2:39 PM
 *
 */

package vn.gtel.app_mng.role.dto.menu_action;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;

import javax.persistence.Column;

@Data
public class RoleActionDTO {

    @Column(name = "MA")
    private String action;
    @Column(name = "TEN")
    private String name;

}
