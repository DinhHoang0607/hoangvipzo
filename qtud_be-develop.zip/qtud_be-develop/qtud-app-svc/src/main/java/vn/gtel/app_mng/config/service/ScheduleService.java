package vn.gtel.app_mng.config.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ScheduleService {

    @Scheduled(fixedDelayString = "300000") // 5m = 300000 ms
    @CacheEvict(value = "config", allEntries = true)
    public void emptyGeneralConfigCache() {
        log.info("---- Empty allEntries cache value = 'config' ---- ");
    }

//    @Scheduled(fixedDelayString = "300000") // 5m = 300000 ms
//    @CacheEvict(value = "detailAccount", allEntries = true)
//    public void emptyDetailAccount() {
//        log.info("---- Empty allEntries cache value = 'detailAccount' ---- ");
//    }

}
