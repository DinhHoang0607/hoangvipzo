 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 6, 2021
 */
package vn.gtel.app_mng.category.dto.res;

import javax.persistence.Column;

import lombok.Data;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

@Data
public class ActionResponse {
	@Column(name = "ID")
    private String id;

	@Column(name = "TEN")
    private String name;
	
    @Column(name = "THU_TU")
    private Long order;

    @Column(name = "MO_TA")
    private String description;

    @Column(name = "MA")
    private String code;

    @Column(name = "TRANG_THAI")
    private Long status;

    @Column(name = "TRANG_THAI_HIEN_THI")
    private String statusName;
}
