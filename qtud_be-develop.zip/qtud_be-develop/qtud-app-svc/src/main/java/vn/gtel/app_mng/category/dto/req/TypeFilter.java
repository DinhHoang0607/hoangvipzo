package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

@Data
@NoArgsConstructor
public class TypeFilter extends TextFilter {

    private Integer type;

    public TypeFilter(Integer page, Integer size, String keySearch, Integer type) {
        super(page, size, keySearch);
        this.type = type;
    }
}
