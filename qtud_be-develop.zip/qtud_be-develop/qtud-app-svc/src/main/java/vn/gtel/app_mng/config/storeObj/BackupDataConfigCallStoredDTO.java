/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  BackupDataConfigCallStoredDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/7/22, 3:13 PM
 *
 */

package vn.gtel.app_mng.config.storeObj;

import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.config.dto.BackUpDataConfigFilter;
import vn.gtel.app_mng.config.dto.BackUpDataConfigItemRqDTO;

import java.util.HashMap;
import java.util.Map;

public class BackupDataConfigCallStoredDTO extends ICallStoredObj {

    private static final String PACKAGE_NAME = "PKG_CH_SAO_LUU_DL";
    public static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_CH_SAO_LUU";

    private static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    private static final String IN_TYPE = "PI_PHAN_LOAI";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_SIZE = "PI_SIZE";
    Map<String, Object> params = new HashMap<>();

    private void setBase() {
        setPackageName(PACKAGE_NAME);
        setResponseType(BackUpDataConfigItemRqDTO.class);
    }

    public BackupDataConfigCallStoredDTO(BackUpDataConfigFilter backUpDataConfigFilter) {
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, backUpDataConfigFilter.getKeySearch());
        params.put(IN_TYPE, backUpDataConfigFilter.getType());
        params.put(IN_PAGE, backUpDataConfigFilter.getPage());
        params.put(IN_SIZE, backUpDataConfigFilter.getSize());
        setParams(params);
    }
}
