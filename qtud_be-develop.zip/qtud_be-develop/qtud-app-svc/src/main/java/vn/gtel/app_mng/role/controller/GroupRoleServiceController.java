package vn.gtel.app_mng.role.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.role.dto.GroupRoleDTO;
import vn.gtel.app_mng.role.dto.menu_action.GroupRoleAccountDTO;
import vn.gtel.app_mng.role.filter.GroupRoleFilter;
import vn.gtel.app_mng.role.service.GroupRoleService;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.sql.SQLException;
import java.util.Optional;

import static vn.gtel.app_mng.common.config.constant.Constants.DEFAULT_PAGE;
import static vn.gtel.app_mng.common.config.constant.Constants.DEFAULT_SIZE;

@Validated
@Tag(name = "Nhóm quyền dịch vụ")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/role-group/service")
public class GroupRoleServiceController {

//    private static final Logger LOGGER = LogManager.getLogger(GroupRoleMenuController.class);
    @Autowired
    private GroupRoleService groupRoleService;

    @Operation(summary = "Thêm mới nhóm quyền")
    @PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseBase submitGroupRole(
            @RequestBody
            @Valid GroupRoleDTO groupRoleDTO
    ) throws Exception, SQLException {
        return groupRoleService.save(groupRoleDTO,2);
    }

    @Operation(summary = "Sửa nhóm quyền")
    @PutMapping(value = "")
    public ResponseBase updateGroupRole(
            @RequestBody
            @Valid GroupRoleDTO groupRoleDTO
    ) throws Exception, SQLException {
        return groupRoleService.save(groupRoleDTO,2);
    }

    @Operation(summary = "Tìm kiếm danh sách nhóm quyền")
    @GetMapping(value = "")
    public ResponseBase search(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page") Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size") Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.DEFAULT_SIZE : size;
        GroupRoleFilter textFilter = new GroupRoleFilter(pageNumber, sizeNumber, keySearch, Constants.GROUP_ROLE_TYPE.SERVICE, null, null);
        return groupRoleService.listGroupRole(textFilter);
    }


    @Operation(summary = "Xóa nhóm quyền")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id
    ) throws Exception {
        return groupRoleService.delete(id);
    }

    @Operation(summary = "Xem chi tiết nhóm quyền")
    @GetMapping(value = "/{id}")
    public ResponseBase detail(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id
    ) throws Exception {
        return groupRoleService.detail(id, false);
    }

    @Operation(summary = "Xem thông tin nhóm quyền")
    @GetMapping(value = "/info/{id}")
    public ResponseBase info(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id
    ) throws Exception {
        return groupRoleService.detail(id, true);
    }

    @Operation(summary = "Gán tài khoản vào nhóm quyền")
    @PostMapping(value = "/set-account-to-role")
    public ResponseBase setAccountToRole(
            @RequestBody
            @Valid GroupRoleAccountDTO groupRoleAccountDTO
    ) throws Exception {
        return groupRoleService.setAccountToRole(groupRoleAccountDTO);
    }

    @Operation(summary = "Kích hoạt/ hủy kích hoạt nhóm quyền")
    @PutMapping(value = "/{id}")
    public ResponseBase setActiveDeActive(
            @Valid
            @NotEmpty(message = "error.common.validate.not.empty")
            @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
            @PathVariable String id
    ) throws Exception {
        return groupRoleService.setActiveDeActive(id);
    }

    @Operation(summary = "DDL danh sách nhóm quyền")
    @GetMapping(value = "/list")
    public ResponseBase list(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,

            @Valid
            @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "page", required = false) Integer page,

            @Valid
            @Min(value = Constants.VALID.MIN_SIZE, message = "error.common.validate.min.value.0")
            @Max(value = Constants.VALID.MAX_SIZE, message = "error.common.validate.max.value.99999999")
            @RequestParam(name = "size", required = false) Integer size
    ) throws IllegalAccessException {
        int pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        int sizeNumber = size == null ? Constants.MAX_ROW_SELECT : size;
        GroupRoleFilter textFilter = new GroupRoleFilter(pageNumber, sizeNumber, keySearch, Constants.GROUP_ROLE_TYPE.SERVICE, Constants.GROUP_ROLE_STATUS.ACTIVE, null);
        return groupRoleService.listGroupRole(textFilter);
    }


    @Operation(summary = "Sinh mã mới")
    @GetMapping(value = "/new-code")
    public ResponseBase generateNewCode(
            @RequestParam(name = "parentCode", required = false) String parentCode,
            @RequestParam(name = "categoryName", required = false) String categoryName
    ) {
        return groupRoleService.generateNewCode(parentCode, "TBL_Q_NHOM_QUYEN");
    }

    @Operation(summary = "DS Nhóm Quyền")
    @GetMapping(value = "/list/{status}")
    public ResponseBase selectList(@PathVariable String status,
                                   @RequestParam(name = "keySearch", required = false) String keySearch,
                                   @RequestParam(name = "id", required = false) String id,
                                   @RequestParam(name = "page") Optional<Integer> page, @RequestParam(name = "size") Optional<Integer> size) {
        int pageNumber = page.orElse(DEFAULT_PAGE);
        int sizeNumber = size.orElse(DEFAULT_SIZE);
        return groupRoleService.selectList(id, status, new TextFilter(pageNumber, sizeNumber, keySearch));
    }
}
