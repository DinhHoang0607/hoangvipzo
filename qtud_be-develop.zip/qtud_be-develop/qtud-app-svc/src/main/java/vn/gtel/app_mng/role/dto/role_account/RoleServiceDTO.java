package vn.gtel.app_mng.role.dto.role_account;

import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
@JsonTypeName("service")
@AllArgsConstructor
@NoArgsConstructor
public class RoleServiceDTO extends RoleDTO{
	private String service;
	private Long maxAccessReq;
	private String method;
}
