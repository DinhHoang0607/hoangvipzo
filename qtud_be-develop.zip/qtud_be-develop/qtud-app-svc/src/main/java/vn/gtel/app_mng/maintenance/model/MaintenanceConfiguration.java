package vn.gtel.app_mng.maintenance.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.maintenance.dto.MaintenanceConfigurationDTO;

import javax.persistence.*;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TBL_CAU_HINH_BAO_TRI")
public class MaintenanceConfiguration {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "MO_TA")
    private String description;

    @Basic
    @Column(name = "NGAY_BAT_DAU")
    private Instant startedDate;

    @Basic
    @Column(name = "NGAY_KET_THUC")
    private Instant finishedDate;

    @Column(name = "NGAY_TAO")
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

    @Basic
    @Column(name = "TRANG_THAI")
    private Long status;

    @Basic
    @Column(name = "DELETED")
    private Long deleted;

    public MaintenanceConfiguration (MaintenanceConfigurationDTO config) {
        this.description = config.getDescription();
        this.startedDate = config.getStartedDate();
        this.finishedDate = config.getFinishedDate();
        this.createdDate = Instant.now();
        this.status = Constants.MAINTENANCE_STATUS.PREPARED;
        this.deleted = Constants.DELETED_MAINTENANCE.NOT_DELETED;
    }

    public MaintenanceConfiguration updateConfig (MaintenanceConfigurationDTO config) {
        if (config.getDescription() != null) this.description = config.getDescription();
        if (config.getStartedDate() != null && this.status.equals(Constants.MAINTENANCE_STATUS.PREPARED)) this.startedDate = config.getStartedDate();
        if (config.getFinishedDate() != null && !this.status.equals(Constants.MAINTENANCE_STATUS.FINISHED)) this.finishedDate = config.getFinishedDate();
        this.lastModifiedDate = Instant.now();
        return this;
    }

    public MaintenanceConfiguration instantFinish () {
        this.status = Constants.MAINTENANCE_STATUS.FINISHED;
        this.finishedDate = Instant.now();
        this.lastModifiedDate = Instant.now();
        return this;
    }

    public MaintenanceConfiguration extendFinished (Instant finishedDate) {
        this.finishedDate = finishedDate;
        this.lastModifiedDate = Instant.now();
        return this;
    }

    public MaintenanceConfiguration cancelConfig () {
        this.deleted = this.deleted.equals(Constants.DELETED_MAINTENANCE.NOT_DELETED) ? Constants.DELETED_MAINTENANCE.DELETED : Constants.DELETED_MAINTENANCE.NOT_DELETED;
        this.lastModifiedDate = Instant.now();
        return this;
    }
}

