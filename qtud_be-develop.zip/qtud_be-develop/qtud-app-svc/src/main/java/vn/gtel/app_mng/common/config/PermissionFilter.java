package vn.gtel.app_mng.common.config;

import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;
import vn.gtel.common.userinfo.AccountLogonContext;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PermissionFilter extends HttpFilter {

    @Value("${toggle.check.role:true}")
    private Boolean enableRole;
    private final RedisTemplate redisTemplate;

    @Override
    protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        if (enableRole) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null) {
//                logger.info(" ---  Check session and get role --- !");
//                HttpSession httpSession = request.getSession();
//                String sessionAccount = (String) httpSession.getAttribute(JwtClaimNames.SUB);
//                String authorization = request.getHeader("authorization");
//                String account = AccountLogonContext.getUsername();
//                Object role = redisTemplate.opsForValue().get("ROLE_" + account);
//                List<String> rolesResponse = role == null ? new ArrayList<>() : (List<String>) new Gson().fromJson(role.toString(), List.class).stream().filter(e -> e != null).collect(Collectors.toList());
//                Collection<? extends GrantedAuthority> authorities = rolesResponse.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
//                authentication = new UsernamePasswordAuthenticationToken(authentication.getPrincipal(), null, authorities);
                Collection<? extends GrantedAuthority> authorities = new ArrayList<>();
                ((UsernamePasswordAuthenticationToken) authentication).setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        }
        filterChain.doFilter(request, response);
    }
}
