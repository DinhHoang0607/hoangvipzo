package vn.gtel.app_mng.account.dto;

import lombok.*;
import vn.gtel.app_mng.role.reponse.GroupRoleResponse;

import javax.persistence.Column;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ExportRoleAccountDTO {

    @Column(name = "MA")
    private String code;

    @Column(name = "TEN")
    private String name;

    @Column(name = "TEN_UNG_DUNG")
    private String appName;




}
