package vn.gtel.app_mng.maintenance.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.maintenance.dto.MaintenanceConfigurationDTO;
import vn.gtel.app_mng.maintenance.dto.filter.MaintenanceConfigurationFilterDTO;
import vn.gtel.app_mng.maintenance.service.MaintenanceConfigurationService;

import javax.validation.Valid;
import java.time.Instant;

@RestController
@RequestMapping("/api/v1/maintenanceConfiguration")
public class MaintenanceConfigurationController {
    @Autowired
    private MaintenanceConfigurationService maintenanceConfigurationService;

    @Operation(summary = "Trạng thái hệ thống")
    @GetMapping(value = "/state")
    public ResponseBase serverStatus() {
        return maintenanceConfigurationService.serverStatus();
    }

    @Operation(summary = "Tạo mới lịch bảo trì")
    @PostMapping(value = "")
    public ResponseBase createMaintenanceSchedule(@RequestBody @Valid MaintenanceConfigurationDTO config) throws Exception {
        return maintenanceConfigurationService.createMaintenanceSchedule(config);
    }

    @Operation(summary = "Sửa lịch bảo trì")
    @PutMapping(value = "")
    public ResponseBase updateMaintenanceSchedule(@RequestBody @Valid MaintenanceConfigurationDTO config) throws Exception {
        return maintenanceConfigurationService.updateMaintenanceSchedule(config);
    }

    @Operation(summary = "Kết thúc bảo trì sớm")
    @PatchMapping(value = "/finished")
    public ResponseBase finishMaintenanceSchedule() throws Exception {
        return maintenanceConfigurationService.finishMaintenanceSchedule();
    }

    @Operation(summary = "Kéo dài thời gian bảo trì")
    @PatchMapping(value = "/extended")
    public ResponseBase extendMaintenanceSchedule(@RequestParam(name = "finishedDate", required = true) Instant finishedDate) throws Exception {
        return maintenanceConfigurationService.extendMaintenanceSchedule(finishedDate);
    }

    @Operation(summary = "Chi tiết lịch bảo trì")
    @GetMapping(value = "/{id}")
    public ResponseBase getMaintenanceSchedule(@PathVariable @Valid String id) throws Exception {
        return maintenanceConfigurationService.getMaintenanceSchedule(id);
    }

    @Operation(summary = "Hủy (xóa) lịch bảo trì")
    @DeleteMapping(value = "/{id}")
    public ResponseBase cancelMaintenanceSchedule(@PathVariable @Valid String id) throws Exception {
        return maintenanceConfigurationService.cancelMaintenanceSchedule(id);
    }

    @Operation(summary = "Danh sách lịch bảo trì")
    @GetMapping(value = "")
    public ResponseBase getMaintenanceScheduleList(
            @RequestParam(name = "description", required = false) String description,
            @RequestParam(name = "startedDateBegin", required = false) Instant startedDateBegin,
            @RequestParam(name = "startedDateEnd", required = false) Instant startedDateEnd,
            @RequestParam(name = "finishedDateBegin", required = false) Instant finishedDateBegin,
            @RequestParam(name = "finishedDateEnd", required = false) Instant finishedDateEnd,
            @RequestParam(name = "minDuration", required = false) Long minDuration,
            @RequestParam(name = "maxDuration", required = false) Long maxDuration,
            @RequestParam(name = "status", required = false) Long status,
            @RequestParam(name = "deleted", required = false) Long deleted,
            @RequestParam(name = "page") Long page,
            @RequestParam(name = "size") Long size
    ) throws Exception {
        Long pageNumber = page == null ? Constants.DEFAULT_PAGE : page;
        Long sizeNumber = size == null ? Constants.MAX_ROW_SELECT : size;
        MaintenanceConfigurationFilterDTO filter
                = new MaintenanceConfigurationFilterDTO(description, startedDateBegin, startedDateEnd, finishedDateBegin, finishedDateEnd, minDuration, maxDuration, status, deleted, pageNumber, sizeNumber);
        return maintenanceConfigurationService.getMaintenanceScheduleList(filter);
    }

    @Operation(summary = "Xóa cache")
    @GetMapping(value = "/clearCache")
    public ResponseBase clearCache() {
        return maintenanceConfigurationService.clearCache();
    }

//    private Boolean isMaintenanceManager() {
//        AccountUserDetails account = new AccountUserDetails();
//        Optional<String> username =;
//        System.out.println(username.get());
//        return username.isPresent() && username.get().toLowerCase().contains("admin");
//    }
}

