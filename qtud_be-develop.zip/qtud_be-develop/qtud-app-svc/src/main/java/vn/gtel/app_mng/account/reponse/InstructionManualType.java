package vn.gtel.app_mng.account.reponse;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InstructionManualType {
    private String name;
    private Integer type;
}
