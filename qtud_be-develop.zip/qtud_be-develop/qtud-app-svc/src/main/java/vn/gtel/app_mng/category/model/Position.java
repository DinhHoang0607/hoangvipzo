package vn.gtel.app_mng.category.model;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TBL_DM_CHUC_VU")
public class Position extends AuditCategoryModel {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "PHAN_LOAI")
    private Integer type;

    @Basic
    @Column(name = "LOAI_CHUC_VU")
    private Integer classify;

}
