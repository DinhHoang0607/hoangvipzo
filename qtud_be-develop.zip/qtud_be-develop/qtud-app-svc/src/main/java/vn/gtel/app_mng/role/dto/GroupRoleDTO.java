/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  GroupRoleDTO.java
 * Created By :  tuannp
 * Created at :  12/20/21, 3:55 PM
 * LastModified  :  12/20/21, 2:02 PM
 */

package vn.gtel.app_mng.role.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;
import vn.gtel.app_mng.category.dto.CodeNameDTO;
import vn.gtel.app_mng.common.dto.AuditCodeDTO;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GroupRoleDTO extends AuditCodeDTO implements Serializable {

//	private List<String> applications;
	private CodeNameDTO application;
	//@NotEmpty(message = "error.common.validate.not.empty")
	private List<RoleItemDTO> roles;
	private Long checkRole;
//	private List<String> positions;
	private List<String> groupAccounts;
	private List<CodeItemWithActionDTO> groupAccountRes;

}
