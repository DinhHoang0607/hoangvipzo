package vn.gtel.app_mng.report.service.Impl;

import com.aspose.cells.Workbook;
import com.aspose.words.Document;
import com.aspose.words.net.System.Data.DataTable;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jxls.common.Context;
import org.jxls.util.JxlsHelper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.dto.excelObj.ReportAccountDTO;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.model.AccountOrganization;
import vn.gtel.app_mng.account.repository.AccountOrganizationRepository;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.category.repo.OrganizationRepo;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.model.AuditModelBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CommonService;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.report.dto.filter.StatisticFilter;
import vn.gtel.app_mng.report.dto.res.AccountOrganizationResponseDTO;
import vn.gtel.app_mng.report.dto.res.CommonReportResponseDTO;
import vn.gtel.app_mng.report.dto.res.MenuResDTO;
import vn.gtel.app_mng.report.service.ReportService;
import vn.gtel.app_mng.report.storeObj.ReportCallStoredDTO;
import vn.gtel.common.config.constants.ReportCommon;
import vn.gtel.common.service.AsposeReportService;
import vn.gtel.common.userinfo.AccountLogonContext;
import vn.gtel.common.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
@AllArgsConstructor
public class ReportServiceImpl implements ReportService {
    private final CallStoredRepository callStoredRepository;
    private final TrimSpaceUtil trimSpaceUtil;
    private final AccountRepository accountRepository;
    private final AccountOrganizationRepository accountOrganizationRepository;
    private final OrganizationRepo organizationRepo;
    private final SimpleDateFormat onlyDateFmt = new SimpleDateFormat("dd-MM-yyyy");
    private final AsposeReportService asposeReportService;
    private final EntityManager entityManager;

    @Override
    public ResponseEntity sumAccount(StatisticFilter filter, String type) throws Exception {
        trimSpaceUtil.validate(filter);
        Map<String, Object> dataMap = new HashMap<>();
        int pageIndex = Constants.DEFAULT_PAGE;
        int pageSize = Constants.MAX_ROW_SELECT;
        String fileOutPut = ReportCommon.TEMPLATE.TK_SL_TK;
        ICallStoredObj callStoredObj = new ReportCallStoredDTO(filter);
        Object res = callStoredRepository.getList(callStoredObj);
        List<CommonReportResponseDTO> lstResult = (List<CommonReportResponseDTO>) res;
        if (CollectionUtils.isEmpty(lstResult)) return ReportCommon.noContent();
        Long sum = 0L;
        for (CommonReportResponseDTO dto : lstResult) {
            sum += dto.getCountNumber();
        }
        dataMap.put("sum", String.valueOf(sum));

        String address = null;
        String name = AccountLogonContext.currentUser().getAccount();
        if (name != null) {
            Optional<Account> account = accountRepository.findByAccount(name);
            String tenCap = "CỤC";
            if (!name.equals(Constants.ADMIN)) {
                tenCap = "PHÒNG";
            }
            if (account.get().getAddressOrgProvinceName() != null) {
                address = account.get().getAddressOrgProvinceName();
            }
            dataMap.put("address", address);
            dataMap.put("tenCap", tenCap);
            dataMap.put("accountName", name);
            dataMap.put("orgName", account.get().getOrganizationParentName().toUpperCase());
        }


        LocalDate now = LocalDate.now();
        int date = now.getDayOfMonth();
        long month = now.getMonth().getValue();
        int year = now.getYear();

        dataMap.put("date", date);
        dataMap.put("month", month);
        dataMap.put("year", year);

        DateTimeFormatter formatterRes = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fromDate = filter.getFromDate().atZone(ZoneId.of("UTC")).toLocalDate().format(formatterRes);
        String fromDateEnd = filter.getToDate().atZone(ZoneId.of("UTC")).toLocalDate().format(formatterRes);

        dataMap.put("fromDate", fromDate);
        dataMap.put("toDate", fromDateEnd);
        dataMap.put("typeDate", "ngày");

        DataTable dataTable = ReportCommon.newDataTable();// new DataTable("lst");

//        dataTable.getColumns().add("stt");
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.name);
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.countNumber);
        AtomicInteger stt = new AtomicInteger();
        if (Constants.EXPORT_TYPE.XLSX.toString().equals(type)) {
            dataTable.getColumns().add("delete");
            for (CommonReportResponseDTO e : lstResult) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getName(), null, e.getCountNumber()};
                    dataTable.getRows().add(objs);
                }
            }
        } else {
            for (CommonReportResponseDTO e : lstResult) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getName(), e.getCountNumber()};
                    dataTable.getRows().add(objs);
                }
            }
        }

        if (Constants.EXPORT_TYPE.PDF.toString().equals(type)) {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_TK.concat(ReportCommon.TEMPLATE.EXT_DOCX);
            try {
                InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
                Document doc = new Document(is);
                return asposeReportService.generateDataReport(doc, Constants.EXPORT_TYPE.PDF.toString().toLowerCase(), dataMap, false, List.of(dataTable), fileOutPut, fileInput);
            } catch (Exception e) {
                log.error("Extract dk1 fail : " + e.getCause());
            }
        } else {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_TK.concat(ReportCommon.TEMPLATE.EXT_XLSX);
            InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
            Workbook workbook = new Workbook(is);
            return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut, "1");
        }
        return ResponseEntity.noContent().build();
//        JRDataSource dataSource = new JREmptyDataSource();
//
//        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
//        String templatePath = "report/Thong_Ke_So_Luong_Tai_Khoan.jasper";
//        String fileName = "Thong_Ke_So_Luong_Tai_Khoan";
//        String mimeType = "." + CommonUtils.toLowerCase(type);
//        Map<String, Object> reportParams = new HashMap<>();
//
//        ICallStoredObj callStoredObj = new ReportCallStoredDTO(filter);
//        Object res = callStoredRepository.getList(callStoredObj);
//        List<ReportAccountResponseDTO> lstResults = (List<ReportAccountResponseDTO>) res;
//        // insert empty into 0 index
//        lstResults.add(0, new ReportAccountResponseDTO());
//        dataSource = new JRBeanCollectionDataSource(lstResults);
//        reportParams.put("dataSource", dataSource);
//
//        oStream = CommonService.generateReport(dataSource, templatePath, reportParams, type.toLowerCase(Locale.ENGLISH));
//        return CommonUtils.downloadFileJasper(oStream, fileName + "_" + sdf.format(new Date()) + mimeType);
    }

    @Override
    public ResponseEntity sumAccessByApp(FilterChart filterChart, String type) throws Exception {
        trimSpaceUtil.validate(filterChart);
        Map<String, Object> dataMap = new HashMap<>();
        int pageIndex = Constants.DEFAULT_PAGE;
        int pageSize = Constants.MAX_ROW_SELECT;
        String fileOutPut = ReportCommon.TEMPLATE.TK_SL_truy_cap_theo_PM;
        ICallStoredObj callStoredObj = new ReportCallStoredDTO(filterChart);
        List<CommonReportResponseDTO> lstResults = (List<CommonReportResponseDTO>) callStoredRepository.getList(callStoredObj);
        if (ReportCommon.isEmptyContent(lstResults)) return ResponseEntity.noContent().build();

        String address = null;
        String name = AccountLogonContext.currentUser().getAccount();
        if (name != null) {
            Optional<Account> account = accountRepository.findByAccount(name);
            String tenCap = "CỤC";
            if (!name.equals(Constants.ADMIN)) {
                tenCap = "PHÒNG";
            }
            if (account.get().getAddressOrgProvinceName() != null) {
                address = account.get().getAddressOrgProvinceName();
            }
            dataMap.put("address", address);
            dataMap.put("tenCap", tenCap);
            dataMap.put("accountName", name);
            dataMap.put("orgName", account.get().getOrganizationParentName().toUpperCase());
        }


        LocalDate now = LocalDate.now();
        int date = now.getDayOfMonth();
        long month = now.getMonth().getValue();
        int year = now.getYear();

        dataMap.put("date", date);
        dataMap.put("month", month);
        dataMap.put("year", year);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter formatterMonth = DateTimeFormatter.ofPattern("yyyyMM");
        DateTimeFormatter formatterYear = DateTimeFormatter.ofPattern("yyyy");
        LocalDate fromDate = null;
        YearMonth fromDateMonth = null;
        Year fromDateYear = null;
        if (filterChart.getFromDateTime() != null) {
            if (filterChart.getAggType().equals("day")) {
                fromDate = LocalDate.parse(String.valueOf(filterChart.getFromDateTime()), formatter);
            } else if (filterChart.getAggType().equals("month")) {
                fromDateMonth = YearMonth.parse(String.valueOf(filterChart.getFromDateTime()), formatterMonth);
            } else if (filterChart.getAggType().equals("quarter")) {
                fromDateMonth = YearMonth.parse(new StringBuilder(String.valueOf(filterChart.getFromDateTime())).insert(4, "0").toString(), formatterMonth);
            } else if (filterChart.getAggType().equals("year")) {
                fromDateYear = Year.parse(String.valueOf(filterChart.getFromDateTime()), formatterYear);
            }
        }

        LocalDate fromDateEnd = null;
        YearMonth fromDateMonthEnd = null;
        Year fromDateYearEnd = null;
        if (filterChart.getToDateTime() != null) {
            if (filterChart.getAggType().equals("day")) {
                fromDateEnd = LocalDate.parse(String.valueOf(filterChart.getToDateTime()), formatter);
            } else if (filterChart.getAggType().equals("month")) {
                fromDateMonthEnd = YearMonth.parse(String.valueOf(filterChart.getToDateTime()), formatterMonth);
            } else if (filterChart.getAggType().equals("quarter")) {
                fromDateMonthEnd = YearMonth.parse(new StringBuilder(String.valueOf(filterChart.getToDateTime())).insert(4, "0").toString(), formatterMonth);
            } else if (filterChart.getAggType().equals("year")) {
                fromDateYearEnd = Year.parse(String.valueOf(filterChart.getToDateTime()), formatterYear);
            }
        }


        DateTimeFormatter formatterRes = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatterResMonth = DateTimeFormatter.ofPattern("MM/yyyy");
        DateTimeFormatter formatterResYear = DateTimeFormatter.ofPattern("yyyy");
        if (filterChart.getAggType().equals("day")) {
            dataMap.put("fromDate", formatterRes.format(fromDate));
            dataMap.put("toDate", formatterRes.format(fromDateEnd));
            dataMap.put("typeDate", "ngày");
        } else if (filterChart.getAggType().equals("month")) {
            dataMap.put("fromDate", formatterResMonth.format(fromDateMonth));
            dataMap.put("toDate", formatterResMonth.format(fromDateMonthEnd));
            dataMap.put("typeDate", "tháng");
        } else if (filterChart.getAggType().equals("quarter")) {
            dataMap.put("fromDate", formatterResMonth.format(fromDateMonth));
            dataMap.put("toDate", formatterResMonth.format(fromDateMonthEnd));
            dataMap.put("typeDate", "quý");
        } else if (filterChart.getAggType().equals("year")) {
            dataMap.put("fromDate", formatterResYear.format(fromDateYear));
            dataMap.put("toDate", formatterResYear.format(fromDateYearEnd));
            dataMap.put("typeDate", "năm");
        }
//        dataMap.put("fromDate", simpleDateFormat.format(fromDate));
//        dataMap.put("toDate", simpleDateFormat.format(toDate));

        DataTable dataTable = new DataTable("lst");

        dataTable.getColumns().add("stt");
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.name);
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.countNumber);
        AtomicInteger stt = new AtomicInteger();

        if (Constants.EXPORT_TYPE.XLSX.toString().equals(type)) {
            dataTable.getColumns().add("delete");
            for (CommonReportResponseDTO e : lstResults) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getName(), null, e.getCountNumber()};
                    dataTable.getRows().add(objs);
                }
            }
        } else {
            for (CommonReportResponseDTO e : lstResults) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getName(), e.getCountNumber()};
                    dataTable.getRows().add(objs);
                }
            }
        }

        if (Constants.EXPORT_TYPE.PDF.toString().equals(type)) {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_truy_cap_theo_PM.concat(ReportCommon.TEMPLATE.EXT_DOCX);
            try {
                InputStream is = CommonService.getReport(fileInput);
                Document doc = new Document(is);
                return asposeReportService.generateDataReport(doc, Constants.EXPORT_TYPE.PDF.toString().toLowerCase(), dataMap, false, List.of(dataTable), fileOutPut, fileInput);
            } catch (Exception e) {
                log.error("Extract dk1 fail : " + e.getCause());
            }
        } else {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_truy_cap_theo_PM.concat(ReportCommon.TEMPLATE.EXT_XLSX);
            InputStream is = CommonService.getReport(fileInput);// CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
            Workbook workbook = new Workbook(is);
            return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut, "1");
        }
        return ResponseEntity.noContent().build();
//        JRDataSource dataSource = new JREmptyDataSource();
//
//        ByteArrayOutputStream oStream = new ByteArrayOutputStream();
//        String templatePath = "report/Thong_Ke_Truy_Cap_Theo_PM.jasper";
//        String fileName = "Thong_Ke_Truy_Cap_Theo_Phan_Mem";
//        String mimeType = "." + CommonUtils.toLowerCase(type);
//        Map<String, Object> reportParams = new HashMap<>();
//
//        ICallStoredObj callStoredObj = new ReportCallStoredDTO(filterChart);
//        List<ReportAccountResponseDTO> lstResults = (List<ReportAccountResponseDTO>) callStoredRepository.getList(callStoredObj);
//        // insert empty into 0 index
//        lstResults.add(0, new ReportAccountResponseDTO());
//        dataSource = new JRBeanCollectionDataSource(lstResults);
//        reportParams.put("dataSource", dataSource);
//        String displayAggType = reportTimeConverter(filterChart.getAggType(), null);
//        reportParams.put("fromTime", "Từ " + displayAggType + " " + reportTimeConverter(filterChart.getAggType(), filterChart.getFromDateTime()));
//        reportParams.put("toTime", "Đến " + displayAggType + " " + reportTimeConverter(filterChart.getAggType(), filterChart.getToDateTime()));
//
//        oStream = CommonService.generateReport(dataSource, templatePath, reportParams, type.toLowerCase(Locale.ENGLISH));
//        return CommonUtils.downloadFileJasper(oStream, fileName + "_" + sdf.format(new Date()) + mimeType);
    }

    @Override
    public ResponseEntity sumAccessByOrg(FilterChart filterChart, String type) throws Exception {
        trimSpaceUtil.validate(filterChart);
        Map<String, Object> dataMap = new HashMap<>();
        int pageIndex = Constants.DEFAULT_PAGE;
        int pageSize = Constants.MAX_ROW_SELECT;
        String fileOutPut = ReportCommon.TEMPLATE.TK_SL_truy_cap_theo_DV;
        ICallStoredObj callStoredObj = new ReportCallStoredDTO(filterChart);
        callStoredObj.setPackageName("PKG_BAO_CAO");
        List<CommonReportResponseDTO> lstResults = (List<CommonReportResponseDTO>) callStoredRepository.getList(callStoredObj);

        DataTable dataTable = new DataTable("lst");

        dataTable.getColumns().add("stt");
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.name);
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.countNumber);
        AtomicInteger stt = new AtomicInteger();

        if (Constants.EXPORT_TYPE.XLSX.toString().equals(type)) {
            dataTable.getColumns().add("delete");
            for (CommonReportResponseDTO e : lstResults) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getName(), null, e.getCountNumber()};
                    dataTable.getRows().add(objs);
                }
            }
        } else {
            for (CommonReportResponseDTO e : lstResults) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getName(), e.getCountNumber()};
                    dataTable.getRows().add(objs);
                }
            }
        }

        String address = null;
        String name = AccountLogonContext.currentUser().getAccount();
        if (name != null) {
            Optional<Account> account = accountRepository.findByAccount(name);
            String tenCap = "CỤC";
            if (!name.equals(Constants.ADMIN)) {
                tenCap = "PHÒNG";
            }
            if (account.get().getAddressOrgProvinceName() != null) {
                address = account.get().getAddressOrgProvinceName();
            }
            dataMap.put("address", address);
            dataMap.put("tenCap", tenCap);
            dataMap.put("accountName", name);
            dataMap.put("orgName", account.get().getOrganizationParentName().toUpperCase());
        }

        LocalDate now = LocalDate.now();
        int date = now.getDayOfMonth();
        long month = now.getMonth().getValue();
        int year = now.getYear();

        dataMap.put("date", date);
        dataMap.put("month", month);
        dataMap.put("year", year);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter formatterMonth = DateTimeFormatter.ofPattern("yyyyMM");
        DateTimeFormatter formatterYear = DateTimeFormatter.ofPattern("yyyy");
        LocalDate fromDate = null;
        YearMonth fromDateMonth = null;
        Year fromDateYear = null;
        if (filterChart.getFromDateTime() != null) {
            if (filterChart.getAggType().equals("day")) {
                fromDate = LocalDate.parse(String.valueOf(filterChart.getFromDateTime()), formatter);
            } else if (filterChart.getAggType().equals("month")) {
                fromDateMonth = YearMonth.parse(String.valueOf(filterChart.getFromDateTime()), formatterMonth);
            } else if (filterChart.getAggType().equals("quarter")) {
                fromDateMonth = YearMonth.parse(new StringBuilder(String.valueOf(filterChart.getFromDateTime())).insert(4, "0").toString(), formatterMonth);
            } else if (filterChart.getAggType().equals("year")) {
                fromDateYear = Year.parse(String.valueOf(filterChart.getFromDateTime()), formatterYear);
            }
        }

        LocalDate fromDateEnd = null;
        YearMonth fromDateMonthEnd = null;
        Year fromDateYearEnd = null;
        if (filterChart.getToDateTime() != null) {
            if (filterChart.getAggType().equals("day")) {
                fromDateEnd = LocalDate.parse(String.valueOf(filterChart.getToDateTime()), formatter);
            } else if (filterChart.getAggType().equals("month")) {
                fromDateMonthEnd = YearMonth.parse(String.valueOf(filterChart.getToDateTime()), formatterMonth);
            } else if (filterChart.getAggType().equals("quarter")) {
                fromDateMonthEnd = YearMonth.parse(new StringBuilder(String.valueOf(filterChart.getToDateTime())).insert(4, "0").toString(), formatterMonth);
            } else if (filterChart.getAggType().equals("year")) {
                fromDateYearEnd = Year.parse(String.valueOf(filterChart.getToDateTime()), formatterYear);
            }
        }


        DateTimeFormatter formatterRes = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatterResMonth = DateTimeFormatter.ofPattern("MM/yyyy");
        DateTimeFormatter formatterResYear = DateTimeFormatter.ofPattern("yyyy");
        if (filterChart.getAggType().equals("day")) {
            dataMap.put("fromDate", formatterRes.format(fromDate));
            dataMap.put("toDate", formatterRes.format(fromDateEnd));
            dataMap.put("typeDate", "ngày");
        } else if (filterChart.getAggType().equals("month")) {
            dataMap.put("fromDate", formatterResMonth.format(fromDateMonth));
            dataMap.put("toDate", formatterResMonth.format(fromDateMonthEnd));
            dataMap.put("typeDate", "tháng");
        } else if (filterChart.getAggType().equals("quarter")) {
            dataMap.put("fromDate", formatterResMonth.format(fromDateMonth));
            dataMap.put("toDate", formatterResMonth.format(fromDateMonthEnd));
            dataMap.put("typeDate", "quý");
        } else if (filterChart.getAggType().equals("year")) {
            dataMap.put("fromDate", formatterResYear.format(fromDateYear));
            dataMap.put("toDate", formatterResYear.format(fromDateYearEnd));
            dataMap.put("typeDate", "năm");
        }

        if (Constants.EXPORT_TYPE.PDF.toString().equals(type)) {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_truy_cap_theo_DV.concat(ReportCommon.TEMPLATE.EXT_DOCX);
            try {
                InputStream is = CommonService.getReport(fileInput);
                Document doc = new Document(is);
                return asposeReportService.generateDataReport(doc, Constants.EXPORT_TYPE.PDF.toString().toLowerCase(), dataMap, false, List.of(dataTable), fileOutPut, fileInput);
            } catch (Exception e) {
                log.error("Extract dk1 fail : " + e.getCause());
            }
        } else {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_truy_cap_theo_DV.concat(ReportCommon.TEMPLATE.EXT_XLSX);
            InputStream is = CommonService.getReport(fileInput);// CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
            Workbook workbook = new Workbook(is);
            return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut, "1");
        }
        return ResponseEntity.noContent().build();
    }

    @Override
    public ResponseEntity sumAccountTotal(Instant fromDate, Instant toDate, String type) throws IOException {
        boolean checkRole = AccountLogonContext.currentUser().getOrganization().equals(Constants.ORGANIZATION_CODE.BCA);
        if (checkRole) {
            if (fromDate == null || toDate == null) {
                fromDate = Instant.now();
                toDate = Instant.now();
            }
            String templatePath = "template/excel/temp_account_report.xlsx";
            InputStream is = null;
            try {
                ByteArrayOutputStream oStream = new ByteArrayOutputStream();
                is = CommonService.class.getClassLoader().getResourceAsStream(templatePath);
                Context context = new Context();
                String rpDate = fromDate.truncatedTo(ChronoUnit.DAYS).equals(toDate.truncatedTo(ChronoUnit.DAYS)) ? onlyDateFmt.format(Date.from(fromDate)) : onlyDateFmt.format(Date.from(fromDate)).concat("-").concat(onlyDateFmt.format(Date.from(toDate)));
                context.putVar("from", onlyDateFmt.format(Date.from(fromDate)));
                context.putVar("to", onlyDateFmt.format(Date.from(toDate)));

                ICallStoredObj callStoredObj = new ReportCallStoredDTO(fromDate, toDate, type);
                Object res = callStoredRepository.getList(callStoredObj);
                List<ReportAccountDTO> lstResults = (List<ReportAccountDTO>) res;
                if (ReportCommon.isEmptyContent(lstResults)) return ResponseEntity.noContent().build();
                context.putVar("rows", lstResults);

                JxlsHelper.getInstance().processTemplate(is, oStream, context);
                return CommonUtils.downloadFileJasper(oStream, "THONG_KE_TAI_KHOAN_" + rpDate + ".xlsx");
            } finally {
                if (is != null) {
                    is.close();
                }
            }
        } else {
            throw new SecurityException("Bạn không có quyền xuất báo cáo này!");
        }
    }

    private String reportTimeConverter(String aggType, Long time) {
        if (StringUtils.isNotEmpty(aggType)) {
            switch (aggType) {
                case "year":
                    return time != null ? time.toString() : "năm";
                case "quarter":
                    return time != null ? String.format("%s/%s", time.toString().substring(5), time.toString().substring(0, 4)) : "quý";
                case "month":
                    return time != null ? String.format("%s/%s", time.toString().substring(4), time.toString().substring(0, 4)) : "tháng";
                case "week":
                    return time != null ? String.format("") : "tuần";
                case "day":
                    return time != null ? String.format("%s/%s/%s", time.toString().substring(6), time.toString().substring(4, 6), time.toString().substring(0, 4)) : "ngày";
            }
        }
        return null;
    }

    @Override
    public ResponseEntity countWarning(FilterChart filterChart, String type) throws Exception {
        trimSpaceUtil.validate(filterChart);
        Map<String, Object> dataMap = new HashMap<>();
        int pageIndex = Constants.DEFAULT_PAGE;
        int pageSize = Constants.MAX_ROW_SELECT;
        String fileOutPut = ReportCommon.TEMPLATE.TK_SL_canh_bao_theo_PM;
        ReportCallStoredDTO callStoredObj = new ReportCallStoredDTO(filterChart);
        callStoredObj.isWarning(true);
        List<MenuResDTO> lstResults = (List<MenuResDTO>) callStoredRepository.getList(callStoredObj);
        if (ReportCommon.isEmptyContent(lstResults)) return ResponseEntity.noContent().build();

        String address = null;
        String name = AccountLogonContext.currentUser().getAccount();
        if (name != null) {
            Optional<Account> account = accountRepository.findByAccount(name);
            String tenCap = "CỤC";
            if (!name.equals(Constants.ADMIN)) {
                tenCap = "PHÒNG";
            }
            if (account.get().getAddressOrgProvinceName() != null) {
                address = account.get().getAddressOrgProvinceName();
            }
            dataMap.put("address", address);
            dataMap.put("tenCap", tenCap);
            dataMap.put("accountName", name);
            dataMap.put("orgName", account.get().getOrganizationParentName().toUpperCase());
        }


        LocalDate now = LocalDate.now();
        int date = now.getDayOfMonth();
        long month = now.getMonth().getValue();
        int year = now.getYear();

        dataMap.put("date", date);
        dataMap.put("month", month);
        dataMap.put("year", year);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter formatterMonth = DateTimeFormatter.ofPattern("yyyyMM");
        DateTimeFormatter formatterYear = DateTimeFormatter.ofPattern("yyyy");
        LocalDate fromDate = null;
        YearMonth fromDateMonth = null;
        Year fromDateYear = null;
        if (filterChart.getFromDateTime() != null) {
            if (filterChart.getAggType().equals("day")) {
                fromDate = LocalDate.parse(String.valueOf(filterChart.getFromDateTime()), formatter);
            } else if (filterChart.getAggType().equals("month")) {
                fromDateMonth = YearMonth.parse(String.valueOf(filterChart.getFromDateTime()), formatterMonth);
            } else if (filterChart.getAggType().equals("quarter")) {
                fromDateMonth = YearMonth.parse(new StringBuilder(String.valueOf(filterChart.getFromDateTime())).insert(4, "0").toString(), formatterMonth);
            } else if (filterChart.getAggType().equals("year")) {
                fromDateYear = Year.parse(String.valueOf(filterChart.getFromDateTime()), formatterYear);
            }
        }

        LocalDate fromDateEnd = null;
        YearMonth fromDateMonthEnd = null;
        Year fromDateYearEnd = null;
        if (filterChart.getToDateTime() != null) {
            if (filterChart.getAggType().equals("day")) {
                fromDateEnd = LocalDate.parse(String.valueOf(filterChart.getToDateTime()), formatter);
            } else if (filterChart.getAggType().equals("month")) {
                fromDateMonthEnd = YearMonth.parse(String.valueOf(filterChart.getToDateTime()), formatterMonth);
            } else if (filterChart.getAggType().equals("quarter")) {
                fromDateMonthEnd = YearMonth.parse(new StringBuilder(String.valueOf(filterChart.getToDateTime())).insert(4, "0").toString(), formatterMonth);
            } else if (filterChart.getAggType().equals("year")) {
                fromDateYearEnd = Year.parse(String.valueOf(filterChart.getToDateTime()), formatterYear);
            }
        }


        DateTimeFormatter formatterRes = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatterResMonth = DateTimeFormatter.ofPattern("MM/yyyy");
        DateTimeFormatter formatterResYear = DateTimeFormatter.ofPattern("yyyy");
        if (filterChart.getAggType().equals("day")) {
            dataMap.put("fromDate", formatterRes.format(fromDate));
            dataMap.put("toDate", formatterRes.format(fromDateEnd));
            dataMap.put("typeDate", "ngày");
        } else if (filterChart.getAggType().equals("month")) {
            dataMap.put("fromDate", formatterResMonth.format(fromDateMonth));
            dataMap.put("toDate", formatterResMonth.format(fromDateMonthEnd));
            dataMap.put("typeDate", "tháng");
        } else if (filterChart.getAggType().equals("quarter")) {
            dataMap.put("fromDate", formatterResMonth.format(fromDateMonth));
            dataMap.put("toDate", formatterResMonth.format(fromDateMonthEnd));
            dataMap.put("typeDate", "quý");
        } else if (filterChart.getAggType().equals("year")) {
            dataMap.put("fromDate", formatterResYear.format(fromDateYear));
            dataMap.put("toDate", formatterResYear.format(fromDateYearEnd));
            dataMap.put("typeDate", "năm");
        }

        DataTable dataTable = new DataTable("lst");
        dataTable.getColumns().add("stt");
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.name);
        dataTable.getColumns().add(MenuResDTO.Fields.menuName);
        dataTable.getColumns().add(MenuResDTO.Fields.type);
        dataTable.getColumns().add(CommonReportResponseDTO.Fields.countNumber);
        AtomicInteger stt = new AtomicInteger();
        for (MenuResDTO e : lstResults) {
            Object[] objs = {stt.incrementAndGet(), e.getName(), e.getMenuName(), e.getType(), e.getCountNumber()};
            dataTable.getRows().add(objs);
        }

        if (Constants.EXPORT_TYPE.PDF.toString().equals(type.toUpperCase())) {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_canh_bao_theo_PM.concat(ReportCommon.TEMPLATE.EXT_DOCX);
            try {
                InputStream is = CommonService.getReport(fileInput);// CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
                Document doc = new Document(is);
                return asposeReportService.generateDataReport(doc, Constants.EXPORT_TYPE.PDF.toString().toLowerCase(), dataMap, false, List.of(dataTable), fileOutPut, fileInput);
            } catch (Exception e) {
                log.error("Extract dk1 fail : " + e.getCause());
            }
        } else {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_canh_bao_theo_PM.concat(ReportCommon.TEMPLATE.EXT_XLSX);
            InputStream is = CommonService.getReport(fileInput);// CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
            Workbook workbook = new Workbook(is);
            return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut, "1");
        }
        return ResponseEntity.noContent().build();
    }

    @Override
    public ResponseEntity<?> reportAccountTransfer(StatisticFilter filter, String type) throws Exception {
        trimSpaceUtil.validate(filter);
        String fileOutPut = ReportCommon.TEMPLATE.TK_SL_CHUYEN_DV;
        List<AccountOrganizationResponseDTO> lstResults = getDataAccountTransfer(filter);
        Map<String, Object> dataMap = new HashMap<>();

        String address = null;
        String name = AccountLogonContext.currentUser().getAccount();
        if (name != null) {
            Optional<Account> account = accountRepository.findByAccount(name);
            String tenCap = "CỤC";
            if (!name.equals(Constants.ADMIN)) {
                tenCap = "PHÒNG";
            }
            if (account.get().getAddressOrgProvinceName() != null) {
                address = account.get().getAddressOrgProvinceName();
            }
            dataMap.put("address", address);
            dataMap.put("tenCap", tenCap);
            dataMap.put("accountName", name);
            dataMap.put("orgName", account.get().getOrganizationParentName().toUpperCase());
        }


        LocalDate now = LocalDate.now();
        int date = now.getDayOfMonth();
        long month = now.getMonth().getValue();
        int year = now.getYear();

        dataMap.put("date", date);
        dataMap.put("month", month);
        dataMap.put("year", year);

        DateTimeFormatter formatterRes = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fromDate = filter.getFromDate().atZone(ZoneId.of("UTC")).toLocalDate().format(formatterRes);
        String fromDateEnd = filter.getToDate().atZone(ZoneId.of("UTC")).toLocalDate().format(formatterRes);

        dataMap.put("fromDate", fromDate);
        dataMap.put("toDate", fromDateEnd);
        dataMap.put("typeDate", "ngày");

        DataTable dataTable = ReportCommon.newDataTable();// new DataTable("lst");
        dataTable.getColumns().add(AccountOrganizationResponseDTO.Fields.organizationName);
        dataTable.getColumns().add(AccountOrganizationResponseDTO.Fields.quantityShipped);
        dataTable.getColumns().add(AccountOrganizationResponseDTO.Fields.numberOfTransfers);
        dataTable.getColumns().add(AccountOrganizationResponseDTO.Fields.waitingForReception);
        dataTable.getColumns().add(AccountOrganizationResponseDTO.Fields.reject);
        AtomicInteger stt = new AtomicInteger();
        if (Constants.EXPORT_TYPE.XLSX.toString().equals(type)) {
            for (AccountOrganizationResponseDTO e : lstResults) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getOrganizationName(), e.getNumberOfTransfers(),
                            e.getQuantityShipped(), e.getWaitingForReception(), e.getReject()};
                    dataTable.getRows().add(objs);
                }
            }
        } else {
            for (AccountOrganizationResponseDTO e : lstResults) {
                if (e != null) {
                    Object[] objs = {stt.incrementAndGet(), e.getOrganizationName(), e.getNumberOfTransfers(),
                            e.getQuantityShipped(), e.getWaitingForReception(), e.getReject()};
                    dataTable.getRows().add(objs);
                }
            }
        }

        if (Constants.EXPORT_TYPE.PDF.toString().equals(type)) {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_CHUYEN_DV.concat(ReportCommon.TEMPLATE.EXT_DOCX);
            try {
                InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
                Document doc = new Document(is);
                return asposeReportService.generateDataReport(doc, Constants.EXPORT_TYPE.PDF.toString().toLowerCase(), dataMap, false, List.of(dataTable), fileOutPut, fileInput);
            } catch (Exception e) {
                log.error("Extract dk1 fail : " + e.getCause());
            }
        } else {
            String fileInput = ReportCommon.TEMPLATE.TK_SL_CHUYEN_DV.concat(ReportCommon.TEMPLATE.EXT_XLSX);
            InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/report/" + fileInput);
            Workbook workbook = new Workbook(is);
            return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut, "1");
        }
        return ResponseEntity.noContent().build();
    }

    private List<AccountOrganizationResponseDTO> getDataAccountTransfer(StatisticFilter dto) {
        Organization organization = null;
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<AccountOrganization> criteriaQuery = criteriaBuilder.createQuery(AccountOrganization.class);
        Root<AccountOrganization> root = criteriaQuery.from(AccountOrganization.class);

        List<Predicate> predicates = new ArrayList<>();
        if (dto.getOriginOrganization() != null) {
            organization = organizationRepo.findByCode(dto.getOriginOrganization());
            predicates.add(criteriaBuilder.or(
                    criteriaBuilder.equal(root.get(AccountOrganization.Fields.newOrganization), dto.getOriginOrganization()),
                    criteriaBuilder.equal(root.get(AccountOrganization.Fields.oldOrganization), dto.getOriginOrganization())));
        }

        if(dto.getFromDate() != null) {
            predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(AuditModelBase.Fields.createdDate), dto.getFromDate()));
        }
        if (dto.getToDate() != null) {
            predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get(AuditModelBase.Fields.createdDate), dto.getToDate()));
        }

        criteriaQuery.where(criteriaBuilder.and(predicates.toArray(new Predicate[0])));
        TypedQuery<AccountOrganization> dataQuery = entityManager.createQuery(criteriaQuery);
        List<AccountOrganization> result = dataQuery.getResultList();
        int quantityShipped = 0;
        int numberOfTransfers = 0;
        int waitingForReception = 0;
        int reject = 0;
        if (result != null && !result.isEmpty() && dto.getOriginOrganization() != null) {
            String organizationCode = dto.getOriginOrganization();
            for (AccountOrganization accountOrganization: result) {
                if(organizationCode.equalsIgnoreCase(accountOrganization.getOldOrganization())) {
                    quantityShipped++;
                }
                if(organizationCode.equalsIgnoreCase(accountOrganization.getNewOrganization())) {
                    numberOfTransfers++;
                }
                if (organizationCode.equalsIgnoreCase(accountOrganization.getNewOrganization())
                        && Constants.TRANSFER_ORG_STATUS.IN_PROGRESS.equals(accountOrganization.getStatus())) {
                    waitingForReception++;
                }
                if (organizationCode.equalsIgnoreCase(accountOrganization.getNewOrganization())
                        && Constants.TRANSFER_ORG_STATUS.REJECT.equals(accountOrganization.getStatus())) {
                    reject++;
                }
            }
        }
        AccountOrganizationResponseDTO responseDTO = new AccountOrganizationResponseDTO();
        responseDTO.setOrganizationCode(dto.getOriginOrganization());
        responseDTO.setOrganizationName(organization != null ? organization.getName() : null);
        responseDTO.setNumberOfTransfers(numberOfTransfers);
        responseDTO.setQuantityShipped(quantityShipped);
        responseDTO.setWaitingForReception(waitingForReception);
        responseDTO.setReject(reject);
        return List.of(responseDTO);
    }
}
