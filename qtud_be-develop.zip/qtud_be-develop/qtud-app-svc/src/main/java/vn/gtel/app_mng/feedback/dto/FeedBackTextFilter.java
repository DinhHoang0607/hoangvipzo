package vn.gtel.app_mng.feedback.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.time.Instant;

@Data
@NoArgsConstructor
public class FeedBackTextFilter  extends TextFilter {
    private Long view;
    private String level;
    private String status;
    private String orgCode;
    private Instant startDate;
    private Instant endDate;
    private String code;
    private String account;
    private Long classify;

    public FeedBackTextFilter(Integer page, Integer size, String keySearch, Long view, String level, String status, Instant startDate, Instant endDate,String orgCode,String code) {
        super(page, size, keySearch);
        this.view = view;
        this.level = level;
        this.status = status;
        this.startDate = startDate;
        this.endDate = endDate;
        this.orgCode = orgCode;
        this.code= code;
    }
}
