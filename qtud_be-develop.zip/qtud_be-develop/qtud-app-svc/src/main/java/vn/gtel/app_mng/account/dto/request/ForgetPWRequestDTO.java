package vn.gtel.app_mng.account.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
public class ForgetPWRequestDTO {
    @NotEmpty(message = "error.common.validate.not.empty")
    private String account;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String name;
}
