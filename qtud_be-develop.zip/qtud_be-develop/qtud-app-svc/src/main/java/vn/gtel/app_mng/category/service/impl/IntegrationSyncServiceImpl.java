package vn.gtel.app_mng.category.service.impl;

import javassist.NotFoundException;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.owasp.encoder.Encode;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.category.dto.res.ApplicationItemResponseDTO;
import vn.gtel.app_mng.category.dto.res.OrganizationResponseDTO;
import vn.gtel.app_mng.category.model.Application;
import vn.gtel.app_mng.common.dto.AuditDTO;
import vn.gtel.app_mng.common.model.AuditModelBase;
import vn.gtel.common.constants.ActionCode;
import vn.gtel.common.dto.LogActionDTO;
import vn.gtel.common.service.LoggingService;
import vn.gtel.common.util.LogUtil;
import vn.gtel.common.util.StringUtils;
import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;
import vn.gtel.app_mng.category.dto.req.IntegrationSyncFilter;
import vn.gtel.app_mng.category.dto.req.IntegrationSyncRequestDto;
import vn.gtel.app_mng.category.dto.req.OrgGroupRoleRequestDto;
import vn.gtel.app_mng.category.dto.res.IntegrationSyncResponseDto;
import vn.gtel.app_mng.category.model.IntegrationSync;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.category.repo.*;
import vn.gtel.app_mng.category.service.IntegrationSyncService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.role.model.GroupRoleOrg;
import vn.gtel.app_mng.role.repository.GroupRoleOrgRepository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.xml.bind.ValidationException;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class IntegrationSyncServiceImpl implements IntegrationSyncService {
    private final IntegrationSyncRepo integrationSyncRepo;
    private final OrganizationRepo organizationRepo;
    private final ApplicationRepo applicationRepo;
    private final PositionCatRepo positionCatRepo;
    private final RankCatRepo rankCatRepo;
    private final ModelMapper modelMapper;
    private final TrimSpaceUtil trimSpaceUtil;
    private final EntityManager entityManager;
    private final GroupRoleOrgRepository groupRoleOrgRepository;
    private final GroupRoleOrgRepository getGroupRoleOrgRepository;
    private final LoggingService loggingService;

    @Override
    public ResponseBase search(IntegrationSyncFilter dto) {
        List<IntegrationSyncResponseDto> data = this.getData(dto);
        long total = this.getTotal(dto);
        return new ResponseBase(new ListResponse(data, total));
    }

    @Override
    public List<String> getOrgUnused() {
//        Pageable pageable = PageRequest.of(pageIndex, pageSize);
//        Page<OrganizationResponseDTO> page = organizationRepo.findUnusedInIntegrationSync(keySearch, pageable);
//        return new ResponseBase(new ListResponse(page.getContent(), page.getTotalElements()));
        List<String> codes = getGroupRoleOrgRepository.getListCodeOrgUsed();
        List<String> codeResults = new ArrayList<>();
        for (String str : codes) {
            codeResults.add(Encode.forHtml(str));
        }
        return codeResults;
    }

    @Override
    public ResponseBase getAppUnused(String keySearch, Integer pageIndex, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageIndex, pageSize);
        Page<AuditDTO> page = applicationRepo.findUnusedInIntegrationSync(keySearch, pageable);
        return new ResponseBase(new ListResponse(page.getContent(), page.getTotalElements()));
    }

    @Override
    public ResponseBase hasExists(String org, String app) {
        IntegrationSync integrationSync = integrationSyncRepo.getByOrgCodeOrAppCode(org, app);
        if (Objects.isNull(integrationSync)) {
            return new ResponseBase(false);
        }
        return new ResponseBase(!Constants.COMMON_STATUS.DELETED.equals(integrationSync.getStatus()));
    }

    @Override
    public ResponseBase detail(String id) throws Exception {
        IntegrationSync entity = integrationSyncRepo.findById(id)
                .orElseThrow(() -> new ValidationException("ValidationException.integration.sync.not.exists.id"));

        return new ResponseBase(modelMapper.map(entity, IntegrationSyncResponseDto.class));
    }

    @Override
    public ResponseBase save(IntegrationSyncRequestDto dto) throws Exception {
        trimSpaceUtil.validate(dto);
        this.validateDto(dto);

        String content = null;
        IntegrationSync entity;
        String action = null;
        boolean isUpdate = StringUtils.isNotEmpty(dto.getId());
        if (isUpdate) {
            action = ActionCode.EDIT;
            entity = integrationSyncRepo.findById(dto.getId())
                    .orElseThrow(() -> new ValidationException("ValidationException.integration.sync.not.exists.id"));
            content = String.format("Đã sửa đơn vị tích hợp tên là %s và mã là %s ,", entity.getOrgName(), entity.getOrgCode());
            String logMess = this.getDetailIntegrationSync(content, dto, entity);
            modelMapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());
            modelMapper.map(dto, entity);
            if (!logMess.equals(content)) {
                loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ROLE.
                        unitIntegrate, isUpdate ? ActionCode.EDIT : ActionCode.ADD, logMess, Instant.now()));
            }
        } else {
            action = ActionCode.ADD;
            entity = integrationSyncRepo.getByOrgCodeOrAppCode(dto.getOrgCode(), dto.getAppCode());
            String id = null;
            if (Objects.isNull(entity)) {
                entity = new IntegrationSync();
            } else {
                id = entity.getId();
            }
            modelMapper.map(dto, entity);
            entity.setId(id);
        }

        Organization organization = organizationRepo.findByCodeAndStatus(dto.getOrgCode(), Constants.COMMON_STATUS.ACTIVE);
        if (Objects.nonNull(organization)) {
            entity.setOrgName(organization.getFullName());
        }

        entity = integrationSyncRepo.save(entity);
        //Log

        if (action.equals(ActionCode.ADD)) {
            content = String.format("Đã thêm mới đơn vị tích hợp tên là %s và mã là %s", entity.getOrgName(), entity.getOrgCode());
        }
//        else if (action.equals(ActionCode.EDIT)) {
//            content = String.format("Đã sửa dơn vị tích hợp tên là %s và mã là %s", entity.getOrgName(), entity.getOrgCode());
//        }
        if (!action.equals(ActionCode.EDIT)) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ROLE.
                    unitIntegrate, isUpdate ? ActionCode.EDIT : ActionCode.ADD, content, Instant.now()));
        }
        return new ResponseBase(modelMapper.map(entity, IntegrationSyncResponseDto.class));
    }

    private String getDetailIntegrationSync(String logContent, IntegrationSyncRequestDto dto, IntegrationSync integrationSync) {
        if (dto == null || integrationSync == null) {
            return null;
        }

        StringBuilder logMessage = new StringBuilder();
        logMessage.append(logContent);
        LogUtil.compareAndLog(logMessage, "[Trạng thái] ", dto.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa", integrationSync.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa");
        LogUtil.compareAndLog(logMessage, "[Mục đích] ", dto.getPurpose(), integrationSync.getPurpose());
        LogUtil.compareAndLog(logMessage, "[Đầu mỗi kỹ thuật - Họ và tên] ", dto.getRelationName(), integrationSync.getRelationName());
        LogUtil.compareAndLog(logMessage, "[Đầu mỗi kỹ thuật - Số hiệu] ", dto.getRelationPoliceNumber(), integrationSync.getRelationPoliceNumber());
        LogUtil.compareAndLog(logMessage, "[Đầu mỗi kỹ thuật - Số điện thoại] ", dto.getRelationPhone(), integrationSync.getRelationPhone());
        LogUtil.compareAndLog(logMessage, "[Đầu mỗi kỹ thuật - Chức vụ] ", dto.getRelationPositionName(), integrationSync.getRelationPosition() == null ? "rỗng" : integrationSync.getRelationPosition().getName());
        LogUtil.compareAndLog(logMessage, "[Đầu mỗi kỹ thuật - Cấp bậc] ", dto.getRelationMilitaryName(), integrationSync.getRelationMilitary() == null ? "rỗng" : integrationSync.getRelationMilitary().getName());
        LogUtil.compareAndLog(logMessage, "[Người đại diện - Họ và tên] ", dto.getRepresentativeName(), integrationSync.getRepresentativeName());
        LogUtil.compareAndLog(logMessage, "[Người đại diện - Số hiệu] ", dto.getRepresentativePoliceNumber(), integrationSync.getRepresentativePoliceNumber());
        LogUtil.compareAndLog(logMessage, "[Người đại diện - Số điện thoại] ", dto.getRepresentativePhone(), integrationSync.getRepresentativePhone());
        LogUtil.compareAndLog(logMessage, "[Người đại diện - Chức vụ] ", dto.getRepresentativePositionName(), integrationSync.getRepresentativePosition() == null ? "rỗng" : integrationSync.getRepresentativePosition().getName());
        LogUtil.compareAndLog(logMessage, "[Người đại diện - Cấp bậc] ", dto.getRepresentativeMilitaryName(), integrationSync.getRepresentativePosition() == null ? "rỗng" : integrationSync.getRepresentativeMilitary().getName());
        LogUtil.compareAndLog(logMessage, "[Người đại diện - Mô tả] ", dto.getDescription(), integrationSync.getDescription());
        return logMessage.toString();
    }

    @Override
    public ResponseBase delete(String id) throws Exception {
        IntegrationSync entity = integrationSyncRepo.findById(id)
                .orElseThrow(() -> new ValidationException("ValidationException.integration.sync.not.exists.id"));

        if (groupRoleOrgRepository.existsByOrgAndStatusNot(entity.getOrgCode(), Constants.COMMON_STATUS.DELETED)) {
            throw new ValidationException("ValidationException.integration.sync.has.used.in.group.role");
        }

        entity.setStatus(Constants.COMMON_STATUS.DELETED);
        entity = integrationSyncRepo.save(entity);
        //Log
        String content = String.format(" Đã %s đơn vị tích hợp tên là %s và mã là %s", Constants.COMMON_STATUS.
                getNameByStatus(entity.getStatus()), entity.getOrgName(), entity.getOrgCode());
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ROLE.
                unitIntegrate, ActionCode.DEL, content, Instant.now()));
        return new ResponseBase(modelMapper.map(entity, IntegrationSyncResponseDto.class));
    }

    @Override
    public ResponseBase activeInActive(String id) throws Exception {
        IntegrationSync entity = integrationSyncRepo.findById(id)
                .orElseThrow(() -> new ValidationException("ValidationException.integration.sync.not.exists.id"));
        Integer status = entity.getStatus();
        if (Constants.COMMON_STATUS.ACTIVE.equals(status) ||
                Constants.COMMON_STATUS.INACTIVE.equals(status)) {
            entity.setStatus(CommonUtils.switchStatus(status));
            if (applicationRepo.existsByCodeAndStatusNot(entity.getAppCode(), Constants.APPLICATION_STATUS.ACTIVE)) {
                throw new ValidationException("ValidationException.integration.sync.app.status.not.active");
            }
            if (organizationRepo.existsByCodeAndStatusNot(entity.getOrgCode(), Constants.ORGANIZATION_STATUS.ACTIVE)) {
                throw new ValidationException("ValidationException.integration.sync.org.status.not.active");
            }
            entity = integrationSyncRepo.save(entity);

            //Log
//            String content = String.format("%s đơn vị tích hợp tên %s và mã %s", Constants.COMMON_STATUS.
//                    getNameByStatus(entity.getStatus()), entity.getOrgName(), entity.getOrgCode());
            String content = String.format("Đã %s đơn vị tích hợp tên %s và mã %s", Constants.GROUP_ROLE_STATUS.ACTIVE.equals(entity.getStatus()) ? "kích hoạt" : "vô hiệu hóa", entity.getOrgName(), entity.getOrgCode());
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ROLE.
                    unitIntegrate, ActionCode.ACTIVE, content, Instant.now()));
            return new ResponseBase(modelMapper.map(entity, IntegrationSyncResponseDto.class));
        }
        return new ResponseBase("ValidationException.integration.sync.nothing.changes");
    }

    private void validateDto(@NonNull IntegrationSyncRequestDto dto) throws ValidationException {
        IntegrationSync integrationSync = integrationSyncRepo.getByOrgCodeOrAppCodeAndStatusNot(dto.getOrgCode(), dto.getAppCode(), Constants.DELETED);
        if (Objects.nonNull(integrationSync) &&
                !Objects.equals(integrationSync.getId(), dto.getId()) &&
                !Constants.COMMON_STATUS.DELETED.equals(integrationSync.getStatus())) {
            throw new ValidationException("ValidationException.integration.sync.exists");
        }

        if (!applicationRepo.existsByCodeAndStatus(dto.getAppCode(), Constants.COMMON_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.integration.sync.not.exists.app");
        }

//        if (!positionCatRepo.existsByCodeAndStatus(dto.getRelationPositionCode(), Constants.COMMON_STATUS.ACTIVE)) {
//            throw new ValidationException("ValidationException.integration.sync.not.exists.relation.position");
//        }
//
//        if (!positionCatRepo.existsByCodeAndStatus(dto.getRepresentativePositionCode(), Constants.COMMON_STATUS.ACTIVE)) {
//            throw new ValidationException("ValidationException.integration.sync.not.exists.representative.position");
//        }

        if (dto.getRelationMilitaryCode() != null &&
                !rankCatRepo.existsByCodeAndStatus(dto.getRelationMilitaryCode(), Constants.COMMON_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.integration.sync.not.exists.relation.military.code");
        }

        if (dto.getRepresentativeMilitaryCode() != null &&
                !rankCatRepo.existsByCodeAndStatus(dto.getRepresentativeMilitaryCode(), Constants.COMMON_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.integration.sync.not.exists.representative.military.code");
        }
    }

    private List<IntegrationSyncResponseDto> getData(IntegrationSyncFilter dto) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<IntegrationSyncResponseDto> criteriaQuery = criteriaBuilder.createQuery(IntegrationSyncResponseDto.class);
        Root<IntegrationSync> root = criteriaQuery.from(IntegrationSync.class);
        Join<IntegrationSync, Application> applicationJoin = root.join(IntegrationSync.Fields.app);
        Join<IntegrationSync, Organization> organizationJoin = root.join(IntegrationSync.Fields.org);
        Predicate predicate = buildPredicate(dto, criteriaBuilder, root, applicationJoin, organizationJoin);
        criteriaQuery.select(criteriaBuilder.construct(IntegrationSyncResponseDto.class, root));
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get(IntegrationSync.Fields.orgName)));
        criteriaQuery.where(predicate);
        TypedQuery<IntegrationSyncResponseDto> dataQuery = entityManager.createQuery(criteriaQuery);
        dataQuery.setFirstResult(dto.getPage() * dto.getSize());
        dataQuery.setMaxResults(dto.getSize());

        return dataQuery.getResultList();
    }

    private long getTotal(IntegrationSyncFilter dto) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> criteriaCountQuery = criteriaBuilder.createQuery(Long.class);
        Root<IntegrationSync> countRoot = criteriaCountQuery.from(IntegrationSync.class);
        Join<IntegrationSync, Application> applicationJoin = countRoot.join(IntegrationSync.Fields.app);
        Join<IntegrationSync, Organization> organizationJoin = countRoot.join(IntegrationSync.Fields.org);
        criteriaCountQuery.select(criteriaBuilder.count(countRoot));
        Predicate countPredicate = buildPredicate(dto, criteriaBuilder, countRoot, applicationJoin, organizationJoin);
        criteriaCountQuery.where(countPredicate);
        TypedQuery<Long> countQuery = entityManager.createQuery(criteriaCountQuery);
        return countQuery.getSingleResult();
    }

    private Predicate buildPredicate(IntegrationSyncFilter dto, CriteriaBuilder criteriaBuilder, Root<IntegrationSync> root,
                                     Join<IntegrationSync, Application> applicationJoin, Join<IntegrationSync, Organization> organizationJoin) {
        List<Predicate> predicates = new ArrayList<>();
        String keySearch = dto.getLikeKeySearch();
        if (StringUtils.isNotEmpty(keySearch)) {
            Predicate predicate = criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.orgCode)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.orgName)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.appName)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.appCode)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.representativeName)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.function("sf_vn2en", String.class, root.get(IntegrationSync.Fields.representativeName)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.relationName)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.function("sf_vn2en", String.class, root.get(IntegrationSync.Fields.relationName)), keySearch),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.purpose)), keySearch)
            );
            predicates.add(predicate);
        }

        String application = dto.getApplication();
        if (StringUtils.isNotEmpty(application)) {
            predicates.add(criteriaBuilder.equal(root.get(IntegrationSync.Fields.appCode), application));
        }

        String organization = dto.getOrganization();
        if (StringUtils.isNotEmpty(organization)) {
            predicates.add(criteriaBuilder.equal(root.get(IntegrationSync.Fields.orgCode), organization));
        }

        String organizationName = dto.getOrganizationName();
        if (StringUtils.isNotEmpty(organizationName)) {
            organizationName = CommonUtils.likeString(CommonUtils.toUpperCase(organizationName));
            Predicate predicate = criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.function("sf_vn2en", String.class, root.get(IntegrationSync.Fields.orgName)), organizationName),
                    criteriaBuilder.like(criteriaBuilder.upper(root.get(IntegrationSync.Fields.orgName)), organizationName)
            );
            predicates.add(predicate);
        }

        Integer status = dto.getStatus();

        if (dto.getFromDate() != null) {
            predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get(AuditModelBase.Fields.createdDate), dto.getFromDate()));
        }

        if (dto.getToDate() != null) {
            predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get(AuditModelBase.Fields.createdDate), dto.getToDate()));
        }

        if (status != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuditModelBase.Fields.status), status));
        } else {
            predicates.add(criteriaBuilder.notEqual(root.get(AuditModelBase.Fields.status), Constants.COMMON_STATUS.DELETED));
        }

        if (dto.getNotCodeList() != null && !dto.getNotCodeList().isEmpty()) {
            predicates.add(criteriaBuilder.and(root.get(IntegrationSync.Fields.orgCode).as(String.class).in(dto.getNotCodeList()).not()));
        }

        if (dto.getInCodeList() != null && !dto.getInCodeList().isEmpty()) {
            predicates.add(criteriaBuilder.and(root.get(IntegrationSync.Fields.orgCode).as(String.class).in(dto.getInCodeList())));
        }
        if (dto.getApplicationType() != null) {
            predicates.add(criteriaBuilder.equal(applicationJoin.get(Application.Fields.type), dto.getApplicationType()));
        }
        if (dto.getOrganizationType() != null && dto.getOrganizationType() == 2) {
            predicates.add(criteriaBuilder.equal(organizationJoin.get(Organization.Fields.orgType), 3));
        } else if (dto.getOrganizationType() != null && dto.getOrganizationType() == 1) {
            predicates.add(criteriaBuilder.or(criteriaBuilder.equal(organizationJoin.get(Organization.Fields.orgType), 1), criteriaBuilder.equal(organizationJoin.get(Organization.Fields.orgType), 2)));
        }
        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    @Override
    public ResponseBase saveRole(String id, OrgGroupRoleRequestDto orgGroupRoleRequestDto) throws NotFoundException {
        IntegrationSync integrationSync = integrationSyncRepo.findById(id).orElseThrow(() -> new NotFoundException("ValidationException.integration.sync.not.exists.id"));

        List<GroupRoleOrg> data = mapGroupRoleOrg(orgGroupRoleRequestDto.getGroupRoles(), integrationSync.getOrgCode());
        groupRoleOrgRepository.saveAll(data);
        String content = "";
        List<String> listInsert = new ArrayList<>();
        List<String> listRemove = new ArrayList<>();
        if (data != null && data.size() > 0) {
            for (GroupRoleOrg item : data) {
                if (item != null && item.getStatus() == Constants.COMMON_STATUS.ACTIVE) {
                    listInsert.add(item.getGroupRole());
                } else if (item != null && item.getStatus() == Constants.COMMON_STATUS.DELETED) {
                    listRemove.add(item.getGroupRole());
                }
            }
        }
        if (listInsert.size() > 0) {
            content += String.format("Gán quyền đơn vị tích hợp [%s].", String.join(",", listInsert));
        }
        if (listRemove.size() > 0) {
            content += String.format(" Gỡ quyền đơn vị tích hợp [%s].", String.join(",", listRemove));
        }
        if (!"".equals(content)) {
            content += String.format(" Đơn vị mã %s và tên %s.", integrationSync.getOrgCode(), integrationSync.getOrgName());
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ROLE.
                    unitIntegrate, ActionCode.EDIT, content, Instant.now()));
        }

        return new ResponseBase();
    }

    private List<GroupRoleOrg> mapGroupRoleOrg(List<CodeItemWithActionDTO> groupRoles, String orgCode) {
        // insert
        List<CodeItemWithActionDTO> insertList = insertItems(groupRoles);
        List<GroupRoleOrg> groupRoleOrgs = groupRoleOrgRepository.findByOrg(orgCode);
        // insert new / restore delete
        Stream<GroupRoleOrg> insertNewOrRestoreDelete = insertList.stream().map(e -> new GroupRoleOrg(groupRoleOrgs, e, orgCode));
        // merge delete + insert
        return Stream.concat(skipItems(groupRoles).stream().filter(e -> e.getAction() == Constants.COMMON_ACTION.DELETE).map(e ->
                new GroupRoleOrg(groupRoleOrgs, e, orgCode)), insertNewOrRestoreDelete).collect(Collectors.toList());
    }

    private List<CodeItemWithActionDTO> insertItems(List<CodeItemWithActionDTO> codeItems) {
        return codeItems.stream().filter(e -> Constants.COMMON_ACTION.INSERT == e.getAction()).collect(Collectors.toList());
    }

    // Skip update, delete not id
    private List<CodeItemWithActionDTO> skipItems(List<CodeItemWithActionDTO> codeItems) {
        return codeItems.stream().filter(e -> List.of(Constants.COMMON_ACTION.INSERT, Constants.COMMON_ACTION.DELETE).contains(e.getAction())
                && !(e.getAction() == Constants.COMMON_ACTION.DELETE && StringUtils.isEmpty(e.getId()))).collect(Collectors.toList());
    }

    @Override
    public ResponseBase getListOrgCode() {
        List<String> orgCodeList = integrationSyncRepo.getOrgCode();
        orgCodeList.add(Constants.ORG_CODE.C08);
        return new ResponseBase(orgCodeList);
    }

    @Override
    public ResponseBase getApplicationByOrganization(String orgCode) {
        IntegrationSync integrationSync = integrationSyncRepo.getByOrgCode(orgCode).orElse(null);
        if (integrationSync != null) {
            ApplicationItemResponseDTO dto = new ApplicationItemResponseDTO();
            dto.setCode(integrationSync.getAppCode());
            dto.setName(integrationSync.getAppName());

            return new ResponseBase(dto);
        }
        return new ResponseBase(null);
    }

}
