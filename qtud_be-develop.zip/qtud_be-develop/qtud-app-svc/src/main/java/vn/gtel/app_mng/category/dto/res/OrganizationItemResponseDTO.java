package vn.gtel.app_mng.category.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.response.AuditItemResponse;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationItemResponseDTO extends AuditItemResponse {

    @Basic
    @Column(name = "MA")
    private String code;

    @Basic
    @Column(name = "ID_DON_VI_CHA")
    private String organizationId;

    @Basic
    @Column(name = "TEN_DON_VI_CHA")
    private String organizationParentName;

    @Basic
    @Column(name = "TEN")
    private String name;

    @Basic
    @Column(name = "NOI_DUNG")
    private String content;

    @Basic
    @Column(name = "KY_HIEU")
    private String symbol;

    @Basic
    @Column(name = "CUM")
    private String cluster;

    @Basic
    @Column(name = "ID_NHOM_DON_VI")
    private String organizationGroupId;

    @Basic
    @Column(name = "TEN_NHOM_DON_VI")
    private String organizationNameId;

    @Basic
    @Column(name = "ID_LOAI_DON_VI")
    private String organizationTypeId;

    @Basic
    @Column(name = "TEN_LOAI_DON_VI")
    private String organizationTypeName;

    @Basic
    @Column(name = "ID_CAP_DON_VI")
    private String organizationLevelId;

    @Basic
    @Column(name = "TEN_CAP_DON_VI")
    private String organizationLevelName;
    @Basic
    @Column(name = "ID_HE_LUC_LUONG")
    private String cardinalityId;
    @Basic
    @Column(name = "TEN_HE_LUC_LUONG")
    private String cardinalityName;
    @Basic
    @Column(name = "DIA_CHI")
    private String address;
    @Basic
    @Column(name = "ID_PHUONG_XA")
    private String villageId;

    @Basic
    @Column(name = "TEN_PHUONG_XA")
    private String villageName;
    @Basic
    @Column(name = "ID_QUAN_HUYEN")
    private String districtId;
    @Basic
    @Column(name = "TEN_QUAN_HUYEN")
    private String districtName;

    @Basic
    @Column(name = "ID_TINH_TP")
    private String countryId;


    @Basic
    @Column(name = "TEN_TINH_TP")
    private String countryName;
    @Basic
    @Column(name = "ID_VUNG")
    private String areaId;
    @Basic
    @Column(name = "TEN_VUNG")
    private String areaName;

    @Basic
    @Column(name = "ID_MIEN")
    private String regionId;
    @Basic
    @Column(name = "TEN_MIEN")
    private String regionName;
    @Basic
    @Column(name = "THONG_KE")
    private Long statistic;
    @Basic
    @Column(name = "NGAY_THANH_LAP")
    private Date establish;
    @Basic
    @Column(name = "MA_DON_VI")
    private String organizationCode;
    @Basic
    @Column(name = "ID_DON_VI_TREN")
    private String organizationTopId;
    @Basic
    @Column(name = "ID_DON_VI_CU")
    private String organizationOldId;
    @Basic
    @Column(name = "ID_CUM")
    private String clusterId;
    @Basic
    @Column(name = "ISLAST")
    private String islast;

    @Basic
    @Column(name = "THU_TU")
    private Long order;
}
