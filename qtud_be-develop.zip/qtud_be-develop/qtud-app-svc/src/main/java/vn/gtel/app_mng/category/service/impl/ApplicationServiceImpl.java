
/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  ApplicationServiceImpl.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/7/21, 10:43 AM
 */

package vn.gtel.app_mng.category.service.impl;

import com.google.gson.Gson;
import javassist.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.category.dto.req.ApplicationFilter;
import vn.gtel.app_mng.category.dto.req.TypeFilter;
import vn.gtel.app_mng.category.model.AuditCategoryModel;
import vn.gtel.app_mng.category.model.IntegrationSync;
import vn.gtel.app_mng.category.repo.IntegrationSyncRepo;
import vn.gtel.app_mng.common.dto.response.ListResponse;
import vn.gtel.app_mng.common.model.AuditModelBase;
import vn.gtel.app_mng.role.model.GroupRole;
import vn.gtel.app_mng.role.model.GroupRoleApplication;
import vn.gtel.app_mng.role.repository.GroupRoleApplicationRepository;
import vn.gtel.app_mng.role.repository.GroupRoleRepository;
import vn.gtel.common.constants.ActionCode;
import vn.gtel.common.dto.LogActionDTO;
import vn.gtel.common.service.LoggingService;
import vn.gtel.app_mng.category.dto.excelObj.ApplicationExcelItemObj;
import vn.gtel.app_mng.category.dto.excelObj.ApplicationExcelObj;
import vn.gtel.app_mng.category.dto.req.ApplicationRequestCodeDTO;
import vn.gtel.app_mng.category.dto.req.ChangeSecretReqDTO;
import vn.gtel.app_mng.category.dto.res.ApplicationItemResponseDTO;
import vn.gtel.app_mng.category.dto.storedObj.ApplicationCallStoredDTO;
import vn.gtel.app_mng.category.model.Application;
import vn.gtel.app_mng.category.repo.ApplicationRepo;
import vn.gtel.app_mng.category.service.ApplicationService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;
import vn.gtel.app_mng.common.dto.response.DetailResponse;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.ExcelObjectMapper;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
//import vn.gtel.app_mng.system.model.File;
import vn.gtel.app_mng.system.repository.FileRepository;
import vn.gtel.common.util.LogUtil;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.xml.bind.ValidationException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

@Slf4j
@Service
public class ApplicationServiceImpl implements ApplicationService {

    @Autowired
    private ApplicationRepo applicationRepo;
    @Autowired
    private GroupRoleApplicationRepository groupRoleApplicationRepo;
    @Autowired
    private GroupRoleApplicationRepository groupRoleApplicationRepository;
    @Autowired
    private GroupRoleRepository groupRoleRepository;
    @Autowired
    private IntegrationSyncRepo integrationSyncRepo;
    @Autowired
    private CallStoredRepository callStoredRepository;
    @Autowired
    private FileRepository fileRepository;
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private TrimSpaceUtil trimSpaceUtil;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private LoggingService loggingService;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private AccountRepository accountRepository;

    //    private static final String DEFAULT_GRANT_TYPE = "authorization_code,password,refresh_token,client_credentials";
    private static final String DEFAULT_GRANT_TYPE = "password,refresh_token,client_credentials";

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");

    private static final String PREFIX_ERR_CONSTRAINT_MESSAGE = "ConstraintViolationException.";

    @Override
    public ResponseBase list(TypeFilter typeFilter, Integer status) throws IllegalAccessException {
        trimSpaceUtil.validate(typeFilter);
        ICallStoredObj callStoredObj = new ApplicationCallStoredDTO(typeFilter, status);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase detail(String id) throws Exception {
        ICallStoredObj callStoredObj = new ApplicationCallStoredDTO(id);
        Object res = callStoredRepository.findById(callStoredObj);
        ApplicationItemResponseDTO responseDTO = (ApplicationItemResponseDTO) res;
//        List<File> files = fileRepository.findByRelativeCodeAndTable(responseDTO.getCode(), Constants.TBL_NAME.APPLICATION);
//        if (CollectionUtils.isNotEmpty(files)) {
//            responseDTO.setFile(Base64.getEncoder().encodeToString(files.get(0).getContent()));
//            responseDTO.setFileName(files.get(0).getFileName());
//        }

        return new ResponseBase(new DetailResponse(responseDTO));
    }

    @CacheEvict(value = "clientDetail", key = "#applicationRequestDTO.code")
    @Override
    public ResponseBase save(ApplicationRequestCodeDTO applicationRequestDTO) throws Exception {
        trimSpaceUtil.validate(applicationRequestDTO);
        if (StringUtils.isNotEmpty(applicationRequestDTO.getParentCode())) {
            Application applicationParent = applicationRepo.findByCodeAndStatus(applicationRequestDTO.getParentCode(), Constants.APPLICATION_STATUS.ACTIVE);
            if (applicationParent == null) {
                throw new NotFoundException(String.format("Không tồn tại mã cha %s !", applicationRequestDTO.getParentCode()));
            }
            if (applicationRequestDTO.getUrl() != null && applicationRepo.existsByUrl(applicationRequestDTO.getUrl())) {
                throw new ValidationException("ValidationException.error.exists.url");
            }
        }
        boolean isUpdate = false;
        String content = null;
        Application application;
        String action;
        String oldValue;
        if (StringUtils.isNotEmpty(applicationRequestDTO.getId())) {
            isUpdate = true;
        }

        List<Application> applicationsChilds = new ArrayList<>();

        if (isUpdate) {
            action = ActionCode.EDIT;
            application = applicationRepo.findById(applicationRequestDTO.getId()).orElse(new Application());
            if (application.getNotEdit() != null && application.getNotEdit() == Constants.BOOLEAN.TRUE) {
                throw new ValidationException("ValidationException.error.not.edit");
            }
            oldValue = new Gson().toJson(application);
            String updatePassword = null;
            if (StringUtils.isNotEmpty(applicationRequestDTO.getClientSecret()) && StringUtils.isNotEmpty(application.getClientSecret())) {
                if (!applicationRequestDTO.getClientSecret().equals(application.getClientSecret())) {
                    if (!new BCryptPasswordEncoder().matches(applicationRequestDTO.getClientSecret(), application.getClientSecret())) {
                        updatePassword = new BCryptPasswordEncoder().encode(applicationRequestDTO.getClientSecret());
                    }
                }
            }
            mapper.getConfiguration().setSkipNullEnabled(true);
            if (StringUtils.isNotEmpty(updatePassword)) {
                applicationRequestDTO.setClientSecret(updatePassword);
            } else {
                applicationRequestDTO.setClientSecret(application.getClientSecret());
            }
            applicationsChilds = applicationRepo.findByParentCode(applicationRequestDTO.getCode());
            if (applicationsChilds != null && applicationsChilds.size() > 0) {
                for (Application applicationChild : applicationsChilds) {
                    applicationChild.setType(applicationRequestDTO.getType());
                }
            }
            content = String.format("Đã sửa phần mềm có mã là %s ", application.getCode());
            String logMess = this.getDetailApplication(content, applicationRequestDTO, application);
            mapper.map(applicationRequestDTO, application);
            if (!logMess.equals(content)) {
                loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                        Constants.MENU_CODE.CATEGORY.app, action, logMess, Instant.now()));
            }
            this.clearCacheApps();
        } else {
            action = ActionCode.ADD;
            oldValue = null;
            application = mapper.map(applicationRequestDTO, Application.class);
            if (StringUtils.isEmpty(application.getGrantType())) {
                application.setGrantType(DEFAULT_GRANT_TYPE);
                application.setNotEdit(applicationRequestDTO.getNotEdit());
            }
            application.setClientSecret(new BCryptPasswordEncoder().encode(application.getClientSecret()));
        }
        applicationRepo.save(application);
        if (applicationsChilds != null && applicationsChilds.size() > 0) {
            applicationRepo.saveAll(applicationsChilds);
        }

//        applicationRequestDTO.setId(application.getId());
//        saveIcon(applicationRequestDTO);

        if (action.equals(ActionCode.ADD)) {
            content = String.format("Đã thêm mới phần mềm có tên là %s và mã là %s", application.getName(), application.getCode());
        }
//        else if (action.equals(ActionCode.EDIT)) {
//            content = String.format("Đã sửa phần mềm có tên là %s và mã là %s", application.getName(), application.getCode());
//        }
        if (!action.equals(ActionCode.EDIT)) {
            loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                    Constants.MENU_CODE.CATEGORY.app, action, content, Instant.now()));
        }
        return new ResponseBase(new DetailResponse(application));
    }

    private String getDetailApplication(String logContent, ApplicationRequestCodeDTO applicationRequestDTO, Application application) {
        if (applicationRequestDTO == null || application == null) {
            return null;
        }

        StringBuilder logMessage = new StringBuilder();
        logMessage.append(logContent);
        LogUtil.compareAndLog(logMessage, "[Tên phần mềm] ", applicationRequestDTO.getName(), application.getName());
        LogUtil.compareAndLog(logMessage, "[Loại phần mềm] ", applicationRequestDTO.getType() == 1 ? "Trong hệ thống" : "Ngoài hệ thống", application.getType() == 1 ? "Trong hệ thống" : "Ngoài hệ thống");
        LogUtil.compareAndLog(logMessage, "[Đường dẫn ảnh] ", applicationRequestDTO.getLogo(), application.getLogo());
        LogUtil.compareAndLog(logMessage, "[Đường dẫn] ", applicationRequestDTO.getUrl(), application.getUrl());
        LogUtil.compareAndLog(logMessage, "[Kiểu ứng dụng] ", applicationRequestDTO.getIsWebsite(), application.getIsWebsite());
        LogUtil.compareAndLog(logMessage, "[Hạn token] ", applicationRequestDTO.getAccessTokenValidity(), application.getAccessTokenValidity());
        LogUtil.compareAndLog(logMessage, "[Hạn refresh token] ", applicationRequestDTO.getRefreshTokenValidity(), application.getRefreshTokenValidity());
        LogUtil.compareAndLog(logMessage, "[Thứ tự] ", applicationRequestDTO.getOrder(), application.getOrder());
        LogUtil.compareAndLog(logMessage, "[Trạng thái] ", applicationRequestDTO.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa", application.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa");
        LogUtil.compareAndLog(logMessage, "[Mô tả] ", applicationRequestDTO.getDescription(), application.getDescription());
        return logMessage.toString();
    }

    private void clearCacheApps() {
        List<Account> accounts = accountRepository.findAll();
        if (accounts != null && accounts.size() > 0) {
            for (Account entity : accounts) {
                redisTemplate.opsForValue().set(Constants.REDIS_KEY.ROLE_APP + entity.getAccount(), null);
//                redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + entity.getAccount());
            }
        }
    }

    private void saveIcon(ApplicationRequestCodeDTO applicationRequestDTO) throws Exception {
        trimSpaceUtil.validate(applicationRequestDTO);
        if (StringUtils.isEmpty(applicationRequestDTO.getFile())) {
            return;
        }
//        if (applicationRequestDTO.getId() == null) {
//            fileRepository.save(newInstanceFromBase64(applicationRequestDTO.getFile(), applicationRequestDTO.getFileName(), applicationRequestDTO.getCode(), Constants.TBL_NAME.APPLICATION));
//        } else {
//            // Update application
//            Application application = applicationRepo.findById(applicationRequestDTO.getId()).orElse(new Application());
//            if (application.getId() != null) {
//                List<File> files = fileRepository.findByRelativeCodeAndTable(application.getCode(), Constants.TBL_NAME.APPLICATION);
//                if (CollectionUtils.isEmpty(files)) {
//                    fileRepository.save(newInstanceFromBase64(applicationRequestDTO.getFile(), applicationRequestDTO.getFileName(), application.getCode(), Constants.TBL_NAME.APPLICATION));
//                } else {
//                    File file = files.get(0);
//                    file.setContent(Base64.getDecoder().decode(applicationRequestDTO.getFile()));
//                    file.setFileName(applicationRequestDTO.getFileName());
//                    fileRepository.save(file);
//                }
//            }
//        }
    }

//    private File newInstanceFromBase64(String base64Str, String fileType, String appCode, String appTblName) throws Exception {
//        File file = new File(Base64.getDecoder().decode(base64Str), fileType, appCode, appTblName);
//        file.setStatus(Constants.FILE_STATUS.ACTIVE);
//        return file;
//    }

    @Override
    public ResponseBase delete(String id) throws Exception {
        Application application = applicationRepo.findById(id).orElseThrow(() ->
                new NotFoundException("ValidationException.error.not.found"));
//        String oldValue = new Gson().toJson(application);
        if (application.getNotEdit() != null && application.getNotEdit() == Constants.BOOLEAN.TRUE) {
            throw new ValidationException("ValidationException.error.not.delete");
        }
        if (applicationRepo.existsApplicationByParentCodeAndStatus(application.getCode(), Constants.APPLICATION_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.error.not.delete.child");
        }
        if (groupRoleApplicationRepo.existsByApplicationAndStatus(application.getCode(), Constants.APPLICATION_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.error.not.delete.role");
        }
        if (integrationSyncRepo.existsByAppCodeAndStatus(application.getCode(), Constants.APPLICATION_STATUS.ACTIVE)) {
            throw new ValidationException("ValidationException.error.not.delete.integration.sync");
        }
        application.setStatus(Constants.APPLICATION_STATUS.DELETED);
        List<GroupRoleApplication> groupRoleApplications = groupRoleApplicationRepository.getByApplication(application.getCode());
        if (!groupRoleApplications.isEmpty() && groupRoleApplications.size() > 0) {
            for (GroupRoleApplication entity : groupRoleApplications) {
                entity.setStatus(Constants.COMMON_STATUS.DELETED);
                GroupRole groupRole = groupRoleRepository.findByCode(entity.getGroupRole());
                if (groupRole.getStatus() != Constants.COMMON_STATUS.DELETED) {
                    groupRole.setStatus(Constants.COMMON_STATUS.DELETED);
                }
            }
        }

        IntegrationSync integrationSync = integrationSyncRepo.findByAppCode(application.getCode());
        if (integrationSync != null) {
            integrationSync.setStatus(Constants.COMMON_STATUS.DELETED);
        }

//        List<File> files = fileRepository.findByRelativeCodeAndTable(application.getCode(), Constants.TBL_NAME.APPLICATION);
//        if (CollectionUtils.isNotEmpty(files)) {
//            File file = files.get(0);
//            file.setStatus(Constants.APPLICATION_STATUS.DELETED);
//            fileRepository.save(file);
//        }

//        String newValue = new Gson().toJson(application);
//        ActionLogDTO actionLogDTO = new ActionLogDTO(Constants.MODULES.APPLICATION, Constants.ACTION.DELETE, oldValue, newValue);
//        actionLogService.saveActionLog(actionLogDTO);
        String content = String.format("Đã xóa phần mềm có tên là %s và mã là %s", application.getName(), application.getCode());
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.app, ActionCode.DEL, content, Instant.now()));
        this.clearCacheApps();
        return new ResponseBase(new DetailResponse(applicationRepo.save(application)));
    }

    @Override
    public ResponseEntity importExcel(MultipartFile file) throws Exception {
        int sheetAt = 0;
        int firstRow = 4;
        ExcelObjectMapper excelObjectMapper = new ExcelObjectMapper(file);
        IExcelMapperObj iExcelMapperObj = new ApplicationExcelObj(0);
        List<ApplicationExcelItemObj> list = excelObjectMapper.map(ApplicationExcelItemObj.class, sheetAt, iExcelMapperObj, firstRow);
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                Constants.MENU_CODE.CATEGORY.app, ActionCode.UPLOAD, null, Instant.now()));
        return saveDataExcel(excelObjectMapper, sheetAt, firstRow, list);
    }

    @Override
    public ResponseBase setActiveDeActive(String id) throws Exception {
        Application application = applicationRepo.findById(id).orElseThrow(() ->
                new NotFoundException("ValidationException.error.not.found"));
        if (Constants.APPLICATION_STATUS.INACTIVE.equals(application.getStatus()) || Constants.APPLICATION_STATUS.ACTIVE.equals(application.getStatus())) {
            Integer tobeUpdateStatus = null;
            if (Constants.APPLICATION_STATUS.INACTIVE.equals(application.getStatus())) {
                if (applicationRepo.existsByCodeAndStatus(application.getParentCode(), Constants.APPLICATION_STATUS.INACTIVE)) {
                    throw new ValidationException("ValidationException.error.exists.app.not.parent");
                }
                tobeUpdateStatus = Constants.APPLICATION_STATUS.ACTIVE;
                application.setStatus(tobeUpdateStatus);
                String content = String.format("Đã %s phần mềm tên %s và mã %s", Constants.COMMON_STATUS.
                        getNameByStatus(application.getStatus()), application.getName(), application.getCode());
                loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                        Constants.MENU_CODE.CATEGORY.app, ActionCode.ACTIVE, content, Instant.now()));
            } else if (Constants.APPLICATION_STATUS.ACTIVE.equals(application.getStatus())) {
                if (applicationRepo.existsByParentCodeAndStatus(application.getCode(), Constants.APPLICATION_STATUS.ACTIVE)) {
                    throw new ValidationException("ValidationException.error.exists.app.parent");
                }
                tobeUpdateStatus = Constants.APPLICATION_STATUS.INACTIVE;
                application.setStatus(tobeUpdateStatus);
                String content = String.format("Đã %s phần mềm có tên là %s và mã là %s", Constants.COMMON_STATUS.
                        getNameByStatus(application.getStatus()), application.getName(), application.getCode());
                loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD,
                        Constants.MENU_CODE.CATEGORY.app, ActionCode.INACTIVE, content, Instant.now()));
            }
            this.clearCacheApps();
            return new ResponseBase(new DetailResponse(applicationRepo.save(application)));
        } else return new ResponseBase("Do not anything!");

    }


    public ResponseEntity saveDataExcel(ExcelObjectMapper excelObjectMapper, int sheetAt, int firstRow, List<ApplicationExcelItemObj> list) throws Exception {
        List<Application> applications = new ArrayList<>();
        Map<Integer, String> errMap = new HashMap<>();
        for (ApplicationExcelItemObj applicationExcelItemObj : list) {
            if (!isEmptyObj(applicationExcelItemObj)) {
                String messageError = "";
                int flag = 0;
                if (StringUtils.isEmpty(applicationExcelItemObj.getCode())) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.code");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorCodeActionMsg(applicationExcelItemObj.getCode());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(applicationExcelItemObj.getName())) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.name");
                    flag++;
                } else {
                    String messageError1 = CommonUtils.errorActionNameMsg(applicationExcelItemObj.getName());
                    messageError += messageError1;
                    if (!messageError1.equalsIgnoreCase("")) {
                        flag++;
                    }
                }

                if (StringUtils.isEmpty(applicationExcelItemObj.getClientSecret())) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.client.secret");
                    flag++;
                } else {
                    if (!CommonUtils.isValidMaxLength(applicationExcelItemObj.getClientSecret(), Constants.VALID.MAX_LENGTH_NAME_250)) {
                        messageError += Messages.getString("error.common.validate.max.size.250");
                        flag++;
                    }
                }
                if (StringUtils.isEmpty(applicationExcelItemObj.getGrantType())) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.grant.type");
                    flag++;
                } else {
                    if (!CommonUtils.isValidMaxLength(applicationExcelItemObj.getGrantType(), Constants.VALID.MAX_LENGTH_NAME_250)) {
                        messageError += Messages.getString("error.common.validate.max.size.250");
                        flag++;
                    }
                }
                if (Objects.isNull(applicationExcelItemObj.getAccessTokenValidity()) || applicationExcelItemObj.getAccessTokenValidity() == 0) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.access.token.validity");
                    flag++;
                }
                if (Objects.isNull(applicationExcelItemObj.getRefreshTokenValidity()) || applicationExcelItemObj.getRefreshTokenValidity() == 0) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.refresh.token.validity");
                    flag++;
                }
                if (applicationExcelItemObj.getOrder() == 0) {
                    messageError += Messages.getString("ValidationException.error.not.null.application.order");
                    flag++;
                }
                if (!StringUtils.isEmpty(applicationExcelItemObj.getParentCode())) {
                    Application application = applicationRepo.findByCode(applicationExcelItemObj.getParentCode());
                    if (application == null) {
                        messageError += Messages.getString("ValidationException.error.not.existed.application.code");
                        flag++;
                    }
                }
                Application application = mapper.map(applicationExcelItemObj, Application.class);
                application.setStatus(Constants.APPLICATION_STATUS.ACTIVE);
                if (StringUtils.isNotEmpty(application.getClientSecret())) {
                    application.setClientSecret(new BCryptPasswordEncoder().encode(application.getClientSecret()));
                }
                Application existApplication = applicationRepo.findByCodeAndName(application.getCode(), application.getName()).orElse(null);
//                if (existApplication != null && flag == 0) {
//                    mapper.getConfiguration().setSkipNullEnabled(true);
//                    mapper.map(application, existApplication);
//                    try {
//                        applicationRepo.save(existApplication);
//                    } catch (Exception ex) {
//                        if (ex instanceof DataIntegrityViolationException) {
//                            if (ex.getCause() instanceof ConstraintViolationException) {
//                                messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
//                                ;
//                            }
//                        }
//                    }
//
//                } else {
                Application applicationByCode = applicationRepo.findByCode(application.getCode());
                if (applicationByCode != null) {
                    messageError += Messages.getString("ValidationException.error.existed.application.code");
                    flag++;
                }
                if (flag == 0) {
                    applications.add(application);
                    try {
                        applicationRepo.save(application);
                    } catch (Exception ex) {
                        if (ex instanceof DataIntegrityViolationException) {
                            if (ex.getCause() instanceof ConstraintViolationException) {
                                messageError = String.format("%s ; %s", messageError, Messages.getString(PREFIX_ERR_CONSTRAINT_MESSAGE + ((ConstraintViolationException) ex.getCause()).getConstraintName()));
                                ;
                            }
                        }
                    }
                }
                //               }
                errMap.put(applicationExcelItemObj.getRow(), messageError);
            }
        }
        return CommonUtils.downloadFile(excelObjectMapper.getOutputFileErrImport(errMap, sheetAt, firstRow, null), "Ket_qua_import_ung_dung_" + sdf.format(new Date()) + ".xlsx");
    }

    private boolean isEmptyObj(ApplicationExcelItemObj applicationExcelItemObj) {
        if (applicationExcelItemObj == null ||
                (StringUtils.isEmpty(applicationExcelItemObj.getCode())) && StringUtils.isEmpty(applicationExcelItemObj.getName())
                        && StringUtils.isEmpty(applicationExcelItemObj.getClientSecret())) {
            return true;
        }
        return false;
    }

    @CacheEvict(value = "clientDetail", allEntries = true)
    @Override
    public ResponseBase changeCs(ChangeSecretReqDTO changeSecretReqDTO) throws IllegalAccessException, ValidationException, NotFoundException {
        trimSpaceUtil.validate(changeSecretReqDTO);
        Application application = applicationRepo.findById(changeSecretReqDTO.getId()).orElseThrow(() ->
                new NotFoundException("ValidationException.error.not.found"));
        if (application.getNotEdit() == Constants.BOOLEAN.TRUE) {
            throw new ValidationException("ValidationException.error.not.changeCs");
        }
        if (!passwordEncoder.matches(changeSecretReqDTO.getOldSecret(), application.getClientSecret())) {
            throw new ValidationException("ValidationException.error.not.match.old.password");
        }
        if (!changeSecretReqDTO.getNewSecret().equals(changeSecretReqDTO.getNewSecretAgain())) {
            throw new ValidationException("ValidationException.error.not.match.new.password");
        }
        if (changeSecretReqDTO.getNewSecret().equals(changeSecretReqDTO.getOldSecret())) {
            throw new ValidationException("ValidationException.error.not.change.new.password");
        }
        application.setClientSecret(passwordEncoder.encode(changeSecretReqDTO.getNewSecret()));
        // Save log

        String content = String.format("Phần mềm tên %s và mã %s", application.getName(), application.getCode());
        loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.CATEGORY.app,
                ActionCode.CHANGE_PW, content, Instant.now()));
        applicationRepo.save(application);
        redisTemplate.delete(vn.gtel.common.constants.Constants.REDIS_KEY.QTUD_CLIENT_TOKEN);
        return new ResponseBase();
    }

    @Override
    public ResponseBase list(ApplicationFilter filter) throws IllegalAccessException {
        trimSpaceUtil.validate(filter);
        int pageIndex = filter.getPage();
        int pageSize = filter.getSize();

        //Truy vấn danh sách
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Application> criteriaQuery = criteriaBuilder.createQuery(Application.class);
        Root<Application> root = criteriaQuery.from(Application.class);
        criteriaQuery.select(root);

        Predicate searchPredicate = buildSearchPredicate(criteriaBuilder, root, filter);
        criteriaQuery.where(searchPredicate);
        criteriaQuery.orderBy(criteriaBuilder.desc(root.get(AuditModelBase.Fields.createdDate)));
        TypedQuery<Application> query = entityManager.createQuery(criteriaQuery);

        int startPosition = pageIndex * pageSize;
        query.setFirstResult(startPosition);
        query.setMaxResults(pageSize);

        List<Application> resultList = query.getResultList();

        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        Root<Application> countRoot = countQuery.from(Application.class);
        countQuery.select(criteriaBuilder.count(countRoot));
        Predicate countPredicate = buildSearchPredicate(criteriaBuilder, countRoot, filter);
        countQuery.where(countPredicate);

        TypedQuery<Long> countTypedQuery = entityManager.createQuery(countQuery);
        Long totalCount = countTypedQuery.getSingleResult();

        ListResponse listResponse = new ListResponse(resultList, totalCount);
        return new ResponseBase(listResponse);
    }

    private Predicate buildSearchPredicate(CriteriaBuilder criteriaBuilder, Root<Application> root, ApplicationFilter filter) {
        List<Predicate> predicates = new ArrayList<>();

        if (filter.getKeySearch() != null && !filter.getKeySearch().isEmpty()) {
            String keySearch = '%' + filter.getKeySearch() + '%';
            Predicate namePredicate = criteriaBuilder.like(root.get(AuditCategoryModel.Fields.name), keySearch);
            Predicate codePredicate = criteriaBuilder.like(root.get(AuditCategoryModel.Fields.code), keySearch);
            predicates.add(criteriaBuilder.or(namePredicate, codePredicate));
        }
        if (filter.getStatus() != null) {
            predicates.add(criteriaBuilder.equal(root.get(AuditModelBase.Fields.status), filter.getStatus()));
        } else {
            predicates.add(criteriaBuilder.equal(root.get(AuditModelBase.Fields.status), Constants.APPLICATION_STATUS.ACTIVE));
        }
        if (filter.getType() != null) {
            predicates.add(criteriaBuilder.equal(root.get(Application.Fields.type), filter.getType()));
        }
        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }
}
