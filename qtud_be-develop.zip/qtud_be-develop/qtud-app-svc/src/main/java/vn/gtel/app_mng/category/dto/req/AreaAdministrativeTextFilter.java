 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 8, 2021
 */
package vn.gtel.app_mng.category.dto.req;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.GetMapping;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import javax.persistence.Basic;
import javax.persistence.Column;

 @Data
 @Getter
 @Setter
 @NoArgsConstructor
 public class AreaAdministrativeTextFilter{


     public AreaAdministrativeTextFilter(String areaAdministrativeParentCode, String areaAdministrativeType) {
         this.areaAdministrativeParentCode = areaAdministrativeParentCode;
         this.areaAdministrativeType = areaAdministrativeType;
     }

     private String areaAdministrativeParentCode;

     private String areaAdministrativeType;


 }
