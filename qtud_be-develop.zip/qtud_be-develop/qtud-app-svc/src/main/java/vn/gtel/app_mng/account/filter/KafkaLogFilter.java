package vn.gtel.app_mng.account.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KafkaLogFilter extends TextFilter {
    private String topic;
    private Long type;
    private Long status;
    private Instant fromDate;
    private Instant toDate;

    public KafkaLogFilter(String topic, Long type, Long status, Instant fromDate, Instant toDate, String keySearch, Integer page, Integer size) {
        super(page, size, keySearch);
        this.topic = topic;
        this.type = type;
        this.status = status;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }
}
