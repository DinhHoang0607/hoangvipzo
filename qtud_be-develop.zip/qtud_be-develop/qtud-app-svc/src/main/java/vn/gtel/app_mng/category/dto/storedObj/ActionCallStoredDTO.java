 /**
 * @author     : tronglm
 * project name: app-mng
 * since       : Dec 6, 2021
 */
package vn.gtel.app_mng.category.dto.storedObj;

import java.util.HashMap;
import java.util.Map;

import vn.gtel.app_mng.category.dto.res.ActionNameIdRes;
import vn.gtel.app_mng.category.dto.res.ActionResponse;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.role.dto.menu_action.RoleActionDTO;
import vn.gtel.app_mng.role.dto.menu_action.RoleMenuByAppFilter;

 public class ActionCallStoredDTO extends ICallStoredObj{
	
	private static final String PACKAGE_NAME = "PKG_DM_HANH_DONG";
    private static final String PROC_SEARCH_NAME = "PROC_TIM_KIEM_HANH_DONG";
    private static final String PROC_FIND_BY_ID_NAME = "PROC_TIM_HANH_DONG";

    private static final String IN_KEY_SEARCH = "PI_KEY_SEARCH";
    private static final String IN_PAGE = "PI_PAGE";
    private static final String IN_SIZE = "PI_SIZE";
    private static final String IN_ID = "PI_ID";
    private static final String IN_APPLICATION = "PI_UNG_DUNG";
     private static final String IN_STATUS = "PI_STATUS";

    Map<String, Object> params = new HashMap<>();

    private void setBase(){
        setPackageName(PACKAGE_NAME);
        setResponseType(ActionResponse.class);
    };

    public ActionCallStoredDTO(TextFilter textFilter, Integer status) {
        setBase();
        setStoredName(PROC_SEARCH_NAME);
        params.put(IN_KEY_SEARCH, textFilter.getKeySearch());
        params.put(IN_PAGE, textFilter.getPage());
        params.put(IN_SIZE, textFilter.getSize());
        params.put(IN_APPLICATION,null);
        params.put(IN_STATUS,status);
        setParams(params);
    }

     public ActionCallStoredDTO(RoleMenuByAppFilter roleMenuByAppFilter) {
         setBase();
         setStoredName(PROC_SEARCH_NAME);
         setResponseType(RoleActionDTO.class);
         params.put(IN_KEY_SEARCH, null);
         params.put(IN_PAGE, roleMenuByAppFilter.getPage());
         params.put(IN_SIZE, roleMenuByAppFilter.getSize());
         params.put(IN_APPLICATION, roleMenuByAppFilter.getApplication());
         params.put(IN_STATUS,1);
         setParams(params);
     }

     public ActionCallStoredDTO(String appCode, boolean isPaging) {
         setBase();
         setStoredName(PROC_SEARCH_NAME);
         setResponseType(RoleActionDTO.class);
         params.put(IN_KEY_SEARCH, null);
         params.put(IN_PAGE, Constants.DEFAULT_PAGE);
         params.put(IN_SIZE, Constants.MAX_ROW_SELECT);
         params.put(IN_APPLICATION, appCode);
         params.put(IN_STATUS,1);
         setParams(params);
     }

    public ActionCallStoredDTO(String id) {
        setBase();
        setStoredName(PROC_FIND_BY_ID_NAME);
        params.put(IN_ID, id);
        setParams(params);
    }



}
