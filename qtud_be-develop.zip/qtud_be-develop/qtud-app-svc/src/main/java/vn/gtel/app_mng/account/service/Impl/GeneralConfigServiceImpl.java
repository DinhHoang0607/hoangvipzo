package vn.gtel.app_mng.account.service.Impl;

import com.google.gson.Gson;
import javassist.NotFoundException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.dto.GeneralConfigDTO;
import vn.gtel.app_mng.account.dto.PasswordRuleDTO;
import vn.gtel.app_mng.account.dto.request.GeneralConfigRequest;
import vn.gtel.app_mng.account.dto.storeObj.GeneralConfigCallStoredDTO;
import vn.gtel.app_mng.account.filter.GeneralConfigFilterDTO;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.account.model.GeneralConfig;
import vn.gtel.app_mng.account.reponse.GeneralConfigResponseDTO;
import vn.gtel.app_mng.account.reponse.InstructionManualType;
import vn.gtel.app_mng.account.repository.AccountRepository;
import vn.gtel.app_mng.account.repository.GeneralConfigRepository;
import vn.gtel.app_mng.account.service.GeneralConfigService;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.category.repo.OrganizationRepo;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.Messages;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.service.CommonService;
import vn.gtel.app_mng.common.util.CommonUtils;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.system.service.ConfigurationChangeLogService;
import vn.gtel.common.dto.AccountDTO;
import vn.gtel.common.userinfo.AccountLogonContext;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class GeneralConfigServiceImpl implements GeneralConfigService {

    @Autowired
    GeneralConfigRepository generalConfigRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private TrimSpaceUtil trimSpaceUtil;

    @Autowired
    private CallStoredRepository callStoredRepository;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private OrganizationRepo organizationRepo;

    @Autowired
    private ConfigurationChangeLogService configurationChangeLogService;

    @Override
    public ResponseBase insertOrUpdateGeneralConfig(GeneralConfigDTO generalConfigDTO) throws IllegalAccessException {
        trimSpaceUtil.validate(generalConfigDTO);

        if (StringUtils.isNotEmpty(generalConfigDTO.getId())) {
            Optional<GeneralConfig> generalConfig = generalConfigRepository.findById(generalConfigDTO.getId());
            if (generalConfig.isPresent()) {
                modelMapper.getConfiguration().setSkipNullEnabled(true);
                modelMapper.map(generalConfig, generalConfig);
                GeneralConfig currentGeneralConfig = generalConfigRepository.save(generalConfig.get());
                //thêm mới 1 key , value vào cache
                generalConfigRepository.updateCacheByKey(generalConfigDTO.getKey());
                return new ResponseBase(currentGeneralConfig);
            } else {
                return new ResponseBase("400", "response.message.fail");
            }
        } else {
            GeneralConfig generalConfig = modelMapper.map(generalConfigDTO, GeneralConfig.class);
            //cập nhập lại giá trị cho cache
            GeneralConfig currentGeneralConfig = generalConfigRepository.save(generalConfig);
            generalConfigRepository.updateCacheByKey(generalConfigDTO.getKey());
            return new ResponseBase(currentGeneralConfig);
        }

    }

    @Override
    public ResponseBase deleteGeneralConfig(String id) {
        Optional<GeneralConfig> generalConfig = generalConfigRepository.findById(id);
        if (generalConfig.isPresent()) {
            generalConfig.get().setStatus(Constants.GENERAL_CONFIG_STATUS.STATUS_DELETE);
            return new ResponseBase(generalConfig);
        } else {
            return new ResponseBase("400", "response.message.fail");
        }
    }

    @Override
    public ResponseBase listGeneralConfig(TextFilter textFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(textFilter);
        ICallStoredObj callStoredObj = new GeneralConfigCallStoredDTO(textFilter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase list(GeneralConfigFilterDTO filter) throws IllegalAccessException {
        ICallStoredObj callStoredObj = new GeneralConfigCallStoredDTO(filter);
        Object res = callStoredRepository.list(callStoredObj);
        return new ResponseBase(res);
    }

    @Override
    public ResponseBase saveAll(GeneralConfigRequest request) throws IllegalAccessException {
        AccountDTO accountDTO = AccountLogonContext.currentUser();
        if (!accountDTO.isAdmin())
            return new ResponseBase(Constants.ERROR_CODE.VALIDATION, Messages.getString("ValidationException.error.system.admin.account.required"), null);
        List<GeneralConfigDTO> gc = new ArrayList<>();
        if (request.getConfigs().size() > 0) {
            configurationChangeLogService.create(generalConfigRepository.findAll(), request.getConfigs());
            request.getConfigs().stream().forEach(cf -> {
                GeneralConfig c = generalConfigRepository.findByKey(cf.getKey());
                if (c == null) {
                    c = new GeneralConfig(cf.getKey(), cf.getValue());
                    generalConfigRepository.save(c);
                } else {
                    if (cf.getValue() == null) {
                        GeneralConfig generalConfig = generalConfigRepository.findByKey("log.system.expired-time:value-default");
                        String values = null;
                        if (generalConfig != null && generalConfig.getValue() != null) {
                            values = generalConfig.getValue();
                        }
                        c.setValue(values);
                    } else {
                        c.setValue(cf.getValue());
                    }
//                    c.setValue(cf.getValue());
                }
                generalConfigRepository.save(c);
                gc.add(new GeneralConfigDTO(c));
            });
            for (String cacheName : Constants.CACHE.APP.GENERAL_CONFIG)
                clearCache(cacheName);
        }
        return new ResponseBase(gc);
    }

    @Override
    public ResponseBase getPasswordRules() throws IllegalAccessException {
        List<GeneralConfigResponseDTO> data = cacheAll(Constants.CACHE.APP.PASSWORD_CONFIG);
        if (data.size() > 0) {
            List<PasswordRuleDTO> pwRules = new ArrayList<>();
            data.stream()
                    .filter(d -> Integer.valueOf(d.getStatus()).equals(Constants.STATUS_CATEGORY_ACTIVE))
                    .forEach(config -> pwRules.add(new PasswordRuleDTO(config)));
            return new ResponseBase(pwRules);
        } else {
            clearCache(Constants.CACHE.APP.PASSWORD_CONFIG);
            return new ResponseBase(Constants.ERROR_CODE.MISSING_CACHE, Messages.getString("error.common.cache.missing"), null);
        }
    }

    @Override
    public String generatePasswordFilter() {
        List<GeneralConfigResponseDTO> data = cacheAll(Constants.CACHE.APP.PASSWORD_CONFIG);
        List<GeneralConfigResponseDTO> dataSorted = new ArrayList<>();
        GeneralConfigResponseDTO endIndex = new GeneralConfigResponseDTO();
        for (GeneralConfigResponseDTO dto : data) {
            if (!dto.getKey().equals("security.password.min_length")) {
                dataSorted.add(dto);
            } else {
                endIndex = dto;
            }
        }
        dataSorted.add(endIndex);
        if (dataSorted.size() > 0) {
            PasswordRuleDTO pwRule = new PasswordRuleDTO(dataSorted);
            return pwRule.getFilter();
        } else {
            clearCache(Constants.CACHE.APP.PASSWORD_CONFIG);
            return "";
        }
    }

    @Override

    public String generateRandomPassword() {
        String filter = generatePasswordFilter();
        if (filter == null) {
            filter = "";
        }
        List<GeneralConfigResponseDTO> data = cacheAll(Constants.CACHE.APP.PASSWORD_CONFIG);
        if (data.size() > 0) {
            Integer numberOfLowercase = Integer.valueOf(data.stream().filter(config -> config.getKey().equals("security.password.lower_case")).findFirst().get().getValue());
            Integer numberOfUppercase = Integer.valueOf(data.stream().filter(config -> config.getKey().equals("security.password.upper_case")).findFirst().get().getValue());
            Integer numberOfNumber = Integer.valueOf(data.stream().filter(config -> config.getKey().equals("security.password.number")).findFirst().get().getValue());
            Integer numberOfSpecial = Integer.valueOf(data.stream().filter(config -> config.getKey().equals("security.password.special")).findFirst().get().getValue());
            Integer numberOfChar = Integer.valueOf(data.stream().filter(config -> config.getKey().equals("security.password.min_length")).findFirst().get().getValue());

            String password = "";
            do {
                password = RandomStringUtils.random(numberOfLowercase, Constants.CHARACTER_SET.LOWER_CASE)
                        + RandomStringUtils.random(numberOfUppercase, Constants.CHARACTER_SET.UPPER_CASE)
                        + RandomStringUtils.random(numberOfNumber, Constants.CHARACTER_SET.NUMBER)
                        + RandomStringUtils.random(numberOfSpecial, Constants.CHARACTER_SET.SPECIAL);
                password += RandomStringUtils.random((password.length() > numberOfChar ? 0 : numberOfChar - password.length()) + (new Random()).nextInt(3), String.join("", Constants.CHARACTER_SET.ALL));
                List<Character> pwChars = Arrays.asList(ArrayUtils.toObject(password.toCharArray()));
                Collections.shuffle(pwChars);
                password = StringUtils.join(pwChars, null);
            } while (!password.matches(filter));
            return password;
        } else {
            clearCache(Constants.CACHE.APP.PASSWORD_CONFIG);
            return "";
        }
    }

    @Override
    public Instant generatePasswordExpirationDate(Instant startDate, Integer type) {
        List<GeneralConfigResponseDTO> data = cacheAll(Constants.CACHE.APP.PASSWORD_CONFIG);
        if (data.size() > 0) {
            if (StringUtils.isNotEmpty(type.toString())) {
                GeneralConfigResponseDTO configDTO = new GeneralConfigResponseDTO();
                switch (type) {
                    case 1:
                        configDTO = data.stream().filter(config -> config.getKey().equals("security.password.expiration_date")).findFirst().get();
                        break;
                    case 2:
                        configDTO = data.stream().filter(config -> config.getKey().equals("security.password.expired_notification_date")).findFirst().get();
                        break;
                }
                switch (configDTO.getUnit()) {
                    case Constants.GENERAL_CONFIG_UNITS.SECOND:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()));
                    case Constants.GENERAL_CONFIG_UNITS.MINUTE:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()) * 60);
                    case Constants.GENERAL_CONFIG_UNITS.HOUR:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()) * 60 * 60);
                    case Constants.GENERAL_CONFIG_UNITS.DAY:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()) * 60 * 60 * 24);
                    case Constants.GENERAL_CONFIG_UNITS.WEEK:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()) * 60 * 60 * 24 * 7);
                    case Constants.GENERAL_CONFIG_UNITS.MONTH:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()) * 60 * 60 * 24 * 30);
                    case Constants.GENERAL_CONFIG_UNITS.YEAR:
                        return startDate.plusSeconds(Long.valueOf(configDTO.getValue()) * 60 * 60 * 24 * 365);
                }
            }
        }
        return startDate.plusSeconds(1 * 60 * 60 * 24 * 365);
    }

    public List<GeneralConfigResponseDTO> cacheAll(String cacheName) {
        String cacheData = (String) redisTemplate.opsForValue().get(cacheName);
        if (StringUtils.isEmpty(cacheData)) {
            ICallStoredObj callStoredObj = new GeneralConfigCallStoredDTO(cacheName);
            List<GeneralConfigResponseDTO> res = (List<GeneralConfigResponseDTO>) callStoredRepository.getList(callStoredObj);
            redisTemplate.opsForValue().set(cacheName, new Gson().toJson(res));
            return res;
        } else {
            List<GeneralConfigResponseDTO> res = new Gson().fromJson(cacheData, new TypeToken<List<GeneralConfigResponseDTO>>() {
            }.getType());
            return res;
        }
    }

    private void clearCache(String cacheName) {
        redisTemplate.opsForValue().set(cacheName, null);
    }


    @Override
    public ResponseEntity getInstructionManual(Integer type) throws Exception {
        Account account = accountRepository.findByAccountAndStatus(AccountLogonContext.getUsername(), Constants.STATUS_CATEGORY_ACTIVE);
        Organization organization = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        if (AccountLogonContext.currentUser().getType().equals(Constants.ACC_EMPLOYEE_TYPE.EMPLOYEE))
            throw new Exception(String.format("%s không phải là tài khoản quản trị!", account.getAccount()));

        String path;
        String file;
        String finalName;

        switch (organization.getOrganizationLevel()) {
            case "002":
                path = "CUC";
                break;
            case "006":
                path = "TINH";
                break;
            case "007":
                path = "PHONG";
                break;
            case "008":
                path = "HUYEN";
                break;
            default:
                path = "";
        }

        switch (type) {
            case 1: // Lấy hướng dẫn tạo tài khoản
                file = "HUONG_DAN_TAO_TAI_KHOAN.docx";
                finalName = "HUONG_DAN_TAO_TAI_KHOAN.docx";
                break;
            case 2: // Lấy hướng dẫn ...
                file = "HUONG_DAN_TAO_TAI_KHOAN.docx";
                finalName = "HUONG_DAN_.docx";
                break;
            case 3: // Lấy hướng dẫn ...
                file = "Huong_Dan_Dieu_Chuyen_PC05_PC03_DTHS.docx";
                finalName = "Huong_Dan_Dieu_Chuyen_PC05_PC03_DTHS.docx";
                break;
            case 4: // Lấy hướng dẫn ...
                file = "Huong_Dan_Dieu_Chuyen_PC05_PC03_NVCB.docx";
                finalName = "Huong_Dan_Dieu_Chuyen_PC05_PC03_NVCB.docx";
                break;
            default: // Lấy hướng dẫn chung
                file = "HUONG_DAN_CHUNG.docx";
                finalName = "HUONG_DAN_CHUNG.docx";
        }

        return CommonUtils.downloadFile(CommonService.pathTempDocx(String.format("%s/%s", path, file)), finalName);
    }

    @Override
    public ResponseBase showInstructionManualList() throws Exception {
        Account account = accountRepository.findByAccountAndStatus(AccountLogonContext.getUsername(), Constants.STATUS_CATEGORY_ACTIVE);
        Organization organization = organizationRepo.findByCodeAndStatus(account.getOrganization(), Constants.STATUS_CATEGORY_ACTIVE);
        if (AccountLogonContext.currentUser().getType().equals(Constants.ACC_EMPLOYEE_TYPE.EMPLOYEE))
            throw new Exception(String.format("%s không phải là tài khoản quản trị!", account.getAccount()));
        List<InstructionManualType> response = new ArrayList<>();
        switch (organization.getOrganizationLevel()) {
            case "001":
                response.add(new InstructionManualType("Tải tệp HD tạo tài khoản", 1));
                break;
            case "007":
                response.add(new InstructionManualType("Tải tệp hướng dẫn chung", 0));
                response.add(new InstructionManualType("Tải tệp HD tạo tài khoản", 1));
                response.add(new InstructionManualType("DTHS : HD sáp nhập PC05 vào PC03", 3));
                response.add(new InstructionManualType("NVCB : HD sáp nhập PC05 vào PC03 ", 4));
                break;
            default:
                response.add(new InstructionManualType("Tải tệp hướng dẫn chung", 0));
                response.add(new InstructionManualType("Tải tệp HD tạo tài khoản", 1));
        }
        return new ResponseBase(response);
    }

    @Override
    public ResponseBase getByKey(String key) throws NotFoundException {
        GeneralConfig gc = generalConfigRepository.findByKey(key);
        if (gc == null) {
            throw new NotFoundException("");
        }
        return new ResponseBase(new GeneralConfigDTO(gc));
    }
}
