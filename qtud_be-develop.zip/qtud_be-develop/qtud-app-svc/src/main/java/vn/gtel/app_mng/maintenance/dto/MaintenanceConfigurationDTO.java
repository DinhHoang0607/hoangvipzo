package vn.gtel.app_mng.maintenance.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaintenanceConfigurationDTO {
    private String id;

    private String description;

    private Instant startedDate;

    private Instant finishedDate;
}

