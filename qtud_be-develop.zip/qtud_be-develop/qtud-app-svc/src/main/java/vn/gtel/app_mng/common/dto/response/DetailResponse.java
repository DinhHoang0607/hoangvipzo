/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  DetailResponse.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/4/21, 11:18 AM
 */

package vn.gtel.app_mng.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailResponse {
    Object detail;
}
