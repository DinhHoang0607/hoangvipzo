package vn.gtel.app_mng.category.model;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;

@Getter
@Setter
@Entity
@FieldNameConstants
@Table(name = "TBL_DV_TRANG_THAI_HO_SO")
public class ProfileStatus extends AuditModel {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @ManyToOne
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name = "LOAI_HO_SO", referencedColumnName = "MA", insertable = false, updatable = false)
    private ProfileType type;

    @Column(name = "LOAI_HO_SO")
    private String typeCode;

    @Column(name = "GIA_TRI")
    private String value;

    @Column(name = "MA_XLVP")
    private String codeXLVP;

    @Column(name = "MA_TNGT")
    private String codeTNGT;
}
