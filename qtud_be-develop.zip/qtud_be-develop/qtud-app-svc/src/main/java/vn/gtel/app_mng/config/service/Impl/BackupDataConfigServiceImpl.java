/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  BackupDataConfigServiceImpl.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  3/7/22, 3:06 PM
 *
 */

package vn.gtel.app_mng.config.service.Impl;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.gtel.app_mng.account.model.Account;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.i.ICallStoredObj;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.model.AuditModel;
import vn.gtel.app_mng.common.repository.CallStoredRepository;
import vn.gtel.app_mng.common.util.TrimSpaceUtil;
import vn.gtel.app_mng.config.dto.BackUpDataConfigFilter;
import vn.gtel.app_mng.config.dto.BackUpDataConfigRqDTO;
import vn.gtel.app_mng.config.model.BackupDataConfig;
import vn.gtel.app_mng.config.repository.BackupDataConfigRepository;
import vn.gtel.app_mng.config.service.BackupDataConfigService;
import vn.gtel.app_mng.config.storeObj.BackupDataConfigCallStoredDTO;

import java.util.ArrayList;
import java.util.List;

@Service
public class BackupDataConfigServiceImpl implements BackupDataConfigService {

    @Autowired
    private CallStoredRepository callStoredRepository;

    @Autowired
    private BackupDataConfigRepository backupDataConfigRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private TrimSpaceUtil trimSpaceUtil;

    @Override
    public ResponseBase save(BackUpDataConfigRqDTO backUpDataConfigRqDTO) throws Exception {
        trimSpaceUtil.validate(backUpDataConfigRqDTO);
        List<BackupDataConfig> saveConfigs = new ArrayList<>();
        backUpDataConfigRqDTO.getConfigs().stream().forEach(configDTO -> {
            boolean isUpdate;
            if(StringUtils.isNotEmpty(configDTO.getId())){
                isUpdate = true;
            } else {
                isUpdate = false;
            }
            BackupDataConfig existType = backupDataConfigRepository.findByType(configDTO.getType());
            if(existType != null){
                existType.setStatus(Constants.CONFIG_STATUS.ACTIVE);
                modelMapper.getConfiguration().setSkipNullEnabled(true);
                modelMapper.map(configDTO, existType);
                saveConfigs.add(existType);
            } else {
                if (!isUpdate) {
                    BackupDataConfig backUpDataConfig = modelMapper.map(configDTO, BackupDataConfig.class);
                    backUpDataConfig.setStatus(Constants.CONFIG_STATUS.ACTIVE);
                    saveConfigs.add(backUpDataConfig);
                } else {
                    BackupDataConfig backUpDataConfig = backupDataConfigRepository.findById(configDTO.getId()).orElse(null);
                    if (backUpDataConfig != null) {
                        modelMapper.getConfiguration().setSkipNullEnabled(true);
                        modelMapper.map(configDTO, backUpDataConfig);
                        saveConfigs.add(backUpDataConfig);
                    }
                }
            }
        });
        return new ResponseBase(backupDataConfigRepository.saveAll(saveConfigs));
    }

    @Override
    public ResponseBase search(BackUpDataConfigFilter backUpDataConfigFilter) throws IllegalAccessException {
        trimSpaceUtil.validate(backUpDataConfigFilter);
        ICallStoredObj callStoredObj = new BackupDataConfigCallStoredDTO(backUpDataConfigFilter);
        Object response = callStoredRepository.list(callStoredObj);
        return new ResponseBase(response);

    }
}
