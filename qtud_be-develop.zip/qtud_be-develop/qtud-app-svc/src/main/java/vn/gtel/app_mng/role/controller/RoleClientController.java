package vn.gtel.app_mng.role.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.role.service.RoleService;

@Validated
@Tag(name = "Quyền client")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/client")
@AllArgsConstructor
public class RoleClientController {

    private static final Logger LOGGER = LogManager.getLogger(RoleClientController.class);
    private final RoleService roleService;

    @Operation(summary = "Danh sách mã quyền theo dịch vụ")
    @GetMapping(value = "/pattern")
    public ResponseBase getPattern() {
        return roleService.getPattern();
    }

    @Operation(summary = "Danh sách mã quyền")
    @GetMapping(value = "")
    public ResponseBase getPermission() {
        return roleService.getClientPermission();
    }

    @Operation(summary = "Thông tin của client")
    @GetMapping(value = "/info")
    public ResponseBase getInfo() {
        return roleService.getInfo();
    }

}
