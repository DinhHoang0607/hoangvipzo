package vn.gtel.app_mng.feedback.dto;

import lombok.Data;

import javax.persistence.Column;
import java.util.ArrayList;
import java.util.List;

@Data
public class FeedBackHistoryImgResponse {

    @Column(name = "ID")
    private String id;
    @Column(name = "NGUOI_GUI")
    private String sender;
    @Column(name = "TEN_NGUOI_GUI")
    private String senderName;
    @Column(name = "NGUOI_XY_LY")
    private String processor;
    @Column(name = "TEN_NGUOI_XU_LY")
    private String processorName;
    @Column(name = "TEN_DON_VI_NGUOI_XU_LY")
    private String orgProcessorName;
    @Column(name = "TRANG_THAI")
    private String status;
    @Column(name = "NGAY_SUA")
    private String modifiedDate;
    @Column(name = "HANH_DONG")
    private String action;
    @Column(name = "NGAY_TAO")
    private String createdDate;
    @Column(name = "NOI_DUNG_TRAO_DOI")
    private String comment;
    private List<FileFeedBackDTO> files ;

}
