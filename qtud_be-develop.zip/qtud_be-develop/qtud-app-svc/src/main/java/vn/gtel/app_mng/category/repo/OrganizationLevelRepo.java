package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.OrganizationLevel;

@Repository
public interface OrganizationLevelRepo extends JpaRepository<OrganizationLevel,String> {
}
