package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import vn.gtel.app_mng.category.model.Position;

import java.util.List;

public interface PositionCatRepo extends JpaRepository<Position,String> {

    Position findByNameAndStatus(String name, Integer status);

    Position findByCode(String code);

    Position findByNameAndStatusAndClassify(String name, Integer status, Integer classify);

    Position findByCodeAndStatusAndClassify(String code, Integer status, Integer classify);

    List<Position> findByStatusAndClassifyOrderByCodeAsc(Integer status, Integer type);

    @Query(value = "SELECT ma FROM tbl_dm_chuc_vu WHERE (ma LIKE '6%' OR ma = '0000') AND loai_chuc_vu = 1", nativeQuery = true)
    List<String> findRestrictedPosition();

    boolean existsByCodeAndStatus(String code, int status);
}
