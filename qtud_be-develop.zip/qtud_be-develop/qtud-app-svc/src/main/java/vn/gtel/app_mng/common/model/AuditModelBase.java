package vn.gtel.app_mng.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.Formula;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@FieldNameConstants
public abstract class AuditModelBase implements Serializable {

    @Column(name = "NGAY_TAO", updatable = false)
    @CreatedDate
    private Instant createdDate;

    @Column(name = "NGUOI_TAO", updatable = false)
    @CreatedBy()
    private String createdBy;

    @Column(name = "NGAY_SUA")
    @LastModifiedDate
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    @LastModifiedBy
    private String lastModifiedBy;

    @Basic
    @Column(name = "TRANG_THAI")
    private Integer status;

    @Formula("GET_STATUS('Trạng thái' , TRANG_THAI)")
    private String statusName;

    public AuditModelBase(Integer status) {
        this.status = status;
    }

    @PrePersist
    public void prePersist() {
        if (this.status == null) {
            this.status = 1;
        }
    }

    @PreUpdate
    public void preUpdate() {
    }
}
