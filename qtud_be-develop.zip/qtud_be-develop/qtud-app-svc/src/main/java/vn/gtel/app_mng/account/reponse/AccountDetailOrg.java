package vn.gtel.app_mng.account.reponse;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;
import java.time.Instant;
import java.util.List;

@Data
public class AccountDetailOrg {
    @Column(name = "ID")
    private String id;

    @Column(name = "TAI_KHOAN")
    private String account;

    @Basic
    @Column(name = "HO_TEN")
    private String fullName;

    @Basic
    @Column(name = "DON_VI")
    private String organizationCode;

    @Basic
    @Column(name = "TEN_DON_VI")
    private String organizationName;

    @Basic
    @Column(name = "PHAN_LOAI")
    private String type;
}
