package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.account.dto.GroupCodeItemWithActionDTO;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "TBL_TK_TRONG_NHOM_TK")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountGroupAccount extends AuditModelBase {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "NHOM_TAI_KHOAN")
    private String groupAccount;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Formula("(select nd.HO_TEN from TBL_TK_NGUOI_DUNG nd where nd.TAI_KHOAN = TAI_KHOAN)")
    private String accountName;

    public AccountGroupAccount(GroupCodeItemWithActionDTO groupCodeItemWithActionDTO) {
        this.id = groupCodeItemWithActionDTO.getId();
        this.account = groupCodeItemWithActionDTO.getCode();
        this.groupAccount = groupCodeItemWithActionDTO.getGroupCode();
        this.setStatus(groupCodeItemWithActionDTO.getAction());
    }

    public AccountGroupAccount(String account, String groupAccount) {
        this.account = account;
        this.groupAccount = groupAccount;
    }

    public AccountGroupAccount(List<AccountGroupAccount> accountGroupAccounts, GroupCodeItemWithActionDTO groupCodeItemWithActionDTO) {
        AccountGroupAccount accountGroupAccount = accountGroupAccounts.stream().filter(e -> e.getAccount().equals(groupCodeItemWithActionDTO.getCode())).findFirst().orElse(null);
        if (accountGroupAccount == null) {
            accountGroupAccount = new AccountGroupAccount(groupCodeItemWithActionDTO);
        } else {
            accountGroupAccount.setStatus(Constants.COMMON_STATUS.ACTIVE);
        }
        this.id = accountGroupAccount.getId();
        this.groupAccount = accountGroupAccount.getGroupAccount();
        this.account = accountGroupAccount.getAccount();
        this.setStatus(accountGroupAccount.getStatus());
    }

    public AccountGroupAccount(AccountGroupAccount entity, Integer status) {
        this.id = entity.getId();
        this.account = entity.getAccount();
        this.groupAccount = entity.getGroupAccount();
        this.setStatus(status);
    }
}
