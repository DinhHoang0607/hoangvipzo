package vn.gtel.app_mng.category.dto.req;

import lombok.Data;

import java.util.List;
@Data
public class DashboardPermissionsReqDTO {
    private String account;
    private List<String> actions;
}
