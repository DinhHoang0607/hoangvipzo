package vn.gtel.app_mng.common.dto.response;

import lombok.Data;

import javax.persistence.Column;
import java.time.Instant;
@Data
public class AuditCategoryResponseDTO {
    @Column(name = "ID")
    private String id;

    @Column(name = "TEN")
    private String name;

    @Column(name = "MA")
    private String code;

    @Column(name = "NGAY_TAO")
    private Instant createdDate;

    @Column(name = "NGUOI_TAO")
    private String createdBy;

    @Column(name = "NGAY_SUA")
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    private String lastModifiedBy;

    @Column(name = "TRANG_THAI")
    private Integer status;

    @Column(name = "TRANG_THAI_HIEN_THI")
    private String statusName;

    @Column(name = "MO_TA")
    private String description;
}
