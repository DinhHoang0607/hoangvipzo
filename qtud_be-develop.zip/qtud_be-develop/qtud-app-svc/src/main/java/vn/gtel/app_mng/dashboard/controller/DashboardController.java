/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  DashBoardController.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/19/22, 2:45 PM
 *
 */

package vn.gtel.app_mng.dashboard.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.dashboard.dto.req.FilterChart;
import vn.gtel.app_mng.dashboard.dto.req.GridFilter;
import vn.gtel.app_mng.dashboard.service.DashboardService;
import vn.gtel.app_mng.dashboard.storeObj.DashboardCallStoredDTO;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.Optional;

@Validated
@Tag(name = "DashBoard")
@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @Operation(summary = "Số tk đang online")
    @GetMapping(value = "/online-current")
    public ResponseBase onlineCurrent() {
        return dashboardService.onlineCurrent();
    }

    @Operation(summary = "Số truy cập trong ngày, năm")
    @GetMapping(value = "/access-today-or-year")
    public ResponseBase accessTodayYear() {
        return dashboardService.sumAccessByTime();
    }

    @Operation(summary = "Số lượt truy cập theo phần mềm")
    @GetMapping(value = "/access-by-app")
    public ResponseBase accessByApp(@NotNull(message = "error.common.validate.not.null")
                                    @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                    @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime,
                                    @RequestParam(name = "orgCode", required = false) String orgCode,
                                    @NotNull(message = "error.common.validate.not.null")
                                    @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                    @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime,
                                    @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType) throws IllegalAccessException {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_COUNT_BY_APP, true, orgCode);
        return dashboardService.countAccessByApp(filterChart);
    }

    @Operation(summary = "Số lượt tài khoản theo tỉnh")
    @GetMapping(value = "/online-by-city")
    public ResponseBase onlineByCity(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @NotNull(message = "error.common.validate.not.null")
            @Min(value = 2024, message = "error.common.validate.min.value.2024")
            @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime,
            @NotNull(message = "error.common.validate.not.null")
            @Min(value = 2024, message = "error.common.validate.min.value.2024")
            @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime,
            @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType
    ) throws IllegalAccessException {
        GridFilter gridFilter = new GridFilter(keySearch, fromTime, toTime, aggType);
        return dashboardService.countOnlineByCity(gridFilter);
    }

    @Operation(summary = "Kết xuất tài khoản theo tỉnh")
    @GetMapping(value = "/online-by-city/export")
    public ResponseEntity onlineByCityExport(
            @Valid
            @Pattern(regexp = Constants.Regex.KEY_SEARCH, message = "error.common.validate.not.special-characters")
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @NotNull(message = "error.common.validate.not.null")
            @Min(value = 2024, message = "error.common.validate.min.value.2024")
            @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime,
            @NotNull(message = "error.common.validate.not.null")
            @Min(value = 2024, message = "error.common.validate.min.value.2024")
            @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime,
            @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType
    ) throws Exception {
        GridFilter gridFilter = new GridFilter(keySearch, fromTime, toTime, aggType);
        return dashboardService.onlineByCityExport(gridFilter);
    }

//    @Operation(summary = "TK mức độ cảnh báo theo số lượt truy cập")
//    @GetMapping(value = "/alert-by-access")
//    public ResponseBase alertByAccess(@NotNull(message = "error.common.validate.not.null")
//                                              @Min(value = 2000L, message = "error.common.validate.min.value.2022")
//                                              @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime,
//                                      @NotNull(message = "error.common.validate.not.null")
//                                      @Min(value = 2000L, message = "error.common.validate.min.value.2022")
//                                      @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime,
//                                      @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType) {
//        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_ALERT_ACCESS);
//        return dashboardService.getChartValue(filterChart);
//    }

    @Operation(summary = "Số lượng tài khoản đăng nhập")
    @GetMapping(value = "/count-login")
    public ResponseBase countLogin(@NotNull(message = "error.common.validate.not.null")
                                   @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                   @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam(required = false) Long fromTime,
                                   @NotNull(message = "error.common.validate.not.null")
                                   @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                   @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam(required = false) Long toTime,
                                   @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType) throws IllegalAccessException {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_LOGIN_ACCOUNT, true);
        return dashboardService.getChartValue(filterChart);
    }
//    @Operation(summary = "Số lượng tài khoản bị khóa")
//    @GetMapping(value = "/count-block-account")
//    public ResponseBase countBlockAccount() throws IllegalAccessException {
//        return dashboardService.getCountAccount(2l);
//    }
//    @Operation(summary = "Số lượng tài khoản hoạt động")
//    @GetMapping(value = "/count-active-account")
//    public ResponseBase countActiveAccount() throws IllegalAccessException {
//        return dashboardService.getCountAccount(1l);
//    }
//    @Operation(summary = "Số lượng tài khoản")
//    @GetMapping(value = "/count-all-account")
//    public ResponseBase countAllAccount() throws IllegalAccessException {
//        return dashboardService.getCountAccount(null);
//    }

    @Operation(summary = "Số lượng tài khoản, số lướng tài khoản hoạt động, số lượng tài khoản bị khóa")
    @GetMapping(value = "/count-account")
    public ResponseBase countAllAccountV2() {
        return dashboardService.getCountAccount();
    }

    @Operation(summary = "Số lượng tài khoản, số lướng tài khoản hoạt động, số lượng tài khoản bị khóa")
    @GetMapping(value = "/count-account-by-org")
    public ResponseBase countAllAccountV3(@Param("orgCode") String orgCode) {
        return dashboardService.getCountAccountByOrg(orgCode);
    }

    @Operation(summary = "Số lượt xác thực hệ thống tích hợp")
    @GetMapping(value = "/client-login")
    public ResponseBase clientLogin(@NotNull(message = "error.common.validate.not.null")
                                    @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                    @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime,
                                    @NotNull(message = "error.common.validate.not.null")
                                    @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                    @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime,
                                    @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType) throws IllegalAccessException {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_COUNT_CLIENT_LOGIN);
        return dashboardService.getChartValue(filterChart);
    }

    @Operation(summary = "Top 10 danh mục sd nhiều nhất")
    @GetMapping(value = "/rank-use-category")
    public ResponseBase top10Category(@NotNull(message = "error.common.validate.not.null")
                                      @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                      @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long fromTime,
                                      @NotNull(message = "error.common.validate.not.null")
                                      @Min(value = 2024, message = "error.common.validate.min.value.2024")
                                      @Max(value = 9999999999999L, message = "error.common.validate.max.value.9999999999999L") @RequestParam Long toTime,
                                      @Pattern(regexp = "^(day|month|quarter|year)$", message = "error.common.validate.not.match.agg.type") @RequestParam String aggType) throws IllegalAccessException {
        FilterChart filterChart = new FilterChart(fromTime, toTime, aggType, DashboardCallStoredDTO.PROC_RANK_10_USE_CATEGORY);
        return dashboardService.getChartValue(filterChart);
    }
}
