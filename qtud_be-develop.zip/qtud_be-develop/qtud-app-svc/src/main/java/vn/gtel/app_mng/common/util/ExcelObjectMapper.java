/*
 *
 * Copyright (c) 2022.
 * Project  :  app-mng
 * File  :  ExcelObjectMapper.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  2/21/22, 10:38 AM
 *
 */

package vn.gtel.app_mng.common.util;

import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.common.dto.CatSheetDTO;
import vn.gtel.app_mng.common.dto.i.IExcelItem;
import vn.gtel.app_mng.common.dto.i.IExcelMapperObj;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
public class ExcelObjectMapper {
    private Workbook workbook;
    private IExcelMapperObj excelMapperObj;

    public ExcelObjectMapper(MultipartFile file) throws IOException {
        workbook = new XSSFWorkbook(file.getInputStream());
    }

    public ExcelObjectMapper(String path) throws IOException {
        InputStream is = null;
        try {
            is = ExcelObjectMapper.class.getClassLoader().getResourceAsStream(path);
            workbook = WorkbookFactory.create(is);// new XSSFWorkbook(file);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.getMessage();
                }
            }
        }
    }

    public <T> ArrayList<T> map(Class<T> clazz, int indexSheet, IExcelMapperObj iExcelMapperObj, int firstRow) throws IllegalAccessException, InstantiationException, NoSuchFieldException {
        excelMapperObj = iExcelMapperObj;
        ArrayList<T> list = new ArrayList<>();
        DataFormatter formatter = new DataFormatter();
        Sheet sheet = workbook.getSheetAt(indexSheet);
        int lastRow = sheet.getLastRowNum();
        for (int i = firstRow; i <= lastRow; i++) {
            if (sheet.getRow(i).getCell(0) == null) {
                break;
            }
            Object obj = clazz.newInstance();
            Field[] fields = obj.getClass().getDeclaredFields();
            for (Field field : fields) {
                System.out.println(field.getName());
                String fieldName = field.getName();
                Integer index = getIndex(fieldName, iExcelMapperObj);
                if (index != null) {
                    Cell cell = sheet.getRow(i).getCell(index);
                    Field classField = obj.getClass().getDeclaredField(fieldName);
                    setFieldVal(obj, classField, cell, formatter);
                }

            }
            Field classField = obj.getClass().getSuperclass().getDeclaredField("row");
            classField.set(obj, i);
            list.add((T) obj);
        }
        return list;
    }

    public Sheet map1(int indexSheet) throws IllegalAccessException, InstantiationException, NoSuchFieldException {
        Sheet sheet = workbook.getSheetAt(indexSheet);
        return sheet;
    }

    private void setFieldVal(Object obj, Field field, Cell cell, DataFormatter formatter) throws IllegalAccessException {
        Class<?> clazz = field.getType();
//        field.setAccessible(true);
        ReflectionUtils.makeAccessible(field);
        if (cell == null) {
            field.set(obj, null);
        } else {
            if (clazz == String.class) {
                String strValue = formatter.formatCellValue(cell);
                field.set(obj, strValue);
            }
            if (clazz == Date.class) {
                field.set(obj, cell.getDateCellValue());
            }
            if (clazz == Integer.class) {
                if (CellType.STRING.equals(cell.getCellType())) {
                    field.set(obj, Integer.parseInt(cell.getStringCellValue()));
                } else {
                    field.set(obj, (int) cell.getNumericCellValue());
                }
            }
            if (clazz == Long.class) {
                if (CellType.STRING.equals(cell.getCellType())) {
                    field.set(obj, Long.parseLong(cell.getStringCellValue()));
                } else {
                    field.set(obj, (long) cell.getNumericCellValue());
                }
            }
            if (clazz == float.class || clazz == double.class) {
                field.set(obj, cell.getNumericCellValue());
            }

        }
    }

    public Integer getIndex(String fieldName, IExcelMapperObj iExcelMapperObj) {
        return iExcelMapperObj.getFieldToIndexMap().get(fieldName);
    }

    public Workbook getOutputFileErrImport(Map<Integer, String> errMap, int sheetAt, int firstRow, IExcelMapperObj iExcelMapperObj) {
        int index = getIndex("resultColumn", (iExcelMapperObj == null) ? excelMapperObj : iExcelMapperObj);
        String nameHeader = "Kết Quả";
        Sheet sheet = workbook.getSheetAt(sheetAt);
        createCellHeader(sheet, firstRow, nameHeader, index);
        Font font = workbook.getFontAt(1);
        font.setColor(Font.COLOR_RED);

        for (Map.Entry<Integer, String> entry : errMap.entrySet()) {
            Row currentRow = sheet.getRow(entry.getKey());
            CellStyle cellStyle = currentRow.getCell(index - 1).getCellStyle();
            cellStyle.setBorderBottom(BorderStyle.THIN);
            cellStyle.setFont(font);
//            setFont(workbook, cellStyle);
            currentRow.createCell(index).setCellValue(StringUtils.isEmpty(entry.getValue()) ? "Thành công" : entry.getValue());
            currentRow.getCell(index).setCellStyle(cellStyle);
            if (StringUtils.isEmpty(entry.getValue())) {
                sheet.autoSizeColumn(index);
            } else {
                sheet.setColumnWidth(index, 60 * 300);
            }
        }

        return workbook;
    }

    public <T> Workbook getTemplateWithData(List<IExcelItem> data, Class<T> clazz, IExcelMapperObj iExcelMapperObj, int sheetAt, int startRow) throws InstantiationException, IllegalAccessException, NoSuchFieldException {
        excelMapperObj = iExcelMapperObj;
        Sheet sheet = workbook.getSheetAt(sheetAt);
        int stt = 1;
        for (IExcelItem excelItem : data) {
            Row currentRow = sheet.createRow(startRow);
            if (startRow == 4) {
                currentRow = sheet.getRow(startRow);
            }
            createDataCell(clazz, iExcelMapperObj, currentRow, excelItem, stt);
            startRow++;
            stt++;
        }
        return workbook;
    }


    public <T> Workbook getTemplateWithData(List<CatSheetDTO> catSheetDTOS, Class<T> clazz, IExcelMapperObj iExcelMapperObj, int startRow) throws IllegalAccessException, NoSuchFieldException, InstantiationException {
        excelMapperObj = iExcelMapperObj;
        for (CatSheetDTO catSheetDTO : catSheetDTOS) {
            Sheet sheet = workbook.getSheetAt(catSheetDTO.getSheetAt());
            int stt = 1;
            int rowIndex = startRow;
            for (IExcelItem excelItem : catSheetDTO.getData()) {
                Row currentRow = sheet.createRow(rowIndex);
                if (rowIndex == 4) {
                    currentRow = sheet.getRow(rowIndex);
                }
                createDataCell(clazz, iExcelMapperObj, currentRow, excelItem, stt);
                rowIndex++;
                stt++;
            }
        }

        return workbook;
    }

    private <T> void createDataCell(Class<T> clazz, IExcelMapperObj iExcelMapperObj, Row currentRow, IExcelItem data, int stt) throws IllegalAccessException, InstantiationException, NoSuchFieldException {
        CellStyle cellStyle = currentRow.getRowStyle();
        currentRow.createCell(0).setCellValue(stt);
        Object obj = clazz.newInstance();
        Field[] fields = obj.getClass().getDeclaredFields();
        if (CollectionUtils.isNotEmpty(iExcelMapperObj.getFieldExport())) {
            for (Field field : fields) {
                String fieldName = field.getName();
                if (iExcelMapperObj.getFieldExport().contains(fieldName)) {
                    Integer index = getIndex(fieldName, iExcelMapperObj);
                    Field classField = data.getClass().getDeclaredField(fieldName);
                    ReflectionUtils.makeAccessible(classField);
                    System.out.println(String.valueOf(classField.get(data)));
                    currentRow.createCell(index).setCellValue(String.valueOf(classField.get(data)));
                    currentRow.getCell(index).setCellStyle(cellStyle);
                }
            }
        }
    }

    public void createCellHeader(Sheet sheet, int firstRow, String nameHeader, int index) {
//        Row row = sheet.getRow(firstRow - 1);
//        Cell cell = row.getCell(index - 1);
//        CellStyle cellStyleHeader = cell.getCellStyle();
        CellStyle cellStyleHeader = sheet.getRow(firstRow - 1).getCell(index - 1).getCellStyle();
        Row currentRowHeader = sheet.getRow(firstRow - 1);
        currentRowHeader.createCell(index).setCellValue(nameHeader);
        currentRowHeader.getCell(index).setCellStyle(cellStyleHeader);
        sheet.autoSizeColumn(index);
    }

    public void setFont(Workbook workbook, CellStyle cellStyle) {
        Font font = workbook.getFontAt(1);
        font.setColor(Font.COLOR_RED);
        cellStyle.setFont(font);
    }
}
