/**
 * @author : tronglm
 * project name: app-mng
 * since       : Dec 7, 2021
 */
package vn.gtel.app_mng.category.dto.req;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuActionDTO {

    private String id;


    @Size(max = 3, message = "error.common.validate.max.size.3")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
    private String action;

    private String actionName;

    private String endPoint;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String method;

    @Size(max = 18, message = "error.common.validate.max.size.18")
    @Size(min = 3, message = "error.common.validate.min.size.3")
    @NotEmpty(message = "error.common.validate.not.empty")
    private String code;

    private String codeActionOther;


    /**
     * @param id
     * @param action
     */
    public MenuActionDTO(String id, String action) {
        super();
        this.id = id;
        this.action = action;
    }

}
