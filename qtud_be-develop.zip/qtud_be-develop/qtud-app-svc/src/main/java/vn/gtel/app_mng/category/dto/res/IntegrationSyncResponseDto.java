package vn.gtel.app_mng.category.dto.res;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.gtel.app_mng.category.model.Application;
import vn.gtel.app_mng.category.model.Organization;
import vn.gtel.app_mng.category.model.IntegrationSync;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.config.constant.StatusEnum;

import java.time.Instant;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
public class IntegrationSyncResponseDto {
    private String id;
    private Instant createDate;
    private String createdBy;
    private Instant lastModifiedDate;
    private String lastModifiedBy;
    private String orgCode;
    private String orgName;
    private Integer orgType;
    private String orgTypeName;
    private String appCode;
    private String appName;
    private Integer appType;
    private String appTypeName;
    private String purpose;
    private String description;
    private String relationName;
    private String relationPositionCode;
    private String relationPositionName;
    private String relationPoliceNumber;
    private String relationPhone;
    private String relationMilitaryCode;
    private String relationMilitaryName;
    private String relationDescription;
    private String representativeName;
    private String representativePositionCode;
    private String representativePositionName;
    private String representativePoliceNumber;
    private String representativePhone;
    private String representativeMilitaryCode;
    private String representativeMilitaryName;
    private String representativeDescription;
    private Integer status;
    private StatusEnum statusName;

    public IntegrationSyncResponseDto(IntegrationSync entity) {
        this.id = entity.getId();
        this.createDate = entity.getCreatedDate();
        this.createdBy = entity.getCreatedBy();
        this.lastModifiedBy = entity.getLastModifiedBy();
        this.lastModifiedDate = entity.getLastModifiedDate();
        Application application = entity.getApp();
        if (Objects.nonNull(application)) {
            this.appCode = application.getCode();
            this.appName = application.getName();
            this.appType = application.getType();
        }

        Organization organization = entity.getOrg();
        if (Objects.nonNull(organization)) {
            this.orgCode = organization.getCode();
            this.orgName = organization.getFullName();
            this.orgType = organization.getOrgType();
        } else {
            this.orgCode = entity.getOrgCode();
            this.orgName = entity.getOrgName();
        }

        this.relationName = entity.getRelationName();
        this.representativeName = entity.getRepresentativeName();
        this.purpose = entity.getPurpose();
        this.status = entity.getStatus();
        this.statusName = StatusEnum.parseByCode(this.status);

        if (Constants.APPLICATION_TYPE.IN.equals(this.appType)) {
            this.appTypeName = Constants.APPLICATION_TYPE_NAME.IN;
        } else if (Constants.APPLICATION_TYPE.OUT.equals(this.appType)) {
            this.appTypeName = Constants.APPLICATION_TYPE_NAME.OUT;
        }

        if (Constants.ORG_TYPE.IN_ONE.equals(this.orgType) || Constants.ORG_TYPE.IN_TWO.equals(this.orgType)) {
            this.orgTypeName = Constants.ORG_TYPE_NAME.IN;
            this.orgType = Constants.ORG_TYPE.IN_ONE;
        } else if (Constants.ORG_TYPE.OUT.equals(this.orgType)) {
            this.orgTypeName = Constants.ORG_TYPE_NAME.OUT;
            this.orgType = 2;
        }
    }
}