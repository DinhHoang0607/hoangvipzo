package vn.gtel.app_mng.category.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import vn.gtel.app_mng.common.model.AuditModel;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public class CategoryAuditModel  extends AuditModel {

    @Basic
    @Column(name = "MA_DANH_MUC")
    private String codeCategory;

    @Basic
    @Column(name = "ID_DANH_MUC")
    private String categoryId;

    @Basic
    @Column(name = "TEN_DANH_MUC")
    private String categoryName;

    @Basic
    @Column(name = "MA_LUU_TRU")
    private String codeResidence;

    @Basic
    @Column(name = "AP_DUNG_VOI")
    private String forWith;

    @Basic
    @Column(name = "PHAN_HE")
    private String subSystem;

    @Basic
    @Column(name = "TINH_TRANG")
    private String statusBusiness;

    @Basic
    @Column(name = "LA_DANH_MUC")
    private String isCategory;

    @Basic
    @Column(name = "MA_DM_AN_NINH")
    private String codeSecurity;

    @Basic
    @Column(name = "MA_DM_CANH_SAT")
    private String codePolice;

    @Basic
    @Column(name = "MA_DANH_MUC_CHUAN")
    private String codeStandard;

    @Basic
    @Column(name = "THU_TU")
    private Long order;

    @Basic
    @Column(name = "CHU_THICH")
    private String note;

    @Basic
    @Column(name = "MA_DANG_KY")
    private String codeRegister;
}
