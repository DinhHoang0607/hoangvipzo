package vn.gtel.app_mng.dashboard.dto.req;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.gtel.app_mng.common.dto.request.TextFilter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@AllArgsConstructor
public class FilterChart extends TextFilter implements Serializable {
    @NotNull
    @Min(value = 2000L)
    @Max(9999999999999L)
    private Long fromDateTime;
    @NotNull
    @Min(2000L)
    @Max(9999999999999L)
    private Long toDateTime;
    //    @NotEmpty
    @Pattern(regexp = "^(day|week|month|quarter|year)$")
    private String aggType;
    private String chartType;
    private String orgCode;
    private boolean orderWithName;

    public FilterChart(@NotNull @Min(value = 2000L) @Max(9999999999999L) Long fromDateTime, @NotNull @Min(2000L) @Max(9999999999999L) Long toDateTime, @Pattern(regexp = "^(day|week|month|quarter|year)$") String aggType, String chartType) {
        this.fromDateTime = fromDateTime;
        this.toDateTime = toDateTime;
        this.aggType = aggType;
        this.chartType = chartType;
    }

    public FilterChart(@NotNull @Min(value = 2000L) @Max(9999999999999L) Long fromDateTime, @NotNull @Min(2000L) @Max(9999999999999L) Long toDateTime, @Pattern(regexp = "^(day|week|month|quarter|year)$") String aggType, String chartType, boolean check, String orgCode) {
        this.fromDateTime = fromDateTime;
        this.toDateTime = toDateTime;
        this.aggType = aggType;
        this.chartType = chartType;
        this.orgCode = orgCode;
    }

    public FilterChart(Long fromTime, Long toTime, String aggType, String chartType, boolean orderWithName) {
        this.fromDateTime = fromTime;
        this.toDateTime = toTime;
        this.aggType = aggType;
        this.chartType = chartType;
        this.orderWithName = orderWithName;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
