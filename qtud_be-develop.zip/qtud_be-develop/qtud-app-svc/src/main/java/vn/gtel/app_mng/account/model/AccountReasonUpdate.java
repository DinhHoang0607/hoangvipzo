package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_TK_LY_DO_CAP_NHAT")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountReasonUpdate extends AuditModelBase {
	/**
	 * 
	 */
	private static final Long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;


	@Basic
	@Column(name = "TAI_KHOAN")
	private String account;

	@Basic
	@Column(name = "LY_DO")
	private String reason;

	@Basic
	@Column(name = "HANH_DONG")
	private Integer action;
}
