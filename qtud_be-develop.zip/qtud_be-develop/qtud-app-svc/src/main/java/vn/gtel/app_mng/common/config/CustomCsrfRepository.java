package vn.gtel.app_mng.common.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.DefaultCsrfToken;
import org.springframework.stereotype.Component;
import vn.gtel.app_mng.common.config.constant.CsrfConstants;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@Slf4j
public class CustomCsrfRepository implements CsrfTokenRepository {

    @Override
    public CsrfToken generateToken(HttpServletRequest request) {
        return new DefaultCsrfToken(CsrfConstants.CSRF_FIELD_HEADER, CsrfConstants.CSRF_FIELD_PARAM, CsrfConstants.CSRF_TOKEN);
    }

    @Override
    public void saveToken(CsrfToken token, HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public CsrfToken loadToken(HttpServletRequest request) {
        return new DefaultCsrfToken(CsrfConstants.CSRF_FIELD_HEADER , CsrfConstants.CSRF_FIELD_PARAM, CsrfConstants.CSRF_TOKEN);
    }

}
