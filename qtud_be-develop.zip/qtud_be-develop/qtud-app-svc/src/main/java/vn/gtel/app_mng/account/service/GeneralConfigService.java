package vn.gtel.app_mng.account.service;

import javassist.NotFoundException;
import org.springframework.http.ResponseEntity;
import vn.gtel.app_mng.account.dto.GeneralConfigDTO;
import vn.gtel.app_mng.account.dto.request.GeneralConfigRequest;
import vn.gtel.app_mng.account.filter.GeneralConfigFilterDTO;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import java.time.Instant;

public interface GeneralConfigService {
    ResponseBase insertOrUpdateGeneralConfig(GeneralConfigDTO generalConfigDTO) throws IllegalAccessException;

    ResponseBase deleteGeneralConfig(String id);

    ResponseBase listGeneralConfig(TextFilter textFilter) throws IllegalAccessException;

    ResponseBase list(GeneralConfigFilterDTO filter) throws IllegalAccessException;

    ResponseBase saveAll(GeneralConfigRequest request) throws IllegalAccessException;

    ResponseBase getPasswordRules() throws IllegalAccessException;

    String generatePasswordFilter();

    String generateRandomPassword();

    Instant generatePasswordExpirationDate(Instant startDate, Integer type);

    ResponseEntity getInstructionManual(Integer type) throws Exception;

    ResponseBase showInstructionManualList() throws Exception;

    ResponseBase getByKey(String key) throws NotFoundException;
}
