package vn.gtel.app_mng.category.dto.req;

import lombok.Data;

import java.time.Instant;
@Data
public class AuditOrganizationRequest {
    private Instant createdDate;
    private String createdBy;
    private Instant lastModifiedDate;
    private String lastModifiedBy;
    private Long status;
    private String description;
    private String code;
    private String name;
}
