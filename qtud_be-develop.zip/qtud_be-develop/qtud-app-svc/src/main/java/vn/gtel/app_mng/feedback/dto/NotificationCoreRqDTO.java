package vn.gtel.app_mng.feedback.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationCoreRqDTO {

    @NotEmpty(message = "error.common.validate.not.empty")
    private String title;
    @NotEmpty(message = "error.common.validate.not.empty")
    private String content;

}
