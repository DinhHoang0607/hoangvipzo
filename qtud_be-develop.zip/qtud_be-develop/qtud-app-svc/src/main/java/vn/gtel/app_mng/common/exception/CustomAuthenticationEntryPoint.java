/*
 * Copyright (c) 2021.
 * Project  :  sso
 * File  :  CustomAuthenticationEntryPoint.java
 * Created By :  tuannp
 * Created at :  12/21/21, 11:13 AM
 * LastModified  :  12/21/21, 11:13 AM
 */

package vn.gtel.app_mng.common.exception;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {
    @Override
    public void commence(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException, ServletException {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.map(httpServletResponse.getOutputStream(), new ResponseBase());
    }
}
