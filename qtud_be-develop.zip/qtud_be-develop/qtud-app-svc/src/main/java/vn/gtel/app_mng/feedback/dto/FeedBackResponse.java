package vn.gtel.app_mng.feedback.dto;

import lombok.Data;

import javax.persistence.Column;

@Data
public class FeedBackResponse {

    @Column(name = "ID")
    private String id;

    @Column(name = "MA")
    private String code;

    @Column(name = "TIEU_DE")
    private String title;

    @Column(name = "SO_DIEN_THOAI")
    private String phoneNumber;

    @Column(name = "NOI_DUNG")
    private String content;

    @Column(name = "PHAN_LOAI")
    private String classify;

    @Column(name = "HIEN_THI_PHAN_LOAI")
    private String displayClassify;

    @Column(name = "MUC_DO")
    private String level;

    @Column(name = "HIEN_THI_MUC_DO")
    private String displayLevel;

    @Column(name = "NGUOI_GUI")
    private String sender;

    @Column(name = "HIEN_THI_NGUOI_GUI")
    private String displaySender;

    @Column(name = "NGAY_TAO")
    private String createdDate;

    @Column(name = "NGAY_SUA")
    private String lastModifiedDate;

    @Column(name = "TRANG_THAI")
    private String status;

    @Column(name = "HIEN_THI_TRANG_THAI")
    private String displayStatus;

//    @Column(name = "KIEU_HANH_DONG_CHO_DA_XU_LY")
//    private String processedActionType;
//    @Column(name = "KIEU_HANH_DONG_CHO_CHO_XU_LY")
//    private String waitingProcessingActionType;
//    @Column(name = "DON_VI_XU_LY")
//    private String organizationProcess;
    @Column(name = "DON_VI_XU_LY")
    private String processingOrg;

    @Column(name = "HIEN_THI_DON_VI_XU_LY")
    private String displayProcessingOrg;
//    @Column(name = "V06")
//    private String actionV06;
    @Column(name = "DON_VI_NGUOI_GUI")
    private String senderOrg;

    @Column(name = "HIEN_THI_DON_VI_NGUOI_GUI")
    private String displaySenderOrg;
//    @Column(name = "HANH_DONG")
//    private Integer action;
}
