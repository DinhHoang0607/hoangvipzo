package vn.gtel.app_mng.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
import vn.gtel.app_mng.account.model.AccountServiceDetail;

import java.util.Optional;

@Repository
public interface AccountServiceDetailRepository extends JpaRepository<AccountServiceDetail, String>{

    AccountServiceDetail findByAccount(String account);

    Optional<AccountServiceDetail>  findByAccountAndName(String account, String name);
}
