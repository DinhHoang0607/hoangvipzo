package vn.gtel.app_mng.category.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.gtel.app_mng.category.model.ProfileType;

@Repository
public interface ProfileTypeRepo extends JpaRepository<ProfileType, String> {
    boolean existsByCodeAndStatus(String code, int status);
}
