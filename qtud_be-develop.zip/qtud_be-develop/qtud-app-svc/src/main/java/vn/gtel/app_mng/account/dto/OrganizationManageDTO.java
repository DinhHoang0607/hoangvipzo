package vn.gtel.app_mng.account.dto;

import lombok.Data;

import javax.persistence.Basic;
import javax.persistence.Column;

@Data
public class OrganizationManageDTO {
    @Basic
    @Column(name = "MA")
    private String organization;

    @Basic
    @Column(name = "TEN")
    private String name;
}
