package vn.gtel.app_mng.feedback.dto;

import lombok.Data;
import vn.gtel.app_mng.common.config.constant.Constants;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class ReceivedDTO {
    @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.validate.max.size.36")
    @NotEmpty(message = "error.common.validate.not.empty")
    private String id;
}
