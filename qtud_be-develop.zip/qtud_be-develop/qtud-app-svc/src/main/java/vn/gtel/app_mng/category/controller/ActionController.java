/**
 * @author tronglm
 * app-mng
 * Dec 6, 2021
 */
package vn.gtel.app_mng.category.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.IOException;
import java.security.InvalidParameterException;
import java.sql.SQLException;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.multipart.MultipartFile;
import vn.gtel.app_mng.category.dto.ActionCodeDTO;
import vn.gtel.app_mng.category.service.ActionService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.request.TextFilter;
import vn.gtel.app_mng.common.dto.response.ResponseBase;
import vn.gtel.app_mng.common.service.CommonService;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.io.IOException;

@Validated
@Tag(name = "Quản lý hành động")
@RestController
@CrossOrigin("*")
@RequestMapping(Constants.ACTION.URL)
public class ActionController {

    @Autowired
    private ActionService actionServiceImpl;

    @Operation(summary = "Thêm mới nút hành động")
    @PostMapping(value = "")
    public ResponseBase create(@RequestBody @Valid ActionCodeDTO req) throws Exception {
        return new ResponseBase(actionServiceImpl.createAction(req));
    }

    @Operation(summary = "Sửa hành động")
    @PutMapping(value = "")
    public ResponseBase update(@RequestBody @Valid ActionCodeDTO req) throws Exception {
        return new ResponseBase(actionServiceImpl.updateAction(req));
    }

    @Operation(summary = "Xóa hành động")
    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        actionServiceImpl.deleteAction(id);
        return new ResponseBase();
    }

    @Operation(summary = "Danh sách hành động")
    @GetMapping(value = "")
    public ResponseBase getList(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
                                @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "keySearch", required = false) String keySearch,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws InvalidParameterException, SQLException, IllegalAccessException {
        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.MAX_ROW_SELECT;
        }
        TextFilter textFilter = new TextFilter(page, size, keySearch);
        return new ResponseBase(actionServiceImpl.listAction(textFilter,Constants.ACCOUNT_STATUS.ACTIVE));
    }


    @Operation(summary = "Chi tiết hành động")
    @GetMapping(value = "/{id}")
    public ResponseBase detailAction(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                     @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return new ResponseBase(actionServiceImpl.detailAction(id));
    }

    @Operation(summary = "Tải template import hành động")
    @GetMapping(value = "/template")
    public ResponseEntity template() throws IOException {
        return CommonService.downloadTemplate("IMPORT_HANH_DONG_TEMPLATE.xlsx", "template_import_hanh_dong.xlsx");
    }

    @Operation(summary = "import hành động ")
    @PostMapping(value = "/import")
    public ResponseEntity importTemplate(MultipartFile file) throws Exception {
        return actionServiceImpl.importExcel(file);
    }

    @Operation(summary = "Kích hoạt, hủy kích hoạt")
    @PutMapping(value = "/{id}")
    public ResponseBase setActiveDeActive(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                          @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return actionServiceImpl.setActiveDeActive(id);
    }


    @Operation(summary = "tìm Kiếm sách hành động")
    @GetMapping(value = "/search")
    public ResponseBase getSearch(@Valid @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
                                @Pattern(regexp = Constants.Regex.NOT_SPECIAL_CHARACTERS, message = "error.common.validate.not.special-characters") @RequestParam(name = "keySearch", required = false) String keySearch,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "page") Integer page,
                                @Valid @Min(value = Constants.VALID.MIN_PAGE, message = "error.common.validate.min.value.0")
                                @Max(value = Constants.VALID.MAX_PAGE, message = "error.common.validate.max.value.99999999") @RequestParam(name = "size") Integer size) throws InvalidParameterException, SQLException, IllegalAccessException {
        if (page == null) {
            page = Constants.DEFAULT_PAGE;
        }
        if (size == null) {
            size = Constants.MAX_ROW_SELECT;
        }
        TextFilter textFilter = new TextFilter(page, size, keySearch);
        return new ResponseBase(actionServiceImpl.listAction(textFilter,null));
    }

    @Operation(summary = "import ứng dụng trả kết quả")
    @PostMapping(value = "/import-return-result")
    public ResponseEntity importReturnResultTemplate(MultipartFile file) throws Exception {
        return actionServiceImpl.importExcelReturnResult(file);
    }

}
