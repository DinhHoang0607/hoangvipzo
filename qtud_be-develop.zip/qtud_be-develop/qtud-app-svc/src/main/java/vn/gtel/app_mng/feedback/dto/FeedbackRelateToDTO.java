package vn.gtel.app_mng.feedback.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class FeedbackRelateToDTO {

    private String id;

    private String content;

    private String title;

    private String code;

}
