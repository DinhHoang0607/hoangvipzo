package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import vn.gtel.app_mng.common.model.AuditModelBase;

import javax.persistence.*;

@Entity
@Table(name = "TBL_TK_PHU_TRACH_DON_VI")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountForManageOrganization extends AuditModelBase {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "ID")
	private String id;

	@Basic
	@Column(name = "TAI_KHOAN")
	private String account;

	@Basic
	@Column(name = "MA_DON_VI_PHU_TRACH")
	private String organization;

}
