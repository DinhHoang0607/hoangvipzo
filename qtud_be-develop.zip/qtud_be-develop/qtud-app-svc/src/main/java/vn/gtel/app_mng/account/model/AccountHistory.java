package vn.gtel.app_mng.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import vn.gtel.app_mng.account.dto.AccountBasicInfoDTO;

import javax.persistence.*;
import java.time.Instant;

@NamedNativeQuery(
        name = "findBasicInfo",
        query = "SELECT tk.tai_khoan, tk.don_vi, nd.chuc_vu, nd.cap_bac, nd.chuc_danh \n" +
                "FROM tbl_tk_tai_khoan tk \n" +
                "LEFT JOIN tbl_tk_nguoi_dung nd ON nd.tai_khoan = tk.tai_khoan \n" +
                "LEFT JOIN tbl_dm_don_vi dv ON dv.ma = tk.don_vi \n" +
                "WHERE nd.phan_loai = 2 AND dv.trang_thai = 1 AND tk.xac_nhan_thong_tin = 2 \n" +
                "AND tk.tai_khoan = :account",
        resultSetMapping = "AccountBasicInfo"
)
@SqlResultSetMapping(
        name = "AccountBasicInfo",
        classes = @ConstructorResult(
                targetClass = AccountBasicInfoDTO.class,
                columns = {
                        @ColumnResult(name = "tai_khoan"),
                        @ColumnResult(name = "don_vi"),
                        @ColumnResult(name = "chuc_vu"),
                        @ColumnResult(name = "cap_bac"),
                        @ColumnResult(name = "chuc_danh")
                })
)

@Entity
@Table(name = "TBL_TK_LICH_SU")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountHistory {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "ID")
    private String id;

    @Basic
    @Column(name = "TAI_KHOAN")
    private String account;

    @Column(name = "THOI_GIAN_BAT_DAU")
    @CreatedDate
    private Instant startDate;

    @Column(name = "THOI_GIAN_KET_THUC")
    private Instant endDate;

    @Basic
    @Column(name = "DON_VI")
    private String organization;

    @Basic
    @Column(name = "CHUC_VU")
    private String position;

    @Basic
    @Column(name = "CAP_BAC")
    private String military;

    @Basic
    @Column(name = "CHUC_DANH")
    private String dignity;

    public AccountHistory(AccountBasicInfoDTO info) {
        this.account = info.getAccount();
        this.startDate = Instant.now();
        this.organization = info.getOrganization();
        this.position = info.getPosition();
        this.military = info.getMilitary();
        this.dignity = info.getDignity();
    }
}
