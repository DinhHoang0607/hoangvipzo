/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  AuditItemResponse.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  12/6/21, 2:27 PM
 */

package vn.gtel.app_mng.common.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.Column;
import java.time.Instant;

@Data
public class AuditItemResponse {

    @Column(name = "ID")
    private String id;

    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    @Column(name = "NGAY_TAO")
    private Instant createdDate;

    @Column(name = "NGUOI_TAO")
    private String createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, timezone = "UTC", pattern = "yyyy-MM-dd'T'HH:mm:ssZ")
    @Column(name = "NGAY_SUA")
    private Instant lastModifiedDate;

    @Column(name = "NGUOI_SUA")
    private String lastModifiedBy;

    @Column(name = "TRANG_THAI")
    private Long status;

    @Column(name = "TRANG_THAI_HIEN_THI")
    private String statusName;

}
