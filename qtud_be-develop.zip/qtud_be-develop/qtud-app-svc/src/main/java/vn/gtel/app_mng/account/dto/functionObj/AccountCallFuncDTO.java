/*
 * Copyright (c) 2021.
 * Project  :  app-mng
 * File  :  AccountCallFuncDTO.java
 * Created By :  tuannp
 * Created at :  $file.created
 * LastModified  :  1/12/22, 11:33 AM
 */

package vn.gtel.app_mng.account.dto.functionObj;

import vn.gtel.app_mng.common.dto.i.ICallFuncObj;

import java.util.HashMap;
import java.util.Map;

public class AccountCallFuncDTO extends ICallFuncObj {

    private static final String FUNC_CHECK_ADMIN = "CHECK_TK_QUAN_TRI";
    private static final String FUNC_CHECK_ADMIN_V06 = "CHECK_TK_QUAN_TRI_V06";
    private static final String FUNC_CHECK_ADMIN_RESPONSE = "QUYEN";

    private static final String IN_ACCOUNT = "TAI_KHOAN_NAME";
    private static final String IN_PI_ID = "TAI_KHOAN_ID";

    Map<String, Object> params = new HashMap<>();


    public AccountCallFuncDTO(String id, String account) {
        setFunctionName(FUNC_CHECK_ADMIN);
        setResponseName(FUNC_CHECK_ADMIN_RESPONSE);
        params.put(IN_PI_ID, id);
        params.put(IN_ACCOUNT, account);
        setParams(params);
    }

    public void checkAdminV06() {
        setFunctionName(FUNC_CHECK_ADMIN_V06);
    }


}
