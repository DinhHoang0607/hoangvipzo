 /*
  *
  * Copyright (c) 2024.
  * Project  :  app-mng
  * File  :  GroupAccountServiceImpl.java
  * Created By :  tuannp
  * Created at :  $file.created
  * LastModified  :  1/22/24, 1:44 PM
  *
  */
 package vn.gtel.app_mng.account.service.Impl;

 import com.aspose.cells.Workbook;
 import com.aspose.words.Document;
 import com.aspose.words.net.System.Data.DataTable;
 import com.google.gson.Gson;
 import lombok.AllArgsConstructor;
 import lombok.extern.slf4j.Slf4j;
 import org.apache.commons.lang3.StringUtils;
 import org.modelmapper.ModelMapper;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.data.domain.Page;
 import org.springframework.data.domain.PageRequest;
 import org.springframework.data.domain.Sort;
 import org.springframework.data.redis.core.RedisTemplate;
 import org.springframework.http.ResponseEntity;
 import org.springframework.stereotype.Service;
 import vn.gtel.app_mng.account.dto.AccountGroupDTO;
 import vn.gtel.app_mng.account.dto.CodeItemWithActionDTO;
 import vn.gtel.app_mng.account.dto.GroupCodeItemWithActionDTO;
 import vn.gtel.app_mng.account.dto.response.AccountGroupResDTO;
 import vn.gtel.app_mng.account.dto.response.AccountResDTO;
 import vn.gtel.app_mng.account.model.Account;
 import vn.gtel.app_mng.account.model.AccountEmployeeDetail;
 import vn.gtel.app_mng.account.model.AccountGroup;
 import vn.gtel.app_mng.account.model.AccountGroupAccount;
 import vn.gtel.app_mng.account.repository.AccountGroupAccountRepository;
 import vn.gtel.app_mng.account.repository.AccountGroupRepository;
 import vn.gtel.app_mng.account.service.GroupAccountService;
 import vn.gtel.app_mng.common.config.constant.Constants;
 import vn.gtel.app_mng.common.config.constant.Messages;
 import vn.gtel.app_mng.common.dto.AuditDTO;
 import vn.gtel.app_mng.common.dto.request.StatusTextFilter;
 import vn.gtel.app_mng.common.dto.request.TextFilter;
 import vn.gtel.app_mng.common.dto.response.DetailResponse;
 import vn.gtel.app_mng.common.dto.response.ListResponse;
 import vn.gtel.app_mng.common.dto.response.ResponseBase;
 import vn.gtel.app_mng.common.model.AuditModel;
 import vn.gtel.app_mng.common.model.AuditModelBase;
 import vn.gtel.app_mng.common.service.CommonService;
 import vn.gtel.app_mng.common.util.CommonUtils;
 import vn.gtel.app_mng.common.util.EncryptAndDecryptTheDatabaseUtil;
 import vn.gtel.app_mng.common.util.TrimSpaceUtil;
 import vn.gtel.app_mng.role.model.GroupRoleAccountGroup;
 import vn.gtel.app_mng.role.model.GroupRoleApplication;
 import vn.gtel.app_mng.role.repository.GroupRoleAccountGroupRepository;
 import vn.gtel.app_mng.role.repository.GroupRoleApplicationRepository;
 import vn.gtel.common.constants.ActionCode;
 import vn.gtel.common.dto.LogActionDTO;
 import vn.gtel.common.service.AsposeReportService;
 import vn.gtel.common.service.LoggingService;
 import vn.gtel.common.userinfo.AccountLogonContext;
 import vn.gtel.common.util.LogUtil;

 import javax.persistence.criteria.CriteriaBuilder;
 import javax.persistence.criteria.Predicate;
 import javax.persistence.criteria.Root;
 import javax.transaction.Transactional;
 import javax.xml.bind.ValidationException;
 import java.io.InputStream;
 import java.text.SimpleDateFormat;
 import java.time.Instant;
 import java.util.*;
 import java.util.concurrent.atomic.AtomicInteger;
 import java.util.stream.Collectors;
 import java.util.stream.Stream;

 @Slf4j
 @Service
 @AllArgsConstructor
 public class GroupAccountServiceImpl implements GroupAccountService {

     @Autowired
     private ModelMapper modelMapper;
     @Autowired
     private AccountGroupRepository accountGroupRepository;
     @Autowired
     private GroupRoleAccountGroupRepository groupRoleAccountGroupRepository;
     @Autowired
     private AccountGroupAccountRepository accountGroupAccountRepository;
     @Autowired
     private GroupRoleApplicationRepository groupRoleApplicationRepo;
     @Autowired
     private TrimSpaceUtil trimSpaceUtil;
     @Autowired
     private LoggingService loggingService;
     @Autowired
     private RedisTemplate redisTemplate;
     @Autowired
     private EncryptAndDecryptTheDatabaseUtil encryptAndDecryptTheDatabaseUtil;
     private final AsposeReportService asposeReportService;
     private final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");

     @Override
     @Transactional
     public ResponseBase save(AccountGroupDTO groupAccountRequestDTO) throws Exception {
         trimSpaceUtil.validate(groupAccountRequestDTO);
         String content = null;
         AccountGroup accountGroup;
         String action;
         String oldValue;
         if (StringUtils.isNotEmpty(groupAccountRequestDTO.getId())) {
             accountGroup = accountGroupRepository.findById(groupAccountRequestDTO.getId()).orElse(null);
             if (accountGroup == null) {
                 throw new ValidationException(Messages.getString("ResponseError.GroupAccount.IsNull"));
             }
             action = ActionCode.EDIT;
             oldValue = new Gson().toJson(accountGroup);
             content = String.format("Đã sửa nhóm người dùng có mã là : %s ,", accountGroup.getCode());
             String logMess = this.getDetailGroupAccount(content, groupAccountRequestDTO, accountGroup);
             accountGroup = modelMapper.map(groupAccountRequestDTO, AccountGroup.class);
             if (!logMess.equals(content)) {
                 loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.group,
                         action, logMess, Instant.now()));
             }
             accountGroupRepository.save(accountGroup);

         } else {
             action = ActionCode.ADD;
             oldValue = null;
             if (accountGroupRepository.existsByCode(groupAccountRequestDTO.getCode())) {
                 throw new ValidationException(Messages.getString("ResponseError.Common.Code.IsExist"));
             }
             accountGroup = modelMapper.map(groupAccountRequestDTO, AccountGroup.class);
             accountGroup.setStatus(Objects.requireNonNullElse(groupAccountRequestDTO.getStatus(), Constants.COMMON_STATUS.ACTIVE));
             accountGroupRepository.save(accountGroup);
             groupAccountRequestDTO.setId(accountGroup.getId());
         }
         saveAccountGroupRole(groupAccountRequestDTO);
         // Save log
         if (action.equals(ActionCode.ADD)) {
             content = String.format("Đã thêm mới nhóm người dùng có tên là %s và mã là %s", accountGroup.getName(), accountGroup.getCode());
         }
//         else if (action.equals(ActionCode.EDIT)) {
//             content = String.format("Đã sửa nhóm người dùng có tên là %s và mã là %s", accountGroup.getName(), accountGroup.getCode());
//         }

         if (!action.equals(ActionCode.EDIT)) {
             loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.group,
                     action, content, Instant.now()));
         }
//		String newValue = groupAccountRequestDTO.toString();
//		ActionLogDTO actionLog = new ActionLogDTO(Constants.MODULES.GROUP_ACCOUNT, action, oldValue, newValue);
//		actionLogService.saveActionLog(actionLog);
         for (CodeItemWithActionDTO codeItemWithActionDTO : groupAccountRequestDTO.getGroupRoles()) {
             GroupRoleApplication groupRoleApplication = groupRoleApplicationRepo.findByGroupRole(codeItemWithActionDTO.getCode());
             String appCode = "";
             if (groupRoleApplication != null && groupRoleApplication.getApplication() != null) {
                 appCode = groupRoleApplication.getApplication();
             }
             List<CodeItemWithActionDTO> accounts = groupAccountRequestDTO.getAccounts();
             if (accounts != null && accounts.size() > 0) {
                 for (CodeItemWithActionDTO entity : accounts) {
                     redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + appCode + "_" + entity.getCode());
                     redisTemplate.delete(Constants.REDIS_KEY.ROLE_APP + entity.getCode());
                 }
             }
         }
         return new ResponseBase(new DetailResponse(modelMapper.map(accountGroup, AccountGroupResDTO.class)));
     }

     private String getDetailGroupAccount(String logContent, AccountGroupDTO groupAccountRequestDTO, AccountGroup accountGroup) {
         if (groupAccountRequestDTO == null || accountGroup == null) {
             return null;
         }

         StringBuilder logMessage = new StringBuilder();
         logMessage.append(logContent);
         LogUtil.compareAndLog(logMessage, "[Tên nhóm] ", groupAccountRequestDTO.getName(), accountGroup.getName());
         LogUtil.compareAndLog(logMessage, "[Mô tả] ", groupAccountRequestDTO.getDescription(), accountGroup.getDescription());
         LogUtil.compareAndLog(logMessage, "[Trạng thái] ", groupAccountRequestDTO.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa", accountGroup.getStatus() == 1 ? "Hoạt động" : "Vô hiệu hóa");
         return logMessage.toString();
     }

     @Override
     public ResponseBase active(String id) throws Exception {
         AccountGroup accountGroup = accountGroupRepository.findById(id).orElse(null);
         if (accountGroup == null) {
             throw new ValidationException(Messages.getString("ResponseError.GroupAccount.IsNull"));
         }
         return changeStatus(accountGroup, Constants.COMMON_ACTION.ACTIVE);
     }

     @Override
     public ResponseBase delete(String id) throws Exception {
         return changeStatus(checkExist(id), Constants.COMMON_ACTION.DELETE);
     }

     private AccountGroup checkExist(String id) throws ValidationException {
         AccountGroup accountGroup = accountGroupRepository.findById(id).orElse(null);
         if (accountGroup == null) {
             throw new ValidationException(Messages.getString("ResponseError.GroupAccount.IsNull"));
         }
         if (accountGroupAccountRepository.existsAccountGroupAccountByGroupAccountAndStatusNot(accountGroup.getCode(), -1)) {
             throw new ValidationException(Messages.getString("ResponseError.GroupAccount.Exists.AccountGroupAccount"));
         }
         if (groupRoleAccountGroupRepository.existsGroupRoleAccountGroupByGroupAccountAndStatusNot(accountGroup.getCode(), -1)) {
             throw new ValidationException(Messages.getString("ResponseError.GroupAccount.Exists.GroupRoleAccountGroup"));
         }
         return accountGroup;
     }

     private ResponseBase changeStatus(AccountGroup accountGroup, int type) throws ValidationException {
//         AccountGroup accountGroup = accountGroupRepository.findById(id).orElse(null);
//         if (accountGroup == null) {
//             throw new ValidationException(Messages.getString("ResponseError.GroupAccount.IsNull"));
//         }
//         String oldValue = new Gson().toJson(accountGroup);
         accountGroup.setStatus(type == Constants.COMMON_ACTION.DELETE ? Constants.COMMON_STATUS.DELETED : CommonUtils.switchStatus(accountGroup.getStatus()));
         accountGroupRepository.save(accountGroup);

         String action = (type == Constants.COMMON_ACTION.DELETE) ? ActionCode.DEL : ActionCode.ACTIVE;
//		String newValue = new Gson().toJson(groupAccount);
//		ActionLogDTO actionLog = new ActionLogDTO(Constants.MODULES.GROUP_ACCOUNT, action, oldValue, newValue);
//		actionLogService.saveActionLog(actionLog);
         // Save log
         String content = String.format("%s nhóm người dùng mã %s và tên %s",
                 Constants.COMMON_STATUS.getNameByStatus(accountGroup.getStatus()), accountGroup.getCode(), accountGroup.getName());
         loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.group,
                 action, content, Instant.now()));
         return new ResponseBase(new DetailResponse(modelMapper.map(accountGroup, AccountGroupResDTO.class)));
     }

     @Override
     public ResponseBase list(StatusTextFilter statusTextFilter) throws Exception {
         trimSpaceUtil.validate(statusTextFilter);
         int pageIndex = Objects.requireNonNullElse(statusTextFilter.getPage(), Constants.DEFAULT_PAGE);
         int pageSize = Objects.requireNonNullElse(statusTextFilter.getSize(), Constants.DEFAULT_SIZE);

         PageRequest pageRequest = PageRequest.of(pageIndex, pageSize, Sort.by(Sort.Order.desc(AuditModelBase.Fields.lastModifiedDate)));
         String account = AccountLogonContext.getUsername();
         String organizationCode = AccountLogonContext.currentUser().getOrganization();
         if (statusTextFilter.isLogin()) {
             if (account.equals(Constants.ADMIN)) {
                 account = null;
                 organizationCode = null;
             }
         } else {
             account = null;
             organizationCode = null;
         }

         Page<AccountGroupResDTO> accountGroupPage = accountGroupRepository.findByKeySearch(statusTextFilter.getLikeKeySearch(), statusTextFilter.getStatus(), pageRequest, account, organizationCode);

//        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//        CriteriaQuery<AccountGroup> criteriaQuery = criteriaBuilder.createQuery(AccountGroup.class);
//        Root<AccountGroup> accountGroupRoot = criteriaQuery.from(AccountGroup.class);
//        criteriaQuery.select(criteriaBuilder.construct(AccountGroup.class, accountGroupRoot.get(AccountGroup.Fields.code)));
//        Predicate searchPredicate = buildSearchPredicate(criteriaBuilder, accountGroupRoot, statusTextFilter);
//        criteriaQuery.where(searchPredicate);
//        TypedQuery<AccountGroup> query = entityManager.createQuery(criteriaQuery);
//
//        int startPosition = pageIndex * pageSize;
//        query.setFirstResult(startPosition);
//        query.setMaxResults(pageSize);
//        List<AccountGroup> resultList = query.getResultList();
//
//        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
//        Root<AccountGroup> countRoot = countQuery.from(AccountGroup.class);
//        countQuery.select(criteriaBuilder.count(countRoot));
//        Predicate countPredicate = buildSearchPredicate(criteriaBuilder, countRoot, statusTextFilter);
//        countQuery.where(countPredicate);
//        TypedQuery<Long> countTypedQuery = entityManager.createQuery(countQuery);
//        Long totalCount = countTypedQuery.getSingleResult();
//
         ListResponse listResponse = new ListResponse(accountGroupPage.toList(), accountGroupPage.getTotalElements());
         return new ResponseBase(listResponse);
     }

     @Transactional
     public void saveAccountGroupRole(AccountGroupDTO groupAccountRequestDTO) {
         String groupCode = groupAccountRequestDTO.getCode();
         accountGroupAccountRepository.saveAll(mapAccountGroupAccount(groupAccountRequestDTO.getAccounts(), groupCode));
         groupRoleAccountGroupRepository.saveAll(mapGroupRoleAccountGroup(groupAccountRequestDTO.getGroupRoles(), groupCode));
     }

     @Override
     public ResponseBase detail(String id) throws Exception {
         AccountGroupResDTO accountGroupResDTO = accountGroupRepository.getDetail(id);
         List<AccountGroupAccount> accounts = accountGroupAccountRepository.findByGroupAccountAndStatus(accountGroupResDTO.getCode(), Constants.COMMON_STATUS.ACTIVE);
         List<GroupRoleAccountGroup> groupRoles = groupRoleAccountGroupRepository.findByGroupAccountAndStatus(accountGroupResDTO.getCode(), Constants.COMMON_STATUS.ACTIVE);
         accountGroupResDTO.setAccounts(accounts.stream().map(CodeItemWithActionDTO::new).collect(Collectors.toList()));
         accountGroupResDTO.setGroupRoles(groupRoles.stream().map(CodeItemWithActionDTO::new).collect(Collectors.toList()));
         return new ResponseBase(new DetailResponse(accountGroupResDTO));
     }

     // Skip update, delete not id
     private List<CodeItemWithActionDTO> skipItems(List<CodeItemWithActionDTO> codeItems) {
         return codeItems.stream().filter(e -> List.of(Constants.COMMON_ACTION.INSERT, Constants.COMMON_ACTION.DELETE).contains(e.getAction())
                 && !(e.getAction() == Constants.COMMON_ACTION.DELETE && StringUtils.isEmpty(e.getId()))).collect(Collectors.toList());
     }

     private List<CodeItemWithActionDTO> insertItems(List<CodeItemWithActionDTO> codeItems) {
         return codeItems.stream().filter(e -> Constants.COMMON_ACTION.INSERT == e.getAction()).collect(Collectors.toList());
     }

     private List<AccountGroupAccount> mapAccountGroupAccount(List<CodeItemWithActionDTO> codeItems, String groupCode) {
         // insert
         List<CodeItemWithActionDTO> insertList = insertItems(codeItems);
         List<AccountGroupAccount> accountGroupAccounts = accountGroupAccountRepository.findByGroupAccount(groupCode);
         // insert new / restore delete
         Stream<AccountGroupAccount> insertNewOrRestoreDelete = insertList.stream().map(e -> new AccountGroupAccount(accountGroupAccounts, new GroupCodeItemWithActionDTO(e, groupCode)));
         // merge delete + insert
         return Stream.concat(skipItems(codeItems).stream().filter(e -> e.getAction() == Constants.COMMON_ACTION.DELETE).map(e ->
                 new GroupCodeItemWithActionDTO().toDelAccountGroupAccount(e, groupCode)), insertNewOrRestoreDelete).collect(Collectors.toList());
     }

     private List<GroupRoleAccountGroup> mapGroupRoleAccountGroup(List<CodeItemWithActionDTO> codeItems, String groupCode) {
         // insert
         List<CodeItemWithActionDTO> insertList = insertItems(codeItems);
         List<GroupRoleAccountGroup> groupRoleAccountGroups = groupRoleAccountGroupRepository.findByGroupAccount(groupCode);
         // insert new / restore delete
         Stream<GroupRoleAccountGroup> insertNewOrRestoreDelete = insertList.stream().map(e -> new GroupRoleAccountGroup(groupRoleAccountGroups, new GroupCodeItemWithActionDTO(e, groupCode)));
         // merge delete + insert
         return Stream.concat(skipItems(codeItems).stream().filter(e -> e.getAction() == Constants.COMMON_ACTION.DELETE).map(e ->
                 new GroupCodeItemWithActionDTO().toDelGroupRoleAccountGroup(e, groupCode)), insertNewOrRestoreDelete).collect(Collectors.toList());
     }

     private Predicate buildSearchPredicate(CriteriaBuilder criteriaBuilder, Root<AccountGroup> categoryRoot, TextFilter textFilter) {
         Predicate predicate = criteriaBuilder.conjunction();
         if (StringUtils.isNotEmpty(textFilter.getKeySearch())) {
             String keySearch = textFilter.getLikeKeySearch();
             Predicate namePredicate = criteriaBuilder.like(categoryRoot.get(AuditDTO.Fields.name), keySearch);
             Predicate codePredicate = criteriaBuilder.like(categoryRoot.get(AuditDTO.Fields.code), keySearch);
             predicate = criteriaBuilder.or(namePredicate, codePredicate);
         } else {
             return predicate;
         }

//        predicate = criteriaBuilder.and(predicate, criteriaBuilder.notEqual(categoryRoot.get(AuditBaseDTO.Fields.status), Constants.COMMON_STATUS.DELETED));
         return predicate;
     }

     @Override
     public ResponseBase selectList(String id, String type, String status, TextFilter textFilter) {
         AccountGroupResDTO accountGroupResDTO = new AccountGroupResDTO();
         String groupCode;
         if (StringUtils.isEmpty(id)) {
             groupCode = null;
         } else {
             accountGroupResDTO = accountGroupRepository.getDetail(id);
             groupCode = accountGroupResDTO.getCode();
         }

         boolean inGroup = Constants.LIST_TYPE.STATUS_IN.equals(status);
         PageRequest pageRequest = PageRequest.of(textFilter.getPage(), textFilter.getSize(), Sort.by(Sort.Order.desc(inGroup ? AuditModelBase.Fields.createdDate : AuditModel.Fields.name)));
         ListResponse listResponse = null;
         String account = AccountLogonContext.getUsername();
         String org = AccountLogonContext.currentUser().getOrganization();
         if (account.equals(Constants.ADMIN)) {
             account = null;
             org = null;
         }
         switch (type) {
             case Constants.LIST_TYPE.ACCOUNT:
                 if (!inGroup)
                     pageRequest = pageRequest.withSort(Sort.by(Sort.Order.asc(AccountEmployeeDetail.Fields.fullName)));
                 listResponse = mapFromAccountGroupAccount(inGroup ? accountGroupAccountRepository.findByGroupAccountAndStatusPaging(groupCode, textFilter.getLikeKeySearch(), pageRequest)
                         : accountGroupAccountRepository.findByGroupAccountAndStatusNotInPaging(groupCode, textFilter.getLikeKeySearch(), pageRequest, org, account));
                 break;
             case Constants.LIST_TYPE.GROUP_ROLE:
                 pageRequest = pageRequest.withSort(Sort.by(Sort.Order.asc(AuditModel.Fields.name)));
//                 listResponse = mapFromGroupRoleAccountGroup(inGroup ? groupRoleAccountGroupRepository.findByGroupAccountAndStatusPaging(groupCode, textFilter.getLikeKeySearch(), pageRequest) :
//                         groupRoleAccountGroupRepository.findByGroupAccountAndStatusNotInPaging(groupCode, textFilter.getLikeKeySearch(), pageRequest,account)
//                 );
//                 listResponse = null;
                 if (inGroup) {
                     listResponse = mapFromGroupRoleAccountGroup(groupRoleAccountGroupRepository.findByGroupAccountAndStatusPaging(groupCode, textFilter.getLikeKeySearch(), pageRequest));
                 } else {
                     if (account == null) {
                         listResponse = mapFromGroupRoleAccountGroup(groupRoleAccountGroupRepository.findByGroupAccountAndStatusNotInPagingAdmin(groupCode, textFilter.getLikeKeySearch(), pageRequest));
                     } else {
                         listResponse = mapFromGroupRoleAccountGroup(groupRoleAccountGroupRepository.findByGroupAccountAndStatusNotInPaging(groupCode, textFilter.getLikeKeySearch(), pageRequest, account));
                     }
                 }
                 break;
             default:
                 listResponse = new ListResponse();
         }
         return new ResponseBase(listResponse);
     }

     private ListResponse mapFromAccountGroupAccount(Page<AccountResDTO> items) {
         if (items.getContent() != null && items.getContent().size() > 0) {
             items.getContent().stream().map(e -> {
                 if (e.getPoliceNumber() != null) {
                     e.setPoliceNumber(encryptAndDecryptTheDatabaseUtil.decrypt(e.getPoliceNumber()));
                 }
                 return e;
             }).collect(Collectors.toList());
         }
         return new ListResponse(items.getContent(), items.getTotalElements());
     }

     private ListResponse mapFromGroupRoleAccountGroup(Page<CodeItemWithActionDTO> items) {
         return new ListResponse(items.getContent(), items.getTotalElements());
     }

     @Override
     public ResponseEntity export(Integer status, String keySearch, String type) throws Exception {
         Map<String, Object> dataMap = new HashMap<>(0);
         int pageIndex = Constants.DEFAULT_PAGE;
         int pageSize = Constants.MAX_ROW_SELECT;

         PageRequest pageRequest = PageRequest.of(pageIndex, pageSize, Sort.by(Sort.Order.asc(AccountGroup.Fields.code)));
         String account = AccountLogonContext.getUsername();
         String organizationCode = AccountLogonContext.currentUser().getOrganization();
         if (account.equals(Constants.ADMIN)) {
             account = null;
             organizationCode = null;
         }
         Page<AccountGroupResDTO> accountGroupPage = accountGroupRepository.findByKeySearch(CommonUtils.toUpperCase(CommonUtils.likeString(keySearch)), status, pageRequest, account, organizationCode);
         if (accountGroupPage.isEmpty()) return ResponseEntity.noContent().build();
         DataTable dataTable = new DataTable("lst");

         dataTable.getColumns().add("stt");
         dataTable.getColumns().add(AccountGroupResDTO.Fields.code);
         dataTable.getColumns().add(AccountGroupResDTO.Fields.name);
         dataTable.getColumns().add(AccountGroupResDTO.Fields.description);
         dataTable.getColumns().add(AccountGroupResDTO.Fields.statusName);
         AtomicInteger stt = new AtomicInteger();
         for (AccountGroupResDTO e : accountGroupPage.getContent()) {
             Object[] objs = {stt.incrementAndGet(), e.getCode(), e.getName(), e.getDescription(), e.getStatusName()};
             dataTable.getRows().add(objs);
         }

         dataMap.put("date", simpleDateFormat.format(new Date()));
         String fileOutPut = "Danh_sach_nhom_tai_khoan";
         if (Constants.EXPORT_TYPE.PDF.toString().toLowerCase().equals(type)) {
             String fileInput = "Danh_sach_nhom_tai_khoan.docx";
             try {
                 InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/docx/account_group/" + fileInput);
                 Document doc = new Document(is);
                 return asposeReportService.generateDataReport(doc, Constants.EXPORT_TYPE.PDF.toString().toLowerCase(), dataMap, false, List.of(dataTable), fileOutPut, fileInput);
             } catch (Exception e) {
                 log.error("Extract dk1 fail : " + e.getCause());
             }
         } else {
             String fileInput = "Danh_sach_nhom_tai_khoan.xlsx";
             InputStream is = CommonService.class.getClassLoader().getResourceAsStream("template/excel/account_group/" + fileInput);
             Workbook workbook = new Workbook(is);
             return asposeReportService.generateExcel(workbook, dataMap, dataTable, fileOutPut, null);
         }
         // Save log
         loggingService.successLog(new LogActionDTO(Constants.APPLICATION_CODE.QTUD, Constants.MENU_CODE.ACCOUNT.group,
                 ActionCode.EXPORT, null, Instant.now()));
         return ResponseEntity.noContent().build();
     }

     @Override
     public ResponseBase newCode() {
         AccountGroup maxCodeAccountGroup = accountGroupRepository.findFirstByOrderByCodeDesc();
         if (maxCodeAccountGroup == null) return new ResponseBase("001");
         return new ResponseBase(CommonUtils.nextCode(maxCodeAccountGroup.getCode()));
     }
 }
