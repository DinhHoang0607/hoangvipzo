package vn.gtel.app_mng.category.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.gtel.app_mng.category.dto.req.IntegrationSyncFilter;
import vn.gtel.app_mng.category.dto.req.IntegrationSyncRequestDto;
import vn.gtel.app_mng.category.dto.req.OrgGroupRoleRequestDto;
import vn.gtel.app_mng.category.service.IntegrationSyncService;
import vn.gtel.app_mng.common.config.constant.Constants;
import vn.gtel.app_mng.common.dto.response.ResponseBase;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/integration-sync-org")
public class IntegrationSyncController {

    private final IntegrationSyncService service;

    @GetMapping(value = "/list")
    public ResponseBase list(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "application", required = false) String application,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,
            @RequestParam(name = "orgName", required = false) String orgName,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "applicationType", required = false) Integer applicationType,
            @RequestParam(name = "organizationType", required = false) Integer organizationType,
            @RequestParam(name = "fromDate", required = false) Instant fromDate,
            @RequestParam(name = "toDate", required = false) Instant toDate,
            @RequestParam(name = "size", required = false) Optional<Integer> size
    ) {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        Integer status = Constants.COMMON_STATUS.ACTIVE;
        IntegrationSyncFilter commonFilter = new IntegrationSyncFilter(pageNumber, sizeNumber, keySearch, application, organization, orgName, status, applicationType, organizationType, fromDate, toDate);
        return service.search(commonFilter);
    }

    @GetMapping(value = "")
    public ResponseBase search(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "application", required = false) String application,
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_18, message = "error.common.validate.max.size.18")
            @RequestParam(name = "organization", required = false) String organization,
            @RequestParam(name = "orgName", required = false) String orgName,
            @RequestParam(name = "status", required = false) Integer status,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size,
            @RequestParam(name = "notCodeList", required = false) List<String> notCodeList,
            @RequestParam(name = "applicationType", required = false) Integer applicationType,
            @RequestParam(name = "organizationType", required = false) Integer organizationType,
            @RequestParam(name = "fromDate", required = false) Instant fromDate,
            @RequestParam(name = "toDate", required = false) Instant toDate,
            @RequestParam(name = "inCodeList", required = false) List<String> inCodeList
    ) {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        IntegrationSyncFilter commonFilter = new IntegrationSyncFilter(pageNumber, sizeNumber, keySearch, application,
                organization, orgName, status, notCodeList, inCodeList, applicationType, organizationType, fromDate, toDate);
        return service.search(commonFilter);
    }

    @GetMapping(value = "/org-unused")
    public List<String> orgUnused(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size
    ) {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        return service.getOrgUnused();
    }

    @GetMapping(value = "/app-unused")
    public ResponseBase appUnused(
            @Valid
            @Size(max = Constants.VALID.MAX_LENGTH_KEY_SEARCH, message = "error.common.validate.max.size.250")
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size
    ) {
        int pageNumber = page.orElse(Constants.DEFAULT_PAGE);
        int sizeNumber = size.orElse(Constants.MAX_ROW_SELECT);
        return service.getAppUnused(keySearch, pageNumber, sizeNumber);
    }

    @GetMapping(value = "/has-exists")
    public ResponseBase hasExists(
            @RequestParam(name = "org", required = false) String org,
            @RequestParam(name = "app", required = false) String app
    ) {
        return service.hasExists(org, app);
    }

    @GetMapping(value = "/{id}")
    public ResponseBase detail(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return service.detail(id);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseBase delete(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                               @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36") @PathVariable String id) throws Exception {
        return service.delete(id);

    }

    @PostMapping(value = "")
    public ResponseBase create(@RequestBody @Valid IntegrationSyncRequestDto request) throws Exception {
        return service.save(request);
    }

    @PutMapping(value = "")
    public ResponseBase update(@RequestBody @Valid IntegrationSyncRequestDto request) throws Exception {
        return service.save(request);
    }

    @PutMapping(value = "/{id}")
    public ResponseBase setActiveDeActive(@Valid @NotEmpty(message = "error.common.validate.not.empty")
                                          @Size(max = Constants.VALID.MAX_LENGTH_ID, message = "error.common.size.max.36")
                                          @PathVariable String id) throws Exception {
        return service.activeInActive(id);
    }

    @PatchMapping(value = "/{id}")
    public ResponseBase saveRole(@RequestBody @Valid OrgGroupRoleRequestDto request, @PathVariable String id) throws Exception {
        return service.saveRole(id, request);
    }

    @GetMapping(value = "/get-list-integrated-org")
    public ResponseBase getListOrgCode() throws Exception {
        return service.getListOrgCode();
    }

    @GetMapping(value = "/get-application-by-org/{organization}")
    public ResponseBase getApplicationByOrganization(@PathVariable String organization) {
        return service.getApplicationByOrganization(organization);
    }
}
