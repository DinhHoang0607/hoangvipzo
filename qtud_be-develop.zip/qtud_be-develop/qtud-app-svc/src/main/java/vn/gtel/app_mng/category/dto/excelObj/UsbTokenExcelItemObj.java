package vn.gtel.app_mng.category.dto.excelObj;

import lombok.Data;
import vn.gtel.app_mng.common.dto.i.IExcelItem;

@Data
public class UsbTokenExcelItemObj extends IExcelItem {
    private String cmmdDatePlace;
    private String address;
    private String areaAdministrative;
    private String code;
    private String sim;
    private String accountCode;
}
