package vn.gtel.app_mng.account.reponse;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class StringAndIntegerResponse {
    private String message;
    private Integer total;

    public StringAndIntegerResponse (String message, Integer total) {
        this.message = message;
        this.total = total;
    }
}
